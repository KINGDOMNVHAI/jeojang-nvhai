"use client";

import Link from "next/link";
import { useSearchParams } from 'next/navigation';
import useTrans from '../../app/hook/useTrans';
import PaginationControls from "@/components/YoutubeRanking/PaginationControls";

import { HiSearch, HiPlay, HiLink } from "react-icons/hi";
import { FaTwitter } from "react-icons/fa";

export default function ChannelList() {

    const trans = useTrans();
    console.log("trans " + trans)
    const searchParams = useSearchParams();

    const listChannel = [
        {
            name: 'KINGDOM NVHAI',
            subcribe: 3190,
            thumbnail: 'img/channel/500x500/kingdom-nvhai-channel-thumbnail.jpg',
            created_date: '2015-06-28',
            facebook: '',
            twitter: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            youtube: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            video_present: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
        },
        {
            name: 'GTCoding',
            subcribe: 35100,
            thumbnail: 'img/channel/500x500/gtcoding-channel-thumbnail.jpg',
            created_date: '2015-06-13',
            facebook: '',
            twitter: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            youtube: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            video_present: undefined,
        },
        {
            name: 'freeCodeCamp.org',
            subcribe: 8330000,
            thumbnail: 'img/channel/500x500/freecodecamp-channel-thumbnail.jpg',
            created_date: '2014-12-17',
            facebook: null,
            twitter: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            youtube: 'https://www.youtube.com/watch?v=PEMfsqZ2-As',
            video_present: null,
        },
        {
            name: 'MUSE VN',
            subcribe: 3190,
            thumbnail: 'img/channel/500x500/musevn-channel-thumbnail.jpg',
            created_date: '2015-06-28',
            facebook: null,
            twitter: null,
            youtube: null,
            video_present: null,
        },
        {
            name: 'Programming With Mosh',
            subcribe: 35100,
            thumbnail: 'img/channel/500x500/programming-with-mosh-channel-thumbnail.jpg',
            created_date: '2015-06-13',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: undefined,
        },
        {
            name: 'ANN NEWS',
            subcribe: 3360000,
            thumbnail: 'img/channel/500x500/ann-news-channel-thumbnail.jpg',
            created_date: '2009-09-10',
            facebook: null,
            twitter: null,
            youtube: null,
            video_present: null,
        },
        {
            name: 'SBS',
            subcribe: 3750000,
            thumbnail: 'img/channel/500x500/sbs-channel-thumbnail.jpg',
            created_date: '2015-06-13',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: undefined,
        },
        {
            name: 'Vexsper',
            subcribe: 165000,
            thumbnail: 'img/channel/500x500/vexsper-channel-thumbnail.jpg',
            created_date: '2015-06-13',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: undefined,
        },
        {
            name: 'Pewdiepie',
            subcribe: 2000000000,
            thumbnail: 'img/channel/500x500/pewdiepie-channel-thumbnail.jpg',
            created_date: '2015-06-28',
            facebook: null,
            twitter: null,
            youtube: null,
            video_present: 'https://youtu.be/PHgc8Q6qTjc',
        },
        {
            name: 'A.I Channel',
            subcribe: 10000000,
            thumbnail: 'img/channel/500x500/kizuna-ai-channel-thumbnail.jpg',
            created_date: '2015-06-13',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: 'https://youtu.be/RvB-kv9q7Pk',
        },
        {
            name: '壱百満天原サロメ / Hyakumantenbara Salome',
            subcribe: 500000,
            thumbnail: 'img/channel/500x500/hyakumantenbara-salome-channel-thumbnail.jpg',
            created_date: '2022-05-18',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: 'https://youtu.be/AniQdstq4KM',
        },
        {
            name: '天野ピカミィ. Pikamee',
            subcribe: 690000,
            thumbnail: 'img/channel/500x500/pikamee-channel-thumbnail.jpg',
            created_date: '2020-03-12',
            facebook: null,
            twitter: null,
            youtube: null,
            video_present: 'https://youtu.be/w_ejnHxTWrU',
        },
        {
            name: 'Nanashi Mumei Ch. hololive-EN',
            subcribe: 1000000,
            thumbnail: 'img/channel/500x500/mumei-channel-thumbnail.jpg',
            created_date: '2021-07-26',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: 'https://youtu.be/M2gwJ-7s0Zo',
        },
        {
            name: 'Tsukumo Sana Ch. hololive-EN',
            subcribe: 500000,
            thumbnail: 'img/channel/500x500/sana-channel-thumbnail.jpg',
            created_date: '2021-07-26',
            facebook: undefined,
            twitter: undefined,
            youtube: undefined,
            video_present: 'https://youtu.be/3Tv5GyebhQo',
        },
    ];

    const totalResult = listChannel.length;

    const page = searchParams.get('page') ?? "1"; // default value is "1"
    // if (Number(page) < 1) page = 1;

    const per_page = searchParams.get('per_page') ?? '3';
    // if (Number(per_page) < 1) per_page = 3;

    // mocked, skipped and limited in the real app
    const startData = (Number(page) - 1) * Number(per_page);
    const endData = startData + Number(per_page);
    const data = listChannel.slice(startData,endData);

    const SocialURL = ({icon, url}) => {
        return url ? (
            <Link className="font-bold text-lg text-blue-700" target="_blank" href={url}>{icon}</Link>
        ) : (
            ''
        )
    }

    const VideoPresent = ({url}) => {
        return url ? (
            <Link className="btn d-block w-100 d-sm-inline-block btn-light" target="_blank" href={url}>Watch Video</Link>
        ) : (
            ''
        )
    }

    const ConditionalPagination = () => {
        return Number(totalResult) > Number(per_page) ? (
            <PaginationControls
                page={page}
                per_page={per_page}
                totalResult={totalResult}
                hasNextPage={endData < listChannel.length}
                hasPervPage={startData > 0}
            />
        ) : (
            ''
        )
    }

    return (
        <div className="event-schedule-area-two bg-color pad100">
            <div className="container">
                <div className="row my-5">
                    <div className="col-lg-10 mx-auto mb-4">
                        <div className="section-title text-center">
                            <h3 className="top-c-sep">{ trans.home.title }</h3>
                            <p>Lorem ipsum dolor sit detudzdae amet, rcquisc adipiscing elit. Aenean socada commodo
                                ligaui egets dolor. Nullam quis ante tiam sit ame orci eget erovtiu faucid.</p>
                        </div>
                    </div>
                </div>

                <div className="row">
                    <div className="col-lg-10 mx-auto">
                        <div className="career-search mb-20">
                            <form action="#" className="career-form mb-20">
                                <div className="row">
                                    <div className="col-md-6 col-lg-3 my-3">
                                        <div className="input-group position-relative">
                                            <input
                                                id="keywords"
                                                type="text"
                                                className="form-control"
                                                placeholder="Enter Your Keywords"
                                            />
                                        </div>
                                    </div>
                                    <div className="col-md-6 col-lg-3 my-3">
                                        <div className="select-container">
                                            <select className="custom-select">
                                                <option defaultValue="">Subcribe Filter</option>
                                                <option value="asc">Increase</option>
                                                <option value="desc">Decrease</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col-md-6 col-lg-3 my-3">
                                        <div className="select-container">
                                            <select className="custom-select">
                                                <option defaultValue="">Select YouTube Content</option>
                                                <option value="vtuber">VTuber</option>
                                                <option value="development">Development</option>
                                                <option value="cosplay">Cosplay</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div className="col-md-6 col-lg-3 my-3">
                                        <button type="button" className="btn btn-lg btn-block btn-light btn-custom" id="contact-submit">
                                            <HiSearch size={24}/>
                                        </button>
                                    </div>
                                </div>
                            </form>

                            <div className="filter-result">
                                <p className="mb-30 ff-montserrat">Total Job Openings : 89</p>

                                {data.map((item) => (
                                    <div className="job-box d-md-flex align-items-center justify-content-between mb-30">
                                        <div className="job-left my-4 d-md-flex align-items-center flex-wrap">
                                            <div className="col-md-2 text-center">
                                                <img src={item.thumbnail} width="100" alt={item.name} />
                                            </div>
                                            <div className="col-md-8">
                                                <h5 className="text-md-left">{item.name}</h5>
                                                <p className="d-md-flex">
                                                    Created date: {item.created_date}<br/>
                                                    Subcribe: {item.subcribe}
                                                </p>
                                                <p>Lorem ipsum dolor sit detudzdae amet, rcquisc adipiscing elit. Aenean socada commodo
                                                    ligaui egets dolor. Nullam quis ante tiam sit ame orci eget erovtiu faucid.</p>

                                                <p className="d-md-flex">
                                                    <SocialURL icon={<FaTwitter size={24}/>} url={item.twitter}></SocialURL>{'\u00A0'}{'\u00A0'}
                                                    <SocialURL icon={<HiPlay size={24}/>} url={item.youtube}></SocialURL>{'\u00A0'}{'\u00A0'}
                                                    <SocialURL icon={<HiLink size={24}/>} url={item.youtube}></SocialURL>
                                                </p>
                                            </div>
                                        </div>
                                        <div className="job-right my-4 flex-shrink-0">
                                            <VideoPresent url={item.video_present}></VideoPresent>
                                        </div>
                                    </div>
                                ))}

                            </div>
                        </div>

                        <ConditionalPagination />
                    </div>
                </div>
            </div>
        </div>
    );
}
