"use client";

import { usePathname, useRouter } from 'next/navigation'
import Link from "next/link";
import { signIn, signOut, useSession } from "next-auth/react";
import useTrans from '../app/hook/useTrans';

export default function Navbar() {
    const { status } = useSession();
    const trans = useTrans()
    const router = useRouter()

    const changeLang = (lang) => {
        console.log("lang")
        console.log(lang)
        router.push('/', '/', { locale: lang })
    }

    return (
        <div className="p-4 flex justify-between items-center shadow-md">
            <Link className="font-bold text-lg text-blue-700" href={"/"}>KAWAII CODE</Link>

            <select className="custom-select" onChange={(e) => changeLang(e.currentTarget.value)}>
                <option defaultValue value="en">English</option>
                <option value="vi">Vietnam</option>
                <option value="kr">Korea</option>
            </select>
        </div>
    );
}

{/* <option value="jp">Japan</option> */}
