import EditTopicForm from "@/components/EditTopicForm"

export default function EditTopic() {
    return (
        <div className="">
            <EditTopicForm />
        </div>
    );
}