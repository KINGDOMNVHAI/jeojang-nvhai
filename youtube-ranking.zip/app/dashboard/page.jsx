import Link from 'next/link';
import UserInfo from "@/components/UserInfo";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "../api/auth/[...nextauth]/route";

export default async function Dashboard() {
  const session = await getServerSession(authOptions);

  if (session == null || session == undefined) redirect("/");

  return <UserInfo />;
}

// const session = await getServerSession(authOptions);
// console.log("session");
// console.log(session.user);
// console.log(authOptions);
// if (!session == null) redirect("/");
