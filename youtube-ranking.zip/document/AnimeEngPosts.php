<?php
namespace App\Seeder\postsSeeder;

use App\Models\posts;
use App\Seeder\postsSeeder\GameEngPosts;
use DB;
use Illuminate\Support\ServiceProvider;

class AnimeEngPosts
{
    public function index()
    {
        posts::where('url_post', 'kadokawa-registers-re-zero-anime-domain-name')->update([
            'name_en_post'    => "Kadokawa Registers 're-zero-anime.jp' Domain Name",
            'present_en_post' => "Domain name for series light novel",
            'content_en_post' => '<p>The Internet domain name re-zero-anime.jp was registered on behalf of Kadokawa Corporation on July 8. There is currently no website at this domain address.</p>

<p>Official Website: <a href="http://re-zero-anime.jp/" rel="nofollow" target="_blank" title="Re:Zero Anime">Re:Zero Anime</a></p>

<center><img src="/upload/images/anime/re-zero-kara-hajimeru-isekai-seikatsu-light-novel-vol1.jpg" width="70%" alt="Kadokawa đăng ký tên miền re-zero-anime.jp" /></center>

<p>Re: Zero Kara Hajimeru Isekai Seikatsu (Re: Life in a different world from zero) is a light novel series written by Tappei Nagatsuki, illustrated by Shinichirou Otsuka,
and published by Kadokawa&apos;s MF Bunko J imprint. The sixth volume shipped on March 25 in Japan.</p>

<p>In the story, Subaru Natsuki is an ordinary high school student who is lost in an alternate world, where he is rescued by a beautiful, silver-haired girl. He stays near her to return the favor, but the destiny she is burdened with is more than Subaru can imagine. Enemies attack one by one, and both of them are killed. He then finds out he has the power to rewind death, back to the time he first came to this world. But only he remembers what has happened since.</p>

<center><img src="/upload/images/anime/re-zero-kara-hajimeru-isekai-seikatsu-light-novel-vol1-2.jpg" width="100%" alt="Kadokawa đăng ký tên miền re-zero-anime.jp" /></center>

<p>The series has inspired two manga adaptations. Kadokawa published Daichi Matsue&apos;s manga Re: Zero Kara Hajimeru Isekai Seikatsu Dai-Ichi-Shō: Ōto no Ichinichi-hen (Chapter 1: Day at the King&apos;s Capital Edition) in Monthly Comic Alive and shipped the second and final compiled volume on March 23.
Square Enix publishes Makoto Fugetsu&apos;s manga Re: Zero Kara Hajimeru Isekai Seikatsu Dai-Ni-Shou: Yashiki no Ishuukan-hen (Chapter 2: Week at a Mansion Edition) in Big Gangan.
The first compiled volume shipped on March 23.</p>

<p>Source: <a href="http://www.animenewsnetwork.com/daily-briefs/2015-07-13/kadokawa-registers-re-zero-anime.jp-domain-name/.90391" rel="nofollow" target="_blank" title="Kadokawa Re:Zero">Anime News Network</a></p>
']);

        posts::where('url_post', '36th-doraemon-the-movie-nobita-and-the-birth-of-japan-2016-film')->update([
            'name_en_post'    => "36th Doraemon the Movie: Nobita and the Birth of Japan 2016 Film's 1st Trailer Previews Story",
            'present_en_post' => "Trailer released on July 24",
            'content_en_post' => '<p>The official website for the 36th Doraemon film, 36th Doraemon the Movie: Nobita and the Birth of Japan 2016 (Eiga Doraemon Shin Nobita no Nihon Tanjō), began streaming the film&apos;s first trailer on July 24.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/AFEHyyeR_8Q" title="Doraemon the Movie Nobita and the Birth of Japan" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer Doraemon the Movie: Nobita and the Birth of Japan 2016</p></center>

<center><img src="/upload/images/anime/Doraemon-the-Movie-Nobita-and-the-Birth-of-Japan-2016.jpg" width="100%" alt="Doraemon the Movie Nobita and the Birth of Japan" /></center>

<p>The previous film in the franchise, Doraemon: Nobita no Space Heroes, opened on March 7. The first 3DCG film in the franchise, Stand By Me Doraemon, opened in Japan in August 2014 before opening in 21 other countries and territories.</p>

<p>Source: <a href="http://www.animenewsnetwork.com/news/2015-07-26/36th-doraemon-the-movie-nobita-and-the-birth-of-japan-2016-film-1st-trailer-previews-story/.90890" rel="nofollow" target="_blank" title="Doraemon the Movie Nobita and the Birth of Japan">Anime News Network</a></p>
']);

        posts::where('url_post', '7-eleven-japan-stop-selling-hentai-by-8-2019')->update([
            'name_en_post'    => "7-Eleven stop selling hentai in Japan by August, 2019",
            'present_en_post' => "This decisions for women, children and foreigners",
            'content_en_post' => '<p>By the end of August, 2019, 15,000 out of 20,000 7-Eleven shops in Japan will stop selling hentai magazines and adult comics on their store shelves due to women, children, and foreigners.</p>

<p>The news comes courtesy of Asashi Shimbun Digital, which published an article on January 21st, 2019, stating...</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/QXbqJ9xPwvg" title="7-Eleven stop selling hentai" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>The news comes courtesy of Asashi Shimbun Digital.</p></center>

<blockquote>
<p>Convenience store Seven-Eleven Japan and Lawson announced on the 21st that the domestic sale of adult magazines within the store will evidently be discontinued by the end of August.</p>

<p>This is being done in consideration of customers who are women, children, and foreign visitors.</p>

<p>Selling adult magazines will likely vanish altogether from Japan&apos;s convenience stores and over-the-counter shops.</p>
</blockquote>

<p>Source: <a href="https://shekelhertz.com/archive-7-eleven-other-stores-to-stop-selling-hentai-in-japan-by-august-2019-due-to-foreigners-olympics/" rel="nofollow" target="_blank" title="7-eleven stop selling hentai">Shekelhertz</a></p>

<p>Several other shops have also stopped selling adult magazines and hentai on the store shelves,
including Aeon Group, which pulled the magazines back in early 2018 out of 7,000 stores.
FamilyMart, another chain, also pulled the magazines out of approximately 2,000 shops out of the total 17,000 shops located around Japan.
They mention that the change was coming ahead of and due in part to those visiting for the 2020 Olympics taking place in Tokyo, Japan.</p>

<center><img src="/upload/images/anime/7-eleven-japan-stop-selling-hentai-by-8-2019-family-mart.jpg" width="70%" alt="7-eleven stop selling hentai" /><br><br>

<p>Adult magazines at a FamilyMart store in Sakai, Osaka</p></center>

<p>In January 2018, the Ministop convenience store chain stopped sales of adult magazines at all of its outlets across Japan. As pornography in print becomes less popular, it may not be too long before other vendors follow suit.</p>

<p>This sort of news shouldn&apos;t be too shocking to anyone considering that back in December of 2018, Senran Kagura producer, Kenichirou Takaki,
blatantly mentioned that fan-service and ecchi content was slowly being driven away, due in some part to the upcoming 2020 Olympics.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">In Japan, Convenience stores stopped put Hentai magazine in shop because for women, children and foreign travelers.<a href="https://t.co/5LSGO3zkvE">https://t.co/5LSGO3zkvE</a></p>&mdash; Poo_Okakura 岡倉ぷぅ (@roninworks) <a href="https://twitter.com/roninworks/status/1087387900843515904?ref_src=twsrc%5Etfw">January 21, 2019</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<img src="/upload/images/anime/7-eleven-japan-stop-selling-hentai-by-8-2019-jk-to-ero-konbini-tenchou-eng.jpg" width="100%" alt="7-eleven stop selling hentai" /><br><br></center>

<h3>Welcomed by Female Staff</h3>

<p>Source: <a href="https://www.nippon.com/en/currents/d00407/ministop%E2%80%99s-ending-adult-magazine-sales-hints-at-change-for-japanese-convenience-stores.html" rel="nofollow" target="_blank" title="7-eleven stop selling hentai">Nippon</a></p>

<p>A public relations representative at Ministop explained the reasoning behind the decision: "We were already considering making such a move as part of our overall goal of making our stores comfortable and convenient for all our customers. Adult magazines had dropped below 10 percent of total magazine sales, and the Chiba municipal initiative impelled us to go ahead and pull the plug."</p>

<p>The move came into effect in Chiba—where the Aeon Group has its headquarters—in December 2017, before being rolled out nationwide in January 2018. Many staff, particularly women who were uncomfortable placing the magazines on racks and seeing them in the stores, have welcomed the change.</p>

<center><img src="/upload/images/anime/7-eleven-japan-stop-selling-hentai-by-8-2019-1.jpg" width="70%" alt="7-eleven stop selling hentai" /><br><br></center>

<p>According to Ministop&apos;s PR representative the chain received a lot of valuable customer feedback regarding the decision.
"Around 80% supported the move, while 10 percent, mostly men, wanted us to go on selling the magazines.
There were also some queries about where we draw the line to define adult magazines. But just as we always bring in other products to replace those that aren&apos;t selling,
we see it as a case of simply no longer stocking one category of magazine."</p>

<h3>An End to Magazines in Convenience Stores?</h3>

<p>The Internet is changing how customers buy magazines and other publications. In September 2017, 7-Eleven began a service whereby regular readers of magazines can order them online or in stores and pick them up at the counter. FamilyMart has teamed up with publisher Goma Books to offer popular ebooks.</p>

<p>In Tokyo there are already some convenience stores that have done away with their magazine section. Perhaps it is only a matter of time before magazines altogether vanish from store shelves.</p>

<center><img src="/upload/images/anime/7-eleven-japan-stop-selling-hentai-by-8-2019-jk-to-ero-konbini-tenchou-2-eng.jpg" width="100%" alt="7-eleven stop selling hentai" /><br><br></center>

']);

//         posts::where('url_post', 'Shinmai-Maou-no-Tesutamento-Co-em-gai-Quy-Vuong')->update([
//             'name_en_post'    => "[Review] Shinmai Maou no Tesutamento - Testament of Sister New Devil",
//             // 'present_en_post' => "",
//             'content_en_post' => '

// <center><img src="/upload/images/anime/shinmai-maou-no-tesutamento-naruse-mio-2.jpg" width="100%" alt="Shinmai Maou no Tesutamento Cô em gái Quỷ Vương" /><br><br>

// <img src="/upload/images/anime/shinmai-maou-no-tesutamento-naruse-mio-3.jpg" width="100%" alt="Shinmai Maou no Tesutamento Cô em gái Quỷ Vương" /><br><br>

// <p>Basara control Mio.</p>

// <img src="/upload/images/anime/shinmai-maou-no-tesutamento-naruse-maria-2.jpg" width="100%" alt="Shinmai Maou no Tesutamento Cô em gái Quỷ Vương" /><br><br>

// <img src="/upload/images/anime/shinmai-maou-no-tesutamento-naruse-maria-3-eng.jpg" width="100%" alt="Shinmai Maou no Tesutamento Cô em gái Quỷ Vương" /><br><br>

// <p>Maria adult form</p></center>
// '
//         ]);

        posts::where('url_post', 'world-end-harem-delayed-to-january-2022')->update([
            'name_en_post'    => "World's End Harem Anime's Delayed to January",
            'present_en_post' => 'Anime is scheduled to premiere on October 8',
            'content_en_post' => '<p>The official website for the television anime of Kotaro Shono&apos;s World&apos;s End Harem science-fiction manga announced on October 8
that the anime&apos;s production committee has delayed the anime&apos;s episode 2 and later episodes from this fall to January 2022
due to a need to "closely examine" the anime&apos;s production. In addition, episode 1 will air as scheduled,
but it will not stream until January 2022. Crunchyroll was slated to stream the anime this season.</p>

<p>The official website: <a href="https://end-harem-anime.com/" rel="nofollow" target="_blank" title="World End Harem Delayed">World End Harem</a></p>

<p>World&apos;s End Harem, Japanese is Shuumatsu no Harem. The original manga had released in May 2016. Anime will release in October 2021.
However, after episode 1 was shown, episode 2 and later episodes were moved to January 2022.</p>

<center><img src="/upload/images/anime/world-end-harem-delayed-to-january-2022-1.jpg" width="100%" alt="World End Harem Delayed"></center>

<p>Announcement: <a href="https://end-harem-anime.com/news/index00320000.html" rel="nofollow" target="_blank" title="World End Harem Delayed">World End Harem</a></p>

<blockquote>
<p>Thank you for your continued support for the TV anime "World&apos;s End Harem".</p>

<p>Since it is necessary to scrutinize the expression of "World&apos;s End Harem" which started broadcasting from October 8, 2021, the broadcasting of the second and subsequent episodes scheduled to be broadcast from October 15 will be delayed to January 2022. We sincerely apologize to everyone who has been looking forward to the work.

<p>Besides, on October 8, we will broadcast the first episode as "special broadcast".
Regarding distribution, we are postponing the distribution date to January 2022, including the first episode.</p>
<p>(Main anime, scheduled to start on October 8, will not be distributed).</p>
<p>We will notify you of the new start date on our website and Twitter after we make a final decision.</p>
</blockquote>

<center><blockquote class="twitter-tweet"><p lang="ja" dir="ltr">本日より放送・配信開始のアニメ『<a href="https://twitter.com/hashtag/%E7%B5%82%E6%9C%AB%E3%81%AE%E3%83%8F%E3%83%BC%E3%83%AC%E3%83%A0?src=hash&amp;ref_src=twsrc%5Etfw">#終末のハーレム</a>』につきまして、表現の精査が必要であるため、来週からの第2話以降の放送と本日からの配信を来年1月クールに延期させていただくことになりました。作品を楽しみにお待ち下さっていた皆様に対して心よりお詫び申し上げます。<a href="https://t.co/ZUzBxb7MGS">https://t.co/ZUzBxb7MGS</a> <a href="https://t.co/RCjrUZ0QG7">pic.twitter.com/RCjrUZ0QG7</a></p>&mdash; 終末のハーレム【公式】TVアニメ2022年1月より放送開始&amp;最新13巻発売中！ (@harem_official_) <a href="https://twitter.com/harem_official_/status/1446279180535074818?ref_src=twsrc%5Etfw">October 8, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<img src="/upload/images/anime/world-end-harem-delayed-to-january-2022-2.jpg" width="100%" alt="World End Harem"><br><br>

<p>Banner of Twitter had been changed</p>

<iframe width="90%" height="315" src="https://www.youtube.com/embed/Fy1HZy-1GvY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="90%" height="315" src="https://www.youtube.com/embed/Nx7EizT4GQY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Old PV video had been substituted by new video</p></center>

<p>The Man-Killer Virus: a lethal disease that has eradicated 99.9% of the world&apos;s male population.
Mizuhara Reito has been in cryogenic sleep for the past 5 years, leaving behind Tachibana Erisa, the girl of his dreams.
When Reito awakens from the deep freeze, he emerges into a sex-crazed new world where he himself is the planet&apos;s most precious resource.
Reito and four other male studs are given lives of luxury and one simple mission: repopulate the world by impregnating as many women as possible!
All Reito wants, however, is to find his beloved Erisa who went missing 3 years ago. Can Reito resist temptation and find his one true love, Tachibana Erisa?</p>

<center><img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-3.jpg" width="70%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-5.jpg" width="70%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-erisa.jpg" width="100%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-akane-eng.jpg" width="100%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-akane-2-eng.jpg" width="100%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-mahiru.jpg" width="100%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-mira-eng.jpg" width="100%" alt="World End Harem"><br><br>

<img src="/upload/images/anime/world-end-harem-harem-hau-tan-the-6-eng.jpg" width="100%" alt="World End Harem"><br><br></center>

<p>Source: <a href="https://www.animenewsnetwork.com/news/2021-10-07/world-end-harem-anime-episode-2-and-later-delayed-to-january/.178250" rel="nofollow" target="_blank" title="World End Harem Delayed">Anime News Network</p>
'
        ]);

        posts::where('url_post', 'rent-a-girlfriend-gets-live-action')->update([
            'name_en_post'    => "Rent A Girlfriend gets live action",
            'present_en_post' => 'Series premieres in July along with anime season 2.',
            'content_en_post' => '<p>Reiji Miyajima&apos;s Rent-A-Girlfriend (Kanojo, Okarishimasu) manga is inspiring a live-action series that will premiere in July.
Ryusei Onishi and actress Hiyori Sakurada (live-action Tokyo Ghoul, Twilight)
will star as the protagonist Kazuya Kinoshita and the heroine Chizuru Mizuhara, respectively.</p>

<p>The official website: <a href="https://kanokari-official.com/" rel="nofollow" target="_blank" title="Rent A Girlfriend live action">Rent A Girlfriend</a></p>
<p>Author&apos;s Twitter <a href="https://twitter.com/Miyajimareiji" rel="nofollow" target="_blank" title="Rent a girlfriend live action">Miyajima Reiji</a></p>

<p>Beside, Shiori Akita as Mami Nanami. Kudou Mio as Sarashina Ruka.</p>

<center><img src="/upload/images/anime/rent-a-girlfriend-gets-live-action-kazuya-chizuru.jpg" width="70%" alt="Rent A Girlfriend live action">

<p>Ryusei and Hiyori as Kazuya and Chizuru</p>

<img src="/upload/images/anime/rent-a-girlfriend-gets-live-action-mami.jpg" width="70%" alt="Rent A Girlfriend live action">

<p>Shiori Akita as Mami Nanami</p>

<img src="/upload/images/anime/rent-a-girlfriend-gets-live-action-ruka.jpg" width="70%" alt="Rent A Girlfriend live action">

<p>Kudou Mio as Sarashina Ruka</p>

<img src="/upload/images/anime/rent-a-girlfriend-gets-live-action-2.jpg" width="70%" alt="Rent A Girlfriend live action">

<p>4 main girls character in the movie</p></center>

<p>The series will air on the Asahi Broadcasting Corporation TV channel on Sundays at 11:55 PM, and it will also air on TV Asahi on Saturdays at 26:30 AM.</p>

<ul>
<li>Director Daisuke Yamamoto
<li>Writer Asou Kumiko
</ul>

<center><blockquote class="twitter-tweet"><p lang="ja" dir="ltr"><a href="https://twitter.com/hashtag/%E3%83%89%E3%83%A9%E3%83%9E%E5%BD%BC%E5%A5%B3%E3%81%8A%E5%80%9F%E3%82%8A%E3%81%97%E3%81%BE%E3%81%99?src=hash&amp;ref_src=twsrc%5Etfw">#ドラマ彼女お借りします</a><br>▷ 第1話より場面写真初公開🌸🤍<br><br>“モテない冴えない大学生の恋物語”が始まる！<a href="https://twitter.com/hashtag/%E5%A4%A7%E8%A5%BF%E6%B5%81%E6%98%9F?src=hash&amp;ref_src=twsrc%5Etfw">#大西流星</a> <a href="https://twitter.com/hashtag/%E3%81%AA%E3%81%AB%E3%82%8F%E7%94%B7%E5%AD%90?src=hash&amp;ref_src=twsrc%5Etfw">#なにわ男子</a> <a href="https://twitter.com/hashtag/%E6%A1%9C%E7%94%B0%E3%81%B2%E3%82%88%E3%82%8A?src=hash&amp;ref_src=twsrc%5Etfw">#桜田ひより</a><a href="https://twitter.com/hashtag/%E7%A7%8B%E7%94%B0%E6%B1%90%E6%A2%A8?src=hash&amp;ref_src=twsrc%5Etfw">#秋田汐梨</a><a href="https://twitter.com/hashtag/%E5%BD%BC%E5%A5%B3%E3%81%8A%E5%80%9F%E3%82%8A%E3%81%97%E3%81%BE%E3%81%99?src=hash&amp;ref_src=twsrc%5Etfw">#彼女お借りします</a><a href="https://twitter.com/hashtag/ABC%E3%83%86%E3%83%AC%E3%83%93?src=hash&amp;ref_src=twsrc%5Etfw">#ABCテレビ</a> <a href="https://twitter.com/hashtag/%E3%83%86%E3%83%AC%E3%83%93%E6%9C%9D%E6%97%A5?src=hash&amp;ref_src=twsrc%5Etfw">#テレビ朝日</a><br>7月放送スタート！ <a href="https://t.co/mkM47HoPgf">pic.twitter.com/mkM47HoPgf</a></p>&mdash; ドラマL『彼女、お借りします』【公式】7月スタート (@kanokari_drama) <a href="https://twitter.com/kanokari_drama/status/1535034004956762121?ref_src=twsrc%5Etfw">June 9, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Hapless college first-year Kazuya Kinoshita, reeling from a bad breakup, rents a few hours of friendly companionship at the aquarium with the idol-beautiful and polite Chizuru.
But Chizuru is studying in the same university with Kazuya. And Kazuya have 2 new rent-girlfriends: Ruka Sarashina and Sumi Sakurasawa.
Family, school, and life all start to go wrong. Kazuya and Chizuru must keep their relationship in secret.
</p>

<center><img src="/upload/images/anime/rent-a-girlfriend-gets-live-action-av.jpg" width="100%" alt="Rent A Girlfriend live action">

<p>Rent A Girlfriend has AV version.</p></center>

<p>Source: <a href="https://www.animenewsnetwork.com/news/2022-05-12/rent-a-girlfriend-manga-gets-live-action-show-starring-naniwa-danshi-idol-ryusei-onishi-hiyori-/.185615" rel="nofollow" target="_blank" title="Rent A Girlfriend live action">Anime News Network</a></p>
'
        ]);

        posts::where('url_post', 'lady-long-legs-quy-co-chan-dai')->update([
            'name_en_post'    => "[Review] Lady Long Legs",
            'present_en_post' => "Manhwa Korea have amazing story, about young man and female director.",
            'content_en_post' => '<p>Categories: Adult, Manhwa, Drama, Comedy</p>

<ul>
<li>Korea name: 키다리 아가씨
<li>English name: Lady Long Legs
<li>Author: 
<li>Illustrator: 
</ul>

<p>This webtoon was released on 2017 and completed with ..... chapters.</p>

<p>Pathetic loser Ji Hyunwoo, 26 years old, lived in the Sunlight orphanage as a child. After failed interview,
he had caused an accident with president of Plan A company, Han Seungah. He must sign a slave contract with her and live in her house! </p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Ji-Hyunwoo-eng.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài" /></center>

<p>In Plan A company, he discovered his true identity.</p>

<p>The M.O company was founded by Han Seungah&apos;s grandfather, Han Chulwoo. Along with my father, Yoon Jeongho. And Ji Hyunwoo&apos;s father, researcher Ji Deokchul. Yoon Heongho wanted to take over the company so he plotted to kill his father and the president Han Chulseung, Han Seungah&apos;s father. His father was save Han&apos;s father live. </p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-1-eng.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài"><br><br></center>

<p>But the woman whose the son has name is Ji Hyunwoo was knew everything. She was decided to switch her son, made his life better. Her son was lived in USA with the named Philip.</p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-2-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài"><br><br>

<p>The protagonist&apos;s father saved the heroine&apos;s father</p></center>

<p>Ji Hyunwoo, who didn&apos;t have any close relatives was sent to an orphanage, not knowing that his father Ji Deokchul had left him 1% of the company&apos;s shares as his inheritance.

That 1% has become very important in the war between Yoon Chae Young&apos;s family and Han Seungah&apos;s family.</p>

<p>Director Han Seungah, who has secretly loved with Philip when he in the orphanage.
Perhaps because of his father&apos;s saving her father. Philip is now named Ji Hyunwoo. She decides to confess to Philip before he go to America.
Unfortunately, Philip called her is fat and ugly. She cried for a few days and was determined to change, becoming the girl with long legs and great body.</p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-5-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" />

<p>This is Philip&apos;s name is Ji Hyunwoo.</p></center>

<p>When she found out that Ji Hyunwoo was in Korea, she went to find him. He threw a box of chocolates on her head and made accident for a Lamborghini.
Taking the opportunity, she forced him to work at her home as a slave and as an employee of the company. His life-changing journey begins.</p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Han-Seungah-1.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Han-Seungah-2-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" /></center>

<p>The advantage of this series is the plot.</p>


<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Yoon-Chae-Young-eng.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Choi-Sooji-eng.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Han-Seungah-3-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Yoon-Chae-Young-2-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Yoon-Chae-Young-1-eng.jpg" width="70%" alt="Lady Long Legs Quý Cô Chân Dài"><br><br>

<p>The girls try to seduce Ji Hyunwoo for the company</p></center>

<p>But the minus point of the story is that the heroine acts like a slut.</p>

<center><img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Han-Seungah-4-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<img src="/upload/images/anime/lady-long-legs-quy-co-chan-dai-Han-Seungah-5-eng.jpg" width="100%" alt="Lady Long Legs Quý Cô Chân Dài" /><br><br>

<p>Han Seungah had sex with other people in front of Ji Hyunwoo</p>

<p>And the ending is also very happy. The villains gets jail time, the protagonists continues to run the company.
This is a series worth watching for those who love romance but still have an attractive plot to follow.</p>
'
        ]);

        posts::where('url_post', 'ex-wife-vo-cu')->update([
            'name_en_post'    => "[Review] Ex Wife",
            'present_en_post' => "The story about relationship of young couple after divorce",
            'content_en_post' => '<p>Categories: Adult, Manhwa, Drama, Comedy, Romance</p>

<ul>
<li>Korea name: 전처와의 동거
<li>English name: Ex Wife
<li>Author: Lee Dae-pal
<li>Illustrator: Black Rabbit
</ul>

<p>This webtoon was released on 2020 and completed with 67 chapters.</p>

<center><img src="/upload/images/anime/ex-wife-vo-cu-1.jpg" width="70%" alt="Ex Wife Vợ cũ"><br><br></center>

<p>Tae Ho and Cha Gaeun decided to divorce after 2 years. But Gaeun&apos;s father has lung cancer. So they have to live together, don&apos;t tell Gaeun&apos;s father the truth.</p>

<center><img src="/upload/images/anime/ex-wife-vo-cu-2.jpg" width="100%" alt="Ex Wife Vợ cũ"><br><br></center>

<p>Before the divorce, Tae Ho had an outside lover, artist Wi San San, who is also an old friend. After the divorce, he had another lover, a new paramedic at Dae Ryuk Hospital, Ms. Jo A Yeong.</p>

<center><img src="/upload/images/anime/ex-wife-vo-cu-san-san-1.jpg" width="100%" alt="Ex Wife Vợ cũ"><br><br>

<p>San San, old friend and glosbe of Tae Ho</p>

<img src="/upload/images/anime/ex-wife-vo-cu-yeong-1-eng.jpg" width="100%" alt="Ex Wife Vợ cũ"><br><br>

<p>Jo A Yeong, paramedic in Tae Ho&apos;s hospital.</p></center>

<p>Chuyện trở nên phức tạp hơn khi các cô gái bắt đầu tìm cách đánh ghen nhau. Vợ cũ muốn đổi hộ lý chăm sóc bố. San San quyết định thuê thám tử theo dõi vợ cũ.
Và kết quả là phát hiện vợ cũ đang có mối quan hệ mới với bác sĩ tâm lý.</p>

<p></p>

<p></p>

<p></p>

<center><img src="/upload/images/anime/ex-wife-vo-cu-gaeun-2.jpg" width="70%" alt="Ex Wife Vợ cũ"><br><br>

<p>Psychiatrist used hypnosis to rape Gaeun, but get caught by detective.</p>

<img src="/upload/images/anime/ex-wife-vo-cu-gaeun-3-eng.jpg" width="100%" alt="Ex Wife Vợ cũ"><br><br>

<p>Just one snap, she immediately has sex with Tae.</p></center>

<p></p>

<p></p>

<p></p>

<p></p>

<center><img src="/upload/images/anime/ex-wife-vo-cu-3-eng.jpg" width="70%" alt="Ex Wife Vợ cũ"><br><br>

<p>Most impressive screen in this story.</p></center>

<p>Nhìn chung, Ex Wife đã làm tốt trong việc xây dựng cốt truyện, cảm xúc nhân vật. Độc giả có thể hiểu rõ hơn cuộc sống của đôi vợ chồng trước và sau khi ly hôn. Dù hết tình, họ vẫn còn nghĩa vụ và vẫn đối xử tốt với nhau. Đây là một bộ manhwa 18+ đáng để theo dõi.</p>
'
        ]);

        posts::where('url_post', 'inu-ni-nattara-suki-na-hito-ni-hirowareta-manga-gets-tv-anime-in-2023')->update([
            'name_en_post'    => "My Life as Inukai-san's Dog get anime PV",
            'present_en_post' => "New visual, opening theme artists also revealed",
            'content_en_post' => '<p>The official website for the television anime of Gosei Furukawa&apos;s My Life as Inukai-san&apos;s Dog (Inu ni Nattara Suki na Hito ni Hirowareta,
literally If I Became a Dog I Would be Picked Up by the Person I Like) manga revealed a second promotional video, new key visual,
and the January 6 premiere on Tuesday. The anime will premiere on January 6 on Tokyo MX and on January 9 on BS11.</p>

<p>The website also revealed the opening theme song artists. The following artists will perform the opening theme song "Gyakyū☆Fuwaku☆Fraction":
Miyuki Hashimoto, Yui Sakakibara, Rita with AiRI, Ayumi, Rekka Katakiri, Yumi Kawamura, Sayaka Sasaki,
Duca, Mitsuki Nakae, Nomiko, Aki Misato, yozuca*, rino, and riya (eufonius). The above video previews the song.</p>

<p>The main cast includes:</p>

<ul>
<li>Shuuichirou Umeda as Pochita the dog
<li>Saya Aizawa as Karen Inukai
<li>Mayu Sagara as Mike Nekotani
<li>Yurie Kozakai as Usagi Tsukishiro
</ul>

<p></p>

<p>Source: <a href="https://www.animenewsnetwork.com/news/2022-11-01/my-life-as-inukai-san-dog-anime-2nd-promo-video-reveals-january-6-debut/.191454" rel="nofollow" target="_blank" title="My Life as Inukai-san Dog get anime PV">Anime News Network</a></p>
'
        ]);

        posts::where('url_post', 'pixiv-announces-tos-changes-prohibiting-sale-of-hardcore-content')->update([
            'name_en_post'    => "Pixiv Announces Upcoming ToS Changes Prohibiting Sale of Hardcore Content",
            'present_en_post' => "It's include themes of incest, bestiality, and non-consensual sex, on all of its platforms.",
            'content_en_post' => '<p>As a platform, Pixiv is an enormously popular image sharing service from Japan. The online community was first launched in 2007 with a beta test, and soon become the go-to website for Eastern artists. In recent years, it has also grown in popularity among Western communities.</p>

<p>Aside from its main websites, Pixiv is also the owner of BOOTH and pixivFANBOX. BOOTH is an online marketplace allowing users to sell their goods through the internet. Meanwhile, pixivFANBOX is a service akin to SubscribeStar, allowing fans to easily support their favorite artists through continuous donations. Creators using Pixiv can also make money by using the request functionality, allowing fans to ask for specific works to be made whilst offering payment for completion.</p>

<p>The types of content that can be sold through Pixiv&apos;s services are regulated by its Service Master Terms of Use. Today, in an announcement, Pixiv has taken notice that some transactions on its website include content prohibited by both its ToS and by the Brand Protection policies of card networks, providing examples of what content is not allowed by the latter. Examples listed by Pixiv include sexual exploitation of minors, incest, bestiality, non-consensual sex and/or mutilation of a person or body part.</p>

<blockquote>
<p><b>Regarding transactions for items</b></p>

<p>Many transactions take place on BOOTH, pixivFANBOX, and the pixiv Requests feature.<br>
Some were found to violate the pixiv Terms of Use, Article 14 "Prohibited Conduct", Item 26 "Using the Services to display, sell, purchase, register, or engage in other transactions involving the products set forth below".</p>

<p>Furthermore, the rules or policies of Brand Protection for Card Networks transactions for content that is patently offensive, unethical, or promote criminal activity; such as, by way of example and not limitation:</p>
<ul>
<li>Sexual exploitation of a minor
<li>Incest
<li>Bestiality
<li>Rape (or any other non-consensual sexual behavior)
<li>Non-consensual mutilation of a person or body part
</ul>

<p>Under the Service Master Terms of Use, we ask that all users check for items that include the above content on BOOTH, pixivFANBOX, and the pixiv Requests feature, and if such content is found, delete the items or set them to private.</p>
</blockquote>

<center><img src="/upload/images/anime/pixiv-announces-tos-changes-prohibiting-sale-of-hardcore-content-1.jpg" width="100%" alt="Pixiv Incest Bestiality Rape" /><br><br>

<blockquote class="twitter-tweet"><p lang="ja" dir="ltr">「決済を伴う取引に関するサービス共通利用規約改定の事前のお知らせとお願い」を公開いたしました。<br><br>このたびの改定は、BOOTH、pixivFANBOX、pixivリクエスト機能など決済を伴う取引に適用されます。<br><br>詳細はこちらをご確認ください。<a href="https://t.co/rlU1CotvzQ">https://t.co/rlU1CotvzQ</a></p>&mdash; pixiv (@pixiv) <a href="https://twitter.com/pixiv/status/1592431082208886787?ref_src=twsrc%5Etfw">November 15, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Pixiv&apos;s Announces</p></center>

<p>Due of this, an update to the terms of service will take place on December 15th, 2022. The new ToS will become accessible ahead of time, in late November, so that users have time to delete content that doesn&apos;t conform to the new rules, or to set such works as private.</p>

<p>It is important to note that, so far, Pixiv hasn&apos;t published an exact list of upcoming changes. While the update will impact users selling physical products or content involving real people, it is uncertain whether it will affect artists using the website as well.</p>

<p>The mentioned Item 26 of Article 14 contains a sizeable list of products which cannot be involved in transactions. The list already includes “Products that contain images or other data corresponding to obscenity, child pornography, or child abuse.” Despite this, many artists creating works featuring loli or shota characters use Pixiv&apos;s financial services. It is unclear whether the paid creation of digital art is considered a service rather than a product, or whether the rules simply don&apos;t target depictions of fictional characters in general.</p>

<p>Source: <a href="https://policies.pixiv.net/en.html" rel="nofollow" target="_blank" title="Pixiv Incest Bestiality Rape">Pixiv&apos;s Policies</a></p>

<p>Currently, the Service Master Terms of Use Article 14 includes three positions which refer to products with erotic content:</p>

<blockquote>
<p>26. Using the Services to display, sell, purchase, register, or engage in other transactions involving the products set forth below:</p>

<ul>
<li>4. Products that contain images or other data corresponding to obscenity, child pornography, or child abuse;
<li>5. Products that contain uncorrected representations of exposed sexual organs or explicit images of sexual intercourse;
<li>7. Prostitution and child prostitution;
</ul>
</blockquote>

<center><img src="/upload/images/anime/pixiv-announces-tos-changes-prohibiting-sale-of-hardcore-content-2.jpg" width="100%" alt="Pixiv Incest Bestiality Rape" /><br><br>

<p>Pixiv&apos;s Policies</p>

<img src="/upload/images/anime/pixiv-announces-tos-changes-prohibiting-sale-of-hardcore-content-hoshimiyamukuro.jpg" width="100%" alt="Pixiv Incest Bestiality Rape" /><br><br>

<p>Fanbox have donate function for creators.</p></center>

<p>Source: <a href="https://www.lewdgamer.com/2022/11/15/pixiv-announces-tos-changes-prohibiting-sale-of-hardcore-content" rel="nofollow" target="_blank" title="Shimazaki Nobunaga COVID-19">Lewdgamer</a></p>
'
        ]);
        
        posts::where('url_post', 'back-street-girls-yakuza-chuyen-gioi')->update([
            'name_en_post'    => "Back Street Girls",
            'present_en_post' => "",
            'content_en_post' => '<p>Categories: action, </p>

<ul>
<li>Japanese name: Back Street Girls
<li>English name: Back Street Girls
<li>Author: Jasmine Gyuh
<li>Artist:
</ul>

<p></p>

<center><img src="/upload/images/anime/back-street-girls-yakuza-chuyen-gioi.jpg" width="100%" alt="Back Street Girls"></center>

<p>3 yakuzas </p>

<ul>
<li> -> Tachibana Mari
<li> -> Yamamoto Airi
<li> -> Sugihara Chika
</ul>

<p></p>

<p></p>

<p></p>

<center><img src="/upload/images/anime/.jpg" width="100%" alt="Back Street Girls">

<p></p></center>

<p></p>
'
        ]);

// Viết bài về Vợ Cũ Ex Wife
// https://manhwa2read.com/manga/cohabitation-with-my-ex-wife/chapter-67/
    }
}
