<?php
namespace App\Seeder\postsSeeder;

use App\Models\posts;
use DB;
use Illuminate\Support\ServiceProvider;

class GameEngPosts
{
    public function index()
    {
        // ============== 2021 ==============

        posts::where('url_post', 'activision-blizzard-sexual-harassment-lawsuit')->update([
            'name_en_post'    => "Activision Blizzard accused of sexual harassment",
            'present_en_post' => "Activision Blizzard CEO calls for investigation amid discrimination suit and employee walkout",
            'content_en_post' => '<p>The California Department of Fair Employment and Housing (DFEH) is suing Activision Blizzard over what court documents refer
to as a "frat boy" workplace culture that subjects its female employees to gender-based discrimination and "constant sexual harassment."
Bloomberg Law first reported the news. Several former Activision Blizzard employees have spoken out on social media to corroborate these stories.</p>

<p>Source: <a href="https://www.theverge.com/2021/7/24/22591611/activision-blizzard-brack-sexual-harassment-lawsuit-california" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">Theverge</a></p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-1.jpg" width="100%" alt="Activision Blizzard sexual harassment" /></center>

<p>"Women of color were particularly vulnerable targets of Activision Blizzard&apos;s discriminatory practices," the DFEH said in the lawsuit.
It also alleged that employees were "discouraged from complaining as human resource personnel were known to be close to alleged harassers."</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Blizzard president J. Allen Brack sent out an email to staff last night addressing the allegations from this week&#39;s explosive lawsuit, calling them &quot;extremely troubling&quot; and saying that he&#39;d be &quot;meeting with many of you to answer questions and discuss how we can move forward.&quot; <a href="https://t.co/NsMV6CNdTE">pic.twitter.com/NsMV6CNdTE</a></p>&mdash; Jason Schreier (@jasonschreier) <a href="https://twitter.com/jasonschreier/status/1418512291218264065?ref_src=twsrc%5Etfw">July 23, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Source: <a href="https://www.polygon.com/22588407/activision-blizzard-sexual-harassment-sexism-california-lawsuit" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">Polygon</a></p>

<p>Former World of Warcraft senior creative director Alex Afrasiabi was named as a top-level "harasser" who was "permitted to engage in blatant sexual harassment with little to no repercussions."</p>

<center><img src="/upload/images/game/sexual-harassment-1.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<blockquote>
<p>We value diversity and strive to foster a workplace that offers inclusivity for everyone. There is no place in our company or industry, or any industry, for sexual misconduct or harassment of any kind. We take every allegation seriously and investigate all claims. In cases related to misconduct, action was taken to address the issue.</p>

<p>The DFEH includes distorted, and in many cases false, descriptions of Blizzard&apos;s past. We have been extremely cooperative with the DFEH throughout their investigation, including providing them with extensive data and ample documentation, but they refused to inform us what issues they perceived. They were required by law to adequately investigate and to have good faith discussions with us to better understand and to resolve any claims or concerns before going to litigation, but they failed to do so. Instead, they rushed to file an inaccurate complaint, as we will demonstrate in court. We are sickened by the reprehensible conduct of the DFEH to drag into the complaint the tragic suicide of an employee whose passing has no bearing whatsoever on this case and with no regard for her grieving family. While we find this behavior to be disgraceful and unprofessional, it is unfortunately an example of how they have conducted themselves throughout the course of their investigation. It is this type of irresponsible behavior from unaccountable State bureaucrats that are driving many of the State&apos;s best businesses out of California.</p>

<p>The picture the DFEH paints is not the Blizzard workplace of today. Over the past several years and continuing since the initial investigation started, we&apos;ve made significant changes to address company culture and reflect more diversity within our leadership teams. We&apos;ve amplified internal programs and channels for employees to report violations, including the “ASK List” with a confidential integrity hotline, and introduced an Employee Relations team dedicated to investigating employee concerns. We have strengthened our commitment to diversity, equity and inclusion and combined our Employee Networks at a global level, to provide additional support. Employees must also undergo regular anti-harassment training and have done so for many years.</p>

<p>We put tremendous effort in creating fair and rewarding compensation packages and policies that reflect our culture and business, and we strive to pay all employees fairly for equal or substantially similar work. We take a variety of proactive steps to ensure that pay is driven by non-discriminatory factors. For example, we reward and compensate employees based on their performance, and we conduct extensive anti-discrimination trainings including for those who are part of the compensation process.</p>

<p>We are confident in our ability to demonstrate our practices as an equal opportunity employer that fosters a supportive, diverse, and inclusive workplace for our people, and we are committed to continuing this effort in the years to come. It is a shame that the DFEH did not want to engage with us on what they thought they were seeing in their investigation.</p>
</blockquote>

<center><img src="/upload/images/game/sexual-harassment-2.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<p>Townsend, who previously served as the assistant for homeland security and counterterrorism to President George W. Bush, has been executive vice president for corporate affairs and chief compliance officer at Activision Blizzard since March 2021.</p>

<p>The company&apos;s Chief Compliance Officer Frances Townsend called the allegations a "distorted and untrue picture of our company" and "factually incorrect, old and out of context" in an internal letter obtained by The Washington Post.</p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-fran-townsend.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br>

<p>Fran Townsend called the allegations a "distorted and untrue picture of our company"</p></center>

<p>Source: <a href="https://www.cnbc.com/2021/07/28/activision-blizzard-ceo-calls-for-investigation-amid-discrimination-suit-walkout.html" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">CNBC</a></p>

<p>She reportedly sent a company-wide email calling it "a truly meritless and irresponsible lawsuit" which "presented a distorted and untrue picture of our company, including factually incorrect, old, and out of context stories".</p>

<center><img src="/upload/images/game/activision-blizzard-sexual-harassment-lawsuit-scandal.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>
'
        ]);

        posts::where('url_post', 'lewd-idol-project-developer-toffer-team-banned-on-paypal')->update([
            'name_en_post'    => "LIP! Lewd Idol Project Developer Toffer Team Banned on PayPal",
            'present_en_post' => 'The Toffer Team PayPal account was locked for selling "sexually oriented materials or services"',
            'content_en_post' => '<p>LIP! Lewd Idol Project is the product of a successful Kickstarter by Toffer Team; it raised a total of 35.116 USD against an original goal of 9.000 USD. The developers planned to release several "Volumes" of the game, each of which would explore new aspects of the story.</p>

<p>Source: <a href="https://www.lewdgamer.com/2021/07/07/lip-lewd-idol-project-developer-toffer-team-banned-on-paypal" target="_blank" title="Lewd Idol Project Paypal">Lewdgame</a></p>

<center><img src="/upload/images/game/lewd-idol-project-fund.jpg" width="100%" alt="Lewd Idol Project Paypal" /></center>

<p>However, adult game Lewd Idol Project is in a bit of trouble - the Toffer Team PayPal account was locked for selling "sexually oriented materials or services" and it has lost access to its Kickstarter funds.</p>

<h3>PayPal&apos;s policy</h3>

<p>Source: <a href="https://www.paypal.com/us/smarthelp/article/HELP384" target="_blank" title="Lewd Idol Project Paypal">Paypal</a></p>

<blockquote>
<p>We don&apos;t permit PayPal account holders to buy or sell:</p>
<ul>
<li>Sexually oriented digital goods or content delivered through a digital medium. Examples of digital goods include downloadable pictures or videos and website subscriptions.
<li>Sexually oriented goods or services that involve, or appear to involve, minors.
<li>Services whose purpose is to facilitate meetings for sexually oriented activities.
</blockquote>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">PayPal has permanently locked our account and remaining Kickstarter raised funds for LIP! Lewd Idol Project.<br><br>Today it was us, tomorrow it could be you or any of your favorite lewd content creators.<br><br>Please read and RT to spread the word, we can&#39;t let this things keep happening. <a href="https://t.co/QiQ3k5Z3Li">pic.twitter.com/QiQ3k5Z3Li</a></p>&mdash; Toffer Team 🔞✨ (@TofferTeam) <a href="https://twitter.com/TofferTeam/status/1412436128716763137?ref_src=twsrc%5Etfw">July 6, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Toffer did not want to specify how much money was held in the PayPal account at the time it was closed. However, he noted that they&apos;ve developed roughly one-third of the game and have had to pay platform fees and taxes in the time since the Kickstarter campaign concluded.</p>

<p>Toffer, the owner of Toffer Team and the lead developer of Lewd Idol Project, explained:</p>
<blockquote>
<p>PayPal locked both our account for sending/receiving any kind of funds, and at the same time, locked our [hard-earned] crowdfunded money via Kickstarter because our business is oriented towards "sexual materials or services"</p>
</blockquote>

<p>Source: <a href="https://techraptor.net/gaming/news/lewd-idol-project-paypal-account-locked-kickstarter-funds" target="_blank" title="Lewd Idol Project Paypal">Techraptor</a></p>

<h3>The story of Lewd Idol Project</h3>

<p>Kairi, a young, innocent, and cheerful girl with a dream... Becoming the biggest and most popular Idol ever! She recently moved to Akihabara in order to achieve this.
But she&apos;s been rejected by around fifteen different agencies so far.</p>

<p>Already short on money, with some increasing debt, and feeling defeated by yet another failed audition, she meets Ranko, a perverted and self-proclaimed lewd producer that introduces the shy Idol wannabe into her most recent and ambitious project... LIP! Lewd Idol Project.</p>

<p>With nothing left to lose, and more questions than answers about this adult oriented Idol group, she embarks into the adventure of a lifetime!</p>

<center><img src="/upload/images/game/lewd-idol-project-kairi.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kanako.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-yuki.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-3.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-4.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-5.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-6.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-7-eng.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-8-eng.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko-3-eng.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-ranko-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-ranko-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-ranko-3-eng.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /></center>
'
        ]);

        posts::where('url_post', 'activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit')->update([
            'name_en_post'    => "Activision Blizzard To DMCA Takedown All Overwatch Porn In Wake Of Harassment Lawsuit",
            'present_en_post' => "This is a sad news for the Overwatch fans. Our freedom of expression is being censored.",
            'content_en_post' => '<p>Activision Blizzard&apos;s PR has been having a rough time trying to smooth over all of the damage that has been caused by their big sexual harassment lawsuit. Nothing they say is quite enough, nothing they do is quite enough.
They&apos;ve already said they were sorry, what more can they really do?</p>

<p>Source: <a href="https://pissdaily.com/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit/" rel="nofollow" target="_blank" title="Overwatch DMCA">Piss Daily</a></p>

<center><img src="/upload/images/game/mei-1-eng.jpg" width="100%" alt="Overwatch Mei" /><br><br>

<img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-mercy.jpg" width="100%" alt="Overwatch Mei" /></center>

<p>DMCA is Digital Millennium Copyright Act. It is a part of the US Copyright Law and relates to a defined process in removing content from the internet.</p>

<p>As part of the U.S. copyright law, the DMCA addresses the rights and obligations of owners of copyrighted material who believe their rights under U.S. copyright law have been infringed, particularly but not limited to, on the Internet.</p>

<p>Activision Blizzard will be beginning to pull the plug on all Overwatch porn. Pornhub in its entirely will be wiped, and from there they&apos;ll slowly make their way
through every other site, taking down every booby, titty, butt, and hole. This could easily send a shockwave rippling through the internet,
as more companies start to crack down on how their IP are used, and what kind of fan content is allowed. Porn and hentai as we know it could be a thing of the past.</p>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-mei-2.jpg" width="100%" alt="Overwatch Mei" /><br><br>

<img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-ana.jpg" width="100%" alt="Overwatch Mei" /><br><br></center>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-pharah.jpg" width="70%" alt="Overwatch DVA" /></center>

<p>"The whole thing has reached absurd levels," said Ellowas, a Source Filmmaker (SFM) artist who was recently hit with a takedown notice, “all of my stuff is gone already.” While Ellowas doesn&apos;t feel Blizzard are being fair in their pursuits, he did concede that they were “well within their legal rights,” adding, however, that "on the other hand you can understand why people are upset."</p>

<p>While Blizzard&apos;s motivations remain a mystery, it&apos;s likely that the publisher hopes to keep up appearances. Of course, as with all things, this can often lead to things blowing up even more than before.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">FANCY VERSION!<br>Don&#39;t worry for the girls, it&#39;s a private pod. I keep this place clean okay?<br><br>Jokes aside, I wasn&#39;t very happy with my latest animation, so I decided to improve it a bit and re-render.<br><br>Grab 720p here <a href="https://t.co/ENjWcgGoaR">https://t.co/ENjWcgGoaR</a> <a href="https://t.co/ALWNQFTQi9">pic.twitter.com/ALWNQFTQi9</a></p>&mdash; HydraFXX (@HydraFXX) <a href="https://twitter.com/HydraFXX/status/1131652865087479808?ref_src=twsrc%5Etfw">May 23, 2019</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<img src="/upload/images/game/tracer-dva-1-eng.jpg" width="100%" alt="Overwatch DVA" /><br><br>

<img src="/upload/images/game/mercy-1-eng.jpg" width="100%" alt="Overwatch Mercy" /></center>

<p>"Blizzard can&apos;t be naive enough to think that they can permanently put an end to Overwatch porn this way," said Ellowas, "They must know that with the popularity Overwatch has gained by now." This sentiment is being echoed among other artists, and with Blizzard&apos;s actions now coming to the forefront, it&apos;s possible this will have something of a Streisand Effect.</p>

<p>Source: <a href="https://www.lewdgamer.com/2016/05/29/blizzard-allegedly-targeting-overwatch-sfm-dmcas" rel="nofollow" target="_blank" title="Overwatch DMCA">lewdgamer</a></p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-10.jpg" width="70%" alt="Overwatch Pornhub" /><br><br>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-11.jpg" width="70%" alt="Overwatch Pornhub" /></center>

<p>A number of other users have also been hit with takedown notices, with one in particular, hitting the news.
A user going by the name <a href="https://www.reddit.com/r/Overwatch/comments/4l6418/blizzard_is_taking_down_overwatch_porn_and/" rel="nofollow" target="_blank" title="Overwatch DMCA">“spornm” posted on Reddit</a> a few days ago, where he detailed his experiences over the past week.
In his post, spornm linked to both a takedown directed at him , and one to another user.</p>

<p>Interestingly, neither of these claims seem to link back to Blizzard. According to the second notice, a company by the name of Irdeto USA claims to be the copyright holder.
Additionally, the admin of <b>overwatchhentai.net</b> noted that they had received a similarly styled notice, however, this time, the claimant was Easy Solutions.</p>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-brigitte-sombra.jpg" width="100%" alt="Overwatch Brigitte Sombra" /></center>

<p>For now, all that&apos;s truly clear is that takedown notices are being issued, and if Blizzard is involved, they&apos;re trying to keep their distance.
Blizzard is still a reputable brand in the gaming industry, which could explain their reluctance to put that brand on the line.
Hiring other, lesser known companies to make claims on their behalf keeps them out of the firing line, and keeps the brand intact.</p>

<p>Ellowas hopes this will all blow over. "Hopefully in a couple of weeks, everything will turn back to normal". He felt this was all just a "ham-handed reaction to mainstream media coverage".
Pornhub&apos;s analysis was well covered by mainstream outlets like Kotaku, which may have led to Blizzard taking notice.</p>

<center><img src="/upload/images/game/dva-1-eng.jpg" width="70%" alt="Overwatch DVA" /></center>

<p>While Blizzard&apos;s motivations remain a mystery, it&apos;s likely that the publisher hopes to keep up appearances. Of course, as with all things, this can often lead to things blowing up even more than before.</p>

<p>Blizzard is slowly dying and the leaders are making more and more wrong moves. The possibility that Blizzard will collapse and belong to China is not far away.
Blizzard once famously fired thousands of American employees to recruit Chinese workers.
Money is the most important thing for Blizzard leaders, but employees or gamers are not important.</p>

<center><img src="/upload/images/game/dva-2-eng.jpg" width="100%" alt="Overwatch DVA" /></center>
'
        ]); // https://www.erome.com/a/YHQkMlPX

        posts::where('url_post', 'hololive-error-trailer-horror-game-hololive')->update([
            'name_en_post'    => "Hololive ERROR trailers horror game for PC",
            // 'present_en_post' => "",
            'content_en_post' => '<p>Hololir ERROR is a first-person horror game based on the hololive ERROR series of 2D story videos.</p>

<p>Official website <a href="https://hololiveerror.hololivepro.com" target="_blank" title="Hololive ERROR">Hololive ERROR</a></p>
<p>Twitter <a href="https://twitter.com/hololivetv" target="_blank" title="Hololive ERROR">Hololive ERROR</a></p>

<center><iframe width="100%" height="450" src="https://www.youtube.com/embed/iHekCdRagR8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>First Hololive ERROR trailer</p></center>

<p>Hololive Production (Japanese: ホロライブプロダクション) is a virtual YouTuber agency owned by Japanese tech entertainment company Cover Corporation.
Hololive have many VTuber from Japan, Indonesia and countries where use English.</p>

<p>In Hololive ERROR trailer, main character has lost between new school and old school. Something terrible happened in old school.
Main character meet a school girl. That is Tokino Sora, first VTuber of Hololive. She ask you: "Will you forever be my friend?".</p>

<center><img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-1.jpg" width="100%" alt="Hololive ERROR" /><br><br>

<img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-2.jpg" width="100%" alt="Hololive ERROR" /><br><br></center>



<center><img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-3.jpg" width="100%" alt="Hololive ERROR" /><br><br>

<iframe width="100%" height="450" src="https://www.youtube.com/embed/WQQAwozBg94" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><br>

<p>Second Hololive ERROR trailer</p></center>

<p>KINGDOM NVHAI had downloaded video and music on Hololive ERROR official website.</p>

<center>
<video width="100%" controls="" preload="" controlslist="nodownload" poster="http://kingdomnvhai.info/upload/images/video/hololive-error-website-bgm-thumbnail.jpg">
<source src="http://kingdomnvhai.info/upload/video/hololive-error-bg-home.mp4" type="video/mp4">
</video>
</center>
'
        ]);

        // ============== 2022 ==============

        posts::where('url_post', 'square-enix-bandai-namco-entertainment-donate-ukraine')->update([
            'name_en_post'    => "Square Enix and Bandai Namco Entertainment has donated Ukraine",
            'present_en_post' => "Square Enix has donated 500000 USD to the Ukraine relief effort",
            'content_en_post' => '<p>Square Enix and Bandai Namco Entertainment announced donations this week for humanitarian aid to Ukraine. Square Enix will donate 500000 USD to United Nations High Commissioner for Refugees (UNHCR), while Bandai Namco Entertainment will donate 100 million yen (approximately 845000 USD) to the Save the Children charity.</p>

<p>In addition, Square Enix group companies have organized a fundraiser and matching gift program with their employees. The proceeds will go to the International Committee of the Red Cross, UNICEF, and Doctors Without Borders.</p>

<p>KOEI Tecmo announced last week that it has donated 500000 USD to UNHCR for Ukraine support. The company is also accepting donations and will bundle them together with those from its employees. Sony Group Corporation announced that it is donating 2 million USD to the United Nations High Commissioner for Refugees and the international NGO, Save the Children while suspending sales of its PlayStation software and hardware in Russia.</p>

<p>The Pokémon Company International donated 200000 USD to GlobalGiving to provide humanitarian relief.
Niantic announced it was donating 200000 USD to charities including United Help Ukraine, Razom Inc., Charitable Fund Voices of Children, International Rescue Committee,
Norwegian Refugee Council, Sunflower of Peace, International Medical Corps and UNICEF. Employees have raised over 75000 USD with matching donations by Niantic.</p>

<p>X Japan member YOSHIKI donated 10 million yen (approximately 87000 USD) to the Ukraine Humanitarian Crisis Emergency Assistance Fund.</p>

<p>Square Enix Holdings Co., Ltd. is a Japanese entertainment conglomerate and video game company best known for its Final Fantasy, Dragon Quest and Kingdom, Dragon Ball.</p>

<center><img src="/upload/images/game/square-enix-bandai-namco-entertainment-donate-ukraine-final-fantasy-tifa.jpg" width="100%" alt="Square Enix Bandai Namco Entertainment Ukraine" title="Square Enix Bandai Namco Entertainment Ukraine" /><br><br>

<img src="/upload/images/game/square-enix-bandai-namco-entertainment-donate-ukraine-dragon-ball-legends.jpg" width="100%" alt="Square Enix Bandai Namco Entertainment Ukraine" title="Square Enix Bandai Namco Entertainment Ukraine" /><br><br></center>

<p>Source: <a href="https://www.animenewsnetwork.com/interest/2022-03-15/square-enix-bandai-namco-ent-donate-to-ukraine/.183608" rel="nofollow" target="_blank" title="Square Enix Bandai Namco Entertainment Ukraine">Anime News Network</a></p>
'
        ]);

        posts::where('url_post', 'nier-automata-anime-teaser')->update([
            'name_en_post'    => "Nier: Automata is getting an anime",
            'present_en_post' => "The show was revealed by Japanese anime production company Aniplex",
            'content_en_post' => '<p>Square Enix has revealed that Nier: Automata is the next game to jump to television. Japanese anime and music production company
Aniplex premiered the news on its YouTube channel before word reached official social media channels.</p>

<p>Official website <a href="https://nierautomata-anime.com/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Nier: Automata anime</a></p>
<p>Official website <a href="https://www.jp.square-enix.com/nierautomata/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Nier: Automata Game</a></p>

<center><iframe width="100%" height="450" src="https://www.youtube.com/embed/2Bh-3CUNH4s" title="Nier: Automata game anime" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">It&#39;s actually happening.<br><br>A <a href="https://twitter.com/hashtag/NieR?src=hash&amp;ref_src=twsrc%5Etfw">#NieR</a>:Automata anime is on the way! <a href="https://t.co/3yIx2IWuVU">https://t.co/3yIx2IWuVU</a> <a href="https://t.co/jiDp4u61NB">pic.twitter.com/jiDp4u61NB</a></p>&mdash; NieR Series (@NieRGame) <a href="https://twitter.com/NieRGame/status/1496476859822972942?ref_src=twsrc%5Etfw">February 23, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script><br><br>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Everything that lives is designed to end.<br>We are perpetually trapped in a never-ending spiral of life and death.<br> <br>The smash hit action RPG from <a href="https://twitter.com/SquareEnix?ref_src=twsrc%5Etfw">@SquareEnix</a>, NieR:Automata announces an anime adaptation! <a href="https://t.co/SFNw35J5xk">pic.twitter.com/SFNw35J5xk</a></p>&mdash; Aniplex of America (@aniplexUSA) <a href="https://twitter.com/aniplexUSA/status/1496467525273780226?ref_src=twsrc%5Etfw">February 23, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Nier: Automata trailer anime and Aniplex&apos;s tweet</p></center>

<p>Set in the year 11945 AD, the story revolves around a proxy war between the human-made androids and the machine army of invaders from another world.
NieR: Automata tells the story of androids 2B, 9S and A2 and their battle to reclaim the machine-driven dystopia overrun by powerful machines.</p>

<center><img src="/upload/images/game/nier-automata-anime-teaser-1.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-2.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-3.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-4.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br></center>

<p>Androids 2B, 9S and A2 are heading to the small screen. Nier: Automata is receiving an anime adaptation, animation studio Aniplex confirmed in a Twitter announcement on Feb 23 2022.</p>

<p>Developed by Platinum Games and Square Enix, Nier: Automata is a role-playing game that&apos;s sold more than 6 million copies globally.</p>

<p>The video game publisher will be producing the TV series along with Aniplex, the studio responsible for other massive hits such as Fullmetal Alchemist and Sword Art Online.
According to Square Enix, the show will largely follow the story of the original game.</p>

<center><img src="/upload/images/game/nier-automata-anime-teaser-bg.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br></center>

<p>Source: <a href="https://www.cnet.com/culture/entertainment/nier-automata-anime-adaptation-in-development/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Anime News Network</a></p>
'
        ]);

        posts::where('url_post', 'overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map')->update([
            'name_en_post'    => "Overwatch 2 Beta begins June 28, will feature Junker Queen, a new map and hero redesigns",
            'present_en_post' => "Sign-ups and more details are coming June 16.",
            'content_en_post' => '<p>The second beta test for Overwatch 2 begins June 28, and will feature the game&apos;s newest character, Junker Queen, as well as a new map. Even better, the servers will be open not only for PC players, but those playing on console as well.</p>

<p>Blizzard announced the big news on the official Overwatch Twitter account, revealing the date for the beta,
the new features players will get to test out, and the signup date: June 16
The developer also shared more details about the beta will be announced on June 16, meaning even more exciting reveals could be on the horizon.</p>

<p>Source: <a href="https://www.gamespot.com/articles/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map/1100-6504595/" rel="nofollow" target="_blank" title="manga is booming north america">Gamespot</a></p>

<center><iframe width="100%" height="450" src="https://www.youtube.com/embed/r8k0eQ2yjns" title="Overwatch 2 Beta Junker Queen" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Junker Queen</p></center>

<p>Numerous characters--from Mercy to Bastion to Baptiste--are getting a redesign.
We don$apos;t yet know what characters will look like in the new game, but we$apos;ve rounded up all of the redesigns Blizzard has revealed so far below.</p>

<center><img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-bastion.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Bastion old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-sombra.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Sombra old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-baptiste.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Baptiste old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-torbjorn.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Torbjorn old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-cassidy.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Cassidy old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-pharah.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Pharah old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-reaper.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Reaper old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-widowmaker.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Widowmaker old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-mei.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Mei old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-genji.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Genji old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-tracer.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Tracer old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-winston.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Winston old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-reinhardt.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Reinhardt old (left) and new (right)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-lucio.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Lucio old (left) and new (right)</p>
</center>

<p>Source: <a href="https://www.gamespot.com/gallery/overwatch-2-hero-redesigns-see-how-characters-looks-have-changed/2900-3150/" rel="nofollow" target="_blank" title="manga is booming north america">Gamespot</a></p>
'
        ]);

        posts::where('url_post', 'open-world-terminator-game-in-development')->update([
            'name_en_post'    => "Open World Terminator Game In Development",
            'present_en_post' => "Survival Open World Game about Judgment Day and Terminator.",
            'content_en_post' => '<p>The Terminator will be back in an open world survival game.
Developed by Nacon Milan, a young studio with only the title Rims Racing under its belt, this untitled Terminator game will be set before the events of Judgement Day when the war between humans and machines begins.
The teaser image shows the T-800, the robot skeleton under Arnold Schwarzenneger&apos;s synthetic skin in the films, but no details so far on whether the iconic actor,
or any characters from the films, will make an appearance.</p>

<center><iframe width="100%" height="450" src="https://www.youtube.com/embed/HCWueOM4q-U" title="Open World Terminator Game" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Untitled Terminator Survival Game - Official Reveal Trailer</p></center>

<p>Terminator had some video game before, like Terminator: Resistance. That is a 2019 first-person shooter video game.</p>

<center><iframe width="100%" height="450" src="https://www.youtube.com/embed/KZSW_9ihCb8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Gameplay of Terminator: Resistance</p></center>

<p>The story of Terminator&apos;s series about a post-apocalyptic future where machines are at war with mankind, and it starred in two good movies and four not-so-good ones.
The cyborg (sometimes the terminator is covered in living tissue like skin and hair so it can pass for human) is known for traveling back in time from the future
to kill young John Connor, because in the future old John Connor is very good at fighting robots. Bad news, though: Connor&apos;s mom, Sarah, is also very good at fighting robots.</p>

<p>Source: <a href="https://www.gamespot.com/videos/open-world-terminator-game-in-development/2300-6458858/" rel="nofollow" target="_blank" title="Open World Terminator">Gamespot</a></p>
'
        ]); // 2022-07-08

        posts::where('url_post', 'nintendo-sexual-harassment-and-discrimination-claims-investigation')->update([
            'name_en_post'    => "Nintendo of America Testers Allege Sexual Harassment, Report Says",
            'present_en_post' => "Nintendo of America president ask employees to speak up if they have faced any form of harassment.",
            'content_en_post' => '<p>Nintendo of America is investigating reports that female game testers were subject to discrimination and harassment, according to internal messages seen by Kotaku.
Earlier this week, the publication published a scathing report exposing a toxic workplace culture at the company in which female staff and contractors were targeted by male colleagues.</p>

<p>According to Kotaku, Nintendo of America president Doug Bowser sent an email to employees acknowledging the claims on August 16th, the same day the report was released. In the message, Bowser stresses that the company is taking the allegations seriously, stating, "We have and will always investigate any allegations we become aware of, and we are actively investigating these most recent claims."</p>

<p>Bowser also highlighted that Nintendo has "strict policies designed to protect our employees and associates from inappropriate conduct and expect full compliance with these policies by all who work for or with us".</p>

<p>Source: <a href="https://www.theverge.com/2022/8/18/23311202/nintendo-harassment-and-discrimination-claims-investigation" rel="nofollow" target="_blank" title="nintendo sexual harassment">Theverge</a></p>

<p>It is worth noting that: when <a href="/post/activision-blizzard-sexual-harassment-lawsuit">Activision Blizzard accused of sexual harassment</a> in 2021,
Doug Bowser reportedly expressed concern over the ongoing situation at Activision Blizzard in a company-wide email, calling the allegations "distressing and disturbing."</p>

<p>"Along with all of you, I&apos;ve been following the latest developments with Activision Blizzard and the ongoing reports of sexual harassment and toxicity at the company. I find these accounts distressing and disturbing. They run counter to my values as well as Nintendo&apos;s beliefs, values and policies."</p>

<p>Activision CEO Bobby Kotick has found himself under pressure to resign, and has reportedly told the company he would consider stepping down if he&apos;s unable to quickly fix the ongoing issues at the company.</p>

<p>Source: <a href="https://www.ign.com/articles/nintendo-joins-sony-and-xbox-calling-activision-blizzard-reports-disturbing" rel="nofollow" target="_blank" title="nintendo sexual harassment">Theverge</a></p>

<h3>How Has Nintendo Responded?</h3>

<p>Source: <a href="https://earlygame.com/news/nintendo-america-sexual-harassment" rel="nofollow" target="_blank" title="nintendo sexual harassment">Early Game</a></p>

<p>Nintendo haven&apos;t reacted publically to the sexual harassment allegations, but in an internal memo the higher ups have asked employees to come forward if they&apos;re uncomfortable.
The memo tries to make pre-existing rules clear, but it&apos;s not as proactive as some would like:</p>

<blockquote>
<p>We have strict policies designed to protect our employees and associates from inappropriate conduct and expect full compliance with these policies by all who work for or with us.</p>

<p>If you experience, have experienced, witness, or have witnessed anything concerning such behavior that is contrary to our Standards of Conduct, employee handbook, or Company Values, please immediately contact your HR Business Partner.</p>
</blockquote>

<p>In 2021, Activision Blizzard has been caught up in a sexual harassment lawsuit. The incident has angered many protesters.</p>

<center><img src="/upload/images/game/sexual-harassment-2.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br>

<p>Fran Townsend called the allegations a "distorted and untrue picture of our company"</p>

<img src="/upload/images/game/nintendo-sexual-harassment-and-discrimination-claims-investigation-1.jpg" width="70%" alt="nintendo sexual harassment" /><br><br></center>

<p>Women who worked at Nintendo of America alleged some male colleagues would make "really gross jokes and comments",
and were threatened with retaliation if they reported incidents to HR ⁠— including dismissal. These stories were outlined in an August 16 Kotaku report.</p>

<p>The report also named Melvin Forrest, one of the company&apos;s top product testers, as encouraging this culture.
"It was pretty common knowledge that he would make comments, hit on people, like to [tell] associates, &apos;Oh she&apos;s so beautiful&apos;" one tester said.</p>

<p>Source: <a href="https://www.dexerto.com/gaming/nintendo-addresses-sexual-harassment-claims-american-office-1907213/" rel="nofollow" target="_blank" title="nintendo sexual harassment">Dexerto</a></p>

<p>Nintendo Co., Ltd. is a Japanese multinational video game company headquartered in Kyoto, Japan.
It has created numerous major franchises, including The Legend of Zelda, Animal Crossing: New Horizons, Super Smash Bros, Fall Guys.</p>

<p>Nintendo and Blizzard is two of the game companies whose characters appear on adult websites: princess Zelda, Mario, Bayonetta and special is Pokémon (?).</p>

<center><img src="/upload/images/game/the-legend-of-zelda-princess-1.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<img src="/upload/images/game/the-legend-of-zelda-princess-2.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<img src="/upload/images/game/the-legend-of-zelda-princess-3.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<img src="/upload/images/game/the-legend-of-zelda-princess-4.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<img src="/upload/images/game/the-legend-of-zelda-princess-5.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<p>Princess Zelda in The Legend of Zelda</p></center>
'
        ]); // 2022-08-18

        posts::where('url_post', 'eva-elfie-interview-dota-2-support-causes-tundra-navi-win')->update([
            'name_en_post'    => "Eva Elfies interview Dota 2 player, support causes Tundra and Navi to win",
            'present_en_post' => "Eva Elfie buff is real?",
            'content_en_post' => '<p>Eva Elfie is a Russian pornographic actress, nude model, and YouTuber. She is the winner of the AVN Awards in the category Best New Foreign Starlet in 2021.</p>

<p>YouTube: <a href="https://www.youtube.com/channel/UCulpMq-W5E_OYziBJhxdUpg" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Instagram: <a href="https://www.instagram.com/theevaelfie/" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Twitter: <a href="https://twitter.com/evaelfie" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>

<center><img src="/upload/images/game/eva-elfie-1.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>

<p>She interview Dota 2 players and took a picture with Aegis of the Immortal shield.</p>

<center><img src="/upload/images/game/eva-elfie-dota-2-1.jpg" width="100%" alt="Pornhub Game Awards" /><br><br>

<img src="/upload/images/game/eva-elfie-dota-2-2.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO" /><br><br>

<p>Eva Elfies with Aegis of the Immortal shield in Dota 2</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/uC3dWk3LhXU" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/iVyp2z87AC8" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>by Eva Elfie interview Dota 2 players in TI11 The International 2022</p></center>

<p>Specially, the "Eva Elfie buff" is what made her famous. She was support to Tundra Esports (Dota 2) and Natus Vincere (CSGO). Both team had impressive wins.</p>

<p>Source: <a href="https://clutchpoints.com/eva-elfies-support-causes-tundra-navi-win" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Clutch Points</a></p>

<p>Elfie appeared in the Singapore Indoor Stadium to show her support to Tundra Esports, who would later win The International with a clean sweep against Team Secret, taking home $8,518,822.</p>

<center><img src="/upload/images/game/eva-elfie-dota-2-tundra.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO" /><br><br>

<p>Eva Elfie was wearing Tundra uniform</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/UhQmAfzaw7c" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Dota 2 The International 2022 - Main Event - Final Day</p></center>

<p>Eva Elfie also attended the CSGO Major at Riocentro, Brazil, this time in support of CSGO team Natus Vincere, much more commonly known as Navi.
Navi, who hasn$apos;t been in their best shape recently, actually won their matches on that day when Elfie was in the stadium showing her support.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Adult Star Eva Elfie is at the CSGO Major and cheering for NAVI and S1mple<br><br>They won today <a href="https://t.co/800tOk8CZ2">pic.twitter.com/800tOk8CZ2</a></p>&mdash; Jake Lucky (@JakeSucky) <a href="https://twitter.com/JakeSucky/status/1589696877091749889?ref_src=twsrc%5Etfw">November 7, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/zlFmD1-bnw0" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>November 8th 2022, Navi win BIG</p></center>

<p>On Twitter, they said:</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Eva Elfie buff is real</p>&mdash; Out of Context Dota 2 (@NoContextDota2) <a href="https://twitter.com/NoContextDota2/status/1586702677219901440?ref_src=twsrc%5Etfw">October 30, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>What do you think? Do you believe in the "Eva Elfie buff", or her supporting winning teams simply a coincidence?</p>

<center><img src="/upload/images/game/eva-elfie-1-eng.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>
'
        ]);


        posts::where('url_post', 'pornhub-game-awards-2022')->update([
            'name_en_post'    => "Pornhub Game Awards 2022",
            'present_en_post' => "Here are some stats that will interest you before we get to the video game characters-related one.",
            'content_en_post' => '<p>The Game Awards 2022 was an award show that honored the best video games of 2022.</p>

<p>Right after The Game Awards 2022 ended, Pornhub, the world&apos;s largest adult movie platform, also had their The Game Awards.</p>

<p>Source: <a href="https://www.reddit.com/r/hiphopheads/comments/9dqc0w/game_thread_pornhub_awards/" rel="nofollow" target="_blank" title="Pornhub Game Awards">Reddit</a></p>

<h2>Most Searched for Video Games</h2>

<center><img src="/upload/images/game/pornhub-game-awards-2022-most-searched-video-games.jpg" width="100%" alt="Pornhub Game Awards" /><br><br>

<p>Fortnite is winner on PornHub</p></center>




<h2>Most Searched Video Game Characters</h2>

<center><img src="/upload/images/game/pornhub-game-awards-2022-most-searched-video-game-characters.jpg" width="100%" alt="Pornhub Game Awards" /><br><br>

<p></p></center>

<p><strong>#1 D.Va (Overwatch)</strong></p>

<p>D.Va is a Tank hero in Overwatch. She has a mech with famous ultimate: Self-Destruct. D.Va&apos;s ultimate voice line: "Nerf this!".</p>

<center><img src="/upload/images/game/dva-1-eng.jpg" width="70%" alt="Pornhub Game Awards D.Va" /><br><br></center>

<p><strong>#2 Jenny Mod (Minecraft)</strong></p>

<p></p>

<p><strong>#3 Widowmaker (Overwatch)</strong></p>

<p>Widowmaker is a Damage Hero in Overwatch. She equips herself with whatever it takes to eliminate her targets, including mines that dispense poisonous gas, a visor that grants her squad infra-sight, and a powerful sniper rifle that can fire in fully-automatic mode.</p>

<center><img src="/upload/images/game/widowmaker-1-eng.jpg" width="70%" alt="Pornhub Game Awards Widowmaker" /><br><br></center>

<p></p>

<p><strong>#4 Lady Dimitrescu (Resident Evil Village)</strong></p>

<center><img src="/upload/images/game/lady-dimitrescu-1-eng.jpg" width="100%" alt="Pornhub Game Awards Lady Dimitrescu" /></center>

<p><strong>#5 Mercy (Overwatch)</strong></p>

<p>Mercy is a Support hero in Overwatch. She is one of the 21 heroes included in the game&apos;s release on 24 May 2016.
A guardian angel to those who come under her care, Dr. Angela Ziegler is a peerless healer, a brilliant scientist, and a staunch advocate for peace.</p>

<p>Mercy is able to revive any nearby fallen teammate, restoring them to full health at the location of their respective soul globe.
Mercy used to be so OP. The ability allowed Mercy to resurrect entire teams, with up to five players able to be brought back all at once.</p>

<center><img src="/upload/images/game/mercy-2-eng.jpg" width="70%" alt="Overwatch Mercy" /></center>

<p><strong>#6 Tracer (Overwatch)</strong></p>

<p></p>

<center><img src="/upload/images/game/tracer-dva-1-eng.jpg" width="100%" alt="Overwatch Tracer DVA" /></center>

<p><strong>#7 Mona (Genshin Impact)</strong></p>

<p>Astrologist Mona Megistus is a playable Hydro character in Genshin Impact.</p>

<p>An astrologist of knowledgeable skill and high pride, Mona has settled in Mondstadt to avoid suffering the ire of her master after unwittingly reading the latter&apos;s diary.</p>

<center><img src="/upload/images/game/astrologist-mona-megistus-1.jpg" width="100%" alt="Astrologist Mona Megistus Genshin Impact" /></center>

<p><strong>#8 Ruby (Fortnite)</strong></p>

<p></p>

<p><strong>#9 Mei (Overwatch)</strong></p>

<p></p>

<center><img src="/upload/images/game/mei-2-eng.jpg" width="100%" alt="Overwatch Mei" /><br><br></center>

<p><strong>#10: Slime (Genshin Impact)</strong></p>

<p></p>

<p></p>

<p><strong>#11: Aura (Fortnite)</strong></p>

<p></p>

<p></p>

<p><strong>#12: Chun-li (Street Fighter)</strong></p>

<p>Chun-Li is the tritagonist and main female protagonist of the Street Fighter series, originally debuting in Street Fighter II.
The first female fighter in the series, she is an expert martial artist and Interpol officer who relentlessly seeks revenge for the death of her father at the hands of M. Bison.</p>

<center><img src="/upload/images/game/chun-li-1-eng.jpg" width="70%" alt="Chun-li Street Fighter" /><br><br></center>

<p><strong>#13: Jett (Valorant)</strong></p>

<p>Jett is the most favorite duelist in Valorant. Representing her home country of South Korea, Jett&apos;s agile and evasive fighting style lets her take risks no one else can. She runs circles around every skirmish, cutting enemies before they even know what hit them.</p>

<p>Jett is Yasuo in Valorant. She can use the wind power to dash, fly and cut enemies with her knives. Yasuo in League of Legends is Samurai, Jett is ninja. They are same fighting style.</p>

<center><img src="/upload/images/game/jett-1-eng.jpg" width="100%" alt="Overwatch Jett" /><br><br></center>

<p><strong>#14: Hu Tao (Genshin Impact)</strong></p>

<p></p>

<p></p>

<p></p>

<p>Ohter Characters:</p>

<p><strong>#15: Eula (Genshin Impact)</strong></p>

<p><strong>#16: Lynx (Fortnite)</strong></p>

<center><img src="/upload/images/game/lynx-fortnite-1-eng.jpg" width="70%" alt="Pornhub Game Awards Ashe Overwatch" /><br><br></center>

<p><strong>#17: Lisa (Genshin Impact)</strong></p>

<p><strong>#18: Evie (Fortnite)</strong></p>

<p><strong>#19: Ashe (Overwatch)</strong></p>

<center><img src="/upload/images/game/ashe-overwatch-1-eng.jpg" width="70%" alt="Pornhub Game Awards Ashe" /><br><br>

<img src="/upload/images/game/ashe-overwatch-2-eng.jpg" width="70%" alt="Pornhub Game Awards Ashe Overwatch" /><br><br></center>

<p><strong>#20: Tristana (League of Legends)</strong></p>

<center><img src="/upload/images/game/tristana-1-eng.jpg" width="70%" alt="Pornhub Game Awards Tristana" /><br><br></center>

'
        ]); // 2022-12-20

        posts::where('url_post', 'hermione-and-professors-on-hogwarts-legacy-is-famous-of-rule-34')->update([
            'name_en_post'    => "Hermione and professors on Hogwarts Legacy is famous of... Rule34",
            'present_en_post' => "The most famous character is Hermione Granger, played by actress Emma Watson",
            'content_en_post' => '<p>Hogwarts Legacy is an immersive, open-world action RPG set in the world first introduced in the Harry Potter books. Hogwarts Legacy is a action role-playing game developed by Avalanche Software and published by Warner Bros.
Following some delays, it was released on 10 February 2023 for PlayStation 5, Windows, and Xbox Series X/S. It is scheduled for release on PlayStation 4, Xbox One, and Nintendo Switch later in 2023.</p>

<p>Official Website: <a href="https://www.hogwartslegacy.com/en-us" rel="nofollow" target="_blank" title="Hogwarts Legacy Official Website">Hogwarts Legacy</a></p>

<p>Hogwarts Legacy is by far the most successful Harry Potter game of all time, and it&apos;s on its way to becoming one of the most successful RPGs, as well. But it has many problem about LGBT community and VTubers,</p>

<p>More: </p>

<p>Of cause, famous games will appear on Rule34. Hogwarts Legacy appeared on the adult websites with images of female characters.
The most famous is Hermione Granger, played by actress Emma Watson in the Harry Potter film series. Some pictures had been drawn by A.I.</p>

<center><img src="/upload/images/game/emma-watson-hermione-1.jpg" width="100%" alt="Hogwarts Legacy Hermione"><br><br>

<p>Hermione Granger, played by actress Emma Watson</p>

<img src="/upload/images/game/hogwarts-legacy-hermione-1.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-2.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-2-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-3.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-4.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-5.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-3-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-4-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-5-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-6-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-7-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-8-eng.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br></center>

'
        ]); // https://rule34.xxx/index.php?page=post&s=list&tags=hermione_granger+

        posts::where('url_post', 'koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist')->update([
            'name_en_post'    => "Koei Tecmo allegedly sends DMCA takedown on Dead or Alive fan artist",
            'present_en_post' => "Tất cả hình ảnh về Dead or Alive trên tài khoản mạng xã hội X của họa sĩ này đã bị xóa",
            'content_en_post' => '<p></p>

<p></p>

<p>Twitter: <a href="https://twitter.com/lewdgazer" rel="nofollow" target="_blank" title="Koei Tecmo DMCA Dead or Alive">lewdgazer</a></p>

<p>X account and Pixiv account of lewdgazer had been deleted all videos, images about Dead or Alive game.</p>

<center><img src="/upload/images/game/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist-lewdgazer.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br>

<img src="/upload/images/game/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist-lewdgazer-1.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br>

<p>Tweet of lewdgazer had been deleted.</p></center>

<p></p>

<p></p>

<center><img src="/upload/images/game/dead-or-alive-helena-douglas-1.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br></center>

<p></p>

<p></p>

<p>Source: <a href="https://nichegamer.com/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist/" target="_blank" title="Koei Tecmo DMCA Dead or Alive">Niche Gamer</a></p>
'
        ]); // 2023-10-06





// https://n4g.com/news/2479832/vr-adventure-game-forbidden-ninja-scroll-patreon-startstoday-hardcore-gamers-unified

    }
}




//
