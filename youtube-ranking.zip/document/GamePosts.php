<?php
namespace App\Seeder\postsSeeder;

use App\Models\posts;
use DB;
use Illuminate\Support\ServiceProvider;

class GamePosts
{
    public function index()
    {
        posts::create([
            'name_vi_post'    => 'World of Warships ra mắt Open Beta',
            'url_post'        => 'world-of-warships-open-beta',
            'present_vi_post' => 'World of Warships, tựa game hải chiến hấp dẫn đã được hãng Wargaming chính thức Open Beta vào ngày 2/7/2015',
            'content_vi_post' => '<p>Game hải chiến World of Warships đã khởi động Open Beta vào ngày 2/7/2015. </p>

<p>World of Warships là tựa game hải chiến, bắn tàu được sản xuất bởi Wargaming, hãng sản xuất game nổi tiếng được nhiều game thủ Việt biết đến với game online World of Tanks.</p>

<p>Trang chủ <a href="http://worldofwarships.asia/" rel="nofollow" target="_blank" title="World of Warships">World of Warships</a> châu Á.</p>

<center><img src="/upload/images/game/World-of-Warships.jpg" width="70%" alt="World of Warships ra mắt Open Beta" /></center>

<p>Trò chơi tương tự như World of Tanks. Người chơi điều khiển các loại tàu chiến của các nước khác nhau như Mỹ, Nga, Nhật... chiến đấu tại các chiến trường khác nhau như băng tuyết, quần đảo hay một vùng biển không có đất liền. Nhiệm vụ của các phe là bắn hạ hết tàu của đối thủ.</p>

<center><img src="/upload/images/game/World-of-Warships-1.jpg" width="70%" alt="World of Warships ra mắt Open Beta" /></center>

<p>Trong bản Open Beta này, người chơi sẽ có thể sử dụng hơn 80 tàu chiến của Mỹ và Nhật Bản cùng với các tàu mới được thêm vào từ Vương quốc Anh và Liên Xô. Thậm chí người chơi có thể điều khiển tàu sân bay, ra lệnh cho máy bay tiêu diệt mục tiêu hoặc điều khiển tàu ngầm, gieo rắc cái chết bất ngờ.</p>

<center><img src="/upload/images/game/World-of-Warships-2.jpg" width="70%" alt="World of Warships ra mắt Open Beta" /></center><br>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/TgkM10WAOdM" frameborder="0" allowfullscreen></iframe></center>
',

            'date_post'         => '2015-07-14',
            'thumbnail_post'    => 'world-of-warships-open-beta-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Phantasmat 4 Dread of Oakville - Thị trấn Oakville kinh hoàng',
            'url_post'        => 'Phantasmat-4-dread-of-oakville-thi-tran-oakville-kinh-hoang',
            'present_vi_post' => 'Bạn đang đi trên đường, đột nhiên gặp một cơn bão lớn. Bạn thấy có ánh sáng ở vách núi liền chạy xe vào đó. Vách núi đổ sập và bạn chỉ có thể tiến lên, bước vào một thị trấn ma ám.',
            'content_vi_post' => '<p>Dòng game phiêu lưu, giải đố thường ít thu hút người chơi do sự đặc thù của nó. Những game phiêu lưu, giải đố khiến nhiều người chơi cảm thấy đau đầu khi giải đố, dẫn đến mất kiên nhẫn. Tuy nhiên, sự hấp dẫn của dòng game này cũng chính là những câu đố hóc búa đó. Khi người chơi phát hiện ra đường đi mới, lắp ghép được những món đồ mới hay giải được một câu đố hóc búa, cảm giác vui sướng thật khó tả.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/0vEWIfx-RTw" frameborder="0" allowfullscreen></iframe></center>

<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Phantasmat 4 Dread of Oakville.
<li>Thể loại: phiêu lưu, giải đố, kinh dị.
<li>Sản xuất năm: 2015.
<li>Hãng sản xuất: Eipix.
<li>Cấu hình: Bộ vi xử lý 2Ghz, RAM 1024 MB, dung lượng ổ cứng 807 MB,  hệ điều hành Windows XP/Windows Vista/Windows 7/Windows 8, MAC.
<li><a href="https://www.eipix.com/hopa-games/" rel="nofollow" target="_blank" title="Phantasmat 4 Dread of Oakville">Trang chủ Eipix.</a>
</ul>

<p><b>Link download (chỉ cần download về và cài đặt miễn phí)</b></p>

<p><a href="https://drive.google.com/file/d/0B9EX0DsknnyebWFDTzR4ODFjYjQ/view?usp=share_link&resourcekey=0-u5myGt-kvEwtcx5EdTJ3cw" rel="nofollow" target="_blank" title="Phantasmat 4 Dread of Oakville">Google Drive KINGDOM NVHAI</a></p>

<p><b>Hướng dẫn chơi từ đầu đến cuối trên <a href="https://www.bigfishgames.com/blog/walkthrough/phantasmat-the-dread-of-oakville-strategy-guide-hints-cheats-codes-tips-tricks/">bigfishgames</a></b></p>

<center><img src="/upload/images/game/Phantasmat-4-Dread-of-Oakville.jpg" width="70%" alt="Phantasmat 4 Dread of Oakville Thị trấn Oakville kinh hoàng" /></center>

<p>Trích lời giới thiệu của hãng Eipix về game:</p>

<p>“Khi lần đầu tiên bạn đến với thị trấn Oakville, bạn nghĩ rằng: "Nơi này có vẻ là một nơi đáng yêu để giết thời gian cho đến khi cơn bão trôi qua”. Ồ, nhưng bạn đã lầm. Bây giờ chỉ có một ý nghĩ trong tâm trí bạn - TRỐN THOÁT!<br>
Hãy cẩn thận nếu bạn muốn rời khỏi nơi này...”</p>

<p>Trò chơi theo dạng góc nhìn người thứ nhất và quan sát tranh tĩnh. Trước mắt bạn là một khung cảnh tĩnh và bạn sẽ phải mò mẫm từng góc cạnh của hình để không bỏ sót bất kỳ món đồ hay lối đi nào. Bạn sẽ phải nhặt tất cả những món đồ, giải các câu đố và tìm đường đi cho mình để tìm hiểu xem sức mạnh ma quỷ nào đã ám lên thị trấn nhỏ bé ven biển này. Và đương nhiên, mục tiêu cuối cùng là thoát ra khỏi đây.</p>

<p>Khi vừa vào game, điều khiến KINGDOM NHAI thích thú là về đồ họa của trò chơi. Dù dung lượng trò chơi rất nhẹ nhưng đồ họa không hề kém chút nào. Cảnh mưa, sấm sét, những hình ảnh rùng rợn khiến KINGDOM NVHAI cảm thấy rất thích thú. Màu sắc khá tươi sáng, không mang vẻ âm u rùng rợn nhưng vẫn tạo nên bản sắc riêng, sự hồi hộp riêng.</p>

<center><img src="/upload/images/game/Phantasmat-4-Dread-of-Oakville-3.jpg" width="70%" alt="Phantasmat 4 Dread of Oakville Thị trấn Oakville kinh hoàng" />

<p>Anh chàng James này không biết mình đã bị mất tích.</p></center>

<p>Trò chơi có cách bố cục khá tốt. Kho đồ, bản đồ và tất cả các nút điều khiển được gom lại ở phía dưới giúp người chơi dễ dàng xem và sử dụng chúng. Bản đồ giúp người chơi dễ xác định được phương hướng trong thị trấn.</p>

<center><img src="/upload/images/game/Phantasmat-4-Dread-of-Oakville-2.jpg" width="70%" alt="Phantasmat 4 Dread of Oakville Thị trấn Oakville kinh hoàng" /></center>

<p>Tuy nhiên, điểm trừ cho trò chơi này là phần hướng dẫn. Nếu bạn chọn chế độ dễ thì trò chơi sẽ hiện ra toàn bộ hướng dẫn. Thậm chí, khi bạn giải đố, nút HINT sẽ giải luôn câu đố giúp bạn. Dù trò chơi khá nhẹ và khá dễ chơi nhưng việc để hướng dẫn như thế không hợp lý, nhất là đối với một game giải đố cần sự động não và kiên nhẫn. Thời lượng và độ khó của game cũng tương đối ngắn.</p>

<p>Nói chung, Phatasmat 4 Dread of Oakville là một game mang tính chất giải trí nhưng vẫn có sức hấp dẫn riêng. Trò chơi cũng có những màn hù dọa khiến người chơi giật mình. Nếu bạn cần tìm một game giải trí nhẹ nhàng mà hấp dẫn thì Phatasmat 4 Dread of Oakville rất đáng để bạn trải nghiệm.</p>',

            'date_post'         => '2015-07-19',
            'thumbnail_post'    => 'Phantasmat-4-Dread-of-Oakville-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Tô Đức Quỳnh ra mắt Huyền Thoại Lục Địa MU phần 2',
            'url_post'        => 'To-Duc-Quynh-ra-mat-Huyen-Thoai-Luc-Dia-MU-phan-2',
            'present_vi_post' => 'Huyền Thoại Lục Địa MU - tác phầm đầu tiên của Việt Nam viết về game online do tác giả Tô Đức Quỳnh phát hành đã ra mắt phần 2 vào ngày 26/6/2015.',
            'content_vi_post' => '<p>Đối với đa phần game thủ Việt Nam, đặc biệt là những fans trung thành của MU Online, chắc chắn đã không còn xa lạ với tác giả Tô Đức Quỳnh, một game thủ kì cựu của MU Online, đồng thời cũng là tác giả cuốn sách “Huyền Thoại Lục Địa MU” được xuất bản vào tháng 9/2011 bởi Nhà Xuất Bản Kim Đồng. Cuốn sách đã trải qua 6 năm viết và 2 năm thẩm định để có được sự công nhận từ giới chuyên môn, trở thành một trong những tiểu thuyết giả tưởng hiếm hoi do người Việt sáng tác, và là tác phẩm văn học đầu tiên viết về Game Online tại Việt Nam.</p>

<center><img src="/upload/images/game/To-Duc-Quynh-Huyen-Thoai-Luc-Dia-MU.jpg" width="70%" alt="Tô Đức Quỳnh ra mắt Huyền Thoại Lục Địa MU phần 2" />

<p>Tô Đức Quỳnh, tác giả Huyền Thoại Lục Địa MU</p></center>

<p>Thời điểm đó, game online Việt Nam chịu nhiều sức ép từ xã hội, giới truyển thông về những thông tin không tốt về game online và những game thủ. 2 game lão làng nhất thời đó là Võ Lâm Truyền Kỳ và MU Việt Nam vẫn trụ được suốt một thời gian dài. Nhưng sau những vụ việc NPH FPT để xảy ra nhiều lỗi, khiến những game thủ kỳ cựu, gắn bó với MU Việt Nam suốt 9 năm đã bỏ đi. Và cuối cùng, MU Online sẽ chính thức đóng cửa vào ngày 27/7/2014.
</p>

<p>Trong thời gian MU Việt Nam hoạt động, FPT đã có những cộng tác viên nhiệt tình như phóng viên NVHAI, thi sĩ Mystery@, BeMyMy... Tô Đức Quỳnh là một trong số đó. Anh đã viết ra phần 1 truyện Huyền Thoại Lục Địa MU. Truyện đã được phát hành và tặng miễn phí trong lần sinh nhật MU thứ 6. Và chỉ trong thời gian ngắn, quyển sách đã được bán hết.</p>

<center><img src="/upload/images/game/Sinh-nhat-MU-Viet-Nam-lan-6.jpg" width="70%" alt="Tô Đức Quỳnh ra mắt Huyền Thoại Lục Địa MU phần 2" />

<p>Sinh nhật MU Việt Nam lần 6</p></center>

<p>Và sau nhiều khó khăn, phần 2 của quyển sách đã được anh ra mắt. Trên trang Facebook Huyền Thoại Lục Địa MU, anh thông báo quyển sách chính thức phát hành vào ngày 26/6/2015 với 3000 bản đầu tiên. </p>

<center><img src="/upload/images/game/Huyen-Thoai-Luc-Dia-MU-phan1-phan2-4.jpg" width="70%" alt="Tô Đức Quỳnh ra mắt Huyền Thoại Lục Địa MU phần 2" />

<p>Huyền Thoại Lục Địa MU phần 1 và 2 của NVHAI mua</p></center>

<p>Giá quyển sách là 96.000 đồng. Tuy nhiên, một số điểm bán sách có giá ưu đãi hơn. Ở tiệm sách 142 Trần Huy Liệu, P15, Quận Phú Nhuận, TP.Hồ Chí Minh, KINGDOM NVHAI mua chỉ với giá 72.000 đồng. Địa chỉ các nhà sách có bán tại <a href="https://www.facebook.com/huyenthoailucdiamu/posts/805552339539955:0">đây. </a></p>

<p>Tác giả Tô Đức quỳnh đã chia sẻ: Phần 2 của Huyền thoại lục địa MU đã được biên tập lại theo đúng chuẩn phong cách của Walt Disney với giọng văn hoàn toàn mới của người Việt. Bởi vậy anh rất tự tin khi nói rằng: “Đây sẽ là một cuốn truyện Việt Nam mang đẳng cấp quốc tế”.</p>

<center><img src="/upload/images/game/To-Duc-Quynh-ra-mat-Huyen-Thoai-Luc-Dia-MU-phan-2-Merlin-P-Mann-va-Jan-Kjaer.jpg" width="50%" alt="Tô Đức Quỳnh ra mắt Huyền Thoại Lục Địa MU phần 2" />

<p>Nhà biên kịch Merlin p.mann (áo đen) và họa sỹ Jan Kjaer (áo xanh) là 2 người thầy đã góp phần nâng cao chất lượng viết của Huyền Thoại Lục Địa MU 2</p></center>

<p>Tác giả cũng chia sẻ về những khó khăn trong quá trình viết sách. </p>

<p>"Nếu được coi hành trình viết sách và xuất bản sách là 100% thì khó khăn đã chiếm tới 90%. Nói vậy để bạn hiểu tôi đã vượt qua những gì để cuốn sách ấy có thể có mặt trên đời. Mười năm kiên trì theo đuổi ước mơ gặp rất nhiều khó khăn đến từ chính gia đình, bạn bè và người thân. Họ ngăn cản, chê bai, không những vậy, nhiều người còn ném đá, coi đó là việc bất khả thi. Trong con mắt họ, game thủ là 1 thằng ăn tàn phá hại cắm đầu chơi game chẳng bao giờ khá lên được.</p>

<p>Nhưng tôi đã chứng minh điều ngược lại. Chỉ cần có niềm tin, không gì là không thể. Hôm nay, tôi vẫn ở đây cùng với cuốn sách phần 2. Còn họ thì đã mãi mãi biến mất. Ước mơ là không giới hạn, hãy cứ làm đi. Ngoài ra, tôi còn gặp khá nhiều khó khăn về kinh phí trong quá trình thực hiện 2 tập tiểu thuyết này."
</p>

<p>Xin chúc anh Tô Đức Quỳnh có nhiều sức khỏe và tiếp tục cống hiến cho cộng đồng game thủ Việt những tác phẩm hấp dẫn và mới mẻ, xây dựng hình ảnh game Việt ngày càng tốt đẹp hơn.</p>',

            'date_post'         => '2015-07-18',
            'thumbnail_post'    => 'To-Duc-Quynh-Huyen-Thoai-Luc-Dia-MU-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Heroes of Might and Magic V',
            'url_post'        => 'Heroes-of-Might-and-Magic-V',
            'present_vi_post' => 'Heroes of Might and Magic sau khi thuộc về Ubisoft, liệu hãng này có thể hồi sinh lại ánh hào quang của một trong số tựa game dàn trận có tuổi đời lão làng này không?',
            'content_vi_post' => '<p>Sau thất bại của Heroes of Might and Magic IV, hãng 3DO tuyên bố phá sản. Heroes of Might and Magic tưởng chừng sẽ bị chôn vùi theo chủ. Nhưng sau này, hãng Ubisoft đã hồi sinh series game này với phần thứ 5 và thêm 2 phần mở rộng là Heroes of Might and Magic V Hammers of Fate và Heroes of Might and Magic V Tribes of the East.</p>

<center><img src="/upload/images/game/Heroes-of-might-and-magic-V-Wallpaper.jpg" width="100%" alt="Heroes of Might and Magic V" /></center>

<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Heroes of Might and Magic V.
<li>Thể loại: dàn trận theo lượt.
<li>Sản xuất năm: 16/5/2006.
<li>Hãng sản xuất: Ubisoft.
<li>Cấu hình:  Pentium 4 / Athlon 1.5 GHz or higher, RAM 512 MB, card màn hình 28 MB AGP GeForce4 Ti4200 / RADEON 8500, Windows 2000/XP, Win7, Win8.
</ul>

<p><b>Link download</b></p>

<ul>
<li><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZeFhOX2gzYnRkVGc/view?usp=sharing&resourcekey=0-IHJj3DcbtsW88ii8SUkLCg" rel="nofollow" target="_blank" title="Heroes of Might and Magic V">File ISO (Sử dụng Daemon Tool Lite để đọc ổ đĩa ảo)</a>
<li><a href="https://drive.google.com/drive/folders/0B2QqgPEJF0YZfjFPeldsbW9Kd0NRQkpuMnlBZmFyU3dzVV9sR2NuX3B5WUVrWGNRRnUyZHM?resourcekey=0-gFcaVYv15O3XlhzEZQpm4A&usp=sharing" rel="nofollow" target="_blank" title="Heroes of Might and Magic V">File rar Google Drive KINGDOM NVHAI (download về rồi giải nén)</a>
<li>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4. Nhớ cài đặt phần free, không cần crack</a>
</ul>

<center><img src="/upload/images/game/Heroes-of-might-and-magic-V.jpg" width="100%" alt="Heroes of Might and Magic V" />

<p>Các trận đánh giữa các đơn vị đôi lúc sẽ hiện hình ảnh cận cảnh</p></center>

<p>Vẫn theo phong cách của dòng game Heroes of Might and Magic, người chơi sẽ chọn cho mình một tòa thành, tạo hero dẫn quân đi tấn công những con quái vật trên bản đồ, đánh chiếm các khu mỏ tài nguyên và kết thúc game khi chiếm được thành của đối thủ. Trong quá trình chiến đấu, hero của bạn sẽ được tăng kinh nghiệm và bạn có thể chọn nâng cấp kỹ năng cho hero.</p>

<p>Ưu điểm dễ nhận thấy nhất là đồ họa. Tất nhiên là hãng Ubisoft đã nâng cấp đồ họa lên thành 3D, có thể xoay chuyển camera dễ dàng. Khi bạn cho các đơn vị chiến đấu, sẽ có cảnh quay cận cảnh trông sống động hơn. Game bao gồm cả 5 kiểu chơi khác nhau (cả trực tuyến lẫn ngoại tuyến). Chơi một mình, hoặc cùng người khác qua mạng Lan, hoặc mạng trực tuyến internet...</p>

<center><img src="/upload/images/game/Heroes-of-might-and-magic-V-2.jpg" width="100%" alt="Heroes of Might and Magic V" /></center>

<p>Heroes of Might & Magic V sẽ có 6 thành phố xuất hiện, đó là Loài người - Haven, loài quỷ - Inferno, Thầy phép - Necropolis, yêu tinh bóng đêm - Dungeon, Phù thủy - Academy, và yêu tinh - Sylvan. Yêu tinh bóng đêm chính là bổ sung mới của bản này. Đây cũng là điểm trừ đầu tiên của phiên bản này. Nếu như trong phần 3, người chơi có đến 9 thành phố thì bây giờ chỉ còn 6.</p>

<p>Điểm trừ thứ 2 là hình ảnh dù được nâng cấp lên thành 3D nhưng không hẳn là đẹp. Một số hình ảnh quái vật vẫn còn hơi cứng. Thất vọng nhất là phần bối cảnh trong tòa thành. Nếu như phần 3, tòa thành là một bức tranh rất đẹp, bố cục gọn gang dễ nhìn thì phần 5, dù là hình ảnh 3D cho phép người chơi xem từng công trình nhưng nhìn tổng thể, bức tranh không đẹp như trước.</p>

<p>Phần bản đồ cũng quá ít so với phần 3 nhưng bạn có thể download các bản đồ mới trên mạng.</p>

<center><img src="/upload/images/game/Heroes-of-might-and-magic-III.jpg" width="100%" />

<p>Tòa thành Haven phần 3 nhìn toàn cảnh</p>

<img src="/upload/images/game/Heroes-of-might-and-magic-V-3.jpg" width="100%" alt="Heroes of Might and Magic V" />

<p>Tòa thành Haven phần 5 nhìn toàn cảnh</p></center>

<p>Một điểm cộng khác của game là Hero giờ có thể sử dụng đòn đánh thường. Trong Heroes of Might and Magic III, các Hero chỉ tấn công bằng kỹ năng tiêu tốn mana. Giờ họ có thể đánh thường trong mỗi lượt như các đơn vị khác. Qua đó tính hiệu quả của Hero tăng lên</p>

<center><img src="/upload/images/game/Heroes-of-might-and-magic-V-4.jpg" width="70%" />

<p>Hero bắn cung vào đối thủ</p></center>

<p>Heroes of Might and Magic V nhìn chung vẫn đáp ứng được kỳ vọng của fan hâm mộ nhưng vẫn chưa vượt qua cái bóng lớn của chính mình trong các phiên bản trước. Hy vọng trong các phần tiếp theo, hãng Ubisoft sẽ làm tốt hơn.</p>
',

            'date_post'         => '2015-07-20',
            'thumbnail_post'    => 'Heroes-of-might-and-magic-V-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => "[Review] King's Bounty The Legend",
            'url_post'        => 'King-Bounty-The-Legend',
            'present_vi_post' => "Kết hợp giữa thể loại nhập vai và dàn trận theo lượt, King's Bounty The Legend dù có phong cách giống với Heroes of Might and Magic nhưng vẫn tạo được sức hút riêng.",
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Kings Bounty The Legend
<li>Thể loại: dàn trận theo lượt.
<li>Sản xuất năm: 23/9/2008
<li>Hãng sản xuất: Katauri Interactive
<li>Cấu hình: Intel Pentium 4 or AMD Athlon 64 2800+ 2.6 GHz Processor, RAM 1GB, 5.5GB Hard Disk Space, DirectX 9.0c, 256MB Nvidia GeFirce 6800/ATI Radeon X800 Video Card
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZSmlFTEpvMHNxaTA/view?usp=sharing" rel="nofollow" target="_blank" title="King Bounty The Legend">Google Drive KINGDOM NVHAI</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/px5cEI-z78U" frameborder="0" allowfullscreen></iframe></center>

<p>Vương quốc Darion từng là một nơi thanh bình, nhưng giờ đây sự xuất hiện của nhiều loại quái vật như người sói, xác chết biết đi. Những cây ăn thịt người mọc tràn lan khắp nơi, gieo rắc nỗi kinh hoàng lên đầu dân chúng. Và thời thế tạo anh hung, vương quốc cần một chiến binh, pháp sư hoặc hiệp sĩ giúp nhà vua tiêu diệt ma quỷ, đem lại cuộc sống bình yên cho dân lành.</p>

<center><img src="/upload/images/game/kings-bounty-the-legend-1.jpg" width="70%" alt="King&apos;s Bounty The Legend" /></center>

<p>Mặc dù với lối chơi tương tự như dòng game dàn trận theo lượt nổi tiếng Heroes of Might and Magic nhưng King&apos;s Bounty: The Legend không có chức năng tùy biến nhân vật ngay từ đầu. Sau khi chọn loại nhân vật, bạn được mang theo một số đồ vật và chọn hướng chuyên sâu trên hệ thống phát triển kỹ năng. Nói đơn giản, trò chơi giống như sự kết hợp giữa thể loại nhập vai và dàn trận theo lượt. Bạn cày level cho hero, nâng kỹ năng và mang quân lính của mình đi chinh phạt nhưng không có tòa thành hay xây nhà nào. Heroes of Might and Magic cho bạn thành lũy, xây nhà còn King&apos;s Bounty: The Legend chỉ tập trung vào 1 hero duy nhất.</p>

<center><img src="/upload/images/game/kings-bounty-the-legend.jpg" width="70%" alt="King&apos;s Bounty The Legend" /></center>

<p>Level của nhân vật càng tăng thì số lượng và chủng loại lính mà bạn có thể điều khiển cũng trở nên đa dạng hơn. Chẳng hạn, ở màn cuối, người chơi sẽ được quyền điều khiển một số loại quái vật như rồng, cây phun độc và ma cà rồng. Bạn còn có thể gặp được những con boss như Kraken, những trận đánh với đối thủ là quái vật khổng lồ hay rồng.</p>

<center><img src="/upload/images/game/kings-bounty-the-legend-2.jpg" width="70%" alt="King&apos;s Bounty The Legend" /></center>

<p>Trò chơi có rất nhiều cảnh đẹp theo phong cách thần thoại châu Âu. Bạn sẽ thấy những con tàu chiến, những tòa lâu đài hay những ngôi làng nhỏ như trong các bộ phim châu Âu thời Trung Cổ, tồn tại tiên, thủy quái, người lùn, xác chết biết đi, người sói và quỷ. Trên bản đồ, những nhân vật có chấm đỏ ở phía trên là kẻ thù của bạn. Nếu chết, người chơi sẽ được đưa trở lại cung điện để hồi sinh. Tại đây bạn có thể mua thêm binh lính, phục hồi sức mạnh và máu. Dù đồ họa đã lỗi thời nhưng vẫn rất đẹp. Cấu hình nhẹ nên game thủ bây giờ hoàn toàn có thể chơi được.</p>

<p>Nếu các bạn muốn trải nghiệm phiên bản mới hơn, hãy tìm đến Kings Bounty: Armored Princess. Chắc chắn bạn sẽ rất thích thú với phiên bản mới này khi bạn được điều khiển một nàng công chúa xinh đẹp và mạnh mẽ đi phiêu lưu khắp thế giới.</p>',

            'date_post'         => '2015-07-21',
            'thumbnail_post'    => 'kings-bounty-the-legend-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Yugioh! Zexal Power of Chaos Yuma the Challenge - Lời thách thức của Yuma',
            'url_post'        => 'Yugioh-Zexal-Power-of-Chaos-Yuma-the-Challenge-Loi-thach-thuc-cua-Yuma',
            'present_vi_post' => 'Trải qua hơn 10 năm, thế giới bài ma thuật Yugioh vẫn phát triển không ngừng. Yugioh! Zexal Power of Chaos Yuma the Challenge là một trong số đó.',
            'content_vi_post' => '<p>Yugioh! Zexal Power of Chaos Yuma the Challenge là tựa game đánh bài dựa trên series manga, anime, game nổi tiếng Yugioh! Trò chơi này là phiên bản thứ 6 của series. Một số game có chút đặc biệt đó là được các fan bổ sung bản MOD, tức là có thêm những lá bài hay hình ảnh mới.</p>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZb0dJWVRGNFFEWlE/view?usp=sharing&resourcekey=0-Yen0GQ2lF-ipceAZXPHczg" rel="nofollow" target="_blank" title="Yugioh! Zexal Power of Chaos Yuma the Challenge">Google Drive KINGDOM NVHAI</a></p>

<center><img src="/upload/images/game/Yugioh-Zexal.jpg" width="70%" alt="Yugioh! Zexal Power of Chaos Yuma the Challenge - Lời thách thức của Yuma" /></center>

<p>Với tổng số lên tới 1109 trong đó 450 lá bài được thêm vào từ sự sáng tạo của tác giả và các nhân vật hoạt hình được xây dựng từ các fan. Ở phiên bản fan-made này, đối thủ của bạn sẽ là Yuma Tsukumo, trong game luật chơi vẫn giữ tính truyền thống, nhưng các lá bài sẽ rất mới lạ và chưa từng nhìn thấy trước đây.</p>

<p>Nếu bạn đã xem anime Yugioh! Zexal thì các bạn đã biết phong cách chơi mới của phần này. Yuma sẽ sử dụng khả năng triệu hồi Exceed (triệu hồi quái thú khi có 2 quái thú cùng level). Tuy nhiên, trong game bạn sẽ không thể triệu hồi một cách thoải mái như anime mà phải sử dụng những lá bài hỗ trợ triệu hồi.</p>

<center><img src="/upload/images/game/Yugioh-Zexal-1.jpg" width="70%" alt="Yugioh! Zexal Power of Chaos Yuma the Challenge - Lời thách thức của Yuma" /></center>

<p>Với số lượng bài lớn này, người chơi có thể tạo nên những bộ bài theo nhiều chiến thuật khác nhau. Tuy nhiên, hơi tiếc là trong phần này, game tập trung vào khả năng triệu hồi Exceed nên những dạng bộ bài khác ít được khai thác tốt, trừ những lá bài cơ bản và quá truyền thống từ đầu series đến giờ.</p>

<p>Hy vọng với anime Yugioh! Arc V đã ra mắt và the movie Yugioh! The Dark Side of Dimensions sẽ ra mắt vào năm 2016, các fan hâm mộ sẽ tiếp tục được hòa mình vào thế giới bài ma thuật Yugioh! với nhiều lá bài mới. Các bạn cũng có thể tìm phiên bản tiếp theo của series game này là Yugioh! Arc V đã ra mắt. Còn bây giờ, triệu hồi Exceed!</p>

<center><img src="/upload/images/game/Yugioh-ARCV.jpg" width="70%" alt="Yugioh! Zexal Power of Chaos Yuma the Challenge - Lời thách thức của Yuma" />
<p>Yugioh! ARC V đã ra mắt.</p></center>',

            'date_post'         => '2015-07-24',
            'thumbnail_post'    => 'Yugioh-Zexal-Power-of-Chaos-Yuma-the-Challenge-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nitroplus Blasterz: Heroines Infinite Duel ra mắt game cho PS3/PS4',
            'url_post'        => 'Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4',
            'present_vi_post' => 'Game đối kháng Nitroplus - Blasterz - Heroines Infinite Duel sẽ ra mắt vào tháng 12/2015 cho hệ máy PS3 và PS4.',
            'content_vi_post' => '<p>Ngày 16/7/2015, website chính thức của trò chơi đối kháng Marvelous và Nitroplus Blasters Heroines Infinite Duel thông báo rằng trò chơi sẽ ra mắt vào ngày 10/12/2015 cho hệ máy PlayStation 3 và PlayStation 4.</p>

<center><img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4-1.jpg" width="70%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" /></center>

<p>Đây là trò chơi đối kháng theo nhóm 3 người. Các nhân vật đều là nữ. Điểm đặc biệt là khi nhân vật thi triển chiêu cuối, sẽ có đoạn anime ngắn xuất hiện. Hình ảnh và hiệu ứng rất tốt.</p>

<center><img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4-Saber.jpg" width="100%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" />

<img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4-Homura.jpg" width="100%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" />

<img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4-Sonico.jpg" width="100%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" />

<p>Đoạn anime khi sử dụng chiêu cuối (Super Move) của Saber, Homura và Sonico.</p></center>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/toTFHSrQ7_U" frameborder="0" allowfullscreen></iframe>
<p>Nitro+ Blasterz -Heroines Infinite Duel Gameplay</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/7NyuXNQwblw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
<p>Tất cả chiêu cuối (Super Move) của các nhân vật</p></center>

<p>Trò chơi sẽ bao gồm một mã download miễn phí cho hai nhân vật mới: Homura đến từ phim Senran Kagura Estival Versus -Shōjo-tachi no Sentaku, và Aino Heart từ Arcana Heart - series trò chơi chiến đấu của Examu. Marvelous cũng công bố trước đó rằng giao diện điều khiển phiên bản của trò chơi sẽ thúc đẩy Super Sonico từ nhân vật đối tác đến nhân vật đang điều khiển.</p>

<p>Những người đặt hàng trước trò chơi cũng sẽ nhận được một mã tải về miễn phí.</p>

<p>Marvelous cũng tiết lộ một gói phiên bản giới hạn (limited edition) cho trò chơi. Gói phiên bản giới hạn bao gồm hộp pha lê 3D nghệ thuật được tạo bởi Nitroplus, nghệ sĩ ở Santa Tsuji, soundtrack của trò chơi, một cuốn sách vẽ nhân vật, và một mã tải về cho phiên bản áo tắm của Super Sonico, Aino Heart, và Homura, có hình ảnh vẽ cử động của các nhân vật. Các phiên bản giới hạn được bán lẻ với giá 12.160 Yên (khoảng 98USD), và phiên bản tiêu chuẩn được bán lẻ với giá 6.990 Yên (khoảng 56USD).</p>

<center><img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-box.jpg" width="70%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" />

<img src="/upload/images/game/Nitroplus–Blasterz-Heroines-Infinite-Duel-ra-mat-game-cho-PS3-PS4-4.jpg" width="100%" alt="Nitroplus - Blasterz - Heroines Infinite Duel ra mắt game cho PS3/PS4" /></center>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/3V7AQVg3Gt0" frameborder="0" allowfullscreen></iframe>

<p>Trailer cách đây 1 năm của game.</p></center>

<div class="td-post-source-via ">
    <div class="td-post-small-box"><span>Nguồn</span>
    <a href="http://www.animenewsnetwork.com/daily-briefs/2015-07-18/nitroplus-blasters-heroines-infinite-duel-game-ships-for-ps3-ps4-on-december-10/.90555" rel="nofollow" target="_blank" title="Nitroplus Blasterz: Heroines Infinite Duel">Anime News Network</a>
    </div>
</div>
',

            'date_post'   => '2015-07-26',
            'thumbnail_post'    => 'Nitroplus-Blasterz-Heroines-Infinite-Duel-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'EA ra mắt trailer Need for Speed: No Limits',
            'url_post'        => 'EA-ra-mat-trailer-Need-for-Speed-No-Limits',
            'present_vi_post' => 'Đường đua đường phố sắp xuất hiện trên chiếc diện thoại của bạn.',
            'content_vi_post' => '<p>Đây là lúc quay trở lại đường đua đường phố một lần nữa, nhưng là với chiếc điện thoại của bạn.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/vWjkr7NFXj0" frameborder="0" allowfullscreen></iframe></center>

<p>Ngày 6/1/2015, Electronic Arts ra mắt đoạn trailer đầu tiên của Need for Speed: No Limits (Need for Speed: Không giới hạn). Các phiên bản mới nhất của Need for Speed sẽ có mặt trên iOS và Android, và dự kiến sẽ được phát hành vào cuối năm nay.</p>

<center><img src="/upload/images/game/Need-for-Speed-No-Limits.jpg" width="100%" alt="EA ra mắt trailer Need for Speed: No Limits" /></center>

<p>Là bản kế tiếp của Most Wanted, Need For Speed: No Limits được cải tiến lớn về mặt đồ họa. Đổ bóng, chi tiết xe hay các hiệu ứng khói lửa, va chạm dưới lớp áo 3D đều được đầu tư rất kĩ càng khiến đồ họa của game có thể sánh ngang tầm nhiều tựa game trên PC, Console.</p>

<p>EA công bố trò chơi trong tháng 11, và nói với Gamespot rằng mục đích là để "định hình lại" thể loại đua xe trên nền tảng điện thoại di động. Need for Speed là game đua xe rất nổi tiếng trên PC, đặc biệt là phiên bản Most Wanted dù đã lâu nhưng vẫn được đưa vào eSport. Sự kiện này chứng tỏ EA muốn chiếm thị phần mobile đầy tiềm năng này.</p>',

            'date_post'   => '2015-07-28',
            'thumbnail_post'    => 'EA-trailer-need-for-speed-no-limits-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Game MMORPG Mabinogi mang sự kiện Sword Art Online đến Bắc Mỹ',
            'url_post'        => 'Game-MMORPG-Mabinogi-mang-su-kien-Sword-Art-Onlineden-Bac-My',
            'present_vi_post' => 'Game MMORPG Mabinogi sẽ có những sự kiện về nhân vật Sword Art Online dành cho game thủ Bắc Mỹ',
            'content_vi_post' => '<p>Người hâm mộ của game MMORPG Mabinogi của Nexon sẽ không cần Nervegear để tham gia vào sự kiện Sword Art Online sắp tới. Trước đây game chỉ giới hạn người chơi tại Hàn Quốc, bây giờ các sự kiện sẽ được dành cho những người chơi trên khắp Bắc Mỹ bắt đầu từ ngày 13/8/2015.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Lq65_wIe2UA" frameborder="0" allowfullscreen></iframe></center>

<p>Sự kiện bao gồm "Dungeon Capture" (13/8 đến 9/9) sẽ cần sự hợp tác của tất cả các người chơi để tìm lối ra hang động của Mabinogi; "Thu Crystallite," (20/8 đến 9/9) yêu cầu người chơi phải giúp Lisbeth thu thập Crystallite khi Kirito được đang cưỡi Rồng Trắng; và "King of the Lake," (27/8 đến 9/9) là một sự kiện đánh cá.</p>

<center><img src="/upload/images/game/Game-MMORPG-Mabinogi-mang-su-kien-Sword-Art-Onlineden-Bac-My-Mabinogi-Yui.jpg" width="100%" alt="Game MMORPG Mabinogi mang sự kiện Sword Art Online đến Bắc Mỹ" />

<p>Những người đăng nhập vào trò chơi vào ngày 23/8 sẽ nhận Yui miễn phí.</p></center>

<div class="td-post-source-via ">
    <div class="td-post-small-box"><span>Nguồn</span>
    <a href="http://www.animenewsnetwork.com/interest/2014-08-08/mabinogi-mmorpg-brings-sword-art-online-event-to-n-america/.77421?utm_source=crowdignite.com&utm_medium=referral&utm_campaign=crowdignite.com" rel="nofollow" target="_blank" title="Sword Art Online">Anime News Network</a>
    </div>
</div>
',

            'date_post'   => '2015-08-01',
            'thumbnail_post'    => 'Mabinogi-mang-su-kien-Sword-Art-Online-cho-Bac-My-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Agatha Christie: And then there were none - Và rồi chẳng còn ai',
            'url_post'        => 'Agatha-Christie-And-then-there-were-none-va-roi-chang-con-ai',
            'present_vi_post' => 'Dựa trên cuốn tiểu thuyết bán chạy nổi tiếng lúc bấy giờ của nhà văn Agatha Christie, tựa game phiêu lưu trinh thám này đã tạo nên sức hút kỳ lạ và là một trong số những game phiêu lưu rất đáng quan tâm.',
            'content_vi_post' => '<p>Agatha Christie: and then there were none là một tựa game nổi tiếng một thời của hãng The Adventure Company. Tựa game này dựa trên cuốn tiểu thuyết nổi tiếng của nhà văn Agatha Christie: Ten Little Niggers (10 người da đen nhỏ). Mười người da đen nhỏ cũng là tác phẩm của Agatha Christie được chuyển thể nhiều lần nhất, cả trực tiếp và gián tiếp, dưới dạng phim điện ảnh, truyền hình và kịch sân khấu.</p>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none.jpg" width="70%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" /></center>

<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Agatha Christie: and then there were none
<li>Thể loại: phiêu lưu, giải đố
<li>Sản xuất năm: 30/10/2005
<li>Hãng sản xuất: Adventure Company
<li>Cấu hình: CPU: 1.8 GHz Pentium IV, RAM: 512 MB, CD-ROM/DVD-ROM: 16X ,Hard Drive Space: 1.5 GB available, Video: 64 MB Directx 9 compatible video card, Sound: 16-bit Directx, Windows XP, 7,8
</ul>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZMEx5M00tc09VYUk/view?usp=sharing&resourcekey=0-5y_owQhF0Df0ACK5phtn4g">Google Drive KINGDOM NVHAI</a>
</ul>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none-1.jpg" width="100%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" />

<p>Vừa vào menu game đã xuất hiện một chiếc thòng lọng treo cổ</p></center>

<p>Câu chuyện kể về 9 vị khách thuộc đủ mọi tầng lớp và lứa tuổi được mời nghỉ tại ngôi biệt thự trên Soldier Island, một hòn đảo nằm trơ trọi ngoài khơi vùng Devon. Sau khi được ông Fred Naracott chở tới đảo, họ nhận ra rằng chủ ngôi biệt thự (người được cho là đã mời họ) không có mặt, đón tiếp họ là hai người quản gia, cặp vợ chồng Thomas và Ethel Rogers. Trong game, bạn là nhân vật chính Naracotte lái thuyền chở đoàn người đến hòn đảo. Khác với trong truyện là ở lò sưởi trong phòng khách là nơi có một bài đồng dao mang tên “Mười người lính nhỏ” còn trong truyện là trong phòng của từng người.</p>

<center><p>Nguyên bản:</p>

<p>“Ten Little Sailor boys went out to dinner.<br>
One choked his little self and then there were nine.</p>

<p>Nine Little Sailor boys sat up very late.<br>
One overslept himself and then there were eight.</p>

<p>Eight Little Sailor boys traveling in Devon.<br>
One said he&apos;d stay there and then there were seven.</p>

<p>Seven Little Sailor boys chopping up sticks.<br>
One chopped himself in halves and then there were six.</p>

<p>Six Little Sailor boys playing with a hive.<br>
A bumblebee stung one and then there were five.</p>

<p>Five Little Sailor boys going in for law.<br>
One got in Chancery and then there were four.</p>

<p>Four Little Sailor boys going out to sea.<br>
A red herring swallowed one and then there were three.</p>

<p>Three Little Sailor boy walking in the zoo.<br>
A big bear hugged one and then there were two.</p>

<p>Two Little boys sitting in the sun.<br>
One got frizzled up and then there were one.</p>

<p>One Little boy left all alone.<br>
He went and hariged himself and then there were none...”</p></center>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none-3.jpg" width="100%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" /><p>Bài đồng dao đặt trên lò sưởi</p>
</center>

<center><p>Tạm dịch:</p>

<p>Mười người lính nhỏ đi ăn<br>
Một mắc nghẹn và còn chín</p>

<p>Chín người lính nhỏ thức rất khuya<br>
Một ngủ quá giấc và còn tám</p>

<p>Tám người lính nhỏ du hành tới Devon<br>
Một ở lại đó và còn bảy</p>

<p>Bảy người lính nhỏ chặt củi<br>
Một tự chặt đôi mình và còn sáu</p>

<p>Sáu người lính nhỏ chơi với tổ ong<br>
Một bị ong nghệ đốt và còn năm</p>

<p>Năm người lính nhỏ chơi trò xử án<br>
Một làm quan tòa và còn bốn</p>

<p>Bốn người lính nhỏ ra biển<br>
Một bị cá nuốt và còn ba</p>

<p>Ba người lính nhỏ tới vườn thú<br>
Một bị gấu vồ và còn hai</p>

<p>Hai người lính nhỏ ngồi dưới nắng<br>
Một bị thiêu đốt và còn một</p>

<p>Chỉ còn lại một người lính nhỏ cô đơn<br>
Tự kết thúc cuộc đời mình và rồi chẳng còn ai.</p></center>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none-2.JPG" width="70%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" /><p>Chiếc bánh trong phòng ăn</p></center>

<p>Khi vừa mới vào phần menu chính, người chơi ngay lập tức cảm nhận được không khí rùng rợn và bí hiểm khi nhìn thấy một tòa biệt thự trong trời tối dưới mưa, kèm theo hình ảnh một chiếc thòng lọng treo cổ lủng lẳng qua lại. Trong trò chơi, cảm giác bí ẩn được thể hiện qua từng bước đi của nhân vật. Mặc dù game không có những pha hù dọa ghê rợn như game kinh dị nhưng với phong cách trinh thám, game đã tạo một cảm giác bí ẩn khá cuốn hút người chơi.</p>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none-4.jpg" width="70%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" />
</center>

<p>Hình ảnh trong game được thể hiện tốt với những vật dụng của thế kỷ 20. Máy nghe nhạc, quả địa cầu, bản đồ, bàn ghế, máy chiếu phim được làm giống như những vật dụng thời đó. Tuy nhiên vẫn tồn tại những điểm khá bất hợp lý như nhà vệ sinh có đến 3 cửa. Những công thức ghép đồ hơi khó cùng với hệ thống câu đố, tìm đường phức tạp đòi hỏi người chơi phải tìm tòi, khám phá nhiều. </p>

<center><img src="/upload/images/game/Agatha-Christie-and-then-there-were-none-5.jpg" width="70%" alt="Agatha Christie: And then there were none Và rồi chẳng còn ai" /><p>10 người lính nhỏ</p>
</center>

<p>Có 10 màn chơi tương ứng với 10 câu đồng dao. Kết thúc của game thuộc dạng kết thúc mở. Có 4 kết thúc:<br>
+ Không cứu được ai cả. Chỉ còn Narcotte sống sót.<br>
+ Không cứu được Vera, chỉ cứu được Lombard.<br>
+ Không cứu được Lombard, chỉ cứu được Vera. <br>
+ Cả ba người còn sống - Kết thúc này có hậu nhất.
</p>

<p>Với hình ảnh ở mức khá, âm thanh tốt, tạo sức hút và cốt truyện hay, Agatha Christie: And then there were none là một tựa game cũ mà hay xứng đáng để các game thủ thích trinh thám có cơ hội thử sức phá án.</a></p>
',

            'date_post'         => '2015-08-03',
            'thumbnail_post'    => 'Agatha-Christie-and-then-there-were-none-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Safecracker - Chuyên gia phá két',
            'url_post'        => 'Safecracker-chuyen-gia-pha-ket',
            'present_vi_post' => 'Hãy thể hiện đầu óc, tư duy logic của bạn khi đối mặt với những chiếc két sắt chứa đựng những câu đố khó chịu nhất.',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Safecracker
<li>Thể loại: giải đố
<li>Sản xuất năm: 2006
<li>Hãng sản xuất: Adventure Company
<li>Cấu hình: CPU: 1 GHz Pentium IV, RAM: 512 MB, CD-ROM/DVD-ROM: 16X , Video: 64 MB Directx 9 compatible video card, Sound: 16-bit Directx, Windows XP, 7,8
</ul>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZZDg0OGNyekJuWWs/view?usp=sharing&resourcekey=0-6Hn3wSPYtyjLPGTQdA5RIA" rel="nofollow" target="_blank" title="Safecracker">Google Drive KINGDOM NVHAI</a>
<li>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4. Nhớ cài đặt phần free, không cần crack</a>
</ul>

<center><img src="/upload/images/game/safecracker.jpg" width="70%" alt="Safecracker - Chuyên gia phá két" /></center>

<p>Cách cài đặt: cài đặt phần mềm Daemon Tool 4, sau đó dẫn đến file .cue của game để chạy đĩa ảo và cài đặt.</p>

<p>Safecracker là một trò chơi thuộc thể loại giải đố. Nội dung câu chuyện là một ông tỷ phú qua đời, để lại di chúc cho con cháu tài sản thừa kế. Và người nào phá được hệ thống két sắt, câu đố hóc búa của ông thiết kế sẽ được hưởng nó. Bạn là người được thuê để làm việc này. Vậy bạn có được lợi lộc gì từ việc này không? Rất nhiều đấy! </p>

<center><img src="/upload/images/game/Safecracker-ket-sat-1.jpg" width="50%" alt="Safecracker - Chuyên gia phá két" />

<p>Câu đố đầu tiên: hãy dịch chuyển sao cho<br>
các viên bi nằm gần các mũi tên cùng màu</p></center>

<p>Hệ thống câu đố trong Safecracker rất đa dạng. Từ những câu đố quen thuộc như xếp các mảnh ghép thành hình hoàn chỉnh, đẩy bi xuống lỗ đến những câu đố làm nát óc người chơi như bấm nút két sắt hiện sai số. Game không cho phép người chơi đi tắt, bỏ sót lại bất kỳ két sắt nào. Người chơi phải vận dụng rất nhiều tư duy, suy nghĩ để có thể phá được hệ thống kế sắt khó chịu này.</p>

<center><img src="/upload/images/game/Safecracker-ket-sat-2.jpg" width="70%" alt="Safecracker - Chuyên gia phá két" /><p>Đáp án câu số 2</p></center>

<p>Mặc dù thể loại game giải đố khá nhàm chán nhưng cộng đồng những người thích chơi những trò chơi trí tuệ vẫn khá đông. Đó là vì họ muốn được tận hưởng cảm giác sung sướng, hạnh phúc giải xong một câu đố hóc búa. Và Safecracker đã làm tốt điều đó khi những câu đố của safecracker rất dễ khiến nhiều người nản lòng. Không chỉ phải vắt chất xám ra để suy nghĩ, trò chơi còn bắt người chơi phải thu thập những mảnh ghép như cầu chì, nguồn điện... để lắp vào một chiếc cửa có khóa mã số bị hỏng. Điều này khiến họ không ngừng làm việc trí óc.</p>

<center><img src="/upload/images/game/Safecracker-1.jpg" width="70%" alt="Safecracker - Chuyên gia phá két" /></center>

<p>Đồ họa trong game cũng bình thường, không có gì nổi trội. Âm nhạc trong game khá trầm lắng, tạo sự im lặng cho người chơi tập trung suy nghĩ. Nói chung game này tạo cho người chơi cảm giác khá trầm lắng, chỉ hợp với những ai sẵn sàng nghiên cứu từng câu đố hóc búa nhất của game.</p>

<center><img src="/upload/images/game/Safecracker-ket-sat-3.jpg" width="70%" alt="Safecracker - Chuyên gia phá két" /><p>Câu đố thứ 3: di chuyển viên bi sắt sao cho rơi vào lỗ, không rơi xuống 4 cạnh bàn.</p></center>

<p>Nhìn chung, safecracker là game giải đố nên khá kén người chơi. Trò chơi này bây giờ rất khó tìm kiếm trên Google vì đã quá cũ. Nếu bạn đã đọc bài viết này, sao bạn không thử sức mình với những câu đố hóc búa? Phần thưởng cuối trò chơi là bạn có liên quan đến di chúc của ông tỷ phú. Hãy thử tìm hiểu nào!</p>',

            'date_post'   => '2015-08-05',
            'thumbnail_post'    => 'Safecracker-chuyen-gia-pha-ket-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Hitman 2: Silent Assasin - Sát thủ thầm lặng',
            'url_post'        => 'Hitman-2-Silent-Assasin-Sat-thu-tham-lang',
            'present_vi_post' => 'Gã sát thủ đầu trọc mang mật danh 47 đã không thể chạy trốn khỏi quá khứ. Giờ hắn ta một lần nữa phải cầm vũ khí để giết người. Lòng tốt của hắn chỉ có Chúa chứng giám và hiểu được.',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Hitman 2: Silent Assasin
<li>Thể loại: Hành động bí mật
<li>Sản xuất năm: 2002
<li>Hãng sản xuất: Eidos Interactive
<li>Cấu hình: CPU: 1.8 GHz Pentium III, RAM: 256 MB, HDD Space: 1GB, Video: 128 MB Directx 8.1 compatible video card, Windows XP, 7,8
</ul>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZMGpLc3doZXFPWm8/view?resourcekey=0-I_HYYpWG2RywP39vwpg8Og" rel="nofollow" target="_blank" title="Hitman 2: Silent Assasin">Google Drive KINGDOM NVHAI</a>
<li>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4. Nhớ cài đặt phần free, không cần crack</a>
</ul>

<center><img src="/upload/images/game/Hitman-2-Silent-Assassin.jpg" width="100%" alt="Hitman 2: Silent Assasin - Sát thủ thầm lặng" /></center>

<p>Series game Hitman đã trở thành tượng đài của dòng game hành động bí mật. Một tay sát thủ đầu trọc với mã vạch sau gáy, mặt lạnh như tiền, được số phận đào tạo thành sát thủ từ nhỏ, không tên, không gia đình, không nguồn gốc, chỉ có con số 47 để mọi người gọi tay sát thủ này. Hắn thực hiện nhiệm vụ từ Âu sang Á, từ thủ đô Moscow của Nga cho đến căn nhà nhỏ trong rừng hẻo lánh của Yakuza Nhật. Hắn sử dụng từ vũ khiến hiện đại như súng bắn tỉa, nỏ, 2 tay 2 súng cho đến vũ khí cận chiến như dao làm bếp, dây xiết cổ một cách thuần thục. Một mình hắn có thể bắn hạ hàng chục lính với những pha xuất hiện đầy bất ngờ và biến mất vào bóng tối. Hắn tung hoành từ trong game đến phim ảnh. Chỉ có một cộng sự bí mật liên lạc với hắn qua máy vi tính mang tên Diana Burnwood là có thể nói chuyện với hắn.</p>

<center><img src="/upload/images/game/Hitman-2-Silent-Assassin-3.jpg" width="100%" alt="Hitman 2: Silent Assasin - Sát thủ thầm lặng" /><p>Khi cải trang phải đi bộ để không bị phát hiện</p></center>

<p>Sau khi giết Tiến sĩ Ort-Meyer, 47 đã làm giả cái chết của mình và không chính thức từ chức ICA, bỏ lại cuộc sống sát thủ, đến một nhà thờ ở Sicily để tìm kiếm sự yên bình. Anh làm việc như một người làm vườn cho Cha Vittorio, người bạn tốt nhất của mình và là một người thầy. Nhưng tay nhúng chàm khó có thể rửa sạch.</p>

<p>Một ngày nọ, trong khi 47 đang sám hối trong phòng rửa tội, Cha Vittorio bị bắt cóc và để lại một bức thư cho 47. 47 quyết định quay trở lại công việc sát thủ để tìm Cha Vittorio. Anh liên hệ cơ quan cũ, những người nghĩ rằng anh đã chết, và thỏa thuận với cộng sự Diana Burnwood. Anh nói rằng ông sẽ quay trở lại làm sát thủ cho ICA nếu cơ quan này có thể giúp anh ta tìm Cha Vittorio. Họ chấp nhận thỏa thuận này.</p>

<p>Màn chơi đầu tiên, Diana nói với 47 rằng Cha Vittorio đã bị bắt cóc bởi một ông chủ Mafia Sicily tên là Giuseppe Giuliano. Người đàn ông đang bắt các linh mục trong một nhà tù trong dinh thự của mình, đặt tên là Villa Borghese. 47 đến và giết chết Giuliano, nhưng không tìm thấy Vittorio. Diana phát hiện Cha Vittorio bị đưa đi bởi những kẻ mặc đồng phục quân đội Nga. Và các màn chơi tiếp theo là những vụ ám sát các viên tướng của Nga.</p>

<p>Game khai thác tốt yếu tố hành động bí mật. Người chơi sẽ phải tìm cách lén lút đi vào một căn nhà đầy Yakuza Nhật hay một tòa nhà toàn dân thường mà không bị phát hiện. Người chơi sẽ phải thể hiện kỹ năng bắn tỉa với hồng tâm rung động như thật cũng như khả năng chạy đua với thời gian để đến vị trí cần thiết đúng giờ trước khi mục tiêu đi mất. Game có 3 chế độ chơi: Normal với 7 lần lưu game, Expert với 3 lần và Professional không có lần lưu game nào.</p>

<center><img src="/upload/images/game/Hitman-2-Silent-Assassin-2.jpg" width="100%" alt="Hitman 2: Silent Assasin - Sát thủ thầm lặng" /><p>Một nhiệm vụ đòi hỏi kỹ năng chạy đua thời gian và bắn tỉa.</p></center>

<p>Tuy nhiên, không biết do cố tình hay sai sót mà game có những điểm lừa người chơi. Chẳng hạn như nhiệm vụ ở Moscow là ám sát 2 tên tướng đang đi dạo trong công viên với hàng chục lính vây quanh. Người chơi sẽ nhận được một quả bom gắn dưới xe ô tô. Theo kế hoạch là người chơi sẽ bắn 1 tên tướng, tên còn lại sẽ vào ô tô và quả bom phát nổ. Nhưng nếu chơi màn chơi đó, bạn sẽ nhận ra việc đặt quả bom vào chiếc xe có 5 tên lính xung quanh là chuyện bất khả thi. Người viết cố gắng lắm cũng chỉ hạ được 3 tên. Và đó là yếu tố mà game lừa người chơi.</p>

<center><img src="/upload/images/game/Hitman-2-Silent-Assassin-1.jpg" width="100%" alt="Hitman 2: Silent Assasin - Sát thủ thầm lặng" />

<p>Tìm đường vào một tòa nhà đầy dân thường.</p></center>

<p>Một điểm khiến KINGDOM NVHAI hơi thất vọng đó là game không thật sự hành động bí mật. AI của game khá kém. Trong màn chơi cứu tù binh dưới hầm đầy lính gác, người chơi có thể sử dụng một mẹo đơn giản là bắn một tên lính để những tên khác nghe thấy tiếng súng. Sau đó chúng cứ lũ lượt kéo đến và người chơi chỉ việc bắn rồi núp. Nói chung là người chơi có thể bắn hạ gần hết số lính trong màn chơi nếu muốn mà không cần phải hành động bí mật gì cả. Thậm chí người chơi có thể dùng AK bắn xả láng mà không sợ bị phát hiện.</p>

<p>Nếu bỏ qua những lỗi nhỏ đó thì Hitman 2 Silent Assasin xứng đáng có mặt trong bộ sưu tập game của bạn. Hệ thống vũ khí khá phong phú, hình ảnh đẹp mắt, cấu hình rất nhẹ và lối chơi đa dạng chắc chắn sẽ cuốn hút bạn. Hãy cùng theo chân sát thủ 47 thực hiện những nhiệm vụ kịch tính nhất.</p>

<p><b>Mẹo</b></p>

<ul>
<li>Một số nhiệm vụ, bạn chỉ cần đứng núp sau cánh cửa, cầm một khẩu súng lớn và đợi những tên lính mở cửa rồi xả đạn. Sau đó đóng cửa lại.
<li>Hãy tiêu diệt càng nhiều lính càng tốt vì rất nhiều trường hợp, sau khi bạn tiêu diệt được mục tiêu, những tên lính đó sẽ chạy đến tìm bạn. Giết nhiều lính sẽ đỡ vất vả hơn sau này.
<li>Cố ý để lính tìm thấy xác chết để chúng chạy đến, sau đó chỉ việc dùng súng giảm thanh bắn vào đầu là nhanh gọn.
</ul>
',

            'date_post'         => '2015-08-06',
            'thumbnail_post'    => 'Hitman-2-Silent-Assassin-sat-thu-tham-lang-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Hektor - Ký ức xáo trộn',
            'url_post'        => 'Hektor-ky-uc-xao-tron',
            'present_vi_post' => 'Mò mẫm trong bóng tối với ngọn lửa nhỏ bé, đi lang thang trong một khu vực dành cho thí nghiệm với những sinh vật quái dị lang thang đâu đó. Nguyên nhân là gì? Đây là đâu? Tại sao bạn lại ở đây?',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Hektor
<li>Thể loại: kinh dị
<li>Sản xuất năm: 1/2015.
<li>Hãng sản xuất: Rubycone
<li>Cấu hình:  CPU: Core I3-2115C 2.4GHz, RAM: 2 GB, CD-ROM/DVD-ROM: 16X ,Hard Drive Space: 4 GB, Video: GeForce GT 740, Sound: 16-bit Directx 11, Windows XP, 7,8.
</ul>

<h3>Link download</h3>

<ul>
<li><a href="http://kumpulbagi.com/alonemisery/hektor-www-minigamespc-net-51056/www-minigamespc-net-flt-hekt,317364,gallery,1,1.iso" rel="nofollow" target="_blank" title="Hektor">Link nước ngoài</a>
<li><a href="https://www.fshare.vn/file/J3J5UK29VCRK" rel="nofollow" target="_blank" title="Hektor">Fshare</a>
<li><a href="https://drive.google.com/file/d/0B8chnwZX7g9ANF9nZDhFTmJfNG8/view?resourcekey=0-ReI5rtMEospYvBn3jKa5xw" rel="nofollow" target="_blank" title="Hektor">Google Drive KINGDOM NVHAI</a>
</ul>

<p>Nguồn link</p>

<ul>
<li>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4. Nhớ cài đặt phần free, không cần crack</a>
</ul>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/ZXlXrI3D3Hw" frameborder="0" allowfullscreen></iframe>

<p>Traler Hektor</p></center>

<p>Hektor là tựa game kinh dị của hãng Rubycone được ra mắt vào đầu năm 2015. Trò chơi này đã thu hút sự chú ý của rất nhiều fan yêu thích thể loại game kinh dị với phong cách tìm và chạy.</p>

<center><img src="/upload/images/game/Hektor.jpg" width="70%" alt="Hektor - Ký ức xáo trộn" /></center>

<p>Cốt truyện của game hơi mù mờ. Bạn sẽ xem một đoạn phim quay cảnh mình đang nằm trên giường với ánh đèn giống như trong phòng phẫu thuật. Sau khi tỉnh lại, bạn thấy mình đang nằm trên sàn nhà, trong một hành lang tối tăm. Chỉ với ánh sáng phát ra từ chiếc đèn pin và ngọn lửa nhỏ bé của cái hộp quẹt, bạn sẽ ph���i tìm hiểu xem bạn đang làm gì ở đây.</p>

<center><img src="/upload/images/game/Hektor-1.jpg" width="100%" alt="Hektor - Ký ức xáo trộn" /></center>

<p>Cảm nhận đầu tiên của KINGDOM NVHAI khi vừa bắt đầu là game tạo cảm giác u ám nặng nề. Nơi bạn đang đi có vẻ giống như một khu thí nghiệm bỏ hoang, có những nhà giam cửa song sắt, những căn phòng bàn giấy, những phòng bảo vệ có màn hình camera... Tất cả đều tối om trừ một số chỗ có công tắc đèn nếu bạn để ý trên tường. Khi đi trong một hành lang dài không ánh sáng, người viết cảm thấy giống như hành lang này dài vô tận. Âm thanh tí tách của nước, gạch đá rơi khi khu vực đột ngột rung chuyển tạo cảm giác như hơi thở của bạn trở nên khó khăn hơn.</p>

<center><img src="/upload/images/game/Hektor-2.jpg" width="100%" alt="Hektor - Ký ức xáo trộn" /></center>

<p>Khu vực này dường như đang bị một sức mạnh ma quái nào đó điều khiển, khiến cho tầm nhìn của người chơi đã tối còn bị méo mó, mờ ảo. Khi người chơi nhìn thấy dòng chữ hướng dẫn cách mở cánh cửa đầu tiên, lối đi phía sau lưng người chơi thay đổi và trở thành lối đi khác. Những sinh vật quái dị trông giống con người bất thình lình xuất hiện trong bóng tối, hồn ma bốc cháy… khiến những ai đã từng chơi Outlast hay những thể loại tương tự cảm thấy run rẩy mỗi khi mở những cánh cửa hay nghe thấy tiếng động lạ. Và giống Outlast, bạn chỉ có thể chạy nhanh hết sức trong bóng tối khi nhìn thấy những sinh vật đó vì trong tay bạn chẳng có vũ khí gì.</p>

<center><img src="/upload/images/game/Hektor-3.jpg" width="100%" alt="Hektor - Ký ức xáo trộn" /></center>

<p>Hektor hơi khác với Outlast là bạn sẽ không thấy ai trong suốt phần lớn thời gian chơi. Điều này nghe có vẻ yên tâm nhưng chắc chắn rằng một khi bạn đã bị hù thì chắc chắn bạn không thể giữ bình tĩnh để bỏ chạy, còn chạy đường nào và chạy được hay không lại là chuyện khác vì mọi thứ rất tối. Tốc độ mở cửa cũng không nhanh như Outlast nên chạy cũng khó hơn. Tốt nhất là bạn nên mở sẵn cửa phòng khi cần. Outlast thì khác, bạn luôn ở trong tư thế sẵn sàng chạy thục mạng nên cảm giác sợ khi chạy không hồi hộp bằng Hektor.</p>

<p>Trò chơi gồm có 3 phần nên thời lượng cũng không quá dài như Outlast. Game có đồ họa đẹp, cấu hình nhẹ và khá hồi hộp. Bạn nên chơi qua Hektor nếu muốn tìm một tựa game kinh dị với phong cách tìm và chạy để "giải trí ".</p>
',

            'date_post'         => '2015-08-07',
            'thumbnail_post'    => 'Hektor-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Kinh nghiệm chọn tướng ở Elo Hell',
            'url_post'        => 'Kinh-nghiem-chon-tuong-o-Elo-Hell',
            'present_vi_post' => 'Có những trận đấu xếp hạng mà kết quả gần như đã được định đoạt ngay từ phần Cấm và Chọn. Có những người dù rất giỏi một tướng nào đó nhưng mãi không thoát ra khỏi Elo Hell.',
            'content_vi_post' => '<p>Lưu ý: bài viết dựa trên kinh nghiệm cá nhân.</p>

<p>Thông thường, khi nhắc đến chọn tướng trong elo hell, nhiều người chỉ nghĩ đơn giản là chơi tốt 1-3 vị tướng tủ ở 1-3 đường quen thuộc hay nếu là người thứ 4, 5 thì chọn tướng theo team hay khắc chế đối thủ. Tuy nhiên, dù bạn có đi ở đường quen thuộc nhưng nếu kỹ năng bạn yếu hơn đối phương hay tướng tủ bạn chơi dễ bị khắc chế đầu trận hay cần phải có nhiều đồ, nhiều mạng thì bạn vẫn có thể thua. Bài viết này sẽ nói về kinh nghiệm chọn tướng để tập luyện trước khi mang vào Elo Hell.</p>

<p>Một đặc điểm mà những người ở Elo Hell luôn luôn có đó là kỹ năng kém. Đó là điều mà nhiều người đã nói. Kỹ năng farm, kỹ năng định hướng, kỹ năng kiểm soát bản đồ, cắm mắt… Rất nhiều kỹ năng mà những người ở Elo Hell hoàn toàn không có hoặc rất kém. Vậy phải chọn tướng thế nào để bù đắp được kỹ năng yếu kém của bạn? Sau đây là những gợi ý dựa trên kinh nghiệm cá nhân:</p>

<p>Bạn hãy lập danh sách những vị tướng đáp ứng đủ các yêu cầu sau đây:</p>

<h3>1 Là tướng tủ của bạn.</h3>
<p>Không cần nói nhiều về việc này nữa.</p>

<h3>2 Là một tướng ít kỹ năng định hướng.</h3>
<p>Điển hình: Sona, Gangplank, Annie, Dr&apos;Mundo, Mordekaiser...</p>

<p>Nếu kỹ năng định hướng của bạn kém, tốt nhất bạn đừng sử dụng những vị tướng đòi hỏi nhiều kỹ năng định hướng như Xerath, Vel&apos;koz, Ziggs (4 kỹ năng định hướng, không cơ động), Oriana (quả cầu bay rất khó), Alistar (combo rất khó), Cho&apos;Gath (Rạn Nứt (Q) khó trúng), Cassiopeia (3 kỹ năng định hướng, chiêu cuối khó hóa đá được đối thủ), Leesin, Yasuo (kỹ năng cần luyện tập rất nhiều)... Tất nhiên nếu đây là những tướng mà bạn đã rất tự tin khi sử dụng thì có thể bỏ qua yêu cầu này.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Velkoz-girl.jpg" width="50%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Xerath-girl.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Nghiêm cấm những người ở Elo Hell dùng Vel&apos;Koz và Xerath trừ khi đó là tướng tủ</p></center>

<h3>3 Là một tướng không bao giờ phế kể cả khi bị thọt.</h3>
<p>Điển hình: Yorick, Kayle, Lissandra, Zilean, Veigar...</p>

<p>Chắc chắn sẽ có những trận bạn rất xanh, ăn được nhiều mạng. Nhưng sẽ có những trận bạn bị thọt hay đồng đội để đối thủ ăn mạng nhiều, cuối cùng đối thủ xanh lè và không thể gỡ lại. Vậy phải làm sao để đối phó với những tình huống đó? Đây là lúc học hỏi cách chọn tướng của những cao thủ tham gia các giải đấu lớn. Tướng mà các cao thủ đánh trong giải đấu lớn thường là tướng không cần quá nhiều đồ đạc, có thể đóng góp cho giao tranh kể cả khi giai đoạn đi đường khó khăn khi phải 1 chấp 2 hay bị gank chết vài mạng, thậm chí là chết nhiều mạng vẫn tác dụng lớn trong giao tranh.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Yorick-grandma.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Rất nhiều người không biết Yorick đã từng tung hoành ngang dọc<br>
trong các giải đấu mùa 2.</p>

<img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Zilean-girl.jpg" width="50%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Chỉ cần có hồi sinh, dù có chết 10 mạng, Zilean vẫn gây ảnh hưởng lớn trong giao tranh</p></center>

<h3>4 Là một tướng có thể hỗ trợ kiểm soát bản đồ.</h3>
<p>Điển hình: Teemo, Maokai, Shaco (kỹ năng kiểm soát bản đồ), Dr.Mundo, Morderkaiser, Vladimir, Zac (mua Đá Tỏa Sáng), Twisted Fate (chiêu cuối phát hiện toàn bộ đối thủ)...</p>

<p>Ở Elo Hell, năn nỉ đồng đội cắm mắt còn khó hơn lên cung trăng. Tốt nhất là bạn hãy chơi những vị tướng có thể tự cắm cho mình vài con mắt hay đơn giản là những kỹ năng xuất hiện tầm nhìn như Maokai quăng chồi non, Shaco đặt hộp, Teemo đặt nấm... Khi đến gần một cái bụi cỏ nào đó hoặc kiểm tra xem đối thủ ăn rồng, baron chưa, bạn có thể dùng kỹ năng để xem. Hoặc bạn có thể mua Hồng Ngọc Tỏa Sáng để cắm phụ đồng đội như Lee Sin cắm mắt hộ thể. Một số vị tướng như Dr.Mundo, Morderkaiser, Vladimir, Zac cần sử dụng máu của mình. Những tướng này nên lên Hồng Ngọc Tỏa Sáng để hỗ trợ tầm nhìn.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/N6wfgTNY5xo" frameborder="0" allowfullscreen></iframe>

<p>Alliance vs Cloud 9 trong Chung Kết Thế Giới mùa 4.<br>
Shook đánh Rammus mua Đá Tỏa Sáng.</p></center>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-tuong-hop-Da-Toa-Sang.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Những tướng có thể lên Hồng Ngọc Tỏa Sáng dù đi ở bất kỳ vị trí nào.</p></center>

<h3>5 Là một tướng đi được gần như mọi vị trí.</h3>
<p>Điển hình: Yorick, Gangplank, Kayle, Galio...</p>

<p>Bạn là s1, s2. Bạn muốn đi đường giữa. Bạn đã chọn tướng chỉ có thể đi đường giữa hoặc đường trên như Ahri, Fizz. S3, s4, s5 cũng muốn đi đường giữa. Họ chọn tướng đi đường giữa. Thế là cãi nhau. Những người còn lại thấy vậy cũng nản.</p>

<p>Vậy giờ phải làm sao? Tốt nhất là bạn hãy chọn những tướng có thể đi được mọi đường để đề phòng những trường hợp như vậy. Đó cũng là cách hay để bạn có thể được tập luyện tướng đó thường xuyên hơn trong đánh thường.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Kayle.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Rất dễ chơi, đẩy đường nhanh, combat tốt và đặc biệt là không bao giờ phế dù bị thọt.<br>
Đó là Kayle.</p></center>

<p>Bạn cũng nên tập một tướng ở nhiều vị trí vì có thể tướng đó có thể cũng thích hợp với vị trí mới. Ví dụ như Viktor, Veigar, Lissandra mặc dù là tướng đường giữa nhưng nếu đi Hỗ Trợ vẫn có thể gây ảnh hưởng lớn. Những tướng đó cấu máu tốt, có hiệu ứng, chiêu cuối rất mạnh, hoàn toàn có thể đi hỗ trợ được.</p>

<h3>6 Là tướng có khả năng đẩy trụ nhanh</b>
<p>Điển hình: Master Yi, Tryndame...</p>

<p>Một vấn đề khác ở Elo Hell đó là đồng đội thích giết người hơn phá trụ. Vì vậy, nếu như có những trận đồng đội quá ham giết người, chẳng còn cách nào khác là bạn phải tự tay đẩy trụ hay đẩy lính lên cao. Cách này cũng có thể kéo dài trận đấu khi team bạn thất thế. Team bạn sẽ có thể có cơ hội lấy lại thế trận bằng cách phá trụ và kéo dài trận đấu.</p>

<h3>7 Là tướng có nhiều sát thương, hiệu ứng mà vẫn chống chịu tốt.</h3>
<p>Điển hình: Galio, Nunu, Lissandra, Amumu, Wukong, Shyvana...</p>

<p>Một số vị tướng khá đặc biệt là có nhiều sát thương, hiệu ứng khống chế mà không cần nhiều đồ sát thương. Vị tướng đó có thể lên nửa chống chịu nửa sát thương rất tốt. Đặc biệt, khi đối thủ chơi những tướng sát thủ như Katarina, Akali, Zed, Master Yi... mà lại còn có lợi thế, đang rất mạnh thì hiệu ứng khống chế nhiều và sức chống chịu tốt chính là phương pháp để khắc chế sát thủ. </p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Galio-Girl.jpg" width="50%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Bạn đã bao giờ nghĩ đến việc dùng Galio để khắc chế Katarina
và những tướng cận chiến ít máu chưa?</p></center>

<h3>8 Là một tướng có chiêu tầm rất xa hay toàn bản đồ.</h3>
<p>Điển hình: Gangplank, Soraka, Kathurs...</p>

<p>Đây cũng là một cách hay. Có thể nhiều người đã biết về Zilean với bộ kỹ năng cũ. Nội tại của Zilean ngày trước có phạm vi toàn bản đồ. Sau này, Riot thấy Zilean đường giữa quá xuất sắc nên đã thay nội tại từ toàn bản đồ chỉ còn phạm vi 1500 xung quanh, mục đích là để Zilean quay về vị trí hỗ trợ. Chỉ một thay đổi nhỏ đó thôi đã khiến Zilean giảm tỉ lệ thắng rất nhiều. Và giờ thì bộ kỹ năng của Zilean đã được làm lại để Zilean có nhiều tác dụng hơn. </p>

<p>Với bộ kỹ năng tầm rất xa hay toàn bản đồ sẽ giúp bạn có mạng giết hoặc hỗ trợ dễ dàng hơn, vừa giúp đỡ đồng đội, vừa dễ kiếm tiền. 2 tướng dễ chơi nhất và có chiêu thức toàn bản đồ là Gangplank và Soraka. Soraka với khả năng hồi máu sẽ giúp Xạ Thủ dễ thở hơn trong giai đoạn ban đầu. Gangplank có thể đi được 4 vị trí và chỉ có chiêu cuối Mưa Đại Bác (R) là kỹ năng định hướng.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Gangplank.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Gangplank có thể đi 3 lane.<br>
Bạn có thể dễ dàng lấy điểm hỗ trợ từ Mưa Đại Bác (R)</p></center>

<p>Kathurs có Khúc Cầu Hồn (R) có thể giúp kiếm mạng hỗ trợ hay mạng giết dễ hơn. Zigg có Siêu Bom Địa Ngục (R) tầm rất xa. Tuy nhiên Ziggs và Kathurs khá khó chơi. Ziggs với 4 kỹ năng định hướng, Kathurs rất yếu máu và tốn năng lượng. Nếu bạn muốn chơi 2 vị tướng này, bạn cần luyện tập rất nhiều.</p>

<p>Một số tướng có kỹ năng toàn bản đồ nhưng lại rất khó trúng như Ezreal, Jinx, Draven, Ashe... thì sẽ không tính vào danh sách này.</p>

<h3>9 Là một tướng có giai đoạn đi đường đơn giản và an toàn</h3>
<p>Điển hình: Dr&apos;Mundo, Irelia, Lulu, Gangplank...</p>

<p>Lưu ý: đơn giản không có nghĩa là dễ dàng.</p>

<p>Có những vị tướng có giai đoạn đi đường rất đơn giản. Ví dụ như Dr&apos;Mundo đi đường chỉ có ôm trụ, farm và hạn chế bị cấu máu đến mức tối đa. Khi đã có được ít nhất 1 món đồ và 1 giày thì Mundo có thể vùng lên đánh lại đối thủ rất khỏe. Các món đồ đầu tiên của Mundo cũng khá rẻ. Thường là Giáp Máu War&apos;mog và Giày Thủy Ngân đầu tiên.</p>

<p>Hoặc như Gangplank chỉ cần đứng farm nhiều lính nhất có thể và cho Mưa Đại Bác (R) vào các đường khác kiếm mạng hỗ trợ. Irelia là tướng farm dưới trụ tốt nhất Liên Minh Huyền Thoại. Đầu game cô ta cũng chỉ cần có vậy để có Tam Hợp Kiếm. Hoàn toàn không có gì phức tạp, đòi hỏi kỹ năng nhiều. Có khi đối thủ sốt ruột, băng trụ và chết, bạn có thể thắng hoặc hòa đường từ đó.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Irelia.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Irelia - tướng farm dưới trụ tốt nhất Liên Minh Huyền Thoại</p></center>

<p>Nếu bây giờ bạn thích đánh những tướng đòi hỏi kỹ năng, thậm chí là phải giết nhiều mạng thì lại là chuyện khác. Giả sử bạn đánh Yasuo, Fiora, Riven. Bạn trao đổi chiêu thức. Khi đó bạn sẽ cần rất nhiều thứ như: phải tính toán sát thương, né kỹ năng, phản xạ nhanh nhạy... Nếu bạn thua, thì gần như 70% bạn thua đường nếu tướng đi rừng không lên hỗ trợ (hiệu quả không lại là chuyện khác). Và chắc chắn không ai muốn nhìn thấy Yasuo, Fiora, Riven đối thủ có được hơn 3 mạng trước phút 20 cả.</p>

<h3>10 Là một tướng hỗ trợ đồng đội, đi gank tốt.</h3>
<p>Điển hình: Yorick, Katarina, Zed...</p>

<p>Một điều mà tất cả những người ở hell elo không biết: đó là trừ Xạ Thủ ra, mọi vị trí đều phải hỗ trợ đồng đội. </p>

<p>Bạn nghĩ đi đường giữa không cần hỗ trợ ai? Nếu bạn xem những người chơi Katarina, Akali, Twisted Fate thì bạn sẽ thấy họ đi gank nhiều hơn đi đường. Nếu nói về đi đường giữa thì chắc chắn Katarina, Akali, Twisted Fate thua xa nhiều tướng khác như Heimerdinger, Viktor, Ahri... Nhưng thứ làm nên sự đáng sợ của Katarina, Akali và Twisted Fate là khả năng đi gank các đường khác và ăn mạng, từ đó họ kiếm được tiền và mạnh lên chứ không phải là đẩy đường.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Katarina.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Nỗi kinh hoàng ở Elo Hell là không chịu cắm mắt thường xuyên.
Và Katarina đã tận dụng tốt sai lầm đó.</p></center>

<p>Bạn nghĩ đi đường trên không cần hỗ trợ ai? Vậy tại sao trong giải đấu, các game thủ chuyên nghiệp luôn cầm Dịch Chuyển? Đó là vì họ muốn hỗ trợ đường khác khi có đánh nhau. Một số tướng như Gangplank, Shen thì không cần Dịch Chuyển vẫn có thể hỗ trợ được.Và nếu như bạn đã chấp nhận đánh những tướng 70% thua đường như Poppy, Singed, Shen thì việc bạn đi gank có khi còn có tác dụng hơn là đi solo với đối thủ mạnh hơn vào đầu game như Fiora, Yasuo, Renekton...</p>

<p>Thậm chí ngay cả tướng Hỗ Trợ cũng phải biết đi gank. Ở rank thấp, tướng Hỗ Trợ đi gank là một cái gì đó xa lạ. Nhưng khi lên rank cao, việc đó là bình thường. Những tướng như Blitcrank, Lulu, Zyra, Morgana, Karma, Alistar... chạy ra đường giữa gank là chuyện thường thấy. Tất nhiên đó là khi Xạ Thủ của bạn đã có lợi thế hoặc đối thủ đang về nhà. Với meta bây giờ, cộng với sự xuất hiện của Bard, Tahm Kench thì việc tướng Hỗ Trợ đi gank là chuyện bình thường.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Yorick-thang-lien-tuc.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" /><br><br>

<img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Yorick-thang-lien-tuc-8thang-1thua.jpg" width="100%" alt="Kinh nghiệm chọn tướng ở Elo Hell" /></center>

<h3>11 Giảm tối đa công việc mà bạn phải làm</h3>
<p>Điển hình: Soraka, Lulu, Janna, Dr.Mundo...</p>

<p>Nếu bạn chơi những tướng như Braum, Leona, Jarvan, Morgana... bạn sẽ phải làm rất nhiều công việc: mở giao tranh, lao vào khống chế càng nhiều đối thủ càng tốt, gây sát thương, bảo vệ đồng đội... Liệu bạn có ôm được hết ngần đó việc? Chưa kể đến trường hợp bạn mở giao tranh dở như Thái Dương Hạ San (R), Băng Địa Chấn (R) hay Khóa Bóng Tối (Q) hụt.</p>

<p>Bạn nên đơn giản hóa công việc của bạn. Khi bạn chơi Soraka, Lulu, Janna, bạn chỉ cần làm 1 việc duy nhất: bảo vệ đồng đội, buff tất cả những gì bạn có như lá chắn, máu, kích hoạt Vinh Quang Chân Chính, Yêu Sách Của Băng Hậu, Dây Chuyền Iron Solari... Còn đồng đội giao tranh kiểu gì cứ để đồng đội lo.</p>

<p>Tuy nhiên, lựa chọn này sẽ là con dao hai lưỡi. Nếu đồng đội khỏe, bạn cũng rất khỏe. Nếu đồng đội phế, bạn sẽ chẳng thể nào cứu trận đấu được vì đối thủ quá xanh. Khi Zed khỏe đến mức Lulu buff chiêu cuối không ăn thua thì chỉ còn cách cầu nguyện cho game kéo càng dài càng tốt.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Lulu-Kogmaw.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" />

<p>Khi chơi Lulu, bạn chỉ cần tập trung bảo vệ Xạ Thủ, <br>
không cần làm việc gì khác nữa.</p></center>

<p>Tất nhiên những lựa chọn trên chỉ là gợi ý. Quan trọng nhất vẫn là trình độ của bạn. Chúc bạn thành công.</p>

<h3>12 Vừa đẩy lẻ, vừa đảo đường bằng Cổng Hư Không.</h3>
<p>Điển hình: Shen, Rek&apos;sai, Sion, Hecarim, Tahm Kench, Rammus, Shyvana…</p>

</p>Trong các giải đấu, chiến thuật vừa đẩy lẻ, vừa đảo đường được thực hiện rất nhiều với Hecarim, Shen, Tahm Kench đường trên vì khả năng đảo đường rất nhanh. Hơn nữa, với trang bị Cổng Hư Không, bạn hoàn toàn có thể đặt Cổng Hư Không như một con mắt tím để đẩy đường và chạy ra hỗ trợ đồng đội. Đối thủ sẽ phải chạy ra phá cổng rồi mới quay lại được.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Rammus-poro.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" /></center>

<p>Cổng Hư Không rất có tác dụng với những tướng như Sion, Rammus. Sion đã có máu tăng vĩnh viễn, mua thêm Cổng Hư Không có giáp, kháng phép và đẩy lính. Rammus, Hecarim, Shyvana có tốc độ di chuyển cực nhanh. Shen với chiêu cuối đảo đường ngay lập tức. Những tướng trên lại là tướng Đấu Sĩ, Đỡ Đòn nên không bao giờ vô tác dụng trong giao tranh.</p>

<center><img src="/upload/images/game/Kinh-nghiem-chon-tuong-o-Elo-Hell-Thong-Dao-zzrot.jpg" width="70%" alt="Kinh nghiệm chọn tướng ở Elo Hell" /></center>
',

            'date_post'         => '2015-08-09',
            'thumbnail_post'    => 'Kinh-nghiem-chon-tuong-o-Elo-Hell-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Hitman: Blood Money - Đồng tiền tội lỗi',
            'url_post'        => 'Hitman-Blood-Money-Dong-tien-toi-loi',
            'present_vi_post' => 'Tiếp tục với những nhiệm vụ ám sát của sát thủ đầu trọc 47. Lần này, tên sát thủ đã có nhiều kỹ năng đặc biệt hơn để thích hợp với những nhiệm vụ khó khăn hơn.',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Hitman: Blood Money
<li>Thể loại: Hành động bí mật
<li>Sản xuất năm: 2002.
<li>Hãng sản xuất: Eidos Interactive.
<li>Cấu hình:  CPU: 2 GHz Pentium IV, RAM: 1GB, HDD Space: 5GB, Video: 128 MB Directx 9, Windows XP, 7,8.
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B28sd7bsR2N9UE01bHM5LTJFcTA/view?resourcekey=0-QUnk10IEomG1jZCINWLMEQ" rel="nofollow" target="_blank" title="Hitman: Blood Money">Google Drive KINGDOM NVHAI</a></p>

<p>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4</a></p>

<center><img src="/upload/images/game/Hitman-Blood-Money-Dong-tien-toi-loi-1.jpg" width="100%" alt="Hitman: Blood Money - Đồng tiền tội lỗi" /></center>

<p>Tiếp tục với series game Hitman, fan hâm mộ thể loại hành động bí mật sẽ được nhập vai sát thủ đầu trọc 47 thực hiện những nhiệm vụ ám sát ở ngay chốn đông người mà không ai bắt được hắn. Hitman Blood Money đã tiếp nối thành công của series game, trở thành một tựa game hành động nhập vai khó có thể bỏ qua.</p>

<p>Trong Hitman Blood Money, sát thủ đầu trọc sẽ phải thực hiện 12 nhiệm vụ ám sát khó khăn. Từ ám sát trong một bữa tiệc trong rừng, một nhà hát kích cho đến khu lễ hội đông người. Và màn chơi cuối cùng là tại nơi mà không ai có thể xâm nhập được: Nhà Trắng để ám sát phó tổng thống. Sau khi làm xong nhiệm vụ tại Nhà Trắng, sát thủ còn thêm một nhiệm vụ phụ nữa.</p>

<center><img src="/upload/images/game/Hitman-Blood-Money-Dong-tien-toi-loi-2.jpg" width="100%" alt="Hitman: Blood Money - Đồng tiền tội lỗi" /></center>

<p>Hitman Blood Money hoàn toàn khác hẳn so với Hitman 2: Silent Assasin. Trong Silent Assasin, các nhiệm vụ đều là những vụ ám sát tại những nơi không người. Xung quanh không có ai ngoài lính và mục tiêu. Vì vậy, bạn có thể hành động khá dễ dàng. Còn Blood Money, 12 màn chơi đều là những chỗ đông người. Bạn sẽ không thể rút súng bắn xong cất đi, đợi tên lính khác chạy tới rồi lại bắn tiếp như trước. Chỉ cần những động tác lạ, người xung quanh sẽ hét lên và bỏ chạy.</p>

<p>Yếu tố hay nhất trong game chính là việc bạn có thể có nhiều cách xử lý. Bạn có thể hạ mục tiêu bằng cách im lặng nhưng hơi khó khăn bằng dao, dây xiết cổ hay thuốc độc. Bạn cũng có thể chọn cách ồn ào như đặt một quả bom vào một gói quà, cặp… rồi để ở khu vực gần mục tiêu. Tuy nhiên, cả 12 màn chơi không có màn nào bắt bạn phải sử dụng súng ngắm để hạ mục tiêu nên bạn không được thể hiện khả năng bắn tỉa nhiều như Silent Assasin.</p>

<center><img src="/upload/images/game/Hitman-Blood-Money-Dong-tien-toi-loi-3.jpg" width="100%" alt="Hitman: Blood Money - Đồng tiền tội lỗi" />

<p>Bắn vỡ hồ bơi kính để nạn nhân rơi từ trên cao xuống</p></center>

<p>Cách thức ám sát cũng rất khác, rất phong phú. Sát thủ 47 giờ đã có nhiều khả năng mới như xô mục tiêu từ trên cao xuống, phi tang xác bằng cách bỏ vào thùng hay ném từ trên cao xuống, leo cột nhà… Thậm chí một số màn đòi hỏi người chơi phải chịu khó tìm tòi cách ám sát mục tiêu. Người viết thích nhất là màn 7 (You Better Watch Out). Mục tiêu đang ngồi ở hồ bơi kính ngoài trời. Sát thủ xuống tầng dưới, bắn một phát súng giảm thanh làm vỡ hồ bơi rồi rút lui. Cách ám sát rất nhanh gọn, không một dấu vết đó thực sự rất sáng tạo.</p>

<p>Tuy nhiên, game vẫn có điểm thiếu sót. Người viết rất khó chịu với sự sợ hãi của dân thường. Nhiều lúc sát thủ đầu trọc chỉ chạy ngang qua, hoàn toàn không làm gì người dân xung quanh nhưng họ cứ nhìn thấy là chạy. Phải chăng cái đầu trọc và bộ mặt lạnh bang của hắn khiến người ta nhìn thấy thôi đã sợ chạy tán loạn? Đó là lỗi game khá khó chịu.</p>

<center><img src="/upload/images/game/Hitman-Blood-Money-Dong-tien-toi-loi-4.jpg" width="100%" alt="Hitman: Blood Money - Đồng tiền tội lỗi" />
<p>Phi tang xác vào thùng.</p></center>

<p>Độ khó của game ngày một tăng. Trong Silent Assasin, người chơi được phép sử dụng 2 tay 2 súng, súng bắn tỉa thì Blood Money khác hẳn. Đầu game, súng ngắn của người chơi sẽ không có giảm thanh, chỉ có 1 khẩu duy nhất. Sau vài nhiệm vụ, sát thủ sẽ có thêm tiền, từ đó tân trang thêm cho vũ khí của mình những phụ kiện như ống giảm thanh, tia hồng ngoại và thêm 1 khẩu súng ngắn nữa. Một điểm hơi thừa là dù game cung cấp Shotgun và M4 nhưng những khẩu này hoàn toàn không dùng đến ngay từ đầu vì nó quá lộ liễu. Có vẻ như những khẩu súng đó chỉ để cho đẹp, làm tăng tính chuyên nghiệp của sát thủ 47. Bù lại, bom kích nổ từ xa lại luôn thường trực trong túi sát thủ nên người chơi có thể làm một pha náo loạn để tiêu diệt mục tiêu.</p>

<p>Hitman Blood Money xứng đáng là một trong số những tựa game không thể bỏ qua. Hình ảnh đẹp mắt, cấu hình rất nhẹ và lối chơi đa dạng chắc chắn sẽ cuốn hút bạn. Hãy nhanh chóng tham gia vào những nhiệm vụ ám sát của sát thủ đầu trọc 47.</p>',

            'date_post'         => '2015-08-11',
            'thumbnail_post'    => 'Hitman-Blood-Money-Dong-tien-toi-loi-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Chronicle: RuneScape Legends - Game đấu bài hấp dẫn mới',
            'url_post'        => 'Chronicle-RuneScape-Legends-Game-dau-bai-hap-dan-moi',
            'present_vi_post' => 'Một tựa game đấu bài mang phong cách mới đang trong giai đoạn Close Beta. ',
            'content_vi_post' => '<p>Trang chủ <a href="https://www.rschronicle.com/">Chronicle: RuneScape Legends</a></p>

<p>Game online đấu bài Chronicle: RuneScape Legends đã mở cửa cho game thủ đăng ký chơi thử closed beta và sẽ mở cửa thử nghiệm dự kiến là vào tháng tới.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/F4Qv221_ydE" frameborder="0" allowfullscreen></iframe><br>

<p>Trailer game Chronicle: RuneScape Legends</p></center>

<p>Nếu như các bạn đã biết đến Hearthstone, một tựa game đấu bài nổi tiếng nhất hiện nay và là một trong số các trò chơi được thi đấu eSport thì Chronicle: RuneScape Legends cũng là một tựa game như vậy. </p>

<p>Tuy nhiên, nếu Hearthstone là tựa game dựa trên World of Warcraft và mang tính chất thuần đấu bài thì Chronicle: RuneScape Legends lại là tựa game dựa trên game RuneScape và có xu hướng theo dạng dàn trận. Bạn sẽ triệu hồi các quái vật trên những bản đồ khác nhau và di chuyển chúng. Giống như bạn đang chơi một ván cờ kết hợp với đấu bài hơn là một game đấu bài thuần túy như Hearthstone. </p>

<p>Trang chủ <a href="http://www.runescape.com/community">RunScape</a></p>

<center><iframe width="420" height="315" src="https://www.youtube.com/embed/17CrXMT2yEY" frameborder="0" allowfullscreen></iframe><br>

<p>Gameplay của Chronicle: RuneScape Legends</p></center>

<p>Đồ họa 3D trong game khá đẹp. Từ tòa lâu đài to lớn đến ngôi làng bé nhỏ đều được thực hiện khá rõ nét. Chronicle: RuneScape Legends cũng giống như Hearthstone. Bạn phải chọn 1 hero và sử dụng 3 loại bài quái vật, phép và bẫy để tấn công đối thủ.</p>

<center><img src="/upload/images/game/Chronicle-RuneScape-Legends-map.jpg" width="100%" alt="Chronicle: RuneScape Legends - Game đấu bài hấp dẫn mới" /></center>

<p>Dựa trên các bình luận trên Youtube, có nhiều ý kiến trái chiều nhau về dạng game này. Có những người thích game thuần đấu bài như Hearthstone nhưng có nhiều ý kiến thích thú về phong cách chơi mới này. Chắc chắn game Chronicle: RuneScape Legends sẽ tiêu hao khá nhiều chất xám của những ai muốn khám phá nó.</p>',

            'date_post'         => '2015-08-25',
            'thumbnail_post'    => 'Chronicle-RuneScape-Legends-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'ELOA - Game 3D Anime mới',
            'url_post'        => 'ELOA-Game-3D-Anime-moi',
            'present_vi_post' => 'Một tựa game MMORPG 3D mang phong cách Anime đang trong giai đoạn thử nghiệm. ELOA - Elite Lord of Alliance do hãng Webzen của Hàn Quốc.',
            'content_vi_post' => '<p>Trang chủ <a href="http://eloa.webzen.com/en">ELOA</a></p>

<p>Hãng Webzen của Hàn Quốc vừa cho ra mắt game MMORPG mang tên ELOA - Elite Lord of Alliance. Game đang trong giai đoạn Close Beta thử nghiệm.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/pvZ_7eNZh8k" frameborder="0" allowfullscreen></iframe>

<p>Trailer ELOA</p></center>

<p>ELOA là game mang phong cách Anime, được thiết kế trên đồ họa 3D với camera xoay nhiều góc độ. Người chơi sẽ hóa thân thành các anh hung đi phiêu lưu, luyện level, mua sắm vũ khí, tham gia các sự kiện như mọi game MMORPG khác.</p>

<center><img src="/upload/images/game/ELOA-Elite-Lord-of-Alliance-1.jpg" width="100%" alt="ELOA - Game 3D Anime mới" /></center>

<p>Nếu ai đã từng chơi game Aura Kingdom thì sẽ thấy ELOA có những điểm tương đồng. Đầu tiên là âm nhạc. Trong trailer, âm nhạc mang phong cách hùng tráng giống như Aura Kingdom. Thứ 2, những bảng điểm, menu, thùng đồ, menu kỹ năng cũng có thiết kế tương tự. Tuy nhiên, trò chơi vẫn mang phong cách khác với Aura Kingdom là bạn sẽ chơi theo góc nhìn 2,5D có thể phóng to thu nhỏ. Aura Kingdom lại là game thuần 3D. Vì vậy, cấu hình của ELOA phù hợp với nhiều loại máy.</p>

<center><img src="/upload/images/game/ELOA-Elite-Lord-of-Alliance-2.jpg" width="100%" alt="ELOA - Game 3D Anime mới" /><br><br>

<img src="/upload/images/game/ELOA-Elite-Lord-of-Alliance-3.jpg" width="100%" alt="ELOA - Game 3D Anime mới" />

<p>ELOA đã được quảng cáo trên các trang mạng.</p></center>

<p>Hiện mọi người đã có thể đăng ký để chơi ELOA. Nếu ai thích thú với Anime Nhật Bản hay đã từng chơi Aura Kingdom, hãy thử ghé qua ELOA thử xem.</p>',

            'date_post'   => '2015-08-28',
            'thumbnail_post'    => 'ELOA-Game-3D-Anime-moi-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Attack On Pearl Harbor - Trân Châu Cảng',
            'url_post'        => 'Attack-On-Pearl-Harbor-Tran-Chau-Cang',
            'present_vi_post' => 'Một tựa game mô phỏng lái máy bay cấu hình nhẹ, dễ chơi và rất hấp dẫn nói về thế chiến thứ 2.',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Attack on Pearl Harbor
<li>Thể loại: Hành động - Mô phỏng
<li>Sản xuất năm: 2007
<li>Hãng sản xuất: Adventure Company
<li>Cấu hình: CPU: 1.6 GHz Pentium IV, RAM: 1 GB, CD-ROM/DVD-ROM: 16X, Hard Drive Space: 250 MB available, Video: 64MB nVidia GeForce 3/ATI Radeon 8500 Directx 9, Sound: 16-bit Directx, Windows XP, 7,8.
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B5kR2OM-nt4TUlRIMGZOLXJzNGs/view?usp=sharing&resourcekey=0-RYD_FdVC4vlE65NyxU5lkQ">Google Drive KINGDOM NVHAI</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/7izBdnQGmuQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Attack on Pearl Harbor Gameplay phe Nhật</p></center>

<p>Sau thành công rực rỡ của bộ phim Pearl Harbor - Trân Châu Cảng được sản xuất năm 2001, những game về thể loại thế chiến thứ 2 xoay quanh Trân Châu Cảng được đi vào sản xuất. Và một tựa game nhẹ mà hay nói về đề tài thế chiến thứ 2 không thể bỏ qua là game Attack on Pearl Harbor được sản xuất vào năm 2007.</p>

<center><img src="/upload/images/game/Pearl-Harbor-Movie.jpg" width="70%" alt="Attack On Pearl Harbor - Trân Châu Cảng" />

<p>Bộ phim Trân Châu Cảng năm 2001 đến bây giờ vẫn thu hút rất nhiều khán giả.</p></center>

<p>Trò chơi khá dễ chơi. Bạn chỉ cần chọn phần chiến dịch, bắt đầu với phe Mỹ hoặc Nhật. Và tất nhiên, trận đánh mở màn chính là trận đánh đã đi vào lịch sử là một trong những trận đánh nổi tiếng nhất thế chiến thứ 2: Trân Châu Cảng. Sau đó là những trận đánh nhỏ khác. Nhiệm vụ của bạn có thể là tiêu diệt toàn bộ máy bay địch, phá hủy các cứ điểm, thả ngư lôi tiêu diệt tàu chiến hay hộ tống máy bay ném bom bay vào Tokyo.</p>

<center><img src="/upload/images/game/Attack-On-Pearl-Harbor-2.jpg" width="100%" alt="Attack On Pearl Harbor - Trân Châu Cảng" /></center>

<p>Chủng loại máy bay mà bạn có thể điều khiển được chia làm 2 loại: máy bay tiêm kích và máy bay ném bom. Máy bay tiêm kích có tốc độ bay rất cao và sung máy khá mạnh. Máy bay ném bom thì to nặng nên bay chậm hơn, khả năng bắn yếu hơn nhưng bù lại có một khẩu súng bắn ngược lại phía sau. Máy bay ném bom còn chia làm 2 loại là máy bay ném ngư lôi và máy bay ném bom.</p>

<center><img src="/upload/images/game/Attack-On-Pearl-Harbor-4.jpg" width="100%" alt="Attack On Pearl Harbor - Trân Châu Cảng" />

<p>Máy bay nào là máy bay Mỹ? Máy bay nào là máy bay Nhật?</p></center>

<p>Cách điều khiển khá dễ. Bạn chỉ cần dùng chuột để điều khiển camera, chuột trái để bắn, chuột phải để ném bom. Không có gì phức tạp. Tuy nhiên, game lại mắc 2 lỗi. Lỗi thứ nhất là lỗi phóng tên lửa của máy bay tiêm kích. Rất nhiều game lấy đề tài thế chiến thứ 2 mắc phải lỗi này. Máy bay thời thế chiến thứ 2 không có khả năng phóng tên lửa. Chính vì lỗi này mà máy bay tiêm kích của bạn dư sức hạ gục đối thủ chỉ với 1 quả tên lửa. Đây là lỗi rất nghiêm trọng.</p>

<p>Lỗi thứ 2 là giọng của điện đài. Người viết thắc mắc chẳng lẽ nhà sản xuất không thể tìm được một người có thể nói giọng điện đài viên mà lại phải dùng những âm thanh khó nghe lặp đi lặp lại như vậy? Lỗi này có thể bỏ qua vì đã có hướng dẫn tiếng Anh nhưng nếu như giọng điện đài là một câu nói hoàn chỉnh thì sẽ hay hơn là những âm thanh giống như radio rè rè lặp đi lặp lại.</p>

<center><img src="/upload/images/game/Attack-On-Pearl-Harbor-3.jpg" width="100%" alt="Attack On Pearl Harbor - Trân Châu Cảng" />

<p>Những dòng hướng dẫn cách chơi của điện đài.</p></center>

<p>Đồ họa của game khá tốt. Người viết rất thích những trận đánh lớn giữa các đội chiến hạm đánh với nhau. Tàu sân bay cho ra nhiều máy bay bắn nhau và cuối cùng là thả bom tiêu diệt toàn bộ tàu đối thủ. Máy bay đối thủ bắn khá rát khiến việc tấn công tàu đối thủ và bảo vệ tàu mình gặp nhiều khó khan. Tuy nhiên, nếu như nhiệm vụ cuối cùng của Mỹ là hộ tống máy bay ném bom hạt nhân tiến vào Hiroshima và Nagasaki thì nhiệm vụ cuối cùng của Nhật lại là chiến đấu xong… đâm đầu xuống đất tự sát. Đây là một điểm khá hài hước của game.</p>

<p>Dù sao, đây cũng là một game cũ mà hay rất đáng chơi nếu bạn yêu thích thể loại mô phỏng lái máy bay mà cấu hình máy không cho phép chơi những game nặng hiện nay. Cách chơi đơn giản mà cũng khá thú vị, đồ họa không quá lỗi thời, chắc chắn bạn sẽ thích những trận chiến đã đi vào lịch sử của thế chiến thứ 2.</p>

<p><b>Học lịch sử:</b></p>

<center><img src="/upload/images/game/Attack-On-Pearl-Harbor-Nhat-that-bai.jpg" width="70%" alt="Attack On Pearl Harbor - Trân Châu Cảng" /></center>

<p>Sau khi Mỹ thất bại thảm hại ở thế chiến thứ 2, Mỹ đã tập trung đánh bại Nhật nhằm rửa hận.</p>

<p>7/1942: tại đảo san hô Midway, Nhật dự định sẽ tiêu diệt hạm đội Mỹ nhưng thất bại nặng nề.</p>

<p>6/1944: cả 2 bên đã sử dụng tổng cộng 24 hàng không mẫu hạm trong trận đánh này (15 của Mỹ và 9 của Nhật). Và Nhật đã thảm bại khi mất 475 máy bay và 3 hàng không mẫu hạm.</p>

<p>10/1944: Trận chiến vịnh Leyte được xem là trận hải chiến lớn nhất của Thế Chiến II. Kết quả là Nhật thất bại với hơn 10000 người chết và 4 hàng không mẫu hạm.</p>

<p>6/8/1945 và 9/8/1945: 2 quả bom nguyên tử được thả xuống Hiroshima và Nagasaki. Tổng cộng hơn 200000 người chết.</p>',

            'date_post'         => '2015-09-08',
            'thumbnail_post'    => 'Attack-On-Pearl-Harbor-Tran-Chau-Cang-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Giới thiệu sơ lược về ELOA',
            'url_post'        => 'Gioi-thieu-so-luoc-ve-ELOA',
            'present_vi_post' => 'Sau bài viết giới thiệu về ELOA, KINGDOM NVHAI sẽ giới thiệu sơ lược về cách chơi game mang phong cách Anime trẻ trung này.',
            'content_vi_post' => '<p>ELOA là game MMORPG của hãng Webzen sản xuất và phát hành. Trò chơi đã chính thức Open Beta vào ngày 17/11/2015. Khi người viết chơi game, đã có nhiều game thủ Việt Nam tham gia trò chơi. Bài viết này sẽ giới thiệu sơ lược về game. Hy vọng những ai yêu thích thể loại game MMORPG hay phong cách Anime, chiến đấu thời Trung Cổ sẽ tham gia trò chơi.</p>

<p>Xem thêm: <a href="/post/ELOA-Game-3D-Anime-moi" target="_blank">ELOA - Game 3D Anime mới</a></p>

<p>Trò chơi có 5 lớp nhân vật:</p>

<ul>
<li>Blood Knight: Khả năng phòng ngự tốt.
<li>Mage: Sát thương phép tầm xa.
<li>Sniper: Sát thương vật lý, sử dụng súng, cung và mìn.
<li>Psychic: Người hỗ trợ cho đồng đội.
<li>Assassin Warrior: Sát thủ sử dụng dao, móng vuốt, lưỡi hái, tiêu diệt 1 hay nhiều mục tiêu với sát thương lớn.
</ul>

<center><img src="/upload/images/game/ELOA-Gioi-thieu-so-luoc-2.jpg" width="100%" alt="Giới thiệu sơ lược về ELOA" />

<p>Người viết chọn nhân vật Sát Thủ (Assassin Warrior)</p></center>

<p>Sau khi đã chọn nhân vật, người chơi bắt đầu tập các thao tác đơn giản, tham gia trận chiến giúp NPC chiếm lại thành trì Baratan Fortress. Sau đó, người chơi sẽ bắt đầu làm các nhiệm vụ và được nhận 1 pet để cưỡi. Người chơi có thể mua thêm nhiều pet khác để chúng buff sức mạnh cho người chơi hoặc làm đồ ăn cho các pet khác để tăng cấp. Tuy nhiên, hãy lưu ý là không phải pet nào cũng cưỡi được.</p>

<center><img src="/upload/images/game/ELOA-Gioi-thieu-so-luoc-3.jpg" width="100%" alt="Giới thiệu sơ lược về ELOA" />

<p>Nơi dịch chuyển đến các vùng đất</p></center>

<p>Tiền tệ trong game có 3 loại: Đồng, Bạc, Vàng. 100 Đồng đổi lấy 1 Bạc. 100 Bạc đổi lấy 1 Vàng. Vũ khí trong game nếu cảm thấy không cần thiết, có thể bỏ đi để tạo ra các quặng Bạc, Vàng… Các quặng đó sẽ được dùng để đúc vũ khí, áo giáp hoặc bình máu, năng lượng.</p>

<center><img src="/upload/images/game/ELOA-Gioi-thieu-so-luoc-4.jpg" width="100%" alt="Giới thiệu sơ lược về ELOA" /></center>

<p>Bản đồ trong game khá rộng lớn nhưng không tạo cảm giác phải chạy bộ quá dài. Sau khi hoàn thành xong nhiệm vụ cuối cùng ở vùng đất hiện tại, người chơi sẽ sang vùng đất thứ 2 là Lost City, dành cho nhân vật từ level 12 trở lên. Quái vật càng lúc càng mạnh, khiến người chơi rất khó để hoàn thành các nhiệm vụ. Người viết nhiều lần bị một đàn quái vật lao vào, đánh mất máu rất nhanh. Nếu không có bình máu thì rất khó có thể sống sót. Nhất là nhiệm vụ cuối cùng cần có party. Nếu không, boss cuối sẽ không thể đánh một mình được.</p>

<center><img src="/upload/images/game/ELOA-Gioi-thieu-so-luoc-5.jpg" width="100%" alt="Giới thiệu sơ lược về ELOA" />

<img src="/upload/images/game/ELOA-Gioi-thieu-so-luoc-6.jpg" width="100%" alt="Giới thiệu sơ lược về ELOA" />

<p>Vùng đất Lost City</p></center>

<p>Người chơi Việt Nam không cần phải lo về kết nối, cấu hình hay bị chặn ID gì cả. Người viết cài game và chơi bình thường như chơi Liên Minh Huyền Thoại ở Việt Nam hay chơi Hearthstone, Aura Kingdom ở nước ngoài. ELOA là trò chơi được đánh giá là cấu hình nhẹ. Một tin bên lề là ELOA chưa về VN. NPH SGame đã ký hợp đồng với Webzen nói rằng thương vụ đang gặp trục trặc. Còn ở phương Tây, game được đổi tên thành Inspirit Online.</p>

<p>Hy vọng với những thông tin giới thiệu vừa rồi, các game thủ Việt Nam sẽ tham gia ELOA để trải nghiệm những điều mới mẻ.</p>
',
            'date_post'   => '2015-09-17',
            'thumbnail_post'    => 'ELOA-Gioi-thieu-so-luoc-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'To Love-Ru Darkness: True Princess được phát hành',
            'url_post'        => 'to-love-ru-darkness-true-princess-game-posts-deviluke-promo',
            'present_vi_post' => 'Game Visual Novel về Thánh Ngã Rito tiếp nối phiên bản Anime thành công trước đó đã ra mắt vào ngày 5/11/2015.',
            'content_vi_post' => '<p>Trên trang chủ của hãng Furyu về game <a href="http://www.cs.furyu.jp/toloveru-tp/">To Love-Ru Trouble Darkness: True Princess</a> đã ra mắt trailer giới thiệu với tiêu đề “Datsu!! Rakuen!? Deviluke-hen” (Thiên đường (Harem) trốn thoát!? Deviluke) vào ngày 8/9/2015. Trò chơi dành cho hệ máy PS Vita đã được phát hành vào ngày 5/11/2015.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/hqRLgiLdY7o" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/KGxX6tnXZ3I" frameborder="0" allowfullscreen></iframe>

<p>Trailer To Love-Ru Trouble Darkness: True Princess</p></center>

<p>Trailer giới thiệu các nhân vật, lấy bối cảnh câu chuyện diễn ra vào tháng 9, trong gia đình và trường trung học Sainan, hứa hẹn một thế giới khác với bản gốc từ Anime và Manga. Trong game, Rito mất ký ức vì "một sự cố nào đó". Cậu không nhớ bất kỳ điều gì từ sau khi gặp Lala. Và 11 cô gái sẽ phải thể hiện tình yêu của họ, làm cho cậu nhớ lại và cũng để cậu tìm cho mình một công chúa thật sự. </p>

<center><img src="/upload/images/game/To-Love-Ru-Trouble-Darkness-True-Princess-1.jpg" width="70%" alt="To Love-Ru Darkness: True Princess được phát hành" /></center>

<p>Nội dung trong game nối tiếp phần Anime đã được phát hành vào tháng 5/2014. Trong phiên bản Anime To Love-Ru Trouble Darkness (hay còn gọi là To Love-Ru Darkness 2nd), Rito đã có thêm 2 cô gái mới vào Harem của mình là Mea và Nemexis. Trong game, cả 2 cô gái cũng sẽ xuất hiện.</p>

<p>Furyu đang "háo hức mong đợi trò chơi mô phỏng hẹn hò." Phiên bản sẽ có giá bán lẻ 6.980¥ (129.800 VNĐ), các phiên bản giới hạn sẽ có giá bán lẻ 8.980¥ (166.900 VNĐ). Các phiên bản tải về sẽ có giá bán lẻ 6.480 ¥ (120.500 VNĐ).</p>

<center><img src="/upload/images/game/To-Love-Ru-Trouble-Darkness-True-Princess-2.jpg" width="70%" alt="To Love-Ru Darkness: True Princess được phát hành" /></center>

<p>Phiên bản giới hạn bao gồm một gói với hình ảnh minh họa độc quyền, một mã sản phẩm cho một trò chơi "nguồn gốc kính xuyên thấu" cho phép người dùng nhìn xuyên quần áo của các nhân vật, một tấm chăn "Momo x Mea" gồm một hình ảnh họ ngủ chung, và 11 áo jacket khác nhau in hình mỗi nhân vật.</p>

<center><img src="/upload/images/game/To-Love-Ru-Trouble-Darkness-True-Princess-4.jpg" width="100%" alt="To Love-Ru Darkness: True Princess được phát hành" />

<img src="/upload/images/game/To-Love-Ru-Trouble-Darkness-True-Princess-5.jpg" width="70%" alt="To Love-Ru Darkness: True Princess được phát hành" /></center>

<p>Nguồn: <a href="http://www.animenewsnetwork.com/news/2015-09-09/to-love-ru-darkness-true-princess-game-posts-deviluke-promo/.92714" rel="nofollow" target="_blank" title="To Love-Ru Trouble Darkness True Princess">Anime News Network</a></p>
',
            'date_post'         => '2015-09-27',
            'thumbnail_post'    => 'to-love-ru-darkness-true-princess-game-posts-deviluke-promo-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Blizzard vinh danh game thủ Hearthstone Việt Nam',
            'url_post'        => 'Blizzard-vinh-danh-game-thu-Hearthstone-Viet-Nam',
            'present_vi_post' => 'Sau những thành tích xuất sắc tại giải Hearthstone Đông Nam Á và Châu Á, Neilyo được Blizzard khen ngợi và chuẩn bị tham gia Chung Kết Thế Giới tháng 11 sắp tới.',
            'content_vi_post' => '<p>Sau trận thắng với game thủ Hearthstone Taesang Hàn Quốc, Trần Hưng Lân (Neilyo) - nhà vô địch Hearthstone khu vực Châu Á sẽ tranh tài tại vòng chung kết thế giới tháng 11 tới đây.</p>

<p>Trang Fanpage của Hearthstone đã đăng <a href="https://www.facebook.com/HearthstoneSEA/photos/a.140648252812317.1073741830.138632246347251/416145065262633/?type=3">hình ảnh khen ngợi Neilyo.</a></p>

<center><img src="/upload/images/game/Blizzard-vinh-danh-game-thu-Hearthstone-Viet-Nam-1.jpg" width="70%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" /></center>

<p>Neilyo là game thủ Hearthstone Việt Nam đã chiến thắng xuất sắc trong khu vực Đông Nam Á và Châu Á vừa qua. Vào tháng 9/2015, Neilyo đã chiến thắng trong khu vực Đông Nam Á sau khi thắng Chalk người Philippines, lên ngôi vô địch giải đấu Hearthstone lớn nhất Đông Nam Á.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/TKof4AE9zmg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận chung kết giữa Neilyo và Chalk</p>

<img src="/upload/images/game/Neilyo-vo-dich-Dong-Nam-A.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<img src="/upload/images/game/Neilyo-vo-dich-Dong-Nam-A-2.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<img src="/upload/images/game/Neilyo-vo-dich-Dong-Nam-A-3.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<img src="/upload/images/game/Neilyo-vo-dich-Dong-Nam-A-4.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<p>Thành tích thi đấu ấn tượng của Neilyo tại giải Đông Nam Á.</p></center>

<p>Sau đó, vào tháng 10, Neilyo đi thi đấu tại giải vô địch Châu Á và đã giành chiến thắng trước đối thủ người Hàn Quốc Taesang. Neilyo là tuyển thủ đầu tiên ở khu vực Châu Á Thái Bình Dương giành vé tham gia giải vô địch Hearthstone thế giới được tổ chức tại Anaheim, California trong sự kiện BlizzCon 2015 diễn ra trong hai ngày 06/11 và 07/11/2015.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/v_IWqJwVIoY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận chung kết giữa Neilyo và Taesang</p></center>

<p>Trên trang <a href="http://www.gosugamers.net/hearthstone/rankings">Gosugamers</a>, lần đầu tiên trong lịch sử, có 1 SEA player lọt vào top 10 thế giới, top 1 Châu Á trên bảng xếp hạng. Đây là một điều đáng tự hào dành cho Việt Nam và Đông Nam Á. Người Việt Nam ở sau Neilyo là TaeyeonK, hiện đang ở trong top 50 thế giới, top 9 Châu Á. </p>

<center><img src="/upload/images/game/Blizzard-vinh-danh-game-thu-Hearthstone-Viet-Nam-Neilyo-rank-10.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<img src="/upload/images/game/Blizzard-vinh-danh-game-thu-Hearthstone-Viet-Nam-Taeyeonk-rank-45.jpg" width="100%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<p>2 game thủ Hearthstone giỏi nhất Việt Nam hiện nay</p>

<img src="/upload/images/game/Blizzard-vinh-danh-game-thu-Hearthstone-Viet-Nam-Neilyo-deck.jpg" width="70%" alt="Blizzard vinh danh game thủ Hearthstone Việt Nam" />

<p>Bộ bài của Neilyo gồm Patron Warrior, Handlock và Druid</p></center>

<p>Hãy cùng theo dõi và cổ vũ cho Neilyo bằng cách tham gia group <a href="https://www.facebook.com/groups/HearthstoneViet/?fref=ts ">Hội giao lưu trao đổi kinh nghiệm chơi Hearthstone</a> hoặc <a href="https://www.facebook.com/HearthstoneSEA?ref=br_rs">Fanpage Hearthstone SEA.</a></p>

<p>(づ｡◕_◕｡)づ NEILYO TAKES MY ENERGY (づ｡◕_◕｡)づ<br>
(づ｡◕_◕｡)づ NEILYO TAKES OUR ENERGY (づ｡◕_◕｡)づ	</p>',

            'date_post'         => '2015-10-04',
            'thumbnail_post'    => 'Blizzard-vinh-danh-game-thu-hearthstone-Viet-Nam-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => "[Review] Winged Sakura: Mindy's Arc - Pháp sư Tinh Linh Mindy",
            'url_post'        => 'winged-sakura-mindy-phap-su-tinh-linh-mindy',
            'present_vi_post' => 'Bạn sẽ nhanh chóng nhập cuộc và cảm thấy sự thú vị, hấp dẫn của Plant vs Zombie phiên bản Anime này.',
            'content_vi_post' => '<p>Winged Sakura: Mindy Arc là game thuộc thể loại thủ thành theo phong cách Anime rất hay và cấu hình nhẹ nhưng vẫn đảm bảo độ hấp dẫn, lôi cuốn, phù hợp mọi lứa tuổi.</p>

<p>Thông tin game</p>

<ul>
<li>Tên game: Winged Sakura: Mindy&apos;s Arc
<li>Thể loại: thủ thành.
<li>Sản xuất năm: 17/10/2014
<li>Hãng sản xuất: <a href="http://wingedsakura.com/" rel="nofollow" target="_blank" title="Winged Sakura: Mindy&apos;s Arc">WINGED SAKURA GAMES</a>
<li>Cấu hình: CPU: 1.5 GHz Pentium IV, RAM: 2 GB, CD-ROM/DVD-ROM: 16X ,Hard Drive Space: 1.5 GB available, Video: 128 MB Directx 9 compatible video card, Sound: 16-bit Directx, Windows XP, 7,8.
</ul>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B-de3XPn3-9ZSjhkVGVfNWd1MXM/view?usp=sharing&resourcekey=0-1vHvmSd2-aXiQe3ojDS0iw" rel="nofollow" target="_blank" title="Winged Sakura: Mindy Arc">Google Drive KINGDOM NVHAI</a>
<li><a href="https://forums.voz.vn/showthread.php?t=3988960" rel="nofollow" target="_blank" title="Winged Sakura: Mindy Arc">Vozforums</a>
</ul>

<center><img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-1.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>

<p>Chỉ cần dùng một câu để miêu tả ngắn gọn về trò chơi này: “Trò chơi này là Plant vs Zombie phiên bản Anime”. Đúng như vậy! Nội dung nói về Mindy, một cô gái đột nhiên phát hiện mình có khả năng triệu hồi Tinh Linh. Và nhiệm vụ của cô là giúp Minzy chống lại cuộc tấn công của các Tinh Linh khác. Từ đó, cô sẽ thu phục được thêm nhiều Tinh Linh, học thêm các phép thuật mới, có vũ khí mới và thêm điểm kinh nghiệm. Theo như giới thiệu trong trailer thì trò chơi có 16 nhân vật để mở khóa.</p>

<center><img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-2.jpg" width="100%"  alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" />

<img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-3.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>

<p>Mặc dù nói rằng trò chơi giống Plant vs Zombie nhưng thực ra chỉ giống 50%. Nếu Plant vs Zombie, khi Zombie đi hết con đường, bạn sẽ thua. Còn Winged Sakura Mindy&apos;s Arc, bạn sẽ có một lượng máu. Chỉ khi nào kẻ địch đánh bạn hết máu, bạn mới thua. Tuy nhiên, Winged Sakura Mindy&apos;s Arc khó hơn Plant vs Zombie là Tinh Linh chỉ xuất hiện trong một khoảng thời gian rồi biến mất, đòi hỏi người chơi phải thao tác thật nhanh và liên tục triệu hồi Tinh Linh.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/2HJfFUKwIMY" frameborder="0" allowfullscreen></iframe>

<img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-4.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" />

<img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-5.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>

<p>Một bản đồ bao gồm nhiều level khác nhau. Người chơi có thể chơi cho đến khi nào đủ sức mạnh rồi mới sang level khác. Hệ thống kỹ năng và đồ dùng cũng khá phong phu. Hệ thống kỹ năng bao gồm 3 phần: Phép thuật tấn công, phép thuật phòng thủ và hồi phục, tăng kinh nghiệm… Đồ dùng cũng khá đa dạng, được chia làm nhiều loại như vũ khí, đồ phòng ngự… và có thể mua bán tùy ý.</p>

<center><img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-6.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" />

<img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-7.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>

<p>Và với các fan Anime, sẽ thật thiếu sót nếu không có những tấm ảnh phong cách Anime. Những tấm ảnh ở mức ecchi nhẹ, một nhân vật bí ẩn được sinh ra trong một bông hoa, những Thiên Thần Sa Ngã với đôi cánh đen... Tất cả sẽ khiến fan của Anime háo hức muốn tham gia trò chơi ngay lập tức. Trò chơi cũng mang phong cách Visual Novel, cốt truyện được kể theo hình tĩnh và ô thoại. Như nhiều thể loại game theo trường phái anime khác, cốt truyện luôn được đầu tư khá tốt. </p>

<center><img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-8.jpg" width="100%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>

<p>Và có thông tin khá thú vị là trên trang chủ <a href="http://wingedsakura.com/" target="_blank" title="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy">wingedsakura.com</a>  có nói về 2 phiên bản Winged Sakura: Battle of Hysteria và Winged Sakura: Akumori&apos;s TG với dòng chữ “Games in Development” (Trò chơi trong giai đoạn phát triển). Hy vọng trong năm 2016 và 2017, phiên bản tiếp theo sẽ được ra mắt. Còn bây giờ, hãy cùng các Tinh Linh chiến đấu nào!</p>

<center><img src="/upload/images/game/winged-sakura-mindy-phap-su-tinh-linh-mindy-10.jpg" width="70%" alt="Winged Sakura: Mindy Arc - Pháp sư Tinh Linh Mindy" /></center>
',
            'date_post'         => '2015-10-13',
            'thumbnail_post'    => 'winged-sakura-mindy-arc-phap-su-tinh-linh-mindy-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Legendary - Sinh vật huyền thoại',
            'url_post'        => 'legendary-sinh-vat-huyen-thoai',
            'present_vi_post' => 'Cảm giác được chiến đấu với những sinh vật huyền thoại đang tấn công cả thế giới chắc chắn sẽ làm háo hức bất cứ game thủ nào.',
            'content_vi_post' => '<p>Nếu bạn là fan của thể loại game bắn súng, muốn được đối đầu với những sinh vật huyền thoại chỉ có trong truyền thuyết thì Legendary là một tựa game không thể bỏ qua. Một tựa game đã từng một thời nổi tiếng. Chắc chắn bạn sẽ cảm nhận sự hoành tráng của game ngay từ những giây phút đầu tiên.</p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-1.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>

<p>Thông tin game</p>

<ul>
<li>Tên game: Legendary
<li>Thể loại: hành động, bắn súng.
<li>Sản xuất năm: 2008
<li>Hãng sản xuất: Spark Unlimited (đóng cửa vào tháng 5/2015)
<li>Cấu hình: CPU: Intel Pentium D805 2.6 GHz, AMD Athlon X2 3800. RAM: 2 GB. Hard Drive Space: 8 GB. Video: X1600, NVIDIA, GeForce, 7600 GT. Sound: 16-bit Directx 9. Windows XP, 7,8.
</ul>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B0B8M6UMphx8NWtEa01rd0psY1k/view?usp=sharing&resourcekey=0-US__xMRkSLrfSfzYKVry1g" rel="nofollow" target="_blank" title="Legendary">Google Drive KINGDOM NVHAI</a>
<li>Phần mềm ổ đĩa ảo <a href="https://drive.google.com/file/d/0B2QqgPEJF0YZUmtYdGs1RGxhZXc/view?usp=sharing&resourcekey=0-YeYY7pGyquq3jpbll_VC-A" rel="nofollow" target="_blank" title="Daemon Tool 4">Daemon Tool 4. Nhớ cài đặt phần free, không cần crack</a>
</ul>

<p>Sau khi loài người phát hiện ra chiếc hộp Pandora và trưng bày nó ở một viện bảo tàng tại New York, Deckard được một tổ chức cử đến để mở khóa chiếc hộp với một chìa khóa được giao cho hắn. Vô tình, Deckard mở khóa và bị gắn một dấu ấn trên tay. Và chiếc hộp bắt đầu giải thoát cho những sinh vật huyền thoại tấn công mọi người, tiêu diệt thế giới.</p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-2.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>

<p>Bạn sẽ ngay lập tức choáng ngợp với sự hoành tráng của game. Những con Griffon bay đầy trời với móng vuốt quắp được cả một chiếc ô tô. Những con Werewoft và Mega Werewoft nhảy xồ ra cào cấu bạn. Những con Minotaur cầm chùy to lớn húc đổ mọi thứ. Một con Golem khổng lồ được tập hợp bởi xe ô tô và hoành tráng nhất là Kraken với những  xúc tu khổng lồ ngay giữa lòng thành phố London. Tất cả đều rất hoành tráng, không chê vào đâu được.</p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-3.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>

<p> Kẻ thù của bạn không chỉ là quái vật mà còn có cả con người. Tổ chức bí ẩn cử tay sai đi lùng giết Deckard do bạn là người duy nhất có thể đóng chiếc hộp Pandora lại. Nhưng may mắn là bạn cũng có quân đội, những người cũng biết bí mật về chiếc hộp Pandora và bạn. Họ sẽ là đồng minh của bạn.</p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-4.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>

<p>Chiến trường trong rất đa dạng và được đầu tư kỹ lưỡng. Từ những đường phố đổ nát với những con Griffon bay rợp trời cho đến những tuyến đường tàu điện ngầm, ống cống với những con quái thú nhỏ bé và "dễ thương" hơn. Từ những khu rừng rậm vắng người cho đến bên trong những tòa nhà to lớn ở New York hay những ngôi nhà nhỏ đổ nát vùng ngoại ô. Từ những màn solo với Minotaur, Griffon cho đến những pha thót tim với một bầy Werewoft xồ đến bạn hay thậm chí là một mình chấp 2 con Minotaur. Tất cả đều tạo cảm giác sợ hãi và chân thực nhất đến cho người chơi. </p>

<p>Chắc chắn bạn không thể không run lên khi thấy những móng vuốt và mỏ của một con Griffon lao thẳng vào xé bạn hay hoảng loạn nhìn cái chùy của Minotaur vung vào người bạn. Lúc đó bạn sẽ thắc mắc: "Tại sao súng của mình yếu thế ?" Vì game không hiện máu của quái vật nên bạn không biết được khi nào chúng mới gục. Nhưng với những con Minotaur và Griffon, bạn sẽ phải xả 2 băng đạn súng trung liên mới hạ được. </p>

<p>Mẹo</p>
<ul>
<li>Nếu như bạn có được những khẩu súng mạnh, hãy giữ nó đợi đến khi có quái vật to lớn mới dùng.
<li>Đối đầu với Minotaur, hãy bắn vào lưng sau khi nó húc vào tường sẽ gây nhiều sát thương hơn. KINGDOM NVHAI đã hạ Minotaur đầu tiên chỉ với Short gun.
</ul>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-5.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" />

<p>Màn đấu tay đôi với Griffon.</p></center>

<p>Vũ khí trong game cũng khá đa dạng. Súng ngắn, Shortgun hay thậm chí là cả súng trung liên để xả thoải mái vào những sinh vật to lớn bay đầy trời. Riêng màn ở London, bạn còn có cả Bazooka có khả năng khóa mục tiêu để bắn Kraken. Lựu đạn có lựu đạn thường và bom xăng. Âm thanh được thể hiện khá tốt với tiếng la hét, đổ nát, quái vật gầm rú hay súng máy bắn liên thanh. Chỉ hơi tiếc là hình ảnh không được tốt do game đã được sản xuất từ năm 2008 nhưng nếu bạn chơi màn chơi ở London thì chắc chắn bạn sẽ không bao giờ chê cảnh tượng trong game: vô số con Griffon bay rợp trời và những cái xúc tu của Kraken khổng lồ đè bẹp bạn</p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-6.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" />

<img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-7.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>

<p>Nhìn chung, Legendary là một game không thể bỏ qua dành cho những ai yêu thích thể loại game bắn súng, chiến đấu với quái vật hay thích những bộ phim theo phong cách ngày tận thế. Chắc chắn Legendary sẽ cho bạn những trận chiến kịch tính nhất. </p>

<center><img src="/upload/images/game/legendary-sinh-vat-huyen-thoai-8.jpg" width="100%" alt="Legendary - Sinh vật huyền thoại" /></center>
',

            'date_post'         => '2015-10-17',
            'thumbnail_post'    => 'legendary-sinh-vat-huyen-thoai-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Neilyo dừng bước tại Hearthstone World Championship 2015',
            'url_post'         => 'Neilyo-dung-buoc-tai-Hearthstone-World-Championship-2015',
            'present_vi_post'  => 'Dù đã rất cố gắng nhưng Neilyo đã thua 1 đối thủ đến 2 lần, đành phải dừng bước tại Hearthstone World Championship 2015.',
            'content_vi_post'  => '<p>Vòng Chung Kết Thế Giới Hearthstone đã diễn ra. Trong vòng bảng, có tổng cộng 4 bảng với 16 game thủ tham gia tranh tài. Neilyo nằm ở bảng C với các đối thủ là LoveCX (Trung Quốc), Ostkaka (Thụy Điển) và Hotform (Canada).</p>

<center><img src="/upload/images/game/Hearthstone-bang-C-CKTG-2015.jpg" width="100%" width="70%" alt="Neilyo dừng bước tại Hearthstone World Championship 2015" />

<img src="/upload/images/game/Hearthstone-Day-Match-2.jpg" width="70%" alt="Neilyo dừng bước tại Hearthstone World Championship 2015" /></center>

<p>Tối ngày 28/10, rạng sang 29/10/2015 đã diễn ra 4 trận của 4 bảng. Neilyo đã thua Hotform, LoveCX đã thua Ostkaka. Vì vậy, LoveCX và Neilyo đã xuống nhánh thua để đấu với nhau. Ai thua sẽ bị loại, người thắng sẽ được tái đấu với nhánh thắng để có 1 vé vào tứ kết. Và Neilyo đã thắng LoveCX.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/UCc1zzP8T9E" frameborder="0" allowfullscreen></iframe>

<p>Trận thi đấu giữa Neilyo và Hotform</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/o83pZ2WmuO8" frameborder="0" allowfullscreen></iframe>

<p>Trận thi đấu giữa LoveCX và Ostkaka</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/puXuym7qNdY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận thi đấu giữa Neilyo và LoveCX</p></center>

<p>Sau khi thua Ostkaka, Hotform tái đấu với Neilyo để giành cơ hội được tái đấu với Ostkaka giành vé vào tứ kết. Neilyo sử dụng bộ bài Secret Paladin, Midrage Hunter và Control Warrior. Trận thứ nhất, bài Warrior của Neilyo quá xấu trong khi bài Mage của Hotform quá đẹp nên thua. Sau đó, Neilyo thắng với Paladin và Hunter. Nhưng thật đáng tiếc là Warrior đã có một ngày thi đấu không thể tệ hơn khi thua Druid và cả Rogue. Kết quả là Neilyo phải dừng bước. </p>

<center><img src="/upload/images/game/Hearthstone-bang-C-Hotform-vs-Neilyo.jpg" width="100%" alt="Neilyo dừng bước tại Hearthstone World Championship 2015" />

<p>Trận tái đấu giữa Hotform và Neilyo rất được chú ý.</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/7XVOFT5pB2U" frameborder="0" allowfullscreen></iframe>

<p>Trận thi đấu giữa Ostkaka và Hotform</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/1psevCnak5o" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận tái đấu giữa Neilyo và Hotform</p></center>

<p>Và như vậy, đứng nhất bảng C là Ostkaka sẽ đấu với nhì bảng D là Pinpinho (Đài Loan) và nhì bảng C là Hotform sẽ đấu với nhất bảng B là Zoro (Trung Quốc).</p>

<center><img src="/upload/images/game/Hearthstone-tran-dau-bang-C-1.jpg" width="100%" alt="Neilyo dừng bước tại Hearthstone World Championship 2015" />

<img src="/upload/images/game/Hearthstone-tran-dau-bang-C-2.jpg" width="100%" alt="Neilyo dừng bước tại Hearthstone World Championship 2015" />

<p>Những trận thi đấu kế tiếp</p></center>

<p>Dù đã bị loại nhưng những người yêu thích Hearthstone Việt Nam vẫn cảm thấy tự hào vì lần đầu tiên Việt Nam có 1 đại diện tham dự vòng Chung Kết Thế Giới. Hy vọng sau này Neilyo và các game thủ Việt Nam sẽ tiếp tục mang vinh quang về cho nước nhà. Còn bây giờ, chúng ta hãy cùng chờ nhà vô địch Hearthstone năm nay.</p>
',

            'date_post'   => '2015-10-29',
            'thumbnail_post'    => 'Neilyo-dung-buoc-tai-Hearthstone-World-Championship-2015-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Ostkaka vô địch Chung Kết Thế Giới Hearthstone 2015',
            'url_post'         => 'Ostkaka-vo-dich-Chung-Ket-The-Gioi-Hearthstone-2015',
            'present_vi_post'  => 'Chức vô địch Hearthstone năm 2015 đã thuộc về Ostkaka đến từ Thụy Điển.',
            'content_vi_post'  => '<p>Rạng sáng 8/11/2015 theo giờ Việt Nam, ngày thi đấu cuối cùng của vòng Chung Kết Thế Giới đã kết thúc với chức vô địch thuộc về Ostkaka đến từ Thụy Điển.</p>

<center><img src="/upload/images/game/lich-thi-dau-ban-ket-chung-ket-hearthstone-2015.jpg" width="70%" alt="Ostkaka vô địch Chung Kết Thế Giới Hearthstone 2015" /></center>

<p>Trong ngày thi đấu cuối cùng, 2 trận bán kết đã diễn ra. Đầu tiên là cặp đấu giữa Ostkaka (Thụy Điển) và Thijs (Netherlands). Sau khi Ostkaka dùng Warrior và Rogue dẫn trước 2-0, Ostkaka cố gắng lội ngược dòng với Warrior và Mage. Trận đấu cuối cùng giữa Mage của Ostkaka với Priest của Thijs, Ostkaka đã giành chiến thắng.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/W62pWehylJQ?list=PLEFn_PVNSM6jaYO5ums6SBzBhQfSTg4oc" frameborder="0" allowfullscreen></iframe>

<p>Trận đấu bán kết 1 giữa Ostkaka và Thijs</p></center>

<p>Trận bán kết 2 giữa Hotform (Canada) và Kno (Hàn Quốc). Kno đã dẫn trước với Warlock. Sau đó Hotform gỡ lại với Mage và Rogue. Kno thắng tiếp với Paladin. Trận đấu cuối cùng là cuộc đọ sức giữa 2 Druid. </p>

<p>Trong trận cuối cùng, Kno quá xui khi Piloted Shredder sinh ra Darnassus Aspirant làm mất mana của mình. Còn Hotform thì quá may mắn khi Piloted Shredder sinh ra Lightwell với khả năng hồi 3 máu cho đồng minh bất kỳ. Với những tình huống may mắn liên tiếp, Hotform đã giành chiến thắng. </p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Is612RtG0jM?list=PLEFn_PVNSM6jaYO5ums6SBzBhQfSTg4oc" frameborder="0" allowfullscreen></iframe>

<p>Trận đấu bán kết 2 giữa Hotform và Kno</p>

<img src="/upload/images/game/Ostkaka-vo-dich-Chung-Ket-The-Gioi-Hearthstone-2015-Hotform-vs-Ostkaka.jpg" width="100%" alt="Ostkaka vô địch Chung Kết Thế Giới Hearthstone 2015" /></center>

<p>Cuối cùng là trận chung kết giữa Ostkaka (Thụy Điển) và Hotform (Canada). Với chiến thắng 3 trận liên tiếp rất thuyết phục, Ostkaka đã chính thức trở thành nhà vô địch Chung Kết Thế Giới Hearthstone 2015. </p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/7a16aKgKi_o?list=PLEFn_PVNSM6jaYO5ums6SBzBhQfSTg4oc" frameborder="0" allowfullscreen></iframe>

<p>Trận chung kết giữa Ostkaka và Hotform</p>

<img src="/upload/images/game/Ostkaka-vo-dich-Chung-Ket-The-Gioi-Hearthstone-2015-Ostkaka-winner.jpg" width="100%" alt="Ostkaka vô địch Chung Kết Thế Giới Hearthstone 2015" /></center>

<p>Một tin bên lề quan trọng khác là Hearthstone đã thông báo ra mắt Adventure mới cho Hearthstone. Adventure mới mang tên The League of Explorers với chuyến phiêu lưu vào hầm mộ kim tự tháp. Sau khi hoàn thành 4 màn chơi, người chơi sẽ được nhận tổng cộng 45 lá bài mới. The League of Explorers chính thức ra mắt vào ngày 12/11/2015.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/wmu0XXpUYog" frameborder="0" allowfullscreen></iframe>

<p>Trailer The League of Explorers</p></center>',

            'date_post'         => '2015-11-08',
            'thumbnail_post'    => 'Ostkaka-vo-dich-chung-ket-the-gioi-hearthstone-2015-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'World of Warcraft: Legion ra mắt trailer',
            'url_post'        => 'World-of-Warcraft-Legion-ra-mat-trailer-moi',
            'present_vi_post' => 'Một trailer mang phong cách phim bom tấn vừa được tung ra để ra mắt phiên bản mới của World of warcraft.',
            'content_vi_post' => '<p>Trang chủ <a href="http://us.battle.net/wow/en/legion/">World of Warcraft</a></p>

<center><img src="/upload/images/game/World-of-Warcralf-Legion.jpg" width="100%" alt="World of Warcraft Legion trailer" /></center>

<p>Blizzard Entertainment - ông trùm của ngành giải trí Mỹ với siêu phẩm game World of Warcraft đã tung trailer mới mang phong cách điện ảnh nhằm quảng bá cho phiên bản World of Warcraft mới. Phiên bản này sẽ ra mắt vào mùa hè 2016.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/eYNCCu0y-Is" frameborder="0" allowfullscreen></iframe>

<p>Trailer World of Warcraft: Legion</p></center>

<p>Đây có lẽ là một động thái nhằm vực dậy tựa game nổi tiếng đang lâm vào tình trạng khủng hoảng này. World of Warcraft đã có một sự sụt giảm số lượng người chơi nghiêm trọng. Tính đến tháng 09/2015, theo số liệu mới nhất của Blizzard, số lượng người chơi chỉ còn 5,5 triệu người. Rõ ràng, tình hình cạnh tranh gay gắt từ các game MMORPG ngày một nhiều như hiện nay thì việc World of Warcraft lung lay địa vị là chuyện khó tránh khỏi.</p>

<center><img src="/upload/images/game/Blizzard-Battle-net.jpg" width="100%" alt="World of Warcraft Legion trailer" />

<p>World of Warcraft cùng những tựa game khác trên Battle.net</p></center>

<p>Tuy nhiên, Blizzard cũng không cần phải quá lo lắng bởi những tín hiệu vui khác đang đến từ các game khác. Game thẻ bài Hearthstone có tốc độ tăng trưởng người chơi 77%. Overwatch, tựa game bắn súng mới ra mắt gần đây đã có hơn 7 triệu game thủ đăng ký. Và ngày 6/11/2015, Hearthstone cùng Overwatch đã tung trailer phiên bản mới thu hút rất nhiều sự chú ý của game thủ.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/UEYp1RTvllM" frameborder="0" allowfullscreen></iframe>

<p>Trailer mới nhất của Overwatch</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/wmu0XXpUYog" frameborder="0" allowfullscreen></iframe>

<p>Trailer mới nhất của Hearthstone</p></center>',

            'date_post'         => '2015-11-10',
            'thumbnail_post'    => 'world-of-warcralf-legion-release-trailer-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => '[Review] Clustertruck - Nhảy trên xe tải',
            'url_post'        => 'Clustertruck-nhay-tren-xe-tai',
            'present_vi_post' => 'Cùng nhảy trên xe tải và vượt qua những cung đường khó đi nhất với game hành động - giải đố Clustertruck.',
            'content_vi_post' => '<h3>Thông tin game</h3>

<ul>
<li>Tên game: Clustertruck
<li>Thể loại: hành động
<li>Sản xuất năm: 22/4/2016
<li>Hãng sản xuất: Landfall Games
<li>Cấu hình: CPU: 2 GHz, RAM 2 GB, Directx 9, Windows XP, 7,8. Hard Drive Space: 300 MB.
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B9EX0DsknnyedzdDQ01KRTBNUkk/view?usp=share_link&resourcekey=0-zsL09CY2D0-4AWubuGnG8Q" rel="nofollow" target="_blank" title="Clustertruck">Google Drive KINGDOM NVHAI</a></p>

<center<img src="/upload/images/game/Clustertruck-Nhay-tren-xe-tai-1.jpg" width="100%" alt="Clustertruck Nhảy trên xe tải" /><br><br></center>

<p>Clustertruck là game hành động của hãng Landfall Games. Khuyến cáo trò chơi này không nên chơi lúc bạn có tâm trạng không tốt vì nó sẽ khiến bạn phát điên vì độ khó của nó.</p>

<p>Luật chơi rất đơn giản: bạn vào vai một tên quậy phá có những cú nhảy chỉ thua Spiderman. Và những tên tài xế xe tải sẽ tăng độ khó cho bạn bằng việc lái xe như những tên say rượu. Bạn chỉ cần nhảy qua nhảy lại, đừng để chân chạm đất hay các tia laze cho đến khi về đích.</p>

<center><img src="/upload/images/game/Clustertruck-Nhay-tren-xe-tai-2.jpg" width="100%" alt="Clustertruck Nhảy trên xe tải" /><br><br></center>

<p>Clustertruck là game hành động theo phong cách giải đố, rèn luyện phản xạ nhanh. Từ những màn đơn giản cho đến những cảnh cả chục chiếc xe tải bay trên không trung như trong phim hành động sẽ vắt kiệt cả sức lực lẫn trí óc bạn. Tuy nhiên, bạn vẫn có thể làm vài mẹo sau để qua một số màn theo cách bớt đau đầu hơn:</p>

<ul>
<li>Hãy thử dùng cách đứng yên trên chiếc xe bạn đang đứng từ đầu đến cuối. Người viết đã vượt qua một số màn nhờ vào cách này. Hoặc hãy chọn chiếc xe ngoài rìa để tránh va chạm.
<li>Màn có những tấm biển gỗ phía trên cao, hãy đứng ở đầu xe tải để núp dưới những tấm bảng gỗ, không cần nhảy đi đâu cả.
<li>Slow Motion chỉ nên dùng trước khi nhảy để xác định xem nên nhảy vào xe nào.
</ul>

<center><img src="/upload/images/game/Clustertruck-Nhay-tren-xe-tai-3.jpg" width="100%" alt="Clustertruck Nhảy trên xe tải" /><br><br>

<p>Hãy đứng trên đầu xe tải để núp dưới các tấm bảng gỗ</p></center>

<p>Âm nhạc khá tốt với những tiếng nổ máy xe và nhạc nền. Tuy nhiên, trò chơi lại không có âm thanh va chạm hay cháy nổ. Đồ họa là điểm mạnh nhất của game với các màn chơi từ sa mạc đến bang tuyết, từ vùng đồng không mông quạnh đến thành phố tuyết tuyệt đẹp. Thậm chí có cả những không gian ảo khiến người chơi khó đoán được đường đi nước bước của xe.</p>

<center><img src="/upload/images/game/Clustertruck-Nhay-tren-xe-tai-4.jpg" width="100%" alt="Clustertruck Nhảy trên xe tải" /><br><br></center>

<p>Chỉ với 300 MB và RAM 2GB, quá nhẹ cho một trò chơi mini giải trí và rèn luyện đầu óc. Hy vọng bạn sẽ vượt qua tất cả những màn chơi cực kỳ khó khăn và thử thách này trong những lúc rảnh rỗi. </p>',

            'date_post'         => '2015-11-14',
            'thumbnail_post'    => 'Clustertruck-Nhay-tren-xe-tai-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Street Fighter V ra mắt trailer',
            'url_post'        => 'Street-Fighter-V-ra-mat-trailer',
            'present_vi_post' => 'Tựa game đối khảng lâu đời nổi tiếng của CAPCOM vừa ra mắt trailer mới. Game sẽ dành cho PS4 và PC.',
            'content_vi_post' => '<p>Ngày 16/11/2015, hãng CAPCOM vừa cho ra mắt trailer của Street Fighter V, game đối kháng dành cho PS4 và PC. Game sẽ được bán tại Bắc Mỹ và Châu Âu vào ngày 16/2/2016</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/EcD5XJl9lw4" frameborder="0" allowfullscreen></iframe>

<p>Trailer Street Fighter V</p></center>

<p>Những nhân vật trong game đã được tiết lộ bao gồm: Ryu, Ken, Chun-Li, Nash, M. Bison, Cammy, Birdie, Vega, Karin Kanzuki, Necalli, Rainbow Mika, Zangief, Laura, Rashid, và Dhalsim. Một số nhân vật khác có thể mua bằng tiền trong game. Necalli, Rashid, và Laura là những nhân vật mới đã được công bố cho đến thời điểm này.</p>

<center><img src="/upload/images/game/CAPCOM-Street-Fighter-1.jpg" width="100%" alt="Street Fighter V trailer" /></center>

<p>Ngày 23/7/2015, một bản beta đã được ra mắt nhưng CAPCOM đã đóng cửa với lý do máy chủ, khiến trò chơi chưa tiếp cận được với nhiều người. Ban đầu, trò chơi chỉ được phát hành qua đĩa. CAPCOM sẽ tạo hệ thống tự động cập nhật miễn phí.</p>

<p>Nguồn: <a href="http://www.animenewsnetwork.com/news/2015-11-16/street-fighter-v-video-previews-game-tutorial-mode/.95443" rel="nofollow" target="_blank" title="Street Fighter V trailer">Anime News Network</a></p>
',

            'date_post'         => '2015-11-17',
            'thumbnail_post'    => 'Street-Fighter-5-ra-mat-trailer-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => '[Review] Kingdom Rush Frontiers - Chiến tuyến phòng vệ',
            'url_post'        => 'kingdom-rush-frontiers-chien-tuyen-phong-ve',
            'present_vi_post' => 'Hãy xây những pháo đài kiên cố, những đội quân mạnh mẽ và rèn luyện Hero để cản bước quân thù. ',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Kingdom Rush Frontiers
<li>Thể loại: thủ thành
<li>Sản xuất năm: 5/2013.
<li>Hãng sản xuất: Ironhide Game Studio
<li>Cấu hình: CPU: CPU: 2 GHz, RAM 2 GB, Directx 9, Windows XP, 7,8. Hard Drive Space: 300 MB.
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B9EX0DsknnyeTVotYzFTeHpIREk/view?usp=share_link&resourcekey=0-wPZK-2zbtRR91OKC9-WRew" rel="nofollow" target="_blank" title="Kingdom Rush Frontiers">Google Drive KINGDOM NVHAI</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/ilshnhXtfKQ" frameborder="0" allowfullscreen></iframe>

<p>Trailer Kingdom Rush Frontiers</p></center>

<center><img src="/upload/images/game/kingdom-rush-frontiers-chien-tuyen-phong-ve-1.jpg" width="100%" alt="Kingdom Rush Frontiers - Chiến tuyến phòng vệ" /><br><br></center>

<p>Nội dung trong game là bạn phải xây những loại nhà cần thiết để cản bước quân thù. Có 4 loại nhà:</p>

<ul>
<li>Nhà lính: gọi một đội lính ra đứng giữa đường đi.
<li>Nhà cung tên: bắn tên với tốc độ cao. Đây là loại nhà nên xây nhiều nhất.
<li>Nhà phép: bắn phép thuật với tốc độ trung bình. Loại nhà này chỉ mạnh khi được nâng cấp tối đa nên không nên xây nhiều.
<li>Nhà đại bác: bắn những quả đại bác lớn với tốc độ chậm. Rất mạnh khi đối đầu với các đơn vị to khỏe, cứng cáp.
</ul>

<center><img src="/upload/images/game/kingdom-rush-frontiers-chien-tuyen-phong-ve-2.jpg" width="100%" alt="Kingdom Rush Frontiers - Chiến tuyến phòng vệ" /><br><br>

<img src="/upload/images/game/kingdom-rush-frontiers-chien-tuyen-phong-ve-3.jpg" width="100%" alt="Kingdom Rush Frontiers - Chiến tuyến phòng vệ" /><br><br></center>

<p>Ngoài ra, bạn còn được sở hữu các Hero với những kỹ năng khác nhau. Càng cho tham chiến nhiều, các Hero càng lên level, kỹ năng càng mạnh. Hero có đủ các loại, từ Thợ Săn thả thú hoang dã đến Cướp Biển giúp bạn có thêm nhiều tiền. Sau này có có Người Đá, Rồng…  </p>

<center><img src="/upload/images/game/kingdom-rush-frontiers-chien-tuyen-phong-ve-4.jpg" width="100%" alt="Kingdom Rush Frontiers - Chiến tuyến phòng vệ" /><br><br></center>

<p>Đồ họa trong game đơn giản nhưng khá tốt, phong phú với các nhà lính, đơn vị quân, bản đồ, vùng đất và cả boss đều được thể hiện khá tốt. Âm thanh cũng rất chân thực với những tiếng kêu la của binh lính, tiếng đại bác, cung tên bay vèo vèo, nổ ầm ầm. Kingdom Rush Frontiers là một game hay mà bạn không nên bỏ qua.</p>
',
            'date_post'         => '2015-11-20',
            'thumbnail_post'    => 'kingdom-rush-frontiers-chien-tuyen-phong-ve-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => '[Review] Spider Man 2 the game - Quyết chiến Tiến Sĩ Bạch Tuộc',
            'url_post'        => 'Spider-Man-2-the-game-quyet-chien-tien-si-bach-tuoc',
            'present_vi_post' => 'Game dựa theo 3 tập phim Spider Man nổi tiếng do Tobey Maguire thủ vai Spider man đã không thành công như mong đợi.',
            'content_vi_post' => '<p>Dựa theo 3 tập phim Spider Man nổi tiếng do Tobey Maguire thủ vai Spider man, tựa game ăn theo cũng đã được ra mắt vào năm 2004. Dưới bàn tay phù phép của Activision, Spider Man 2 đã tạo nên 1 cơn sốt không nhỏ trên thị trường game vào thời điểm đó.</p>

<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Spider Man 2 the game
<li>Thể loại: hành động
<li>Sản xuất năm: 2004
<li>Hãng sản xuất: Activision, Marvel
<li>Cấu hình: Intel Core® 2 Quad 2.4 Ghz or AMD Athlon II X4 2.6 Ghz, RAM 2 Gb, DirectX 9, Windows Vista/7/8
</ul>

<center><img src="/upload/images/game/Spider-Man-2-the-game-quyet-chien-tien-si-bach-tuoc-1.jpg" width="50%" alt="Spider Man 2 the game - Quyết chiến Tiến Sĩ Bạch Tuộc" /></center>

<h3>Link download</h3>

<ul>
<li><a href="https://drive.google.com/file/d/0B9EX0DsknnyeRENpWGF6LW1MZm8/view?usp=sharing&resourcekey=0-qMvfn40wvpJVoumxajl0PQ" rel="nofollow" target="_blank" title="Spider Man 2 The Game">Google Drive KINGDOM NVHAI</a>
</ul>

<p>Tuy nhiên, có một thế giới ngược giữa DC Comic và Marvel ở trong game và trên màn ảnh. Đó là trên phim, Marvel làm tốt bao nhiêu thì DC Comic làm trùm trong game bấy nhiêu. Và Spider Man 2 The Game cũng không phải ngoại lệ. </p>

<p>Mặc dù có thể thông cảm một chút vì trò chơi được làm từ năm 2004 nhưng thật sự, nếu bạn kỳ vọng về một Spider Man đu dây qua các tòa nhà như trong phim thì bạn sẽ khá thất vọng về màn đu dây cũng như bối cảnh trong game. Thành phố New York ngoài đời đông đúc, nhộn nhịp bao nhiêu thì trong game y như một thành phố hoang như các game về ngày tận thế. Không một chiếc xe, không một bóng người qua lại. Màn đu dây của Spider Man vẫn bị rập khuôn từ các game trước đó là bắn tơ vào không khí rồi đu nên cảm giác cũng không đã như phim.</p>

<center><img src="/upload/images/game/Spider-Man-2-the-game-quyet-chien-tien-si-bach-tuoc-2.jpg" width="100%" alt="Spider Man 2 the game - Quyết chiến Tiến Sĩ Bạch Tuộc" /></center>

<p>Một điểm cộng là ngoài Doctor Octopus, Spider Man còn đối đầu với nhiều kẻ thù khác như Rhino trốn thoát khỏi nhà tù hay đánh nhau với Man Wolf. Những kẻ thù đều được hướng dẫn, chỉ ra điểm yếu nên cũng khá dễ hạ. Một điểm thất vọng là có vẻ game này chỉ dành cho thiếu nhi. Trò chơi khá dễ chơi nên có thể hoàn thành game nhanh. Trong game lại không có âm nhạc, mọi thứ khá im lặng. Thêm các câu đố mở cửa bằng âm thanh, tìm chìa khóa có thể làm bạn mất thêm chút thời gian nhưng không phải là thử thách khó.</p>

<center><img src="/upload/images/game/Spider-Man-2-the-game-quyet-chien-tien-si-bach-tuoc-3.jpg" width="100%" alt="Spider Man 2 the game - Quyết chiến Tiến Sĩ Bạch Tuộc" /></center>

<p>Mặc dù lối chơi có một chút mở. Ví dụ bạn có thể rảnh rỗi đi tìm những tên tội phạm vượt ngục ẩn nấp đâu đó hay đu bay khắp thành phố New York ngắm cảnh. Nhưng bạn vẫn phải làm theo cốt truyện, nhiệm vụ chính. Giá như nhà phát triển bổ sung thêm sự đa dạng trong khi thiết kế các nhiệm vụ, Spider Man 2 sẽ rất tuyệt. Rất tiếc khi phải nói rằng, Spider Man 2 chỉ là game giải trí nhẹ nhàng lúc rảnh rỗi hoặc dành cho thiếu nhi chứ không phải tựa game lớn như mong đợi.</p>',

            'date_post'         => '2015-12-01',
            'thumbnail_post'    => 'Spider-Man-2-the-game-quyet-chien-tien-si-bach-tuoc-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Senran Kagura Estival Versus - Mùa hè đầy nắng',
            'url_post'        => 'Senran-Kagura-Estival-Versus-mua-he-day-nang',
            'present_vi_post' => 'Hãy cùng hòa mình vào bãi biển cùng các thiên thần ninja.',
            'content_vi_post' => '<p>Senran Kagura là series game được thiết kế bởi Tamsoft và sản xuất bởi Marvelous Entertainment. Senran Kagura: Estival Versus được phát hành ngày 26/3/2015 tại Nhật Bản. Ngoài ra, series còn có phiên bản Manga, Anime.</p>

<p>Câu chuyện nói về Học viện Hanzo được tạo ra bởi Chính phủ Nhật Bản để chống lại các ninja đen được thuê bởi các tập đoàn và các chính trị gia. Chỉ có các cá nhân với một hồ sơ sạch, không giết bất cứ ai, có thể ghi danh. Trong game, bạn sẽ điều khiển các cô gái shinobi (hiểu đơn giản là ninja) xinh đẹp, có khả năng biến hình với các trang phục, vũ khí đặc trưng để tấn công kẻ thù là những shinobi đen bịt mặt.</p>

<p>Trong Senran Kagura: Estival Versus, các nhân vật tại 5 trường shinobi bị hút vào cổng không gian và được đưa đến một hòn đảo nhiệt đới. 2 chị em Ryouna và Ryoubi phát hiện ra chị cả Ryouki của mình đã được hồi sinh. </p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/AfrFi3pf3rY?list=PLDreFvf-2E24QfVqz-GdEojWQo4WhpV9B" frameborder="0" allowfullscreen></iframe>

<p>Danh sách video gameplay Senran Kagura: Estival Versus</p></center>

<p>Vẫn theo phong cách của series Senran Kagura, hình ảnh nhân vật 3D góc nhìn người thứ 3 xoay quanh các cô gái chiến đấu trong những bộ đồ thiếu vải hết sức có thể. Kỹ năng Shinobi Biến Hình thay đổi quần áo và những tuyệt chiêu của các ninja được nâng cấp khá tốt. Mới vào game, người chơi sẽ được hướng dẫn cách điều khiển, di chuyển và chiến đấu những trận khởi động với các shinobi đen.</p>

<p>Cốt truyện được kể bằng các đoạn cutscene anime và đoạn hội thoại ngắn với các nhân vật 3D. Nhưng các đoạn cutscene hơi nhiều, khiến người chơi cảm giác như đang xem anime 2D và 3D hơn là chơi game. Nhưng khuyết điểm này có thể thông cảm vì series game Senran Kagura rất coi trọng cốt truyện.</p>

<p>Ấn tượng nhất của game tất nhiên là các cảnh ecchi. Ngay từ bài hát mở đầu Sunshine Fes, mức độ ecchi đã lộ rõ với cảnh các cô gái mặc bikini trắng nhảy múa. Khi xem OVA, mức độ ecchi đã được nâng lên để thu hút thêm khán giả.</p>

<p>Một số hình ảnh gameplay của Senran Kagura Estival Versus</p>

<center><img src="/upload/images/game/Senran-Kagura-Estival-Versus-Gameplay-1.jpg" width="100%" alt="Senran Kagura Estival Versus - Mùa hè đầy nắng" />

<img src="/upload/images/game/Senran-Kagura-Estival-Versus-Gameplay-2.jpg" width="100%" alt="Senran Kagura Estival Versus - Mùa hè đầy nắng" />

<img src="/upload/images/game/Senran-Kagura-Estival-Versus-Gameplay-3.jpg" width="100%" alt="Senran Kagura Estival Versus - Mùa hè đầy nắng" />

<img src="/upload/images/game/Senran-Kagura-Estival-Versus-Gameplay-4.jpg" width="100%" alt="Senran Kagura Estival Versus - Mùa hè đầy nắng" />

<img src="/upload/images/game/Senran-Kagura-Estival-Versus-Gameplay-5.jpg" width="100%" alt="Senran Kagura Estival Versus - Mùa hè đầy nắng" /></center>',

            'date_post'         => '2015-12-10',
            'thumbnail_post'    => 'senran-kagura-estival-versus-mua-he-day-nang-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        //==================-------------------------------- Đăng bài tiếp từ đây --------------------------------==================//

        posts::create([
            'name_vi_post'    => 'Adventures of Mana - game trên Smartphone ra mắt trailer',
            'url_post'        => 'Adventures-of-Mana-game-tren-Smartphone-ra-mat-trailer',
            'present_vi_post' => 'Adventures of Mana là tựa game nhập vai hành động dành cho iOS và Android vừa được cho ra mắt trailer giới thiệu.',
            'content_vi_post' => '<p>Square Enix đã tung ra trailer tiếng Anh và Nhật Bản vào ngày 20/1/2016 của game Adventures of Mana (Những cuộc phiêu lưu của Mana). Game hành động nhập vai là phiên bản làm lại của Final Fantasy Adventure dành cho iOS và Android. Bạn có thể xem trang chủ của game tại <a href="http://www.jp.square-enix.com/seiken/en/">Square Enix.</a> </P>

<center><img src="/upload/images/game/Adventures-of-Mana-1.jpg" width="70%"/></center>

<p>Cả hai video thông báo 4/2/2016 là ngày phát hành. Phiên bản tiếng Anh của game sẽ có sẵn cho iOS và Android, trong khi phiên bản tiếng Nhật sẽ có sẵn cho iOS, Android, và PlayStation Vita.
</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/_2Mu-lqV_BY" frameborder="0" allowfullscreen></iframe>

<p>Trailer tiếng Anh Adventures of Mana</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/lcmIZ5IVRgM" frameborder="0" allowfullscreen></iframe>

<p>Trailer tiếng Nhật Adventures of Mana</p></center>

<p>Trang web tiếng Anh nói đây là” Final Fantasy Adventure cổ điển vượt thời gian cho một thế hệ mới”. Phiên bản làm lại sẽ có những câu chuyện và nhân vật chính từ các trò chơi ban đầu như Anh hùng, Shadow Night, Bogard, và Chocobo. Trang web cũng mô tả câu chuyện của trò chơi:</p>

<center><img src="/upload/images/game/Adventures-of-Mana-2.jpg" width="70%" alt="Adventures of Mana - game trên Smartphone ra mắt trailer" /></center>

<p>Được thờ trên đỉnh Mt. Illusia, cao hơn cả những đám mây cao nhất là Tree of Mana. Nó tạo ra năng lượng sự sống từ thiên thể Ether vô biên. Truyền thuyết nói rằng ai đặt tay mình trên thân cây sẽ được bất tử - một sức mạnh mà Dark Lord of Glaive luôn tìm kiếm để có sự thống trị.</p>

<p>Anh hùng của chúng ta là một trong vô số các đấu sĩ đã giao kèo với Duchy of Glaive. Mỗi ngày, anh và các bạn xấu số của mình phải chiến đấu với quái vật để giải trí cho Dark Lord. Nếu chiến thắng, họ sẽ bị giam vào ngục tối để chờ đợi trận đấu tiếp theo. Nhưng cơ thể thì dần dần lụi tàn trước số phận tàn nhẫn của họ.</p>

<p>Square Enix đã phát hành phiên bản gốc Final Fantasy Adventure cho Game Boy vào năm 1991. Đó là game đầu tiên trong loạt game Mana.</p>',

            'date_post'   => '2016-01-21',
            'thumbnail_post'    => 'Adventures-of-Mana-game-Smartphone-ra-mat-trailer-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,

            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Avabel Online - MMORPG 3D cho di động',
            'url_post'        => 'Avabel-Online-MMORPG-3D-cho-di-dong',
            'present_vi_post' => 'Avabel Online là game MMORPG 3D dành cho di động m...',
            'content_vi_post' => '<p>Đây là game thuộc thể loại MMORPG 3D đồ họa chất lượng cao xuất hiện trên thiết bị di động. Avabel Online hội tụ đầy đủ tính năng điều khiển không thua kém gì một game online trên PC như PvP , GvG ( War Guild ), Dungeon, săn boss , chế đồ… Avabel Online được xem là một game bom tấn dành cho iOS/Android. Bạn có thể tải game trên <a href="https://play.google.com/store/apps/details?id=com.asobimo.avabel_gp_b3">Google Play.</a></p>

<center><img src="/upload/images/game/Avabel_Online.jpg" width="100%" alt="Avabel Online MMORPG 3D cho di động" />

<iframe width="100%" height="350" src="https://www.youtube.com/embed/MiIVSS0iBkU" frameborder="0" allowfullscreen></iframe>

<p>Trailer Avabel Online</p></center>

<p>AVABEL Online đưa người chơi tới một tòa tháp với nhiều căn phòng khác nhau. Mỗi phòng đưa người chơi đến một thế giới riêng có boss cũng như cấp độ khác nhau. Càng lên cao, cấp độ càng khó. Như các game MMORPG khác, game cũng dẫn dắt người chơi với các chuỗi  nhiệm vụ để người chơi làm quen với game, lấy vũ khí và kinh nghiệm.</p>

<center><img src="/upload/images/game/Avabel-Online-1.jpg" width="100%" alt="Avabel Online MMORPG 3D cho di động"" /></center>

<p>Avabel Online có 6 nhân vật: Warrior, Rogue, Ranger, Creator, Acolyte, Magician. Hệ thống vũ khí có thể khảm ngọc, chế tạo như mọi game MMORPG khác. Xét về mặt số lượng game thủ, Avabel cũng hoàn toàn áp đảo sản phẩm cùng loại cho dù tuổi đời của game cũng được 2 năm tuổi. Cấu hình nhẹ cũng là ưu điểm lớn của game.</p>

<center><img src="/upload/images/game/Avabel-Online-2.jpg" width="100%" alt="Avabel Online MMORPG 3D cho di động" /></center>

<p>Một tin bên lề là ngày 29/1/2016, trên trang Twitter của bộ phim Anime Date a live có nói đến việc Kadokawa hợp tác với Avabel Online để cho các nhân vật Date a live xuất hiện trong game. Trang chủ <a href="http://avabel.jp/landing/date-a-live" target="_blank">Avabel x Date a live</a></p>

<center><img src="/upload/images/game/avabel-online-date-a-live.jpg" width="100%" alt="Avabel Online MMORPG 3D cho di động" />

<img src="/upload/images/game/avabel-online-date-a-live-1.jpg" width="100%" alt="Avabel Online MMORPG 3D cho di động" /></center>

<p>Nhìn chung, Avabel Online khá ấn tượng về phần đồ họa hình ảnh và âm thanh. Nếu bạn là người yêu thích thể loại game cày cuốc level, khám phá thế giới mới thì hãy nhanh tay bước vào thế giới Avabel Online.</p>',

            'date_post'         => '2016-02-04',
            'thumbnail_post'    => 'Avabel-Online-MMORPG-3D-cho-di-dong-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Neilyo vô địch giải Golden Monkey Invitational',
            'url_post'        => 'Neilyo-vo-dich-Golden-Monkey-Invitational',
            'present_vi_post' => 'Ngày 13/2/2016, giải Golden Monkey Invitational đã diễn ra suốt 9 giờ đồng hồ. Chức vô địch đã thuộc về Neilyo của Việt Nam.',
            'content_vi_post' => '<p>Ngày 13/2/2016, vào lúc 3 giờ theo giờ Việt Nam, giải đấu Golden Monkey Invitational dành cho các tuyển thủ Đông Nam Á đã diễn ra. Việt Nam có 3 đại diện tham gia là Neilyo, zGGLeoz và Ikki. Neilyo - tên thật là Trần Hưng Lân - là đại diện của Việt Nam đã được tham gia giải Chung Kết Thế Giới 2015. Ikki là admin của <a href="https://www.facebook.com/hearthstone.vn/?fref=ts">fanpage Hearthstone Vietnam.</a></p>

<center><img src="/upload/images/game/Golden-Monkey-Invitational-1.jpg" width="70%" alt="Neilyo vô địch giải Golden Monkey Invitational" /></center>

<p>Luật thi đấu:</p>
<ul>
<li>Mỗi người chơi chuẩn bị 3 deck của 3 class khác nhau.
<li>Thi đấu theo thể lệ Conquest; bo3-cấm 1 class từ đầu đến Tứ kết, Bán kết và Chung kết thi đấu bo5 sử dụng cả 3 deck đã được chuẩn bị.
<li>Tất cả các deck phải sử dụng: Elise Starseeker, 1 trong những lá bài Rồng Legendary 9 mana: Alexstraza, Nefarian, Onyxia, Ysera, Malygos, Nozdormu, ít nhất 1 Bomb Lobber, và ít nhất 2 Mad Bomber/2 Madder Bomber hoặc cả 4.
<li>Người chơi có thể có những lá Rồng Legendary khác ngoài những lá liệt kê ở trên trong deck, nhưng những lá rồng đã được liệt kê sẽ không được sử dụng lặp lại ở những deck khác nhau. Ví dụ, 1 deck sử dụng Ysera, 1 deck khác có Alexstraza, 1 deck khác có Nefarian, nhưng cả 3 deck thì đều có thể có Chromagus hay Deathwing,..
<li>Không được sử dụng những lá bài 2 mana và 7 mana trừ những ngoại lệ sau: Flare, Mad Bomber, Lorewalker Cho.
</ul>

<center><img src="/upload/images/game/Golden-Monkey-Invitational-2.jpg" width="70%" alt="Neilyo vô địch giải Golden Monkey Invitational" />

<img src="/upload/images/game/Golden-Monkey-Invitational-3.jpg" width="70%" alt="Neilyo vô địch giải Golden Monkey Invitational" /></center>

<p>Nếu như Neilyo có 3 trận thắng khá thuyết phục, thậm chí thắng cả đối thủ Chalk đã từng đấu với anh trong trận chung kết chọn đại diện tham dự Chung Kết Thế Giới thì 2 tuyển thủ zGGLeoz và Ikki lại thua mặc dù họ đã đánh rất tốt và rất cố gắng.</p>

<p>Cả giải đấu đã diễn ra suốt 9 giờ. Trong trận chung kết diễn ra vào khoảng 10 giờ tối theo giờ Việt Nam, Neilyo đã chiến thắng một cách khá may mắn vào những thời khắc khó khăn nhất trước đối thủ Heisnotaxel người Singapore. Trận đầu tiên, Heisnotaxel đã chiến thắng với Shaman trước Warlock của Neilyo. 3 trận sau đó, Hunter của Heisnotaxel đã thất bại trước Priest, Warlock và Warrior của Neilyo. Neilyo đã rất may mắn trong trận thứ 3 khi Warlock rút bài may mắn để hồi máu trước những đòn tấn công thẳng mặt của Hunter.</p>

<center><img src="/upload/images/game/Golden-Monkey-Invitational-4.jpg" width="70%" alt="Neilyo vô địch giải Golden Monkey Invitational" />

<img src="/upload/images/game/Golden-Monkey-Invitational-5.jpg" width="70%" alt="Neilyo vô địch giải Golden Monkey Invitational" /></center>

<center><iframe src="http://player.twitch.tv/?video=v44405329" frameborder="0" scrolling="no" height="378" width="620"></iframe>

<p>Toàn bộ trận đấu của giải.</p></center>

<ul>
<li>Hạng nhất: neilyo (Vietnam)
<li>Hạng nhì: heisnotaxel (Singapore)
<li>Hạng ba: Aaron (Singapore)
<li>Hạng tư: Chalk (Philippines)
</ul>

<p>Xin chúc mừng Neilyo đã có thêm thành tích mở đầu năm 2016. Chúng ta hãy cổ vũ cho Neilyo sẽ tiếp tục chiến thắng và góp mặt vào Chung Kết Thế Giới 2016.</p>',

            'date_post'         => '2016-02-14',
            'thumbnail_post'    => 'neilyo-won-golden-monkey-invitational-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Empire Earth - Đế chế thiên niên kỷ',
            'url_post'        => 'Empire-Earth-de-che-thien-nien-ky',
            'present_vi_post' => 'Mọi thế hệ 8x, 9x đời đầu yêu thích thể loại dàn trận đều đánh giá game này hay hơn cả Age of Empires. Tất nhiên rồi! Vì đây là game chiến thuật hay nhất năm 2001. ',
            'content_vi_post' => '<p>Là một trong các tựa game cũ mà hay, Empire Earth đã từng được đánh giá là game hay nhất năm 2001, có thể đánh giá ngang với Age of Empires lừng danh với sự đa dạng thời kỳ, binh chủng, công trình hơn hẳn và hình ảnh, màu sắc tương tự Age of Empires. Những ai thuộc thế hệ 8x, 9x yêu thích thể loại game dàn trận, chiến thuật chắc chắn không thể quên được Empire Earths - Đế Chế Thiên Niên Kỷ.</p>

<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: Empire Earth
<li>Thể loại: Dàn trận
<li>Sản xuất năm: 2001
<li>Hãng sản xuất: Sierra Entertainment
<li>Cấu hình: OS: Windows XP/ Vista/ 7; CPU: Pentium II 350MHz; RAM: 64MB; HDD: 450MB hard disk space; Graphics: 32 MB VRAM
</ul>

<h3>Link download</h3>

<p><a href="https://drive.google.com/file/d/0B2QqgPEJF0YZOGNlTlM2WnM4MGs/view?resourcekey=0-z4XkqZ6VBF6vP-Z-TtkHnw" rel="nofollow" target="_blank" title="Empire Earth - Đế chế thiên niên kỷ">Google Drive KINGDOM NVHAI</a></p>

<center><img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-1.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" /></center>

<p>Nếu Age of Empires chỉ cho bạn 5 thời kỳ thì Empire Earth sẽ cho bạn 22 thời kỳ, một con số rất đồ sộ vì mỗi thời kỳ là một bộ hình ảnh công trình, binh chủng khác nhau.
Bạn sẽ được chứng kiến cảnh xã hội thời đồ đá, con người ăn lông ở lỗ, ném đá, cầm chày đánh nhau. Bước sang đồ đồng, đồ sắt với giáo mác, voi ngựa giống trong các bộ phim Hy Lạp, La Mã cổ đại.
Chứng kiến những chiếc máy bay, xe tăng Mark V trong Thế Chiến Thứ Nhất giống hệt trong sử sách, đội quân Kamikaze (Phong Thần) khủng khiếp của Nhật Bản trong Thế Chiến Thứ Hai.
Và cuối cùng là 2 thời kỳ của khoa học viễn tưởng, robot, tia laze, tên lửa bắn ầm ầm.</p>

<p>Danh sách các đơn vị trong <a href="http://ee.heavengames.com/new/eeh/gameinfo/units/index.php?sepoch=11" target="_blank" rel="nowfollow">Empire Earth</a></p>

<center><img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-Mark-V.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<p>Mark V trong game và ngoài thật</p>

<img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-Enterprise.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<p>USS Enterprise trong game và ngoài thật</p></center>

<p>Để thực tế hơn và cũng để giảm tải số lượng binh chủng, hình ảnh, mỗi thời kỳ sẽ có một số loại quân tiêu biểu.
Nếu ở thời kỳ gần Thế Chiến Thứ Nhất, người viết rất ấn tượng với những con thuyền buồm giống hệt trong phim Cướp Biển Caribe.
Con tàu to cao, 2-3 dàn pháo ở 2 bên mạn tàu bắn rất đẹp mắt, đã tai. Còn nếu bạn thích Thế Chiến, bạn sẽ không thể rời mắt khỏi những chiếc xe tăng trau chuốt từng chi tiết,
máy bay ném bom hạt nhân giống như chiếc đã từng ném xuống Nhật Bản. Cột khói, ánh sáng chói lòa, phá sập 2-3 công trình chỉ với 1 quả bom. Một cảnh tượng không thể chê vào đâu được.</p>

<center><img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-nuclear.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-nuclear-1.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<p>Cảnh ném bom nguyên tử chói lòa màn hình</p>

<img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-2.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<p>Chế độ tự tạo map. Tàu thế kỷ 14-15 của châu Âu đánh với thuyền bè thời đồ đá.</p></center>

<p>Game cũng giảm bớt số lượng binh chủng không cần thiết. Nếu bạn đã chơi Thế Chiến, bạn sẽ không thể xây hay gọi cung thủ được.
Nếu bạn chơi thời khoa học viễn tưởng, những chiếc máy bay bị bỏ bớt gần hết để thay cho robot.
Rất đáng tiếc. Thời kỳ mà người viết cảm thấy không hài long nhất là thời khoa học viễn tưởng. Trong thời này, xe tăng và bộ binh không có nhiều tác dụng khi chỉ đi dưới đất còn robot vừa vượt nước, vừa bay trên trời.
Tàu chiến cũng ít tác dụng hơn khi phải cạnh tranh với tàu ngầm. Nhất là khi đối thủ sử dụng tàu ngầm tên lửa hạt nhân, đứng từ khoảng cách rất xa với sát thương rất lớn, cực kỳ khó chịu khi phải cử máy bay đi tìm diệt.</p>

<p>Việc có nhiều binh chủng giúp game đa dạng, thực thế hơn. Tuy nhiên, có những đơn vị hoàn toàn có thể bỏ bớt. Thời thế chiến là thời bộ binh, xe tăng và máy bay phát triển vượt bậc, đơn vị đa dạng.
Tuy nhiên, bộ binh có quá nhiều đơn vị và chức năng chỉ có một là tấn công quân mặt đất. Tầm xa bình thường, sát thương bình thường, hình ảnh bình thường nhưng lại có đến 2-3 đơn vị bộ binh tương tự nhau.
Khi qua thời khoa học viễn tưởng, hình ảnh của xe tăng và bộ binh giống như làm để cho có. Sức ảnh hưởng chỉ ấn tượng với các đơn vị phòng không, còn khi đánh với bộ binh thì hoạt động bình thường.
Những tia laze đứt đoạn không đẹp bằng đạn pháo của thế chiến, cũng không có cảnh khói lửa khi những viên đạn nổ trên mặt đất, tia laze chỉ bất chợt xuất hiện rồi biến mất.</p>

<center><img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-3.jpg" width="70%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-4.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" /></center>

<p>Hay như các đơn vị pháp sư hô mưa gọi gió. Dù nhiều phép hay nhưng có những phép chẳng gây ra được sát thương gì như núi lửa. Núi lửa chỉ có thể gọi ở nơi đất trống không nhà, không khoáng sản.
Người viết thử gọi núi lửa ở một khu vực gần đoạn đường hành quân của đối thủ, kết quả là sát thương chẳng gây ra được bao nhiêu.
Tuy nhiên, phép gọi bão lốc xoáy thì ngược lại. Phép này phòng không chống máy bay rất tốt và không thể bị phá hủy, có thể điều khiển được cơn bão đó bay thẳng vào sân bay địch.</p>

<center><img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-5.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<img src="/upload/images/game/Empire-Earth-de-che-thien-nien-ky-volcano.jpg" width="100%" alt="Empire Earth - Đế chế thiên niên kỷ" />

<p>Trông rất đẹp nhưng núi lửa này chẳng có tác dụng gì nhiều</p></center>

<p>Empire Earth có tổng cộng 21 đất nước, phe phái. Những phe phái từ thời Tiền sử đến thời kỳ Tăm tối gồm Hy Lạp cổ đại, Đế quốc Assyria, Babylon, Byzantine La Mã, Carthage và Vương quốc Israel.
Những phe phái thời Trung Cổ đến Cận đại gồm Áo, Anh, Frank, Vương quốc Ý, Đế quốc Ottoman và Tây Ban Nha.
Những phe phái từ thời đại Nguyên tử đến thời kỳ Hiện đại gồm Pháp, Đức, Anh, Ý, Liên Xô và Mỹ.
Cuối cùng là những phe phái từ thời đại Kỹ thuật số đến thời kỳ Vũ trụ gồm Trung Quốc, Novaya Nga và Lực lượng nổi dậy.</p>

<p>Giống như nhiều game chiến lược thời gian thực khác, Empire Earth có phần chiến dịch (Campaigns). Tuy nhiên, không như một số game khác, mỗi màn chơi sẽ kể một câu chuyện và người chơi có một phần trong câu chuyện đó.
Chia ra từ chiến dịch của Nga, nhiệm vụ “Chiến dịch Sư tử biển” trong chiến dịch của Đức và màn chơi đầu tiên trong phần này là chiến dịch Hy Lạp.
Tất cả các trận chiến trong các chiến dịch đều có thực trong lịch sử, ngoại trừ phe Nga trong thời hiện đại.
Nhiệm vụ của các chiến dịch khá đa dạng. Từ việc lén lút trốn chạy để đến điểm tập kết đến thủ thành, tiêu diệt 3 căn cứ của đối thủ.</p>

<p>Empire Earth đạt số điểm tầm 82% theo Game Rankings và đoạt giải thưởng "PC Game of the Year" (trò chơi máy tính của năm) 2001 từ GameSpy.
Game được IGN xếp hạng 8.5/10 và nhận xét rằng “Bất kỳ ai quen thuộc với Age of Empires sẽ bị nhấn chìm vào Empire Earth.
Với một số bổ sung và một vài thay đổi nhỏ về mô hình kinh tế và giao diện gần chính xác như vậy vào Age of Empires II”.
Đúng như lời nhận xét của IGN, Empire Earth thật sự là phiên bản nâng cấp của Age of Empires nên người chơi có thể nhanh chóng hòa nhập vào game.
Ngoài ra nó còn được tái phát hành trong bản gộp Empire Earth Gold Edition vào ngày 6/5/2003. Nó gồm cả phiên bản gốc và bản mở rộng. </p>
',

            'date_post'         => '2016-03-20',
            'thumbnail_post'    => 'Empire-Earth-de-che-thien-nien-ky-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Overwatch 1 tháng sau Open Beta',
            'url_post'        => 'overwatch-sau-1-thang-open-beta',
            'present_vi_post' => 'Sau 1 tháng kể từ ngày Open Beta 5/5/2016, Overwatch đã trở thành cơn sốt trong giới game thủ.',
            'content_vi_post' => '<p>Overwatch là tựa game bắn súng mới của Blizzard chính thức cho các game thủ chơi miễn phí từ ngày 5/5/2016 đến ngày 9/5/2016. Sau đó,Overwatch đã được Blizzard chính thức bán vào ngày 24/5/2016 với giá 40 USD (khoảng 880.000 VNĐ). Và sau đây là tổng hợp những thông tin về Overwatch sau 1 tháng được bày bán.</p>

<center><iframe width="545" height="300" src="https://www.youtube.com/embed/paDxNkQipeI" frameborder="0" allowfullscreen></iframe>

<p>Trailer Overwatch Vietsub về Hanzo và Genji</p></center>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-1.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />
</center>

<p><b>Sức hút bất ngờ, phong cách mới mẻ.</b></p>

<p>Mới mở cửa được mấy ngày nhưng Overwatch đã trở thành một tựa game nổi tiếng tại Hàn Quốc, Trung Quốc, Việt Nam và nhiều nước khác. Với phong cách chơi kết hợp giữa MOBA và bắn sung, Overwatch thực sự là một luồng gió mới dành cho các game thủ.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-2.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />
</center>

<p>Với các nhân vật khác nhau, người chơi có thể chọn cho mình những nhân vật tương ứng với các vị trí y như trong game MOBA như Liên Minh Huyền Thoại, Dota… Có 4 loại nhân vật: tấn công như Genji, tanker như Reinhardt, D.Va, phòng thủ như Hanzo và hỗ trợ như Mercy với nhiều phong cách chơi khác nhau như đặt bẫy, ám sát, dùng súng phóng lựu, khiên năng lượng chứ không đơn thuần như những game bắn súng khác là chọn nhân vật giống nhau xong lao vào xả đạn. Overwatch đòi hỏi người chơi phải có kỹ năng và đầu óc chiến thuật tốt.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-3.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />
</center>

<p>Và hiện nay, con số game thủ chơi Overwatch đã lên đến 7 triệu. Riêng Việt Nam đã gần đạt con số 7000 người. Nhiều người Việt Nam đã chịu bỏ tiền mua game, không chơi crack. Đây là một tín hiệu vui về ý thức game thủ Việt Nam. Game thủ sẵn sàng bỏ tiền nếu như game đó là một game có chất lượng.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-4.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />
</center>

<p><b>Mạnh tay với hack</b></p>

<p>Và khi nhắc đến chất lượng khi phải bỏ tiền ra mua game, chắc chắn nhiều người sẽ đặt câu hỏi: “Bảo mật của Overwatch có tốt không?” Và câu trả lời của Blizzard là xóa sổ1572 account tại cụm máy chủ Trung Quốc để làm gương.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-5.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />
</center>

<p>Thậm chí, có thông tin về một người chơi đã sử dụng nick hack và bị khóa tài khoản. Sau đó người này đã 2 lần mua game, 2 lần tạo tài khoản, thậm chí cả fake IP mà vẫn bị khóa tài khoản chỉ sau 1-2 ngày chơi. Tính ra, người này đã tốn tổng cộng 120 USD (gần 3 triệu VNĐ) mà chẳng được gì chỉ vì một lần hack.</p>

<p>Rõ ràng, với ông trùm Blizzard, một khi đã làm là tới nơi tới chốn. Blizzard sẵn sàng loại bỏ hàng ngàn tài khoản hack để giữ lại hơn 7 triệu game thủ đang muốn thưởng thức một trò chơi công bằng, trong sạch và mang đậm chất giải trí.</p>

<p><b>Phim đen về Overwatch được tìm kiếm</b></p>

<p>Sau khi Overwatch nổi đình nổi đám, nhiều người nước ngoài đã tìm kiếm phim đen trên các trang phim khiêu dâm. Một số họa sĩ còn sáng tác ra những tấm hình khiêu dâm về các nhân vật Overwatch. Một số tấm mang tính vui vẻ, hài hước. Một số lại gợi dục, dành cho lứa tuổi trên 18.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-6.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-7.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />

<p>Một số tấm mang tính hài hước, giải trí.<br> Các cô gái trong series Senran Kagura.</p>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-8.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />

<p>Một số tấm dành cho lứa tuổi trên 16.</p>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-9.jpg" width="100%" alt="Overwatch 1 tháng sau Open Beta" /><br><br>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-dva-tracer.jpg" width="100%" alt="Overwatch 1 tháng sau Open Beta" /><br><br>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-widowmaker-reaper.jpg" width="100%" alt="Overwatch 1 tháng sau Open Beta" />

<p>Và một số tấm dành cho lứa tuổi trên 18.</p>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-10.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" /><br><br>

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-11.jpg" width="70%" alt="Overwatch 1 tháng sau Open Beta" />

<p>Số liệu tìm kiếm</p></center>

<p>Nhìn chung, với lối chơi mới mẻ, sáng tạo cùng việc nghiêm trị hack của Blizzard, Overwatch hứa hẹn sẽ là một game ăn khách trong tương lai, thậm chí có thể được đưa vào eSport. Tuy nhiên, Overwatch sẽ cần một máy có cấu hình tương đối và một đường truyền mạng tốt để có thể chơi thoải mái. Hy vọng các game thủ sẽ sớm được trải nghiệm Overwatch.</p>
',

            'date_post'         => '2016-06-07',
            'thumbnail_post'    => 'overwatch-sau-1-thang-open-beta-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Injustice 2 sẽ ra mắt vào năm 2017',
            'url_post'        => 'Injustice-2-se-ra-mat-vao-nam-2017',
            'present_vi_post' => 'Trailer Injustice 2 đã được DC Entertainment ra mắt trên kênh Youtube, khiến các fan háo hức tột cùng.',
            'content_vi_post' => '<p>Sau khi bộ truyện comic Injustice: God among us thành công vang dội, game cùng tên đã ra mắt vào năm 2013, dành cho  PlayStation 3, Xbox 360, và Wii U.</p>

<center><img src="/upload/images/game/injustice-2-wallpaper.jpg" width="100%" alt="Injustice 2 sẽ ra mắt vào năm 2017" /></center>

<p>Ngày 8/6/2016, trên kênh Youtube của DC Entertainment đã ra mắt trailer Injustice 2 đầy hấp dẫn. Game sẽ được phát hành dành cho PS4 và Xbox One.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/KgmItga6jxs" frameborder="0" allowfullscreen></iframe>

<p>Injustice 2 Trailer Vietsub Engsub</p></center>

<p>Injustice là bộ Comic nói về cuộc nội chiến giữa các siêu anh hùng. Sau khi Lois Lane, vợ của Superman bị Joker giết, Superman đã bị hận thù điều khiển, khiến anh ta giết Joker. Và từ đó, Superman quyết định lập ra chế độ độc tài, bắt loài người khắp thế giới phải tuân theo ý mình để đảm bảo không có một cuộc xung đột, chiến tranh nào xảy ra.</p>

<p>Nhưng Superman đã mù quáng đến mức giết cả bạn bè của mình chỉ vì họ muốn để loài người tự quyết định vận mệnh. Green Arrow, Captain Atom và nhiều anh hùng khác đã chết. Batman quyết tâm ngăn cản Superman. Trận chiến này đã lôi kéo nhiều thế lực ngoài hành tinh, thậm chí cả thần linh vào cuộc.</p>

<p>Injustice 2 cung cấp cho người chơi những trải nghiệm mở rộng lớn hơn trước. Mỗi trận đấu xác định bạn trong trò chơi, nơi các biểu tượng nhân vật DC mạnh mẽ hơn và được kiểm soát trong suốt trò chơi. Đối với các game thủ lần đầu tiên chơi có thể điều khiển giao diện nhân vật, chiến đấu và phát triển trên một loạt các chế độ chơi game.</p>',

            'date_post'         => '2016-06-08',
            'thumbnail_post'    => 'Injustice-2-se-ra-mat-vao-nam-2017-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Những lệnh cấm Pokemon GO trên thế giới',
            'url_post'        => 'Nhung-lenh-cam-Pokemon-GO-tren-the-gioi',
            'present_vi_post' => 'Một số nơi bị cấm người chơi Pokemon GO vào đó. Thậm chí có quốc gia cấm hoàn toàn Pokemon GO.',
            'content_vi_post' => '<p>Pokemon GO - một hiện tượng toàn cầu và là một bước đột phá lớn trong ngành công nghiệp game dựa trên thực tế ảo.
Khi Pokemon GO du nhập vào bất cứ một quốc gia nào, game đều tạo ra nhiều những phản ứng trái chiều. Những ý kiến ủng hộ Pokemon GO thường là:</p>

<ul>
<li>Một phương pháp vừa giải trí, vừa tập thể dục hữu hiệu thay vì ngồi ở nhà cày game.
<li>Mang đến nhiều giá trị thương mại, kinh tế cho các quán nước, tiệm trông xe hay cả những địa điểm vui chơi...
<li>Sáng tạo thêm nhiều cách chơi game, học thêm nhiều điều về mạng Internet, GPS, giả lập Android...
</ul>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/uTWaLPAr7nY" frameborder="0" allowfullscreen></iframe>

<p>Pewdiepie chơi Pokemon GO trên máy vi tính.</center</p></center>

<p>Tuy nhiên mặt trái của nó là điều cũng không thể đếm xuể. Mới đây nhất ở quốc gia láng giềng với Việt Nam là Campuchia đã ban hành một chỉ thị nhằm ngăn chặn những game thủ chơi Pokemon GO lai vãng đến bảo tàng diệt chủng Tuol Seng. Các địa danh trong khu vực bảo tàng chính là những chứng tích của diệt chủng man rợ mà chế độ Khmer Đỏ đã gây ra với chính đồng bào mình, ước tính con số 1,8 triệu người đã chết trong giai đoạn mà Khmer Đỏ cầm quyền.</p>

<center><img src="/upload/images/game/Nhung-lenh-cam-Pokemon-GO-Bao-tang-diet-chung-Tuol-Sleng.jpg" width="70%" alt="Những lệnh cấm Pokemon GO trên thế giới" />

<img src="/upload/images/game/Nhung-lenh-cam-Pokemon-GO-Bao-tang-diet-chung-Tuol-Sleng-1.jpg" width="70%" alt="Những lệnh cấm Pokemon GO trên thế giới" />

<p>Biển cấm Pokemon GO tại Bảo tàng diệt chủng Toul Sleng, Campuchia</p></center>

<ul>
<li>"Họ không nên chơi ở đây. Nơi đây không phải là nơi săn bắt Pokemon", Chum Mey, một trong số ít nhân chứng còn sót lại từng ở nhà tù Toul Seng nói với tờ Cambodia Daily.
<li>"Nơi này chứa đầy những nồi buồn và sự đau khổ", Mey, người mất vợ và các con của mình bởi chế độ diệt chủng Khơme Đỏ nói thêm.
<li>"Tôi không nghĩ việc chơi game ở đây là thích hợp", một du khách người Đài Loan cho biết
</ul>

<p>Giám đốc bảo tàng Chhay Visoth nói với Cambodia Daily: "Nếu chúng tôi biết họ tới đây với mục đích săn tìm Pokemon thì chắc chắn họ sẽ không được vào".
Tính đến thời điểm hiện tại, bất cứ du khách nào cầm theo các thiết bị điện tử thông minh sẽ được các nhân viên bảo vệ buộc phải rời đi. </p>

<center><img src="/upload/images/game/Nhung-lenh-cam-Pokemon-GO-bien-bao-cam-Pokemon-GO.jpg" width="70%" alt="Những lệnh cấm Pokemon GO trên thế giới" />

<p>Một biển cấm Pokemon GO</p></center>

<p>Ngoài ra, trên thế giới còn nhiều những vị trí nhạy cảm, bao gồm cả các trại tập trung Auschwitz ở Ba Lan, đài tưởng niệm bom Hiroshima Atomic tại Nhật Bản. Tại Thái Lan, cơ quan quản lý viễn thông thông báo kế hoạch hạn chế game thủ Pokemon GO tại một số địa điểm từ Cung điện Hoàng gia đến chùa chiền và bệnh viện. Tại Mỹ, Bảo tàng Holocaust yêu cầu không chơi Pokemon GO vì đây là hành vi “hoàn toàn không thích hợp”. Thậm chí Iran đã tiến hành chặn Pokemon GO trên phạm vi toàn quốc. </p>

<p>Ở Việt Nam cũng đã có trường hợp cô giáo mải chơi Pokemon GO mà quên công việc đứng đón học sinh. Cuối cùng, nhà trường đã cắt 1/3 lương tháng và cấm mọi điện thoại của giáo viên. Xem chi tiết tại <a href="http://gamethu.net/tin-tuc/mobile/ca-truong-cam-smartphone-vi-mot-giao-vien-mai-choi-pokemon-go-3450328.html ">đây.</a></p>

<p>Và trên hết, nhiều người lo ngại Pokemon GO sẽ hình thành một thế hệ Zombie, tức là những người đi ra ngoài đường chỉ biết cắm mặt nhìn điện thoại hay các thiết bị điện tử khác. Thực tế là đã có những vụ tai nạn xe cộ, cướp giật điện thoại, thậm chí leo rào vào Nhà Trắng chỉ để bắt Pokemon GO.</p>

<center><img src="/upload/images/game/Nhung-lenh-cam-Pokemon-GO-2.jpg" width="70%" alt="Những lệnh cấm Pokemon GO trên thế giới" />

<p>Pokemon GO sẽ là liều thuốc cải thiện tình trạng này?</p>

<img src="/upload/images/game/Nhung-lenh-cam-Pokemon-GO-3.jpg" width="70%" alt="Những lệnh cấm Pokemon GO trên thế giới" />

<p>Hay sẽ tạo nên một thế hệ Zombie?</p></center>

<p>Thực tế, nước Nhật đã mất đi 1 thế hệ vì các trò chơi điện tử, nghiện game và đó là bài học cho bất cứ ai. Những con nghiện NEET suốt ngày ngồi ở nhà cày game đã  khiến nước Nhật, Hàn Quốc, Trung Quốc và nhiều nước đã phát triển phải tìm cách bắt các bộ phận giới trẻ này phải sống thực tế hơn. Có lẽ vì vậy mà Pokemon GO đã ra đời nhằm cải thiện phần nào cuộc sống của họ. Tuy nhiên, vì Pokemon GO còn là tựa game đi đầu trong xu thế phát triển game thực tế ảo nên trong tương lai, các nhà phát triển còn rất nhiều việc phải làm.</p>',

            'date_post'         => '2016-07-01',
            'thumbnail_post'    => 'Nhung-lenh-cam-Pokemon-GO-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'     => 'Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?',
            'url_post'         => 'Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao',
            'present_vi_post'  => 'Huấn luyện, chiến đấu để thu phục là những tính năng bị loại bỏ trong Pokemon GO',
            'content_vi_post'  => '<p>Pokemon GO hiện đang là cơn sốt trên toàn thế giới. Khắp các thành phố lớn, đâu đâu cũng thấy nhiều người nhìn chằm chằm vào điện thoại để tìm Pokemon. Pokemon GO còn giúp cho những cửa hàng kinh doanh đột nhiên phát đạt. Quả thật, Pokemon GO đang trở thành trào lưu nóng hổi hiếm thấy trên khắp thế giới</p>

<p>Tuy nhiên, nếu so sánh với những phiên bản máy cầm tay cũ Gameboy thì quả thật, Pokemon GO đã làm hỏng hình ảnh của những người đã từng một thời chinh chiến khắp các phiên bản Pokemon và làm thay đổi hình ảnh của những ai có tuổi thơ yêu thích phiên bản Anime. Hãy cùng xem Pokemon GO khác xa với Gameboy và Anime như thế nào.</p>

<center><img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-1.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" />

<p>Biểu tượng của hãng Nintendo,<br>
khiến người chơi phải mua thêm máy chơi game Gameboy</p></center>

<h3>Game dành cho game thủ thành phố</h3>

<p>Một điểm chung hiện nay của Pokemon GO là chỉ chơi được ở các bản đồ thành phố, khu vực đông dân cư hoặc có sóng Wifi, 3G mạnh. Nếu giả sử chúng ta lên rừng, đến những chỗ hoang vu thì khả năng bắt Pokemon là không thể. Thậm chí, ngay cả trong thành phố cũng có những nơi nhạy cảm, không thích hợp để bắt Pokemon như viện bảo tàng, đền chùa…</p>

<h3>Chiến đấu để bắt Pokemon</h3>

<p>Ai là fan Pokemon hay đã từng chơi các tựa game Pokémon trên hệ máy Gameboy thời kỳ đầu, hẳn không thể quên cách thu phục Pokemon hoang dã.
Đầu tiên, bạn phải chiến đấu với chúng. Sau khi đánh cho Pokemon gần hết máu, người chơi có thể ném Pokeball ra để bắt.</p>

<center><img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-2.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" /></center>

<p>Còn Pokemon GO? Rất đơn giản: ném Pokeball ra là có thể thu phục được. Như vậy hoàn toàn không giống phim.
Nhiều người dùng cả những quả cầu cấp cao hơn như Masterball, Ultraball... thì việc thu phục càng giảm mất tính hấp dẫn.</p>

<h3>Huấn luyện Pokemon</h3>

<p>Tính năng quan trọng nhất của dòng game và phim Pokemon không phải là bắt càng nhiều càng tốt mà là huấn luyện.
Chỉ với những con Pokemon yếu ớt ban đầu, bạn phải chiến đấu với các huấn luyện viên khác hoặc với Pokemon hoang dã để tăng level cho Pokemon.
Thậm chí, những con Pokemon không thể chiến đấu như Abra, Magikarp muốn tiến hóa thành Alakazam, Gyarados phải trải qua giai đoạn đầu cực kỳ khó khăn để cày level cho chúng.</p>

<center><img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-3.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" />

<p>Magikarp và Abra là 2 Pokemon nổi tiếng<br>
vì chúng không tự chiến đấu được.</p></center>

<img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-4.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" />

<p>Nhưng công sức sau khi huấn luyện chúng<br>
là những con Pokemon cực mạnh.</p></center>

<b><p>Hack Pokemon</p></b>

<p>Một điểm có ích của Pokemon GO là nó bắt người chơi phải đi ra đường như một hình thức tập thể dục thay vì ngồi một chỗ trong phòng để cày game. Vậy mà game thủ giờ còn hack cả Google Map chỉ để tiện đường đi thì hết nói nổi. Game thủ đã hack Pokemon, fake GPS, thậm chí gần đây Google Map còn thông báo việc bản đồ bị chỉnh sửa. Chơi game mà lại đi hack như thế thì còn giá trị gì?</p>

<h3>Trao đổi Pokemon và tiêu cực</h3>

<p>Một tính năng khác là trao đổi Pokemon. Chắc mọi người còn nhớ máy trao đổi Pokemon trong phim dùng để trao đổi những con Pokemon với nhau. Trong Pokemon GO, hiện giờ tính năng đó chưa có. Nhưng có thông tin sắp tới, các game thủ Pokemon GO sẽ có tính năng trao đổi với nhau, thậm chí mua bán với nhau. Xem chi tiết tại <a href="http://gamek.vn/pokemon-go-se-co-tinh-nang-trao-doi-dan-cay-tien-chac-chan-thich-dieu-nay-20160711150433491.chn">đây.</a></p>

<center><img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-5.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" />

<p>Trong số Pokemon của đội Hỏa Tiễn, con nào là con được trao đổi?</p></center>

<p>Việc này có thể rất tốt khi nó giúp mọi người tương tác, giao tiếp với nhau nhưng cũng sẽ xảy ra những ý đồ xấu khi có thể có lừa đảo hay hack level để bán kiếm tiền. Và hơn nữa, nó còn khiến những người lười biếng không còn muốn đi ra ngoài đường. Cứ gọi cho những người cày game để mua Pokemon là có ngay một con Pokemon đúng ý và rất mạnh.</p>

<h3>Yêu thương Pokemon</h3>

<p>Hãy nghe tâm sự của <a href="https://www.facebook.com/Risechi/posts/607655176075104" target="_blank">một fan Pokemon</a> cảm thấy thất vọng sau khi chơi Pokemon GO.</p>

<center><img src="/upload/images/game/Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-6.jpg" width="70%" alt="Pokemon GO đã làm hỏng hình ảnh Pokemon như thế nào?" />

<p>Ash và Pikachu, tình bạn không thể thay thế</p></center>

<p>Quả thật, khi xem Anime, người viết cũng thấy điểm hay nhất trong phim là yêu thương một con Pokemon như vật nuôi của mình. Dù nó không phải Pokemon siêu hiếm, siêu mạnh nhưng một huấn luyện viên phải luôn xem nó như một người bạn đồng hành, bạn chiến đấu. Ash có thể có nhiều Pokemon, nhưng Pokemon mà cậu chọn - cũng như chọn cậu - chính là Pikachu. Đó chính là điểm khiến Pikachu trở nên cực kỳ đặc biệt trong thế giới Pokemon, mặc dù nó không phải Pokemon hiếm hay mạnh nhất.</p>

<p>Còn Pokemon GO? Một khi đã mất cảm giác được huấn luyện, bạn cũng sẽ mất luôn cảm giác yêu thương Pokemon đó. Một con Pokemon đã cùng bạn huấn luyện khổ cực để lên level chắc chắn phải có giá trị hơn những con Pokemon bình thường khác. Pokemon đầu tiên, cùng sánh đôi với bạn chắc chắn có ý nghĩa rất lớn.</p>

<p>Tóm lại, Pokemon GO thực sự là một bước đột phá lớn trong nền công nghiệp game. Nhưng vì là game đi đầu trong bước đột phá này nên chắc chắn không tránh khỏi sai lầm. Người viết hy vọng có thể sau này sẽ có một phiên bản Pokemon GO 2 hay một game tương tự với chủ đề khác để có thể trải nghiệm game một cách hoàn hảo và sâu sắc hơn, thay vì cứ chạy theo phong trào rồi đánh mất ý nghĩa của nó.</p>',

            'date_post'         => '2016-07-03',
            'thumbnail_post'    => 'Pokemon-GO-da-lam-hong-hinh-anh-Pokemon-nhu-the-nao-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Game dành cho streamer nghèo',
            'url_post'     	  => 'game-danh-cho-streamer-ngheo',
            'present_vi_post' => 'Có cần thiết phải mua dàn máy khủng, chơi game xịn mới gọi là streamer?',
            'content_vi_post' => '<p>Giới streamer thường khoe dàn máy khủng chục triệu, trăm triệu VND cho các bạn trẻ xem. Mục đích thường là để khán giả lóa mắt, thèm muốn, hâm mộ. Tuy nhiên, chính những hình ảnh đó đã sinh ra một suy nghĩ: "Phải có công cụ tốt mới có thể làm streamer".</p>

<p>Điều đó chỉ đúng một phần. Nếu các streamer lựa chọn những tựa game nặng như PUBG thì bắt buộc cần có máy khủng. Vậy còn các tựa game nhẹ khác thì sao? Streamer không bắt buộc phải chơi game nặng. Sau đây là những tựa game dành cho các streamer chỉ cần máy tính trung bình (khoảng 10 triệu VND) vẫn có thể chơi thoải mái và làm khán giả cười thích thú.</p>

<h3>Minecraft</h3>

<p>Đây chắc chắn là game phải kể đầu tiên. PewDiePie, các Virtual Youtuber và các Youtuber Việt Nam đều chơi game này. Một game rất nhẹ nhàng nhưng đầy yếu tố bất ngờ và sáng tạo. Đây cũng là giải pháp khi các streamer không có ý tưởng hoặc đang bận việc. Năm 2019, PewDiePie kết hôn với Mariza. Trong thời gian đó, PewDiePie liên tục chơi Minecraft. Nhiều khả năng do anh quá bận với việc chuẩn bị đám cưới.</p>

<center><img src="/upload/images/game/game-danh-cho-streamer-ngheo-pewdiepie-minecraft.jpg" width="100%" alt="PewDiePie Minecraft" />

<p>Trước video đám cưới của PewDiePie là rất nhiều video Minecraft.</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/z_b8Tvf3v8U" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Các Hololive Virtual Youtuber chơi Minecraft rất thường xuyên. Họ có cả server Minecraft riêng.</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/DP6F0O4t5kc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Series Minecraft của BHGaming nổi tiếng một thời</p></center>

<h3>Cat Mario</h3>

<p>Mario phiên bản cực khó này được rất nhiều Youtuber, streamer chơi. Tất cả họ đều có điểm chung (không rõ là diễn hay thật) là đập bàn, gào thét mỗi khi chết. Câu hỏi mà họ hay hỏi nhất là "Ai làm ra trò chơi này vậy?"</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/HAxqEsLAB2s" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PewDiePie chơi Cat Mario</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/FyKwWVCXsKg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Natsuiro Matsuri, Hololive Virtual Youtuber chơi Cat Mario</p>

<img src="/upload/images/game/game-danh-cho-streamer-ngheo-bhgaming-cat-mario.jpg" width="100%" alt="BHGaming Cat Mario" />

<p>BHGaming chơi Cat Mario</p></center>

<p>Cat Mario là web game của Trung Quốc. Bạn có thể chơi tại <a href="http://www.cat-mario.com/" target="_blank" title="Virtual Youtuber Hololive">cat-mario.com.</a> Mặc dù tựa game này chỉ có thể giúp các streamer diễn khoảng tối đa 2-3 video nhưng đây vẫn là lựa chọn tốt. Hoàn toàn miễn phí và không yêu cầu cấu hình. Chỉ cần trình duyệt của bạn cho phép chạy Flash là ổn.</p>

<h3>Guts and Glory</h3>

<p>Hay còn được gọi với tên khác là Happy Wheel. Đây là game khá máu me và hài hước có thể mua trên Steam. Bạn sẽ vào vai một nhân vật lái xe đạp, ô tô hay thậm chí là xe đạp trẻ con để vượt qua những địa hình đồi núi, thị trấn. Chuyện sẽ chẳng có gì đáng nói nếu như những địa hình đó không có bom rơi, đạn lạc. Những chiếc máy cưa, mìn rải trên đất, máy bắn tên sượt qua tứ phía quanh bạn sẽ cho bạn cảm giác thót tim và cực kỳ vui nhộn.</p>

<center><img src="/upload/images/game/game-danh-cho-streamer-ngheo-pewdiepie-guts-and-glory.jpg" width="100%" alt="Pewdiepie Guts and Glory" />

<p>PewDiePie chơi Guts and Glory rất nhiều</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/aYZP1wQZEdg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực Tiếp Game chơi Guts and Glory một lần rồi đầu hàng</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/_KyHOBG4UPY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Kizuna AI chơi Guts and Glory</p></center>

<h3>Human Fall Flat</h3>

<p>Nếu những game trên không thể chơi trong thời gian dài được thì đây là game giải đố vui vẻ và lâu bền nhất mà các streamer cần. Human Fall Flat là game giải đố có thể chơi nhiều người cùng lúc với cấu hình nhẹ. Các nhân vật được thiết kế rất phong phú như Thanos, Doraemon… Bản đồ cũng được thiết kế, làm mới liên tục. Game có thể được mua trên Steam.</p>

<center><img src="/upload/images/game/game-danh-cho-streamer-ngheo-truc-tiep-game-human-fall-flat.jpg" width="100%" alt="Pewdiepie Guts and Glory" />

<p>Series Human Fall Flat nổi tiếng của Trực Tiếp Game</p>

<img src="/upload/images/game/game-danh-cho-streamer-ngheo-hololive-human-fall-flat.jpg" width="100%" alt="Pewdiepie Guts and Glory" />

<p>Hololive Virtual Youtuber cũng có series Human Fall Flat</p></center>

<h3>Các game kinh dị nói chung</h3>

<p>Game kinh dị luôn tạo cho người chơi và khán giả những pha giật mình thót tim. Đó là lý do các streamer và Youtuber dù có lựa chọn game gì làm thương hiệu thì vẫn phải chơi vài game kinh dị để thu hút khán giả.</p>

<center><img src="/upload/images/game/game-danh-cho-streamer-ngheo-ManlyBadassHero.jpg" width="100%" alt="ManlyBadassHero" />

<p>ManlyBadassHero chuyên chơi game kinh dị</p></center>

<p>Những game kinh dị cấu hình nhẹ thường là game cũ như Mad Father, Outlast, Dead Space, Silent Hill, Home Sweet Home... Trong đó có một game mà rất nhiều Streamer và Youtuber chơi từ thời xa xưa đến giờ, đó là “5 đêm khoái lạc trong nhà nghỉ của Freedy” (Trích Vũ - Trực Tiếp Game).</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/1U85PF2D4YA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực tiếp game chơi Five Nights at Freddy&apos;s</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/PeBpl5gERNY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>BHGaming chơi Five Nights at Freddy&apos;s 4</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/RJVLczBM73s" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PewDiePie chơi Five Nights at Freddy&apos;s bản VR</p></center>

<p>Thêm 1 series nữa là Outlast. Dù được phát hành vào ngày 4/9/2013, Outlast vẫn được các Youtuber và Streamer làm series chơi đến tận bây giờ. Cấu hình cũ của Outlast dư sức chơi khỏe trên các máy tính phổ thông hiện giờ với RAM chỉ 4GB và máy core i3. Dù đã có Outlast 2, phần 1 và phần Whistle Blower vẫn có những điểm hấp dẫn với cốt truyện dễ hiểu. Nhân vật chính đi vào một nhà thương điên thí nghiệm sinh vật đột biến và thoát ra với đầy đủ bằng chứng. Còn Outlast 2 nói về tôn giáo nên hơi khó hiểu.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/BCWtNrrQZeI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Kizuna AI live stream tựa game cũ kỹ này vào đầu năm 2020.</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/CrGa54rpvF4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PewDiePie chơi Outlast</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/0kcYNJA-ItI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>BHGaming chơi Outlast: Whistle Blower</p></center>

<h3>60 Seconds</h3>

<p>Nếu còn 60 giây để chạy tận thế, bạn sẽ làm gì? Một tựa game rất hài hước và thú vị kể về một gia đình sẽ sống sót trong bao lâu dưới hầm trú ẩn. Trong 60 giây, nhân vật bạn điều khiển sẽ mang đồ ăn, thức uống, thành viên gia đình hay bất kỳ thứ gì khác như súng, mặt nạ phòng độc, bộ bài, bản đồ...</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/5uiFQpaGTcc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/17ZoYA1wujE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực Tiếp Game phá đảo 60 Seconds</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/59WBQFXqlSM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PewDiePie chơi 60 Seconds</p></center>

<p></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/J_fivtFXQLE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/sZKB81wE_HQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Kizuna AI chơi 60 Seconds</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/ETlMYY1gDoc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Mio chơi 60 Seconds</p></center>




<h3>Getting Over It</h3>

<p>Tựa game này được ra mắt vào năm 10/2017. Đây là game nói về một người đàn ông không chân, ngồi trong một cái chum và leo núi bằng một cái cuốc. Trông người đàn ông khuyết tật này thật tràn đầy nghị lực. Anh ta dùng cuốc leo núi, vách đá và leo lên cả vũ trụ bằng những viên thiên thạch.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/oLMQyA3Y1y4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực Tiếp Game cùng đồng bọn chơi Getting Over It</p></center>

<p>Đây là một trong số các trò chơi có độ khó đến mức ức chế, thậm chí hơn cả Cat Mario. Chỉ cần làm sai, bạn sẽ rơi xuống, thậm chí rơi lại từ đầu game. Game đề cao nghị lực phi thường của những người khuyết tật, luôn vượt qua mọi khó khăn để làm được điều phi thường.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/ontj3y9IEuM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>VTuber Haato của Hololive phá đảo Getting Over It</p></center>







<h3>Paper, Please</h3>

<p>Trang chủ <a href="https://papersplea.se/" target="_blank">Paper, Please</a></p>

<p>Người chơi vào vai một lính kiểm soát biên giới của đất nước hư cấu..., kiểm tra giấy tờ của người dân trước cho phép hoặc từ chối họ đặt chân vào đất nước mình.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/gUg6t2zYYT4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Giới thiệu Paper, Please của Phê Game</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/YFHHGETsxkE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Phim ngắn của Paper, Please</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/RsWQfZl-Xtc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PewDiePie chơi Paper, Please</p></center>



<p>Các Youtuber khác chơi Paper, Please như BHGaming, Trực Tiếp Game...</p>



<h3>Plague inc Evolved</h3>

<p>Game này đột nhiên nổi như cồn khi dịch COVID-19 bùng phát. Ai cũng muốn làm Chúa tạo ra virus với đủ các loại tên bẩn bựa như: bệnh NGU, bệnh Chim To... và cho virus lan khắp thế giới. Để ăn theo trào lưu, các video này luôn để những từ khóa như Corona, Wuhan, China...</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/c8a8HmL90xM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>BHGaming chơi Plague inc Evolved từ năm 2015</p></center>

',

            'date_post'         => '2016-08-14',
            'thumbnail_post'    => 'game-danh-cho-streamer-ngheo-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 1,
            'updated_at'        => '2020-02-13 15:00:00',
        ]);

        posts::create([
            'name_vi_post'    => 'Vietnamese Road - giao thông Việt Nam trên iOS và Android',
            'url_post'        => 'Vietnamese-Road-giao-thong-Viet-Nam-tren-iOS-va-Android',
            'present_vi_post' => 'Đường phố Việt Nam lên game dành cho điện thoại di động.',
            'content_vi_post' => '<p>Vietnamese Road là một tựa game vui nhộn đầy thử thách do HanelSoft, một công ty thành viên thuộc Hanel kết hợp sản xuất với công ty Nhật Bản Hiropro, ra mắt từ tháng 6/2016. Trò chơi hiện có hơn 7.000 lượt tải về trên cả iOS và Android bao gồm cả bản tiếng Anh và tiếng Việt. Trong đó hơn 75% là người dùng nước ngoài.</p>

<p>Khi tham gia vào game <em>Vietnamese Road</em> thì người chơi sẽ có nhiệm vụ phải điều khiển nhân vật khi đi sang đường tại những địa điểm của Việt Nam với nhiều phương tiện đang di chuyển trên đường một cách dày đặc nên bạn sẽ phải cần thận khi sang đường để không bị những chiếc xe như Dream chiến, Lead chiến, xe chở lợn, xe chở gà… đâm phải. </p>

<center><img src="/upload/images/game/Vietnamese-Road-giao-thong-Viet-Nam-tren-iOS-va-Android-1.jpg" width="70%" alt="Vietnamese Road - giao thông Việt Nam trên iOS và Android" /></center>

<p>Ý tưởng sáng tạo ra trò chơi đến từ Enomoto Kaori (1986), một cô gái Nhật đang sống và làm việc tại Hà Nội. Enomoto là nhà thiết kế game của Hanelsoft và cũng góp mặt trong đội phát triển của sản phẩm. Cô sang Việt Nam từ tháng 7/2015, cô gái Nhật Bản cho biết đã yêu mến đất nước và nền văn hóa tại nơi đây. Nhận thấy Việt Nam chưa có nhiều sản phẩm game có nội dung quảng bá văn hóa Việt, cô đã quyết định làm một tựa game mang phong cách Việt Nam và Vietnamese Road ra đời.</p>

<center><img src="/upload/images/game/Vietnamese-Road-giao-thong-Viet-Nam-tren-iOS-va-Android-Enomoto-Kaori.jpg" width="70%" alt="Vietnamese Road - giao thông Việt Nam trên iOS và Android" /></center>

<p>Nữ thiết kế game còn đang ấp ủ một dự án game di động khác có nội dung về ẩm thực Việt Nam, dự kiến sẽ ra mắt vào đầu năm 2017.</p>',

            'date_post'         => '2016-08-20',
            'thumbnail_post'    => 'Vietnamese-road-Giao-thong-Viet-Nam-tren-IOS-va-Android-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Snake eSports thua World Elite và 10 trận 1 ngày của Sofm',
            'url_post'        => 'Snake-eSports-thua-World-Elite-va-10-tran-1-ngay-cua-Sofm',
            'present_vi_post' => 'Dù đã cố gắng vượt qua Vici Gaming, Snake eSport vẫn gục ngã trong trận cuối cùng trước World Elite.',
            'content_vi_post' => '<p>Sau khi Saigon Joker không còn hy vọng tại giải Wildcard, người hâm mộ eSport Việt Nam đặt niềm tin vào Sofm tại Trung Quốc với hy vọng được nhìn thấy Sofm tại Chung Kết Thế Giới. Và ngày cá chép vượt Vũ Môn đã đến. 27/8/2016, Sofm phải đánh 10 trận với World Elite để giành vé vào Chung Kết Thế Giới.</p>

<p>Như chúng tôi đã đưa tin thì vào ngày hôm qua, chàng thần đồng Liên Minh Huyền Thoại của chúng ta - SofM đã chính thức bước vào vòng loại khu vực CKTG cùng với Snake eSports. Khi công bố lịch vòng loại LPL, người ta chỉ biết trận 1 giữa Snake eSports và Vici Gaming sẽ thi đấu vào ngày 27 và trận cuối cùng đấu với I May sẽ vào ngày 28. Sau đó, ban tổ chức quyết định trận thứ 2 với World Elite sẽ đánh ngay sau khi trận thứ 1 với Vici Gaming kết thúc. </p>

<p>Và kết quả là Snake eSports của Sofm đã phải đánh 10 trận liên tiếp trong ngày 27/8/2016. Bị chèn ép lịch thi đấu, quản lý Snake eSports lên tiếng mỉa mai ban tổ chức LPL, gọi đây là một trận BO10. </p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/_Lz3WAVnTYI" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/P8QDb-S1G4I" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/y01nVJiPgOg" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/vwP-7pRZgfU" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/HqBIcckoqz8" frameborder="0" allowfullscreen></iframe>

<p>Snake eSport vs Vici Gaming</p></center>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/oYhf5LteSpA" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/3Qiz3VC83sw" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/aHWMN1OSzIk" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/CSwGbo8zUog" frameborder="0" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/TMS965xDdpg" frameborder="0" allowfullscreen></iframe>

<p>Snake eSport vs World Elite</p></center>

<p>"Thật không may, chúng tôi đã thất bại trong ván đấu cuối cùng của cặp Bo10 hôm nay. Thua ở trong vòng lại CKTG, mùa giải năm nay của chúng tôi đã chính thức kết thúc. Hẹn gặp lại các bạn vào năm sau".</p>

<center><img src="/upload/images/game/Snake_eSports_thua_World_Elite_va_10_tran_1_ngay_cua_Sofm_2.jpg" width="70%" alt="Snake eSports thua World Elite và 10 trận 1 ngày của Sofm" /></center>

<p>Thật đáng tiếc cho Sofm, Saigon Joker và những người hâm mộ Việt Nam. Có lẽ Chung Kết Thế Giới mới chỉ ở trong tầm mắt chứ chưa trong tầm tay họ. Hãy dành những lời cảm ơn sâu sắc nhất đến với những người đã cố gắng hết sức vì màu cờ sắc áo nước nhà.</p>',

            'date_post'   => '2016-08-27',
            'thumbnail_post'    => 'Snake-eSports-thua-World-Elite-va-10-tran-1-ngay-cua-Sofm-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Tỉnh Miyagi quảng cáo cho Pokemon GO',
            'url_post'        => 'Tinh-Miyagi-quang-cao-cho-Pokemon-GO',
            'present_vi_post' => 'Pokemon GO sẽ là nguồn thu lợi lớn cho tỉnh Miyagi để tỉnh này khắc phục thiệt hại do thiên tai gây nên.',
            'content_vi_post' => '<p>Tỉnh Miyagi thuộc vùng Tohoku, phía Đông Bắc đảo Honshu là một trong ba tỉnh bị ảnh hưởng nhất bởi trận động đất / sóng thần / thảm họa hạt nhân tháng 3/2011. Tỉnh này vẫn chưa được khôi phục hoàn toàn. Và nơi này đang dùng Pokemon GO - cơn sốt trên điện thoại thông minh nhất hiện giờ - làm công cụ để phát triển kinh tế.</P>

<center><img src="/upload/images/game/Tinh-Miyagi-chinh-lai-khu-vuc-cho-Pokemon-GO-1.jpg" width="70%" alt="Tỉnh Miyagi quảng cáo cho Pokemon GO" /></center>

<p>Ngày 30/8/2016, tỉnh thông báo sẽ chi 30 triệu Yên cho Pokemon GO, bao gồm mở nhiều PokeStops, các Pokemon các du khách có thể bắt được và cung cấp không gian công cộng để chơi cũng như các gian hàng bán hàng hóa từ các quận khác và tỉnh Kumamoto. Tỉnh Kumamoto là khu vực chịu thiệt hại nặng trong trận động đất năm nay. 15 triệu Yên sẽ được đầu tư cho quảng cáo, tờ rơi, Internet và quảng cáo trên truyền hình.</p>

<center><img src="/upload/images/game/Tinh-Miyagi-chinh-lai-khu-vuc-cho-Pokemon-GO-2.jpg" width="70%" alt="Tỉnh Miyagi quảng cáo cho Pokemon GO" /></center>

<p>Sự kiện Pokemon GO tại Miyagi sẽ được tổ chức vào tháng 10. Các doanh nghiệp phần lớn đều hoan nghênh trò chơi kể từ khi nó mang lại số người chơi kỷ lục. Cổ phiếu của Nintendo tăng gấp đôi trong 2 tuần sau khi ra mắt của trò chơi. </p>

<p>Trang nguồn: <a href="https://www.animenewsnetwork.com/interest/2016-09-04/miyagi-prefecture-bets-on-pokemon-go-for-regional-revitalization/.106040">Anime News Network</a></p>',

            'date_post'         => '2016-09-05',
            'thumbnail_post'    => 'Tinh-Miyagi-chinh-lai-khu-vuc-cho-Pokemon-GO-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] 60 Seconds - Sinh tồn dưới hầm tránh tận thế',
            'url_post'        => '60-seconds-sinh-ton-duoi-ham-tranh-tan-the',
            'present_vi_post' => 'Bạn có thể đưa gia đình mình vượt qua những ngày tháng hậu tận thế để đến nơi an toàn không?',
            'content_vi_post' => '<h3>Thông tin và cấu hình</h3>

<ul>
<li>Tên game: 60 Seconds
<li>Thể loại: nhập vai, quản lý
<li>Sản xuất năm: 2015
<li>Hãng sản xuất: Robot Gentleman
<li>Cấu hình: CPU: Intel Core 2 Duo 2.0+ GHz / AMD CPU, RAM: 4 GB, HDD Space: 3GB, Video: nVidia GeForce 8800 GT hoặc AMD Radeon HD2900 XT (với 512MB VRAM), Windows XP trở lên.
</ul>

<h3>Link download</h3>

<ul>
<li><a href="" rel="nofollow" target="_blank" title="60 Seconds - Sinh tồn dưới hầm tránh tận thế">Google Drive KINGDOM NVHAI</a>
<li><a href="https://icongnghe.com/60-seconds-viet-hoa/" rel="nofollow" target="_blank" title="60 Seconds - Sinh tồn dưới hầm tránh tận thế">icongnghe</a>
<li><a href="https://download.com.vn/60-seconds/download" rel="nofollow" target="_blank" title="60 Seconds - Sinh tồn dưới hầm tránh tận thế">Download.com.vn</a>
</ul>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-1.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" /></center>

<p>60 Seconds là game nhập vai quản lý với cấu hình rất nhẹ, được Việt hóa bởi <a href="https://www.facebook.com/vvmteam" rel="nofollow" target="_blank" title="60 Seconds - Sinh tồn dưới hầm tránh tận thế">V.V.M Team.</a> Bạn trong vai vợ/chồng trong một gia đình 4 thành viên. Trong 60 giây, bạn phải thu nhặt những nhu yếu phẩm quan trọng để mang xuống hầm trú ẩn. Sau đó sử dụng chúng một cách thông minh để sống sót càng lâu càng tốt qua thảm họa hạt nhân. Không chỉ có thảm họa, căn hầm của bạn sẽ xảy ra nhiều vấn đề khác như chuột gián, cháy nổ, những kẻ lạ mặt không rõ tốt xấu… Quyết định sáng suốt và một chút may mắn sẽ giúp bạn.</p>

<p>Trang chủ <a href="http://robotgentleman.com/press/" rel="nofollow" target="_blank" title="Robot Gentleman">Robot Gentleman</a></p>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-2.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" /></center>

<p>Gameplay được chia làm 2 phần: 60 giây trước thảm họa và thời gian sống dưới lòng đất.</p>

<p>Bắt đầu tiếng còi báo động có bom hạt nhân, bạn sẽ nhanh chóng đi nhặt tất cả các nhu yếu phẩm cần thiết và 3 người thân trong nhà để ném xuống hầm. Bạn chỉ có 4 ô đồ. Những món đồ nhỏ như lương thực, bộ bài, bàn cờ… chỉ chiếm 1 ô. Những món đồ trung bình như rìu, súng, vợ, con trai… chiếm 2 ô. Và những món đồ lớn như con gái, vali… chiếm 3 ô. </p>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-3.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-4.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" /></center>

<p>Tiếp đến là thời gian sống dưới lòng đất. Khoảng thời gian này được chia làm 2 phần: còn phóng xạ và hết phóng xạ.</p>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-5.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" /></center>

<p>Khoảng thời gian còn phóng xạ là khoảng 2-3 tuần. Để đảm bảo, bạn nên mang theo radio để biết khi nào thông báo phóng xạ đã tan bớt.</p>

<p>Trong thời gian còn phóng xạ, có 2 việc chính cần làm là giữ sức khỏe để đi ra ngoài tìm đồ và chống chọi với chuột gián. Thời gian này ít ai đi lại bên ngoài vì phóng xạ. Nếu bạn có mặt nạ thì mới đi. Hoặc ít nhất là có hộp thuốc để khi về bị nhiễm bệnh thì còn cứu được. Tiếp theo là chuột gián và nhện. Nhện là yếu nhất, có thể dung sách hoặc tay không đập. Gián phải dùng dụng cụ như sách, bình xịt. Chuột nguy hiểm nhất, phải dùng đến súng hay rìu.</p>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-6.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-7.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Chia khẩu phần ăn và cử ai đó ra ngoài.</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-8.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Những vấn đề cần lựa chọn cách giải quyết.</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-9.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-10.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-11.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Jimmy đã hoàn thành xuất sắc nhiệm vụ đi tìm đồ</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-12.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Tên buôn nhếch nhác với cái túi đựng con mèo.<br>
Mèo có tác dụng đuổi chuột và đôi lúc mang đồ về.</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-13.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Vali tăng thêm số lượng đồ mang về</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-14.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Khi ốm sẽ xuất hiện hộp thuốc. Bệnh có thể lây sang người khác.</p></center>

<p>Sau 3 tuần, số lượng người xuất hiện ngày càng nhiều. Lúc này sẽ có người tốt và người xấu. Hãy cố gắng liên lạc với người tốt để họ cứu bạn và bạn chiến thắng. Ngược lại, quyết định sai sẽ khiến kẻ xấu bắt bạn, chiếm hầm của bạn hay thậm chí là bị mèo xâm chiếm. Lúc này, những món đồ thu phát tín hiệu cực kỳ quan trọng. Tinh thần của các nhân vật cũng rất quan trọng. 2 đứa trẻ có thể chạy ra khỏi hầm bỏ đi nếu chúng quá bực bội vì không được ăn hay giải trí.</p>

<center><img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-15.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Sau 3 tuần, số lượng người tới cứu giúp ngày càng nhiều</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-16.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Quyết định sai làm hỏng cái radio. Quyết định đúng giúp tìm thấy khẩu súng.</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-17.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Bản đồ rất quan trọng sau này</p>

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-18.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<img src="/upload/images/game/60-seconds-sinh-ton-duoi-ham-tranh-tan-the-19.jpg" width="100%" alt="60 Seconds - Sinh tồn dưới hầm tránh tận thế" />

<p>Bạn bị xua đuổi bởi mèo. Mèo đã xâm chiếm thế giới.</p></center>


















<p>Những món đồ bị đánh giá phế nhất game:</p>

<ul>
<li>Con gái: trong 60 giây đầu, con gái chiếm 3 ô đồ, nhanh đói và nuôi tốn kém.
<li>Bàn cờ: gần như chẳng thấy đồ vật này phát huy tác dụng.
<li>Bộ bài: ít khi thấy khả năng đánh dấu cho người bên ngoài phát huy tác dụng.
</ul>

<p>Mọi người có thể xem live stream của Trực Tiếp Game phá đảo tựa game này.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/5uiFQpaGTcc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/17ZoYA1wujE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực Tiếp Game phá đảo 60 Seconds</p></center>

<p></p>
',

            'date_post'   => '2016-09-06',
            'thumbnail_post'    => '60-seconds-sinh-ton-duoi-ham-tranh-tan-the-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);





        // ----------------------------------- Bài viết cần xem thời gian ---------------------------------

        posts::create([
            'name_vi_post'    => 'EVE: Valkyrie ra mắt trailer gameplay trên PS4 VR',
            'url_post'        => 'EVE-Valkyrie-ra-mat-trailer-gameplay-tren-ps4-vr',
            'present_vi_post' => 'Hãy cùng trải nghiệm game thực tế ảo để cùng tham gia vào không chiến ngoài vũ trụ với EVE: Valkyrie.',
            'content_vi_post' => '<p>EVE: Valkyrie là một trò chơi bắn súng trong vũ trụ. Người chơi sẽ sử dụng kính thực tế ảo để có cảm giác như đang ở trong một cuộc không chiến thực sự. Eve: Valkyrie sẽ được phát hành trên Microsoft Windows và PlayStation 4 VR. Trong thời gian phát triển, trò chơi được gọi là EVE-VR.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/AZNff-of63U" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe></center>

<p>Nhà sản xuất EVE: Valkyrie, CCP Games đã tiết lộ: từ 3/2016, họ đã tinh chỉnh và cập nhật hệ thống chiến đấu để chúng trở nên trực quan, thoải mái và dễ chịu hơn. Họ đã học được rất nhiều về những gì nên và không nên làm trong VR. Khả năng cân bằng, điều khiển tàu nhận được nhiều sự trợ giúp tích cực từ cộng đồng người chơi.</p>

<center><img src="/upload/images/game/EVE-Valkyrie-ra-mat-trailer-gameplay-tren-ps4-vr-1.jpg" width="70%" alt="EVE: Valkyrie ra mắt trailer gameplay trên PS4 VR" /></center>

<p><b>Chiến đấu nhiều người chơi</b></p>

<p>Chiến đấu nhiều người chơi là trải nghiệm chính của Valkyrie. Tại đây, bạn sẽ kiếm được điểm kinh nghiệm (XP), xếp hạng phi công và mở khóa nhiều tàu, nâng cấp rộng hơn. Bạn có thể bay một mình hoặc chơi với đội hình tối đa 5 người. Bạn cũng có thể chơi ở chế độ co-op và đối mặt với các phi công AI phù hợp để bổ sung kỹ năng của bạn.</p>

<p>Có ba lớp tàu chính trong Valkyrie: Fighter (tấn công), Heavy (đỡ đòn) và Support (hồi máu). Mỗi lớp có tiến trình riêng và lớp kinh nghiệm cụ thể. Khi bạn kiếm được XP trong một lớp cụ thể, bạn sẽ mở khóa các tàu mới và nâng cấp công thủ.</p>

<p>Trò chơi sẽ được phát hành vào ngày 13/10/2016.</p>

<center><img src="/upload/images/game/EVE-Valkyrie-ra-mat-trailer-gameplay-tren-ps4-vr-2.jpg" width="70%" alt="EVE: Valkyrie ra mắt trailer gameplay trên PS4 VR" />
<br><br>
<img src="/upload/images/game/EVE-Valkyrie-ra-mat-trailer-gameplay-tren-ps4-vr-3.jpg" width="70%" alt="EVE: Valkyrie ra mắt trailer gameplay trên PS4 VR" />
<br><br>
<img src="/upload/images/game/EVE-Valkyrie-ra-mat-trailer-gameplay-tren-ps4-vr-4.jpg" width="70%" alt="EVE: Valkyrie ra mắt trailer gameplay trên PS4 VR" />
<br><br>
<iframe width="560" height="315" src="https://www.youtube.com/embed/AdfFnTt2UT0" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>

<p>Kênh Youtube EVE Online</p></center>

<p>Trang chủ <a href="https://www.evevalkyrie.com/">EVE: VALKYRIE</a></p>',

            'date_post'   => '2016-10-07',
            'thumbnail_post'    => 'Eve-Valkyrie-trailer-gameplay-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Trailer game người lớn thực tế ảo Kanojo',
            'url_post'        => 'Trailer-game-nguoi-lon-thuc-te-ao-Kanojo',
            'present_vi_post' => 'Nhà phát triển game Illusion giới thiệu game thực tế ảo Kanojo dành cho lứa tuổi 18+',
            'content_vi_post' => '<p>Nhà phát triển game Illusion đã mở trang web tiếng Anh vào ngày 13/10/2016 để tiết lộ trò chơi người lớn VR Kanojo sắp tới. Illusion mô tả trò chơi như một "kinh nghiệm thực tế với bạn gái ảo".</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/e1P4OUw5D7M" frameborder="0" allowfullscreen></iframe>

<p>Trailer VR Kanojo</p></center>

<p>Đoạn video giới thiệu nữ sinh trung học Yuhi Sakura tương tác với người chơi. Người chơi có thể trả lời câu hỏi bằng cách gật đầu hay lắc đầu hoặc chọn câu trả lời như các game Visual Novel trước đây.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/1ujtdDdLd3E" frameborder="0" allowfullscreen></iframe>

<p>Bài hát của game</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/miVNsupbnaY" frameborder="0" allowfullscreen></iframe><br><br>

<iframe width="560" height="315" src="https://www.youtube.com/embed/U-fXGRtLHaI" frameborder="0" allowfullscreen></iframe><br><br>

<iframe width="560" height="315" src="https://www.youtube.com/embed/6fjIp9uiD1c" frameborder="0" allowfullscreen></iframe>
</center>

<p>Game mô tả Sakura là một cô gái luôn tươi cười và vui vẻ với mọi người. Cô ấy thích đồ ngọt. Món đồ ngọt cô ấy thích nhất là Socola Bocky. Illusion sẽ phát hành game này vào tháng 1/2017 cùng với phiên bản PC. Game được lưu ý chỉ dành cho lửa tuổi 18+. </p>

<p>Nguồn tin <a href="http://www.animenewsnetwork.com/interest/2016-10-15/illusion-reveals-vr-kanojo-adult-vr-game/.107581" target="_blank">Anime News Network </a></p>',

            'date_post'   => '2016-10-14',
            'thumbnail_post'    => 'Trailer-game-nguoi-lon-thuc-te-ao-Kanojo-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Pokemon GO tổ chức sự kiện trong game đầu tiên mừng Halloween',
            'url_post'        => 'Pokemon-GO-to-chuc-su-kien-trong-game-dau-tien-mung-Halloween',
            'present_vi_post' => 'Lần đầu tiên Pokemon GO có sự kiện trong game để các game thủ tham gia bắt Pokemon',
            'content_vi_post' => '<p>Sau gần 3 tháng ra mắt trên thế giới, ở Việt Nam là từ ngày 6/82016, Pokemon GO đã gây cơn sốt lớn trên khắp thế giới. Giờ dù đã hạ nhiệt nhưng những người yêu thích Pokemon thực sự vẫn đang thưởng thức trò chơi này. Vào ngày 23/10/2016, nhà phát hành Nintedo đã ra mắt trailer sự kiện trong game đầu tiên của Pokemon GO. Đó là sự kiện dành cho dịp lễ Halloween, diễn ra từ 26/10/2016 đến 1/11/2016.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/An2Dq6FcMjU" frameborder="0" allowfullscreen></iframe>

<p>Trailer sự kiện Halloween của Pokemon GO</p></center>

<p>Theo như trên phần mô tả của video, người chơi sẽ nhận được gấp đôi số kẹo mỗi khi thu phục, nở trứng và chuyển đổi Pokemon. Ngoài ra, một số Pokemon sẽ được tăng tỷ lệ có thể tìm được chúng. Những Pokemon đó là: Drowzee, Gastly, Gengar, Golbat, Haunter, Hypno và Zubat.</p>

<p>Nguồn tin <a href="http://www.animenewsnetwork.com/news/2016-10-24/pokemon-go-celebrates-halloween-with-1st-in-game-event/.108032">Anime News Network </a></p>',

            'date_post'   => '2016-10-24',
            'thumbnail_post'    => 'Pokemon-GO-to-chuc-su-kien-trong-game-dau-tien-mung-Halloween-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Gatebox - bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số',
            'url_post'        => 'Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so',
            'present_vi_post' => 'Gatebox, một bước tiến công nghệ đang đe dọa đến thảm họa dân số cả thế giới trong tương lai.',
            'content_vi_post' => '<p>Gatebox, trailer về chiếc hộp dành cho những chàng trai độc thân tại Nhật đang trở thành cơn sốt về công nghệ và là mối lo về thảm họa dân số sắp khiến thanh niên nước Nhật và cả thế giới phải gánh chịu trong giữa và cuối thế kỷ 21. <a href="http://gatebox.ai/">Trang chủ Gatebox.</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/nkcKaNqfykg" frameborder="0" allowfullscreen></iframe><br>

Trailer Gatebox
</center>

<p>Sản phẩm công nghệ mới mang tên Gatebox vừa được hãng Vinclu của Nhật Bản ra mắt, nó mang đến một nhân vật ảo làm bạn với người dùng. Azuma Hikari sẽ là nhân vật đầu tiên được đưa vào trong chiếc Gatebox. Theo như trailer, Azuma Hikari là nhân vật 3D có khả năng báo thức, dự báo thời tiết, thậm chí là nhắn tin hỏi thăm và bật điện trong nhà. Chắc chắn trong tương lai, người dùng sẽ có thể chọn và mua các nhân vật đúng ý mình từ các bộ Anime, Manga. Giá sản phẩm này là 2600USD.</p>

<center><img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-1.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-2.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />
</center>

<h3>Bước tiến công nghệ</h3>

<p>Phải công nhận công nghệ Nhật Bản phát triển thuộc hàng nhanh nhất thế giới. Công nghệ 3D mới ngày nào còn xuất hiện trong phim Iron man với khả năng tự xử lý những yêu cầu của người dùng thì nay đã xuất hiện và làm những yêu cầu cơ bản như báo thức, dự báo thời tiết, thậm chí là bật điện trong nhà. Không biết đến giữa thế kỷ 21, nó còn có thể làm được gì nữa.</p>

<center><img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-3.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-4.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-5.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />
</center>

<p>Với công nghệ này, những người đàn ông sẽ có không chỉ một mà là nhiều cô gái trẻ mãi không già, tính cách như một người vợ hoàn hảo và đặc biệt là không bao giờ phản bội, bỏ bạn theo chàng trai khác. Vậy bạn có cần bạn gái nữa không?</p>

<h3>Đàn ông vùng lên</h3>

<p>Nếu như xoay ngược thời gian, về thời Trung Quốc với chính sách một con, chúng ta hay nghe về tình trạng chênh lệch giới tính nghiêm trọng. Hậu quả của nó mang lại là đàn ông không thể lấy vợ vì các cô gái thời nam nữ bình đẳng, chênh lệch giới tính này quá vật chất. Đàn ông bây giờ luôn than phiền rằng phụ nữ chỉ thích những đại gia có tiền, có nhà, có xe. Thời buổi nam nữ bình đẳng, ly dị quá dễ dàng, không cần hòa giải như trước khiến đàn ông càng lúc càng thất vọng về phụ nữ.</p>

<p>Những câu chuyện trong vòng gần 20 đầu thế kỷ 21 này đã cho chúng ta thấy một thế hệ những cô gái thực dụng. Nào là “So sánh trai Việt trai Tây”, nào là “Khóc sau xe ô tô hay cười sau xe đạp”, “Gái đẹp và đại gia”, “Tình phí”, “Đi ăn ai trả tiền?”, “Chán chồng, thích làm bà mẹ đơn thân”, “Thoải mái tình dục”…  đã khiến rất nhiều đàn ông cảm thấy thất vọng, chán nản với phụ nữ thời nay không còn biết những thứ đơn giản nhất như nữ công gia chánh, chỉ còn biết tiền để mong cuộc sống của mình là hoàng hậu trong lâu đài đẹp đẽ hoặc một cuộc sống không phụ thuộc vào đàn ông vì lý do đàn ông lấy về sẽ ngoại tình, bồ bịch.</p>

<center><img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-6.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<p>Bà mẹ đơn thân là cách sống của nhiều phụ nữ thời nay</p></center>

<p>Và giờ đây, khi các nhân vật nữ trong anime, game, manga Nhật Bản đang dần thay thế các cô gái ngoài đời thực với đầy đủ ngoại hình và tính cách của một người vợ hoàn hảo, những người đàn ông đã tuyên bố phụ nữ đời thực chả là gì so với gái ảo. Dù những lý lẽ của các cô gái thực đưa ra là “Nó có sinh con được không?”, “Xài một thời gian là chán” thì cũng không thể giúp cải thiện hình ảnh các cô gái đã bị xấu xí suốt một thế hệ được.</p>

<center><img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-7.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<p>Những lý do con gái đưa ra cũng không cải thiện được hình ảnh đã bị xấu xí.</p>

<img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-8.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" />

<p>Cách đàn ông vùng lên</p></center>

<h3>Thảm họa dân số</h3>

<p>Một nghiên cứu mới công bố của Quốc hội Hàn Quốc cho thấy người nước này sẽ “tuyệt chủng” trong năm 2750 vì tỷ lệ sinh liên tục sụt giảm. Trung Quốc đang phải chịu hậu quả từ chính sách một con. Nhật Bản nổi tiếng với những con NEET, những thanh niên chán sex. Nghiên cứu của Viện Quốc gia về Dân số và An sinh xã hội Nhật Bản cho thấy: “Gần như 70% đàn ông và 60% phụ nữ chưa lập gia đình, họ cũng không ở trong bất kỳ mối quan hệ nào”.</p>

<p>Làm việc quá nhiều là nguyên nhân chính cho tình trạng này. Với giờ làm thuộc hàng cao nhất thế giới, Nhật Bản là nước có số người chết vì làm việc quá sức cũng thuộc hàng cao nhất thế giới. Tự tử, đột quỵ vì làm việc đã trở thành điều bình thường khi cạnh tranh công việc mỗi lúc một gay gắt. Người Nhật gọi là hiện tượng Karoshi, chết vì làm việc quá sức.</p>

<center><img src="/upload/images/game/Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-so-9.jpg" width="70%" alt="Gatebox bước tiến công nghệ, đàn ông vùng lên và thảm họa dân số" /></center>

<p>Vì vậy, Gatebox thực sự là điểm báo cho một mối hiểm họa về dân số và sinh sản trong tương lai. Các nước phát triển sẽ chịu ảnh hưởng đầu tiên. Và ngăn chặn điều này là không thể khi công nghệ ngày một phát triển và đang ảnh hưởng trực tiếp đến lối sống của nhiều người. Từ thế hệ những người ngồi lỳ quán net cho đến thế hệ cúi đầu nhìn điện thoại. Công nghệ đang đe dọa đến dân số của cả thế giới. </p>',

            'date_post'         => '2016-12-27',
            'thumbnail_post'    => 'Gatebox-buoc-tien-cong-nghe-dan-ong-vung-len-va-tham-hoa-dan-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Số phận hẩm hiu của game bom tấn ELOA',
            'url_post'        => 'so-phan-ham-hiu-cua-game-bom-tan-ELOA',
            'present_vi_post' => 'Game bom tấn với đồ họa 3D phong cách anime đẹp mắt đã bị khai tử lần thứ 2 vào ngày 11/8 vừa qua.',
            'content_vi_post' => '<p>Trang chủ <a href="http://eloa.webzen.com/en">ELOA</a></p>

<p>ELOA - Elite Lord of Alliance là tựa game MMORPG của hãng Webzen của Hàn Quốc. Trò chơi có 5 lớp nhân vật thuộc 4 đại chủng tộc với những bộ kỹ năng khác nhau và đi khám phá thế giới. KINGDOM NVHAI đã từng có bài viết giới thiệu sơ lược về game bom tấn này. Tuy nhiên, trò chơi đã không đáp ứng kỳ vọng như những gì đã đầu tư và bị chính cha đẻ Webzen khai tử đến 2 lần chỉ trong chưa đầy 2 năm.</p>

<p><a href="/post/ELOA-Game-3D-Anime-moi">ELOA - Game 3D Anime mới</a></p>

<p><a href="/post/Gioi-thieu-so-luoc-ve-ELOA">Giới thiệu sơ lược về ELOA</a></p>

<center><img src="/upload/images/game/ELOA-Elite-Lord-of-Alliance-4.jpg" width="100%" alt="ELOA - Game 3D Anime mới" /></center>

<p>ELOA đã từng có giai đoạn cực thịnh khi đánh bật rất nhiều tên tuổi ra khỏi các bảng xếp hạng. Tuy nhiên, chỉ sau 1 năm, trò chơi này đã bị khai tử vào tháng 10/2016. </p>

<center><img src="/upload/images/game/so-phan-ham-hiu-cua-game-bom-tan-ELOA-1.jpg" width="100%" alt="ELOA - Game 3D Anime mới" />

<p>Thông báo đóng cửa của Webzen.</p></center>

<p>Sau vài tuần, Game & Game quyết định mua lại bản quyền sản phẩm và phát hành tại khu vực Bắc Mỹ vào tháng 11/2016. Thế nhưng cũng chỉ chưa đầy 1 năm sau, game đã tiếp tục phải tuyên bố đóng cửa. Có lẽ do người chơi vẫn bị ảnh hưởng từ các tựa game nổi tiếng trước đó như Aura Kingdom, game phong cách anime nổi tiếng nhất hiện tại. Lần này có lẽ sẽ là lần cuối vì khó ai dám khởi động lại một game thất bại đến 2 lần như vậy.</p>
',

            'date_post'         => '2017-08-12',
            'thumbnail_post'    => 'so-phan-ham-hiu-cua-game-bom-tan-ELOA-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,
            'update'            => 0,
        ]);


        posts::create([
            'name_vi_post'    => 'Drama Optimus tố cáo Zeros - kịch bản của Garena?',
            'url_post'        => 'Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena',
            'present_vi_post' => 'Thuyết âm mưu không phải là không có lý từ cộng đồng mạng',
            'content_vi_post' => '<p>Đầu năm 2019, ngay sau kỳ nghỉ Tết Nguyên Đán, cộng đồng game Liên Minh Huyền Thoại đã nhận một drama cực kỳ chất lượng: Optimus tố cáo Zeros cày thuê.</p>

            <h3>Sự việc</h3>

            <p>Zeros là em trai Minas, đang thi đấu cho Phong Vũ Buffalo ở vị trí Đường Trên. Vào một buổi livestream của Minas, Minas đã cho Zeros mượn tài khoản đánh xếp hạng. Sự việc này vi phạm luật của Riot là game thủ chuyên nghiệp không được phép cày thuê. Và Optimus đã tố cáo Zeros cày thuê cho Minas.</p>

<p>Bài tố cáo trên Facebook của Optimus</p>

<center><img src="/upload/images/game/Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-1.jpg" width="70%" alt="Drama Optimus tố cáo Zeros - kịch bản của Garena"/>

<iframe width="560" height="315" src="https://www.youtube.com/embed/c7kokEWEJTY" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Game 1</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/2wz-ktc7X4g" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Game 2</p></center>

<p>VCS đã nhận được thông tin và quyết định ra án phạt cho Zeros như sau:</p>

<center><img src="/upload/images/game/Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-2.jpg" width="70%" alt="Drama Optimus tố cáo Zeros - kịch bản của Garena"/></center>

<h3>Dư luận</h3>

<p>Vụ việc trên đã khiến dư luận chia làm 2 phe: phe bên vực Zeros và Minas và phe ủng hộ Optimus làm đúng luật.</p>

<p>Về lý, Optimus đã làm đúng luật. Zeros phạm luật rõ ràng, có bằng chứng không thể chối cãi. Ai cũng phải công nhận Zeros làm sai dù có ủng hộ anh em họ đến đâu.<br>
Về tình cảm, Optimus làm vậy đã khiến họ trở thành kẻ thù của nhau. Từng là đồng đội với Minas, từng chinh chiến cùng nhau tại các giải trong và ngoài nước. Vậy mà giờ đây, Optimus lại có hành động phũ phàng đến vậy.</p>

<p>Nhưng một số thuyết âm mưu nói rằng: phải chăng đây là kịch bản của Garena để trận đấu giữa họ kịch tính hơn? Phải chăng có bên thứ 3 sắp đặt? Thuyết âm mưu này khá hay, hợp lý và giúp 2 phe nguội bớt những lời chỉ trích. Ai là người được lợi nhất trong drama này? Chắc chắn là Garena.</p>

<h3>Garena được lợi gì từ drama?</h3>

<p><b>Tiền vé:</b> vé thi đấu trận lượt đi giữa PVB và SGD đã hết. Lượt theo dõi lên đến 216.000 người khi nhà chính của SGD nổ lần thứ 2. Và chắc chắn lượt về cũng sẽ bán hết vé.</p>

<center><img src="/upload/images/game/Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-3.jpg" width="70%" alt="Drama Optimus tố cáo Zeros - kịch bản của Garena"/></center>

<p><b>Giải đấu hấp dẫn hơn:</b> Một nghệ thuật câu view mà các chương trình truyền hình hay làm là tạo ra vai phản diện. Nếu ai đã từng xem các chương trình truyền hình thực tế như Masterchef phiên bản Mỹ, Next top model đều sẽ thấy tất cả có đặc điểm chung: đều có vai phản diện, cãi nhau nhằm tạo kịch tính.</p>

<center><img src="/upload/images/game/Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-4.jpg" width="70%" alt="Drama Optimus tố cáo Zeros - kịch bản của Garena"/>

<p>MasterChef mùa 4 có vai phản diện Krissi vào đến vòng 4 người.</p></center>

<p>Điều đó là hợp lý vì nếu một cuộc thi cứ diễn ra bình thường, thi đấu xong giành chức vô địch thì những trận đấu vòng loại chẳng có gì đáng xem. Khán giả chỉ chờ đến trận tứ kết, bán kết và chung kết mà xem. Vậy thì ban tổ chức lấy tiền đâu mà chi trả cho các khoản phí các trận vòng loại?</p>

<p>Đặc điểm của bóng đá, E-sport, những môn thể thao nhận được nhiều sự quan tâm luôn có drama. Nào là Messi vs Ronaldo, nào là Việt Nam vs Thái Lan, giờ đến Optimus vs Zeros. Những cặp đối đầu kẻ thù của nhau như vậy sẽ khiến giải đấu hay trận đấu giữa họ trở nên hấp dẫn hơn rất nhiều. Và nguồn thu từ vé, quảng cáo sẽ tăng chóng mặt.</p>

<p><b>Lấy lại tiền từ LCK:</b> một tin không vui là VETV sẽ không bình luận giải LMHT của Hàn Quốc là LCK nữa vì lượt xem quá ít nên không mua được bản quyền. Lý do là vì LCK đánh quá nhàm chán, chỉ farm và kiểm soát bản đồ. Cuối trận giao tranh 1 - 2 pha là xong.</p>

<p>Đặc biệt là khi các ngôi sao như Faker, Khan đều đã dần hết thời, thua các đội tân binh khiến khán giả giảm sút. Ngay cả trang báo của Garena là lienminh360 cũng không còn đăng nhiều tin tức về SKT hay LCK như trước nữa.</p>

<center><img src="/upload/images/game/Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-5.jpg" width="70%" alt="Drama Optimus tố cáo Zeros - kịch bản của Garena"/></center>

<p><b>Tương lai của VCS:</b> những drama này sẽ còn ảnh hưởng qua nhiều mùa giải nữa. Mỗi trận đấu có Optimus và Zeros, Noway với đội tuyển cũ là GAM, Optimus với đội tuyển cũ là GAM đều sẽ là tâm điểm của VCS.</p>

<p>Nhìn chung, thuyết âm mưu Garena là chủ mưu của drama Optimus tố cáo Zeros không phải là không có lý. Hãy để mọi chuyện ở mức có thể kiểm soát được, tránh những chuyện chỉ trích nhau ngoài đời. Chỉ cần drama trở thành câu chuyện thú vị trên sàn đấu để khán giả và VCS đều có lợi là đủ.</p>
',

            'date_post'         => '2019-01-17',
            'thumbnail_post'    => 'Drama-Optimus-to-cao-Zeros-kich-ban-cua-Garena-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Ultra Instict Shaggy xuất hiện trong Mortal Kombat',
            'url_post'        => 'ultra-instict-shaggy-xuat-hien-trong-mortal-kombat',
            'present_vi_post' => 'Một tin gây chấn động làng game và cartoon khi Shaggy được tung ảnh phát ra hào quang màu xanh.',
            'content_vi_post' => '<p>Có phải chúng ta đang sống trong thời đại mà người hâm mộ quyết định số phận của một tác phẩm? Ít nhất đó là những gì đang diễn ra trong ngành công nghiệp trò chơi điện tử. Trong vài giờ qua, một trong những chiến dịch điên rồ nhất những năm gần đây đã bắt đầu.</p>

<p>Một sự kiện chưa từng có khi 90.000 người đã ký đơn online mong muốn Shaggy, nhân vật chính trong phim cartoon “Scooby-Doo”, tham gia "Mortal Kombat 11" mới.</p>

<p>Thông thường, những yêu cầu như thế này sẽ dẫn đến áp lực cho nhà phát triển. Họ sẽ phải làm sao để pha trộn mà vẫn hài hòa, không để xảy ra tình trạng “nồi thập cẩm”. Ed Boon, nhà sáng tạo ra "Mortal Kombat" đã đăng trên Twitter rằng: “Tôi sẽ trộn shit của các bạn vào game chiến đấu”, kèm theo một bức vẽ Shaggy trông như đang trong trạng thái Ultra Instict của Son Goku trong Dragon Ball</p>

<p>Nguồn: <a href="http://www.cooperativa.cl/noticias/tecnologia/industria/videojuegos/creador-de-mortal-kombat-da-luz-verde-a-la-llegada-de-shaggy-de/2019-01-28/202551.html" rel="nofollow" target="_blank"> Cooperativa</a></p>

<center>
<blockquote class="twitter-tweet" data-lang="en"><p lang="en" dir="ltr">Hi? Lo? Mid? Grab? I will mix your shit up in fighting games! <a href="https://t.co/nzCq4iskj7">pic.twitter.com/nzCq4iskj7</a></p>&mdash; Ed Boon (@noobde) <a href="https://twitter.com/noobde/status/1089991951166906369?ref_src=twsrc%5Etfw">January 28, 2019</a></blockquote>
<script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<img src="/upload/images/game/ultra-instict-shaggy-xuat-hien-trong-mortal-kombat-goku.jpg" width="70%" alt="Ultra Instict Shaggy xuất hiện trong Mortal Kombat" />

<p>Từ màu sắc đến thần thái, <br>
từ khung cảnh xung quanh đến dáng đứng không khác gì Ultra Instict Son Goku</p></center>

<p>Sáng kiến này được nảy ra khi anh xem một đoạn video fan made. Nội dung lấy từ cartoon khi Shaggy đánh bại một nhóm người đi xe motor được lồng nhạc nền Ultra Instinct. Phải chăng meme này đã đi quá xa, xa đến mức người làm ra nó cũng không ngờ được ý tưởng của mình lại vĩ diệu đến thế?</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/7h9V0nDT9XU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

<p>Mặt khác, lấy các nhân vật từ nhiều nguồn khác nhau không phải chuyện mới đối với "Mortal Kombat." Game đã lấy nhân vật Kratos từ "God of War" và một loạt các nhân vật phản diện trong nhiều phim kinh điển khác.</p>

<p>Chúng ta có được thấy Shaggy đánh bại những chiến binh hung dữ như Sub-Zero hay Raiden không? Hãy đợi đến ngày 23/4/2020 khi “Mortal Kombat 11” được ra mắt.</p>

<p>Nguồn: <a href="https://www.dreamteamfc.com/c/gaming/438968/people-petitioning-get-shaggy-into-mortal-kombat-11-ed-boon-release-rumour/" rel="nofollow" target="_blank">Dreamteamfc</a></p>
',

            'date_post'         => '2019-01-29',
            'thumbnail_post'    => 'ultra-instict-shaggy-xuat-hien-trong-mortal-kombat-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam',
            'url_post'        => 'msi-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam',
            'present_vi_post' => 'Ngày càng nhiều sự kiện tầm cỡ quốc tế được tổ chức tại Việt Nam.',
            'content_vi_post' => '<p>MSI 2019 - Giải đấu Liên Minh Huyền Thoại giữa mùa được tổ chức vào tháng 5. Vòng khởi động sẽ được tổ chức tại Việt Nam. Vòng chung kết sẽ được tổ chức tại Đài Bắc. Đây là một tin rất vui đối với nền E-sport, Liên Minh Huyền Thoại nói riêng và cả nước Việt Nam nói chung.</p>

<center><img src="/upload/images/game/MSI-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam-1.jpg" width="70%" alt="MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam" />

<p>Bài đăng của <a href="https://www.facebook.com/GGstadiumvn/posts/1245841008903157?__tn__=K-R">GG Stadium</a></p></center>

<p>Trong những năm gần đây, những sự kiện lớn của thế giới thường được tổ chức tại Việt Nam.</p>

<p>Tháng 5/2016: Obama sang thăm Việt Nam.<br>
Năm 2017: bộ phim KONG được quay tại Quảng Bình, Việt Nam. APEC Việt Nam 2017.<br>
Tháng 3/2019: tổng thống Donald Trump và chủ tịch Kim Jong un sang Việt Nam.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/mtZUdPtZorU?start=340" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>5:40 BLV Mạnh An nhận xét về tình hình an ninh tại Việt Nam so với các nước khác</p>

<img src="/upload/images/game/MSI-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam-2.jpg" width="70%" alt="MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam" />

<p>Gần đây nhất là hội nghị thượng đỉnh Mỹ - Triều được tổ chức tại Việt Nam</p></center>

<p>Liên tiếp các sự kiện lớn được tổ chức tại Việt Nam cho thấy tầm quan trọng, uy tín và an ninh của Việt Nam trên trường quốc tế. Đặc biệt là khi thế giới chia rẽ, càng lúc càng bất ổn. 15/3/2019 vừa qua, 1 vụ <a href="https://lostbird.vn/kham-pha-cung-lac/tin-tuc/vua-livestream-vua-thet-hay-subscribe-cho-pewdiepie-khi-xa-sung-giet-40-nguoi-602347.html" rel="nofollow">xả súng tại New Zealand</a> cướp đi sinh mạng của 40 người. Châu Âu thì lục đục với Anh vì Brexit. Trung Quốc thì chiến tranh thương mại với Mỹ.</p>

<center><img src="/upload/images/game/MSI-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam-3.jpg" width="70%" alt="MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam" /></center>

<p>Như lời BLV Mạnh An chia sẻ, Mỹ cần một nơi an ninh tốt, an toàn. Vậy nên Riot chọn Trung Tâm Hội Nghị Quốc Gia Hà Nội sẽ là nơi diễn ra các trận vòng bảng của 6 đội là điều hợp lý. Nhưng vì Việt Nam chưa đủ điều kiện về cơ sở vật chất cũng như đảm bảo máy móc để tổ chức các trận của 4 đội mạnh nhất trở đi nên Đài Bắc sẽ thay thế. Điều này cũng hợp lý khi trong trận lượt về của PVB và SGD, lỗi âm thanh đã khiến trận đấu bị hoãn hơn 1 tiếng đồng hồ.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/-FcA6VAIdI4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trong lúc chờ xử lý lỗi âm thanh, 2 BLV chém gió với nhau</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/vaDfYj71SSI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Sau khi cấm chọn xong, khan giả vẫn tiếp tục phải chờ.</p></center>

<p>Dù vẫn còn nhiều thiếu sót nhưng Việt Nam đang dần trở thành nơi đáng quan tâm của thế giới nếu họ cần một điểm đến an toàn. Cộng đồng Liên Minh Huyền Thoại cùng hy vọng một ngày nào đó, Chung Kết Thế Giới sẽ được tổ chức tại Việt Nam. Và các thần tượng như Faker, Doublelift sẽ biết mùi rank Việt khắc nghiệt như những gì Cowsep đã trải qua.</p>

<img src="/upload/images/game/MSI-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam-4.jpg" width="100%" alt="MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam" />
',

            'date_post'         => '2019-03-25',
            'thumbnail_post'    => 'msi-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Trailer 4K Project EVE đẹp mê hồn của Shiftup',
            'url_post'        => 'trailer-4K-project-eve-shiftup',
            'present_vi_post' => 'Cô gái với thân hình nóng bỏng, khuôn mặt búp bê bước xuống Trái Đất hoang tàn đổ nát, mang theo nhiệm vụ giành lại Trái Đất khỏi các sinh vật ngoài hành tinh',
            'content_vi_post' => '<p></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/vLsSuuSAIys" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer đẹp mê hồn của Project EVE</p></center>

<p>Trang chủ <a href="http://shiftup.co.kr/EVE/" rel="nofollow" target="_blank" title="Shiftup Project EVE">Project EVE của Shiftup</a></p>
<p>Các game khác của <a href="http://shiftup.co.kr/products/#%20" rel="nofollow" target="_blank" title="Shiftup Project EVE">Shiftup</a></p>

<p>Giới thiệu ngắn của nhân vật nữ trong trailer</p>

<blockquote>
<p>70 năm kể từ lần lặn đầu tiên.<br>
Cuối cùng chúng tôi đã trở thành những người sống sót đầu tiên.<br>
Bây giờ, đã đến lúc đưa Trái Đất trở lại.</p>
</blockquote>

<center><img src="/upload/images/game/trailer-4K-project-eve-shiftup-1.jpg" width="100%" alt="Trailer 4K Project EVE đẹp mê hồn của Shiftup" />

<p>Nhân vật nữ với khuôn mặt búp bê thường thấy trong game Trung Quốc <br>(ảnh chụp ở độ phân giải 4K)</p></center>
',

            'date_post'         => '2019-04-04',
            'thumbnail_post'    => 'trailer-4K-project-eve-shiftup-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'NIKKE: The Goddess of Victory - trailer nóng bỏng khác của Shift Up',
            'url_post'        => 'NIKKE-The-Goddess-of-Victory-trailer-nong-bong-khac-cua-shift-up',
            'present_vi_post' => 'Một bình luận trên Youtube đã miêu tả ngắn gọn về trailer rằng: "Nikke : The goddess of THICC"',
            'content_vi_post' => '<p>Sau trailer đồ họa 4K chân thực và đầy sống động của game Project EVE, Shift Up tiếp tục tung ra trailer mới vào ngày 3/4/2019 dành cho tựa game di động NIKKE: The Goddess of Victory - Những nữ thần chiến thắng</p>

<p>Trang chủ của game <a href="http://shiftup.co.kr/nikke/" rel="nofollow" target="_blank" title="NIKKE: The Goddess of Victory">NIKKE: The Goddess of Victory</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/R7-bRUSwgQw" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer NIKKE: The Goddess of Victory</p></center>

<p>Trailer nói về cảnh hồi tưởng lại của Lapi, một nữ chiến binh đang trong thang máy trở về căn cứ dưới lòng đất. Cô hồi tưởng lại trận chiến chống lại đoàn quân người máy cùng đồng đội Neon. Và khi trùm cuối xuất hiện, nó đốt cháy mọi thứ. Tất cả ký ức của Lapi chỉ có ở ngoài chiến trường. Có vẻ cô là dạng chiến binh được cường hóa.</p>

<center><img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-trailer-nong-bong-khac-cua-shift-up-1.jpg" width="100%" alt="NIKKE The Goddess of Victory" />

<p>Nhân vật Lapi chiến đấu với đoàn quân người máy.</p>

<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-trailer-nong-bong-khac-cua-shift-up-2.jpg" width="100%" alt="NIKKE The Goddess of Victory" />

<p>Căn cứ dưới lòng đất</p></center>

<p>Trò chơi theo dạng thay đổi nhân vật. Mỗi nhân vật có các sở trường khác nhau để sử dụng tùy vào loại quân của đối phương. Lapi chuyên bắn súng máy (Rifle) trong khi Neon có thể phóng tên lửa (Laucher) vào số đông đối thủ. Ngoài 2 nhân vật người chơi điều khiển, còn có 2 nhân vật phụ khác là Idda (Rifle) và Vesti (Laucher) đứng ngoài hỗ trợ. Người chơi chỉ cần chọn mục tiêu, 2 nhân vật phụ sẽ bắn tự động. </p>

<center><img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-trailer-nong-bong-khac-cua-shift-up-3.jpg" width="100%" alt="NIKKE The Goddess of Victory" />

<p>Với người viết, đây là wallpaper đẹp nhất.<br>
Download bản đẹp tại trang chủ Shift Up.</p></center>

<p>Trailer đã ngay lập tức nhận được 1 bình luận rất súc tích, miêu tả ngắn gọn: Nikke: The goddess of THICC. Cảnh vòng 3 của Lapi rung lên khi bắn súng thật khó cưỡng. Tấm hình wallpaper rất quyến rũ nhưng vẫn miêu tả chân thực sự khốc liệt của chiến trường. Cách chơi trong trailer cũng có vẻ không quá khó. Thật sự game đã gây ấn tượng mạnh về mọi mặt: cốt truyện, đồ họa, cách chơi, vẻ đẹp quyến rũ.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Y3TK79p5SDA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<video width="100%" controls preload controlsList="nodownload">
<source src="http://shiftup.co.kr/wp-content/uploads/2019/04/nikke_bg_short_1080.mp4?id=6067" type="video/mp4">
</video>

<p><a href="http://shiftup.co.kr/wp-content/uploads/2019/04/nikke_bg_short_1080.mp4?id=6067" rel="nofollow" target="_blank">Video background của trang web.</a></p></center>

<p>Cảnh tóc Lapi tung bay trong gió vô cùng. Game được lập trình bằng Unity, có thể tải trên Google Play cho Android hoặc App Store cho iOS. Hy vọng trong tương lai, những nữ thần chiến thắng sẽ mang chiến thắng về cho game, giúp game phát triển và có thêm nhiều nhân vật, chiến trường mới hơn.</p>

<center><img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-1.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>
<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-2.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>
<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-3.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>
<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-4.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>
<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-5.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>
<img src="/upload/images/game/NIKKE-The-Goddess-of-Victory-figure-1-1-6.jpg" width="70%" alt="NIKKE The Goddess of Victory" /><br><br>

<p>Figure Rapi tỷ lệ 1:1</p></center>
',

            'date_post'         => '2019-04-06',
            'thumbnail_post'    => 'NIKKE-The-Goddess-of-Victory-trailer-nong-bong-khac-cua-shift-up-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream MSI 2019 ngày đầu tiên',
            'url_post'        => 'garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019',
            'present_vi_post' => 'VETV cũng bị trục trặc khi đang truyền hình trực tiếp MSI 2019 ngày 1/5/2019',
            'content_vi_post' => '<p>Sự kiện MSI 2019 tổ chức tại Việt Nam và Đài Loan đang thu hút sự chú ý của cả thế giới, đặc biệt là Đài Loan và Việt Nam, 2 quốc gia đăng cai tổ chức MSI 2019. Việt Nam đã chuẩn bị rất kỹ lưỡng để chào đón sự kiện này. Tuy nhiên, 2 sự cố bất ngờ tại cả 2 quốc gia đã khiến người hâm mộ đặt câu hỏi: "Phải chăng Việt Nam đang chịu vạ lây từ Đài Loan?"</p>

<h3>VETV đột ngột ngừng phát sóng ngay giữa trận đánh</h3>

<p>Trong buổi tối 1/5/2019, khi trận đấu khởi động thứ 7 của MSI 2019 giữa Phong Vũ Buffalo và 1907 Fenerbahçe Espor diễn ra thì luồng stream trực tiếp của VETV đã đột nhiên bị dừng đột xuất vì lý do mưa bão. Khán giả phải qua các kênh phát trực tiếp của nước ngoài LOL Esport, Garena eSport... VETV cũng thông báo thêm là sẽ tiếp tục ngừng phát sóng trực tiếp đối với ngày thứ 2 của giải đấu với cùng một lý do trên.</p>

<p>Không những thế, trang web của VETV cũng đang bị sập một cách khó hiểu mà không có một thông báo hay lời giải thích nào từ phía họ.</p>

<center><img src="/upload/images/game/garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019-1.jpg" width="100%" alt="Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream MSI 2019 ngày đầu tiên" /></center>

<h3>Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream</h3>

<p>Link bài viết trên <b><a href="https://www.reddit.com/r/leagueoflegends/comments/bjf6of/garena_taiwan_got_caught_using_esport_betting/">Reddit</a></b></p>

<p>Khán giả Việt Nam đang thắc mắc thì một tin sét đánh khác: Theo video cắt lại được thì nhân viên phụ trách trình chiếu luồng trực tiếp đã đăng nhập vào một trang web cá độ eSport Bắc Kinh để tham gia đặt cược. Cộng đồng LMHT Đài Loan đã cực kì giận dữ và phản ứng gay gắt. Garena Đài Loan đã ra thông báo đuổi việc người phụ trách kênh ngay sau đó. (tên tuổi của người này bị giữ bí mật) </p>

<center><img src="/upload/images/game/garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019-2.jpg" width="70%" alt="Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream MSI 2019 ngày đầu tiên" /></center>

<center><img src="/upload/images/game/garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019-3.jpg" width="70%" alt="Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream MSI 2019 ngày đầu tiên" /></center>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/kKI7vSgeJKs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Video từ máy của streamer tại Garena Đài Loan</p></center>

<p>Nguyên văn từ Garena Đài Loan</p>

<center><img src="/upload/images/game/garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019-4.jpg" width="70%" alt="Garena Đài Loan bị phát hiện cá độ trái phép trong lúc stream MSI 2019 ngày đầu tiên" /></center>

<blockquote>
<p>"Những gì nhân viên chúng tôi đã làm là minh chứng rõ nét nhất của tiêu cực trong Esports.<br>

Sau khi điều tra chúng tôi phát hiện ra đây chỉ là hành vi cá nhân và đi ngược hoàn toàn với đạo đức cũng như nguyên tắc Thể Thao Điện Tử.<br>

Do đó chúng tôi quyết định sa thải hoàn toàn vị đạo diễn này vì lý do tiêu cực cờ bạc trong thi đấu."</p>
</blockquote>

<p>Theo luật, những trang cá độ không phải do Riot tổ chức đều phạm luật. LMHT Đài Loan vừa dính vào bê bối bán độ của Dragon Gate tại giải LMS. Vụ việc này càng làm cộng đồng LMHT Đài Loan phẫn nộ và làm xấu hình ảnh của Đài Loan trong mắt Riot.</p>

<p>Việc cờ bạc, cá độ luôn là vấn đề phải được quản lý chặt chẽ, dù ở Việt Nam hay nước ngoài. Suy cho cùng, sự cố tại Việt Nam, dù có liên quan đến Đài Loan hay không cũng là do lỗi kỹ thuật và yếu tố khách quan nên chắc chắn Riot sẽ không có động thái gì đến Việt Nam. Khán giả Việt Nam còn hy vọng sau vụ việc này, Đài Loan sẽ phải mất một suất tại CKTG 2019 cho Việt Nam.</p>
',

            'date_post'         => '2019-05-02',
            'thumbnail_post'    => 'garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nghi ngờ Riot đánh sập kênh VETV, khán giả Việt Nam dislike LOL Esport trong ngày thi đấu thứ 2',
            'url_post'        => 'viewer-vietnam-dislike-lol-esport-in-msi-day-2',
            'present_vi_post' => 'Một số khán giả nghi ngờ Riot "ghen ăn tức ở" số lượt xem với VETV dẫn đến ngắt sóng stream trực tiếp MSI 2019 nên đã dislike LOL Esport',
            'content_vi_post' => '<p>Ngày 3/5/2019 là ngày thi đấu thứ 2 của vòng khởi động MSI 2019 tổ chức tại Việt Nam. Trong ngày thứ 1, khán giả Việt Nam và Đài Loan đã dính 2 scandal cùng lúc. <a href="/post/garena-dai-loan-bi-phat-hien-ca-do-trai-phep-trong-luc-stream-msi-2019">Garena Đài Loan bị phát hiện cá độ trái phép</a> còn VETV Việt Nam đột ngột ngưng phát sóng trận đấu hấp dẫn nhất trong ngày, giữa Phong Vũ Buffalo và 1907 Fenerbahçe Espor</p>

<p>Một số khán giả Việt Nam đã nghĩ ra "Thuyết Âm Mưu", cho rằng LOL Esport hay Riot nhúng tay vào việc này. Lý do là vì vòng khởi động thường ít view, trừ fan hâm mộ của 2 đội. Vì vậy Riot đã ngắt sóng của VETV để khán giả buộc phải qua LOL Esport hay các kênh khác xem.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/klX-DmU7A78" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Video stream của LOL Esport ngày thứ 2</p></center>

<p>Chính vì "Thuyết Âm Mưu" đó, một số khán giả Việt Nam đã kêu gọi dislike kênh stream của LOL Esport khi trận đấu đầu tiên giữa Phong Vũ Buffalo và Isurus Gaming diễn ra. Số lượng dislike lên đến hơn 4500 .</p>

<center><img src="/upload/images/game/nghi-ngo-riot-danh-sap-kenh-vetv-khan-gia-viet-nam-dislike-lol-esport-trong-ngay-thi-dau-thu-2-1.jpg" width="100%" alt="Nghi ngờ Riot đánh sập kênh VETV, khán giả Việt Nam dislike LOL Esport trong ngày thi đấu thứ 2" />

<p>Một số thành phần đã kêu gọi dislike LOL Esport</p></center>

<p>Các khán giả có văn hóa khác của Việt Nam đã kêu gọi like cho LOL Esport để giữ gìn hình ảnh Việt Nam. Đây là lần đầu tiên Việt Nam được đăng cai tổ chức MSI 2019. Vì vậy, việc giữ gìn hình ảnh cực kỳ quan trọng. Nếu làm xấu mặt Việt Nam như sự cố của Garena Đài Loan, chắc chắn sẽ khó có cơ hội thứ 2. Thậm chí, khả năng Việt Nam có 2 suất vào CKTG như năm 2017 càng xa vời hơn.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/tJOniactkzk?start=2648" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>44:10, BLV Khánh Hiệp nói không có chuyện "ghen ăn tức ở" về views từ các kênh nước ngoài<br>
45:32, khuyên mọi người đừng dislike LOL nước ngoài.</p></center>

<p>Trước đó, tài khoản Facebook của Faker vừa đổi ảnh đại diện đã bị các thành phần phá hoại của Việt Nam vào bình luận tràn lan, dù Faker không dùng Facebook đã 5 năm nay. Game thủ Việt Nam xưa nay nổi tiểng thế giới với hack, crack, chửi bới trên các game nước ngoài. Giờ còn thêm cả dislike Youtube, spam Facebook. Điều này càng làm xấu hình ảnh của Việt Nam.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/aCEJrbQepAs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<img src="/upload/images/game/nghi-ngo-riot-danh-sap-kenh-vetv-khan-gia-viet-nam-dislike-lol-esport-trong-ngay-thi-dau-thu-2-2.jpg" width="100%" alt="Nghi ngờ Riot đánh sập kênh VETV, khán giả Việt Nam dislike LOL Esport trong ngày thi đấu thứ 2" />

<p>Tài khoản Facebook của Faker bị spam</p></center>

<p>Nói chung, các khán giả đều được xem miễn phí. Vì một sự cố không rõ nguyên do mà khán giả Việt Nam lại dislike kênh LOL nước ngoài, không những chẳng được gì mà còn làm xấu hình ảnh Việt Nam trong mắt bạn bè quốc tế. BLV Khánh Hiệp và rất nhiều khán giả hiểu việc này quan trọng như thế nào. Hy vọng cộng đồng Liên Minh Huyền Thoại Việt Nam sẽ chung tay giữ gìn hình ảnh đất nước để nhiều sự kiện lớn tiếp tục được tổ chức tại Việt Nam.</p>
',

            'date_post'         => '2019-05-03',
            'thumbnail_post'    => 'nghi-ngo-riot-danh-sap-kenh-vetv-khan-gia-viet-nam-dislike-lol-esport-trong-ngay-thi-dau-thu-2-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Những tướng Liên Minh Huyền Thoại hơn 2 năm chưa có được 3-5 skin.',
            'url_post'        => 'nhung-tuong-lien-minh-huyen-thoai-hon-2-nam-chua-co-duoc-3-5-skin',
            'present_vi_post' => 'Kẻ ăn không hết, người làm không ra. Tướng thì gần 10 skin. Tướng thì 3 skin không có nổi',
            'content_vi_post' => '<p>MSI 2019 đã đến. Phong Vũ Buffalo đã mang về 2 vé đến với Chung Kết Thế Giới 2019 về cho Việt Nam sau trận thắng 3-2 đầy căng thẳng với Vega đến từ nước Nga. Cũng thời điểm này, Riot đã cho ra bộ skin Học Viện Chiến Binh nhân dịp Yumi ra mắt. Đây là bộ skin mang phong cách anime rất đẹp, nhưng cũng đã gây phản ứng với cộng đồng khi một lần nữa, Ezreal và Lux có thêm trang phục. Cộng đồng bắt đầu liệt kê lại những vị tướng đã rất lâu chưa có trang phục như Volibear, Urgot, Swain...</p>

<center><img src="/upload/images/game/lux-hoc-vien-chien-binh.jpg" width="100%" alt="Lux Học Viện Chiến Binh" />

<p>Lux Học Viện Chiến Binh</p></center>

<p>Bài viết này sẽ liệt kê lại những tướng đạt <b>một trong hai</b> tiêu chí:<b> đã ra mắt cách đây 2 năm (tức là từ 5/2017 trở về trước) và số lượng trang phục hiện giờ chỉ vào khoảng 3-5 skins. (tính đến MSI 2019)</b></p>

<h3>Ivern</h3>

<p>Lần đầu ra mắt: 10/2016<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Ivern Dunkmaster</p>

<center><img src="/upload/images/game/ivern-sieu-sao-up-ro.jpg" width="100%" alt="Ivern siêu sao úp rổ" />

<p>Ivern Siêu Sao Úp Rổ</p></center>

<p>Chỉ duy nhất 1 skin Kẹo Ngọt từ khi mới ra mắt. Mãi đến 2019, Ivern mới có thêm Ivern Úp Rổ. Ivern xứng đáng giữ vị trí đầu bảng danh sách này khi bị hắt hủi cả trong trận đấu lẫn số lượng skin. Nếu không có trang phục này, Ivern có lẽ sẽ ra tướng ít skin nhất tính đến MSI 2019.</p>

<h3>Aurelion Sol</h3>

<p>Lần đầu ra mắt: 3/2016<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Mecha Aurelion Sol</p>

<center><img src="/upload/images/game/aurelion-sol-may-moc.jpg" width="100%" alt="Aurelion Sol Máy Móc" />

<p>Aurelion Sol Máy Móc</p></center>

<p>Vị tướng bị hắt hủi tiếp theo là Aurelion Sol, hơn 3 năm nay chỉ có 2 trang phục. Trang phục Aurelion Sol Máy Móc cũng là một niềm an ủi kha khá khi skin này nằm trong dòng skin Mecha khá đẹp. Giống như Ivern, nếu không có skin này được ra mắt trong năm 2018 thì Aurelion Sol là vị tướng không có trang phục mới.</p>

<h3>Illaoi</h3>

<p>Lần đầu ra mắt: 11/2015<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Resistance Illaoi</p>

<center><img src="/upload/images/game/illaoi-khang-chien.jpg" width="100%" alt="Illaoi Kháng Chiến" />

<p>Illaoi Kháng Chiến</p></center>

<p>Dù không được xuất hiện trong giải đấu, Illaoi vẫn là tướng rất mạnh trong đánh thường và đánh xếp hạng. Với khả năng cấu rỉa cũng như 1vs2 rất tốt, Illaoi một khi đã khỏe thì không thể ngăn cản. Illaoi Kháng Chiến được ra mắt khá đặc biệt. Nó là kết quả của một cuộc bình chọn 3 trang phục dành cho Illaoi. Tuy nhiên, với gần 4 năm chinh chiến, 2 trang phục là một con số quá nghèo nàn.</p>

<h3>Kled</h3>

<p>Lần đầu ra mắt: 8/2016<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Count Kledula</p>

<center><img src="/upload/images/game/ba-tuoc-kledula.jpg" width="100%" alt="Bá Tước Kledula" />

<p>Bá Tước Kledula</p></center>

<p>Số phận của Kled khá hơn các vị tướng kể trên một chút khi Kled là một sự lựa chọn nổi tiếng ở giải đấu chuyên nghiệp Đài Loan LMS. Với phong cách hổ báo, Kled phù hợp với lối chơi lao vào khô máu. Bá Tước Kledula mới được ra mắt vào dịp Halloween năm ngoái là trang phục đầu tiên sau 2 năm chờ đợi. Tuy vậy, trông trang phục này cũng không có gì quá đặc biệt.</p>

<h3>Ornn</h3>

<p>Lần đầu ra mắt: 8/2017<br>
Số skin tính đến MSI 2019: 1 skin<br>
Trang phục gần nhất: Thunder Lord Ornn</p>

<center><img src="/upload/images/game/ornn-than-sam.jpg" width="100%" alt="Ornn Thần Sấm" />

<p>Ornn Thần Sấm</p></center>

<p>Ornn được xuất hiện trong MSI và CKTG nhiều hơn Kled và tất cả các tướng kể trên. Lúc mới ra mắt, Thổi Bễ (W) thật sự là một chiêu lỗi với sát thương rất lớn. Bắt đầu từ năm 2018, Ornn được xuất hiện tại giải đấu chuyên nghiệp. MSI 2018, Stark của EVOS mang Ornn solo thắng nhiều tuyển thủ đường trên lúc đó. Tuy nhiên, sau khi meta chống chịu, đánh cuối game dần bị chuyển sang meta đánh nhanh, cộng với việc Ornn bị giảm sức mạnh, Ornn đã mất tích trong 1 năm vừa qua. Ornn Thần Sấm là skin duy nhất Riot cho Ornn tính đến hiện giờ.</p>

<h3>Rek&apos;sai</h3>

<p>Lần đầu ra mắt: 12/2014<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Rek&apos;sai Pool Party</p>

<center><img src="/upload/images/game/reksai-tiec-be-boi.jpg" width="100%" alt="Rek&apos;sai Tiệc Bể Bơi" />

<p>Rek&apos;sai Tiệc Bể Bơi</p></center>

<p>Một trường hợp kỳ lạ so với 3 vị tướng trên là Rek&apos;sai. Dù luôn xuất hiện trong các giải đấu lớn, Rek&apos;sai lại chẳng có trang phục nào mới kể từ khi Rek&apos;sai Tiệc Bể Bơi được ra mắt vào năm 2017. Trước hay sau khi được làm lại, Rek&apos;sai vẫn là cái tên sáng giá trong nhiều meta đi rừng. Lối lên đồ nửa chống chịu nửa sát thương, khả năng hất tung có thể phối hợp với Đấng Yasuo là những gì làm nên tên tuổi của vị tướng này.</p>

<h3>Kindred</h3>

<p>Lần đầu ra mắt: 10/2015<br>
Số skin tính đến MSI 2019: 2 skin<br>
Trang phục gần nhất: Kindred Super Galaxy</p>

<center><img src="/upload/images/game/kindred-sieu-nhan-thien-ha.jpg" width="100%" alt="Kindred Siêu Nhân Thiên Hà" />

<p>Kindred Siêu Nhân Thiên Hà</p></center>

<p>Tương tự như Rek&apos;sai, Kindred cũng là trường hợp kỳ lạ khi được xuất hiện trong giải đấu nhiều nhưng trang phục vẫn ít. Thực ra Kindred cũng mới nổi trở lại gần đây nhưng vẫn được nhiều người đánh xếp hạng yêu thích vì chiêu cuối bất tử. Trang phục của Kindred Siêu Nhân Thiên Hà, cùng bộ với Rumble rất đẹp cũng là một niềm an ủi dành cho vị tướng đã bị ẩn danh một thời gian dài này. </p>

<h3>Tahm Kench</h3>

<p>Lần đầu ra mắt: 7/2015<br>
Số skin tính đến MSI 2019: 3 skin<br>
Trang phục gần nhất: Coin Emperor Tahm Kench</p>

<center><img src="/upload/images/game/tahm-kench-coin-emperor.jpg" width="100%" alt="Tahm Kench Thần Tài" />

<p>Tahm Kench Thần Tài</p></center>

<p>Vị tướng hỗ trợ an toàn bậc nhất Liên Minh Huyền Thoại, cá trê Tahm Kench luôn là lựa chọn đáng quan tâm trong các giải đấu lớn. Tuy nhiên, số lượng trang phục lại chỉ có 3, khá hơn Rek&apos;sai và Kindred. Một sự khó hiểu không hề nhẹ dành cho Riot. Tahm Kench Thần Tài được ra mắt vào Tết năm nay cũng không được đánh giá cao.</p>

<h3>Bard</h3>

<p>Lần đầu ra mắt: 7/2015<br>
Số skin tính đến MSI 2019: 3 skin<br>
Trang phục gần nhất: Bard</p>

<center><img src="/upload/images/game/Bard-nhac-si-lang-thang.jpg" width="100%" alt="Bard Nhạc Sĩ Lang Thang" />

<p>Bard Nhạc Sĩ Lang Thang</p></center>

<p>Vị tướng troll team bậc nhất Liên Minh Huyền Thoại này được an ủi bằng 3 trang phục, nhiều hơn các vị tướng kể trên. Tuy nhiên, số lần xuất hiện trong trò chơi rất ít vì độ khó chơi của Bard. Chỉ cần quăng chiêu cuối sai, bạn có thể dẫn cả đội đến thất bại.</p>

<h3>Urgot</h3>

<p>Lần đầu ra mắt: 8/2010<br>
Số skin tính đến MSI 2019: 4 skin<br>
Trang phục gần nhất: High Noon Urgot</p>

<center><img src="/upload/images/game/urgot-cao-boi.jpg" width="100%" alt="Urgot Cao Bồi" />

<p>Urgot Cao Bồi</p></center>

<p>Dù là một trong các vị tướng có mặt trong trò chơi từ mùa 2 nhưng Urgot chỉ mới có 4 trang phục. Trang phục Urgot Cỗ Máy Chiến Đấu cách trang phục Urgot Cao Bồi hơn 1 năm.</p>

<p>Số phận của Urgot đã khá lên trong 2 năm trở lại đây kể từ khi Urgot được làm lại vào năm 2017 và được Archie mang vào Chung Kết Thế Giới 2 trận trong năm này. Năm 2018 là năm thăng hoa của Urgot trước khi bị giảm sức mạnh. Xin chúc mừng Urgot vì vị tướng này có hành trình sáng lạng hơn đa số vị tướng khác trong danh sách này.</p>

<h3>Yorick</h3>

<p>Lần đầu ra mắt: 6/2011<br>
Số skin tính đến MSI 2019: 4 skin<br>
Trang phục gần nhất: Meowrick</p>

<center><img src="/upload/images/game/yorick-meowrick.jpg" width="100%" alt="Yorick Mèo" />

<p>Yorick Mèo</p></center>

<p>Sau Urgot, Yorick là vị tướng lâu đời tiếp theo của LMHT. Yorick đã được làm lại vào năm 2017. Tuy nhiên, vẫn chưa có nhiều khởi sắc về sự hiện diện của vị tướng này. Dù gần đây, Yorick được xuất hiện nhiều hơn trong các giải đấu chuyên nghiệp của LCK và LCS. Nhưng tại VCS, những trận mà Yorick xuất hiện đều là thua. Trang phục Yorick Mèo được ra mắt vào ngày Cá Tháng Tư năm nay. Đặc biệt hơn, Yorick Hồ Quang là trang phục được ra mắt sau 6 năm chờ đợi. Một khoảng thời gian quá dài.</p>

<h3>Lissandra</h3>

<p>Lần đầu ra mắt: 4/2013<br>
Số skin tính đến MSI 2019: 4 skin<br>
Trang phục gần nhất: Coven Lissandra</p>

<center><img src="/upload/images/game/lissandra-tien-hac-am.jpg" width="100%" alt="Lissandra Tiên Hắc Ám" />

<p>Lissandra Tiên Hắc Ám</p></center>

<p>Cũng là một vị tướng nổi tiếng, thường được chọn trong các giải đấu lớn, nhưng Lissandra lại phụ thuộc vào meta. Hiện giờ, Lissandra không được chọn nhiều cả trong đánh xếp hạng lẫn giải đấu. Lissandra Tiên Hắc Ám cũng là một trang phục đẹp. Trang phục của Lissandra rất đẹp nhưng con số vẫn chỉ dừng lại là 4.</p>

<h3>Lissandra</h3>

<p>Lần đầu ra mắt: 4/2013<br>
Số skin tính đến MSI 2019: 4 skin<br>
Trang phục gần nhất: Badlands Baron Rumble</p>

<center><img src="/upload/images/game/rumble-ong-trum-xe-do.jpg" width="100%" alt="Rumble Ông Trùm Xế Độ" />

<p>Rumble Ông Trùm Xế Độ</p></center>

<p>Từ sau khi Rumble Siêu Nhân Thiên Hà cực kỳ đẹp ra mắt năm 2014, người chơi phải đợi đến 4 năm mới có Rumble Ông Trùm Xế Độ. Dù vị tướng này luôn nằm trong các hot pick đường trên, thậm chí có giai đoạn Rumble đi rừng nổi lên, nhưng số trang phục của Rumble chỉ có 4 trang phục. Chưa kể 2 trang phục đầu khá xấu. Hoạt ảnh của Rumble cũng đã lỗi thời.</p>
',
            'date_post'         => '2019-05-09',
            'thumbnail_post'    => 'nhung-tuong-lien-minh-huyen-thoai-hon-2-nam-chua-co-duoc-3-5-skin-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật',
            'url_post'        => 'harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat',
            'present_vi_post' => 'Sau thế giới Pokemon trở thành hiện tượng vào giữa năm 2016, chúng ta sắp được đến với thế giới phù thủy Harry Potter sống chung với Muggle.',
            'content_vi_post' => '<p>Khi trailer Pokemon GO lần đầu ra mắt vào năm 2015,  nhiều người đã nghĩ đây chỉ là trò đùa cho đến khi nó thực sự ra mắt tại khắp thế giới. Cả thế giới đã rúng động trước công nghệ Thực Tế Ảo (Virtual Reality) y như trong các bộ anime thể loại Mecha như Yugi-oh. Những mặt tích cực và tiêu cực của Pokemon GO đã xuất hiện, khiến người dân và các nhà chức trách phải vào cuộc. Pokemon GO thật sự đã là một cuộc cách mạng của ngành công nghiệp game thế giới.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/2sj2iQyBTQs" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Pokemon GO xuất hiện vào năm 2015<br>
khiến nhiều người nghĩ đây chỉ là trò đùa</p></center>

<p>Và năm nay, vào ngày 14/5/2019, 1 trailer trên Youtube về tựa game Harry Potter: Wizards Unite. Trong trailer là cảnh thế giới Muggle xuất hiện các Tử Thần Thực Tử. Một quyển Quái Thư Về Quái Vật trong cửa hàng tiện lợi. Chó ba đầu trong tập 1 xuất hiện ở sân bóng. Và kết thúc trailer là cảnh 3 người dùng đũa phép chiến đấu với Tử Thần Thực Tử. Đó chính là nội dung về một thế giới phép thuật sẽ tồn tại song song với thế giới thực và bạn sẽ tiếp xúc với thế giới đó thông qua chiếc điện thoại của mình.</p>

<p>Trang chủ <a href="https://www.harrypotterwizardsunite.com/" rel="nofollow" target="_blank" title="Harry Potter: Wizards Unite">Harry Potter: Wizards Unite</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/VkMmlBmVncg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Harry Potter: Wizards Unite</p></center>

<p>Sau đây là những thông tin của fanpage Học viện Pháp thuật và Ma thuật Hogwarts Việt Nam. Fanpage này có hơn 170.000 like. KINGDOM NVHAI sẽ tóm tắt lại những ý chính.</p>

<p>Fanpage <a href="https://www.facebook.com/HogwartsVietnam/?__tn__=kC-R&eid=ARCqDTEIVLqohGQRNRs5VQb23CVA9WwGKxaRBUSleW7rPl8xpOfiIvJoNKahjT4_GcXbnjstGqB0IPel&hc_ref=ARSjnhYBoBHeqJ9WX2fRpfLsnt1TzV2H7woZ5cY641Hj6zSHylqkDHjYSssu0BsQjjA&fref=nf">Học viện Pháp thuật và Ma thuật Hogwarts Việt Nam</a></p>

<h3>Game sẽ được chính đội ngũ của Pokémon GO phát triển.</h3>

<p>Studio phát triển game là Niantic, đây cũng chính là studio phát triển game Pokemon GO. Chắc chắn studio này sẽ rút kinh nghiệm và tăng sự trải nghiệm của người chơi. Nghĩa là người chơi sẽ được chính thức đắm mình trong thế giới phù thuỷ như mình hằng mong ước nhờ công nghệ thực tế ảo tăng cường (AR).</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-1.jpg" width="70%" alt="Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật" />

<p>Logo png của Harry Potter: Wizards Unite</p></center>

<h3>Cốt truyện game</h3>

<p>Trong một diễn biến bất ngờ, loài người bắt đầu nhận thấy sự xuất hiện của các dấu hiệu pháp thuật rải rác khắp thế giới Muggles, cảnh báo nguy cơ dập tắt nỗ lực che giấu Thế giới pháp thuật. Để ngăn chặn điều này, Bộ Pháp thuật đã yêu cầu tăng cường đào tạo và huấn luyện các phù thuỷ để tham gia vào Đội Phù Thuỷ Đặc Nhiệm Tức Thời để thực hiện trọng trách này.</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-2.jpg" width="70%" alt="Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật" />

<p>Thông báo tuyển dụng của Bộ Pháp Thuật</p></center>

<h3>Gameplay</h3>

<p>Cách chơi sẽ tương tự như Pokémon. Ngoài các chức năng quen thuộc như xem ID Bộ Pháp Thuật, thi đấu, thu thập vật phẩm để pha chế thuốc còn có những cuộc chạm trán 3D chi tiết và phong phú trong Thực Tế Ảo 360 độ. Trong đó, người chơi cần thi triển nhiều loại phép thuật khác nhau. Tính năng này chưa từng có trong Pokémon GO.</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-3.jpg" width="70%" alt="Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật" /></center>

<h3>Nhân vật</h3>

<p>Do game vẫn đang trong quá trình hoàn thiện dần, nên hiện tại chúng ta sẽ chỉ thấy các nhân vật sau xuất hiện trong game:</p>

<ul>
<li>Constance Pickering
<li>Harry Potter
<li>Mordecai Berrycloth
<li>Minerva McGonagall
<li>Mathilda Grimblehawk
<li>Gareth Greengrass
<li>Hermione Granger
<li>Grim Fawley
<li>Regina Rowle
</ul>

<center><img src="/upload/images/game/harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-4.jpg" width="70%" alt="Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật" /></center>

<h3>Yếu tố phép thuật</h3>

<p>Game sẽ có những cảnh chiến đấu với Giám Ngục và Tử Thần Thực Tử. Vì vậy phép thuật sẽ được thi triển đa dạng và phong phú trong tính năng Thực Tế Ảo 360 độ.</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-5.jpg" width="70%" alt="Harry Potter: Wizards Unite - Pokemon GO phiên bản thế giới phép thuật" /></center>

<h3>Bao giờ thì chơi được?</h3>

<p>Hiện game đang tiến hành thử nghiệm phiên bản dành cho máy Android tại New Zealand và Úc.</p>

<p>Chắc chắn Harry Potter: Wizards Unite sẽ không gây xôn xao lớn như Pokémon GO nhưng vẫn có thể soán ngôi Pokémon GO để trở thành game Thực Tế Ảo nổi tiếng nhất. Các fan trung thành của series Harry Potter sẽ tự do sống trong thế giới phép thuật của mình mà không gặp phải những chỉ trích hay can thiệp từ chính quyền hay báo chí. Hãy cùng theo dõi sự phát triển của thế giới phép thuật sắp được ra mắt nhé!</p>
',
            'date_post'         => '2019-05-14',
            'thumbnail_post'    => 'harry-potter-wizards-unite-pokemon-go-phien-ban-the-gioi-phep-thuat-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Harry Potter Wizards Unite có thể vượt qua Pokémon GO để trở thành game di động hàng đầu không?',
            'url_post'        => 'harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong',
            'present_vi_post' => 'Pokémon GO là cuộc cách mạng về game mà nhân loại từng tạo ra. Nhưng liệu Harry Potter: Wizards Unite có thể soán ngôi vị này?',
            'content_vi_post' => '<h2>Niantic đánh bại sản phẩm tốt nhất của chính mình?</h2>

<center><img src="/upload/images/game/harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong-1.jpg" width="100%" alt="Harry Potter Wizards Unite Pokémon GO" /></center>

<p>Cả 2 trò chơi đều cùng chung nhà phát triển là Niantic, một công ty con thuộc Google.</p>

<p>Hiện tại Niantic đang phát triển 2 trò chơi: Pokémon GO và Ingress Prime. Pokémon GO nổi tiếng nhờ thương hiệu có sẵn. Còn Ingress Prime chỉ nổi tiếng ở mức tương đối mặc dù Ingress cũng có bộ anime của riêng mình.</p>

<p>Trang chủ <a href="http://ingressanime.com/en/" rel="nofollow" target="_blank" title="Ingress Anime">Ingress Anime</a></p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong-2.jpg" width="100%" alt="Harry Potter Wizards Unite Pokémon GO Ingress Prime" /></center>

<p>Thương hiệu Harry Potter lớn không kém Pokémon và đây là lý do tại sao rất nhiều game thủ phấn khích trước viễn cảnh của Harry Potter: Wizards Unite. Chúng ta biết Niantic có khả năng tạo ra Pokémon Go, vậy tại sao thế giới phù thủy Harry Potter không thể tốt hơn thế?</p>

<h2>Tại sao Harry Potter: Wizards Unite lại có thể đánh bại Pokémon GO?</h2>

<p>Hãy cùng so sánh những yếu tố sau để chấm điểm. Đây sẽ là một cuộc so găng giữa Harry Potter: Wizard Unite và Pokémon GO và KINGDOM NVHAI sẽ là trọng tài.</p>

<p><strong>Chơi miễn phí (Free-to-play)</strong></p>

<p>Giống như Pokémon Go, Harry Potter Wizard Unite được chơi miễn phí. Mặc dù có mua bán trong game, nhưng người chơi có thể chơi hoàn toàn miễn phí để tối đa hóa số lượng người chơi.</p>

<p>Kết quả: 1-1</p>

<p><strong>Câu chuyện đằng sau trò chơi (Game story)</strong></p>

<p>Pokémon GO có một cốt truyện phong phú, kéo dài từ cuối những năm 1990 đến tận ngày nay. Harry Potter: Wizard Unite có tập 1 được xuất bản vào ngày 26/6/1997, cũng có cốt truyện phong phú nhưng đã bị chững lại sau khi cốt truyện chính của Harry Potter đã kết thúc. Những câu chuyện sau này như Fantastic Beast (Sinh Vật Huyền Bí) chỉ là phần ngoại truyện.</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong-3.jpg" width="100%" alt="Harry Potter Fanastic Beasts" /></center>

<p>Nhưng bù lại, Harry Potter: Wizard Unite có cốt truyện riêng là thế giới Muggle bị tấn công bởi thế giới phù thủy. Còn Pokémon GO vẫn chỉ đơn giản là bắt các Pokémon và thi đấu, không có cốt truyện rõ ràng. Số lượng Pokémon cũng khá ít, xoay quanh các Pokémon đời đầu vì chúng quen thuộc với đa số người chơi. Còn các Pokémon sau này khá xa lạ do nhiều người đã rời bỏ series này vì quá dài.</p>

<p>Kết quả: 2-2</p>

<p><strong>Học từ Pokémon GO (Learnt from Pokémon GO)</strong></p>

<p>Pokémon Go là trò chơi đầu tiên đưa thực tế mở rộng vào trò chơi. Tuy nhiên, điều này đã xuất hiện năm 2016. Bây giờ là năm 2019, công nghệ đã tiên tiến.</p>

<p>Đây lại là lợi thế mà Harry Potter: Wizard Unite mạnh nhất. Không chỉ có lợi thế về công nghệ, trò chơi còn rút kinh nghiệm từ những sai lầm và các vụ việc liên quan đến chính trị, tôn giáo, văn hóa của các nước. Sẽ không còn cảnh người chơi đi vào các khu vực nhạy cảm về tâm linh như đền chùa, bảo tàng để bắt Pokémon nữa. Đặc biệt nhất là những vụ tai nạn chết người khi đang chơi Pokémon GO.</p>

<p>Kết quả: 3-2 Harry Potter: Wizard Unite dẫn trước</p>

<p><strong>Độ phức tạp của trò chơi (Game complexity)</strong></p>

<p>Harry Potter có vẻ hơi khó hiểu và khó nhớ đối với nhiều người do lượng thông tin về phép thuật, tên các sinh vật huyền bí hay các loại thuốc pha chế khá lớn. Chắc chắn càng về sau, lượng thông tin này càng lớn và hơi khô khan. Mấy ai nhớ được tất cả các phép đã xuất hiện trong phim Harry Potter.</p>

<center><img src="/upload/images/game/harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong-4.jpg" width="70%" alt="Harry Potter Wizards Unite Pokémon GO" />

<p>Có ai nhớ được phép gọi rắn trong trận đấu giữa Malfoy và Harry là gì không?</p></center>

<p>Đây lại là một lợi thế khác biệt mà Pokemon GO có nhờ vào việc khái niệm cơ bản là tìm Pokémon và bắt. Cách bắt Pokémon được tối giản, không còn cảnh phải đánh cho Pokémon hoang dã gần hết máu rồi bắt như thời Gameboy hay như trong phim. Bạn chỉ cần ném Pokéball chuẩn là bắt được. Chưa kể đến lợi thế sưu tầm Pokémon. Những game sưu tầm thẻ bài, thú vật hiếm luôn có sức hút kỳ lạ.</p>

<p>Kết quả: 3-3 Pokémon GO gỡ hòa</p>

<p>Với 4 tiêu chí kể trên, kết quả cuối cùng là 2 game rất ngang nhau, khó có thể biết được game nào sẽ trở thành game thực tế mở rộng thành công nhất. Chúng ta chỉ còn cách chờ tương lai trả lời.</p>

<p>Nguồn: <a href="https://www.dexerto.com/pokemon/harry-potter-wizards-unite-pokemon-go-558561" rel="nofollow" target="_blank" title="Harry Potter Wizards Unite">Dexerto</a></p>
',

            'date_post'         => '2019-05-19',
            'thumbnail_post'    => 'harry-potter-wizards-unite-co-the-vuot-qua-pokemon-go-de-tro-thanh-game-di-dong-hang-dau-khong-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Atelier Ryza sắp có mặt trên PC, PS4, Switch',
            'url_post'        => 'atelier-ryza-release-for-pc-ps4-switch',
            'present_vi_post' => 'Game thuộc thể loại cày level phong cách Anime rất giống với Aura Kingdom',
            'content_vi_post' => '<p>Atelier Ryza: The Queen of Eternal Darkness and Secret Hideout là một tựa game hành động nhập vai theo phong cách anime mới của Koei Tecmo. Trò chơi sắp được ra mắt vào ngày 29/10/2019.</p>

<p>Trang chủ <a href="https://www.gamecity.ne.jp/atelier/ryza/" target="_blank" rel="nofollow"> Atelier Ryza: The Queen of Eternal Darkness and Secret Hideout</a></p>

<p>Kênh Youtube <a href="https://www.youtube.com/channel/UCyF1q25e_j9MytZR4sGLiDA" target="_blank" rel="nofollow"> ガストチャンネル</a> có các video khác về game.</p>

<center><img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-1.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" />

<iframe width="100%" height="350" src="https://www.youtube.com/embed/PXakcGwMURE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer game Atelier Ryza</p></center>

<p>Lời giới thiệu trên trang chủ, phần Introduction:</p>

<blockquote>
<p>Even though everyone has them,<br>
the memories we create with our friends are special to each and every one of us.</p>
<p>The story of "Atelier Ryza" is about a girl and her friends on the verge of adulthood,<br>
discovering what is most important to them.</p>

<p>Mọi người đều có chúng,<br>
những kỷ niệm với bạn bè là điều gì đó vô cùng đặc biệt đối với mỗi người chúng ta.</p>
<p>Câu chuyện của "Atelier Ryza" kể về một cô gái và những người bạn của cô ấy tìm thấy điều gì đó đặc biệt trước khi bước vào tuổi trưởng thành.</p>
</blockquote>

<p>Trò chơi như một câu chuyện với nhiều lớp nhân vật. Trong đó nhân vật chính, cũng là nhân vật được nhiều sự chú ý nhất là Realuin Ryza Stout, lồng tiếng bởi Noguchi Yuri. Theo wiki: Ryza là một cô gái bình thường có đặc điểm độc đáo là… rất bình thường. Ryza có tính cách hoang dã và tomboy với ý thức mạnh mẽ về công lý. Dù cô ấy có thể hơi bướng bỉnh, nhưng trái tim của cô ấy đã ở đúng chỗ. Toàn bộ thế giới của cô bị đảo lộn trong một cuộc gặp gỡ lạ thường. </p>

<center><img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-characters.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<p>Từ trái qua: Reisalin Ryza Stout, Lent, Tao, Klaudia, Empel, Lila</p>

<img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-character-ryza.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<p>Thông tin về Ryza</p>

<img src="/upload/images/game/atelier-ryza-ryza-klaudia-1.jpg" width="70%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<img src="/upload/images/game/atelier-ryza-ryza-1.jpg" width="70%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<img src="/upload/images/game/atelier-ryza-ryza-2.jpg" width="70%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<p>Fan art về Ryza.</p>

<img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-game-ryza.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-game-klaudia.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-game-lila.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<p>Ảnh trong game của Ryza, Klaudia và Lila</p></center>

<p>Từ những hình ảnh giới thiệu, chúng ta có thể thấy Ryza là lớp nhân vật cận chiến dùng giáo có 3 mũi. Klaudia dùng phép thuật bằng âm nhạc và vũ khí là một cây sáo, có lẽ cô là hỗ trợ. Lila thuộc dạng sát thủ với bộ vuốt dài đáng sợ. Ngoài ra còn có Lent Marslink khỏe mạnh với cây đại đao to lớn. Tao Mongarten như một tri thức có vũ khí là cây búa. Empel Vollmer như một pháp sư cầm quyền trượng.</p>

<p>Khung cảnh và đồ họa trong game rất giống với Aura Kingdom dù không cùng nhà phát hành. Những ngọn cây cổ thụ cao chót vót. Những cảnh làng mạc, bến cảng hay viên đá to lớn lơ lủng giữa hồ. Thậm chí, bản nhạc cuối trailer cũng có gì đó rất giống với nhạc trong game Aura Kingdom. Đó có phải là ngẫu nhiên không? Hệ thống chiến đấu của các nhân vật. Tất cả đều mang màu sắc rất huyền ảo, thần thoại và đậm chất anime. Chỉ cần nhìn game, người chơi đã cảm thấy đây là một thế giới đáng để phiêu lưu và khám phá. </p>

<center><img src="/upload/images/game/atelier-ryza-sap-co-mat-tren-pc-ps4-switch-2.jpg" width="100%" alt="Atelier Ryza sắp có mặt trên PC, PS4, Switch" /><br><br>

<p>Đây là cảnh mà KINGDOM NVHAI thích nhất trong trailer</p></center>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/TtYcVa0MvPI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/CJsHBoZRfUU" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer thế giới trong Atelier Ryza</p></center>

<p>Cách thiết kế nhân vật cũng khá gợi cảm. Cặp đùi căng nhờ đôi vớ của Ryza, bộ ngực của Lila hay phong cách quyền quý của Klaudia không tạo cảm giác thô tục mà vẫn rất cuốn hút. Giới hạn độ tuổi của game là vị thành niên trên 13.</p>

<p>Game sẽ được phát hành trên đĩa và kỹ thuật số cho PlayStation 4 / Switch và nhưng chỉ có kỹ thuật số cho PC thông qua Steam.</p>
',

            'date_post'         => '2019-06-01',
            'thumbnail_post'    => 'atelier-ryza-release-for-pc-ps4-switch-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'AVENGER game ra mắt trailer tại E3 2019',
            'url_post'        => 'avenger-game-ra-mat-trailer-tai-E3-2019',
            'present_vi_post' => 'Một tin vui và không có gì ngạc nhiên. Không thể nào ngành giải trí lại bỏ qua một siêu bom tấn như Avenger.',
            'content_vi_post' => '<p>Hãng Marvel vừa có ra mắt trailer về các siêu anh hùng của hãng này. Đây là trailer đầu tiên kể từ sau khi phim Avengers: Endgame kết thúc. Avengers Endgame được ra mắt vào 22/4/2019. Trailer được ra mắt vào 10/6/2019.</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/LDBojdBAjXU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Nội dung trailer là cảnh cả đội Avenger bao gồm Captain America, Iron Man, Hulk, Black Widow và Thor đang dự một buổi lễ công nghệ cao ở San Francisco. Buổi lễ trở thành thảm họa khi Hydra tấn công dẫn đến sự tàn phá lớn, tàu sân bay bị đánh chìm, rất nhiều người chết. Họ đổ lỗi cho nhau và tan rã. 5 năm sau, thế giới lâm vào tình trạng nguy hiểm. Hy vọng duy nhất là tập hợp lại các siêu anh hùng mạnh nhất Trái Đất.</p>

<center><img src="/upload/images/game/avenger-game-ra-mat-trailer-tai-E3-2019-1.jpg" width="100%" alt="AVENGER game ra mắt trailer tại E3 2019" />

<p>Trận chiến tại cầu Cổng Vàng, thành phố San Francisco</p></center>

<p>Nhìn vào trailer, chúng ta có thể thấy hình ảnh, âm thanh khá tốt. Cảnh chiến đấu trên cầu Cổng Vàng, cảnh Hydra cho khẩu súng điện tử bắn vào Thor để Thor phải đánh trả và làm sập cầu. Tuy nhiên, nội dung cốt truyện lại quá quen thuộc. Vẫn cốt truyện bình thường như bao phim hành động khác là các siêu anh hùng đánh với kẻ xấu và thất bại, dẫn đến cãi nhau và tan rã. Đến khi có biến cố lớn xảy ra, họ lại tập hợp và chống lại kẻ xấu.</p>

<p>Phần description bên dưới video trên Youtube như sau:</p>

<p>Marvel Entertainment và Square Enix rất vui mừng được tiết lộ Marvel Avengers Avengers, một trò chơi phiêu lưu hành động hoành tráng kết hợp cách kể chuyện điện ảnh với lối chơi single-player và co-operative gameplay. Được phát triển bởi Crystal Dynamics hợp tác với Eidos-Montréal, Nixxes Software và Crystal Northwest, Avengers của Marvel sẽ phát hành cho hệ PlayStation 4, các thiết bị Xbox One bao gồm Xbox One X, Stadia và hệ PC vào ngày 15/5/2020.</p>
',

            'date_post'         => '2019-06-11',
            'thumbnail_post'    => 'marvel-avenger-game-release-trailer-in-E3-2019-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Armored Mewtwo xuất hiện trong sự kiện Pokemon GO',
            'url_post'        => 'armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go',
            'present_vi_post' => 'Bộ giáp cực chất, thể hiện phong cách mạnh mẽ của Mewtwo khiến khán giả thêm háo hức.',
            'content_vi_post' => '<p>Mewtwo - Pokemon huyền thoại đầu tiên của thế giới Pokemon, cũng là Pokemon huyền thoại được yêu thích nhất đã được độ thêm một bộ giáp trông rất mạnh mẽ và cứng cáp với tên gọi Armored Mewtwo (tạm dịch là Mewtwo Giáp Sắt hay Chiến Giáp Mewtwo).</p>

<p>Trailer mới nhất của Pokemon GO nói về sự kiện săn boss khủng gọi là Raid Battle. Game thủ sẽ có cơ hội sở hữu Armored Mewtwo trong sự kiện này. Sự kiện diễn ra từ ngày 10/7/2019 đến 31/7/2019.</p>

<center><img src="/upload/images/game/armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go-armored-mewtwo-1.jpg" width="100%" alt="Armored Mewtwo Pokemon GO" />

<iframe width="560" height="315" src="https://www.youtube.com/embed/D7nbsoa9PNk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Armored Mewtwo cực chất</p></center>

<p>Có lẽ Pokemon GO đang tận dụng dư âm từ bộ phim Thám Tử Pikachu được chiếu vào tháng 6/2019. Trong phim, Pikachu là một con Pokemon mất trí nhớ làm bạn với Tim để tìm ra âm mưu liên quan đến Mewtwo và sự mất tích của cha mình.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/1roy4o4tqQM" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Detective Pikachu</p></center>

<p>Pokemon GO là tựa game đầu tiên sử dụng tính năng thực tế ảo trên bản đồ Google Map. Trò chơi cho phép bạn bắt Pokemon qua điện thoại thông minh ngay trên đường phố thật. Tuy nhiên, đã có nhiều cuộc tranh cãi nổ ra vì sự an toàn thông tin cũng như cả mạng sống của người chơi sau khi có nhiều vụ tai nạn thật xảy ra, thậm chí có cả người chết.</p>

<p>Mewtwo là Pokemon huyền thoại hệ Siêu Linh. Lần đầu xuất hiện trong Pokemon The Movie: Mewtwo Strike Back (Mewtwo Trở Lại). Mew là một con Pokemon hệ Siêu Linh cổ đại. Sau khi loài người phát hiện ra ADN của Mew, họ đã đưa về và nhân bản ra Mewtwo, Pokemon mạnh mẽ hơn cả Mew. Mewtwo không chấp nhận làm vật thí nghiệm của loài người nên đã tạo ra nhiều Pokemon nhân bản để biến thế giới này thành thế giới của Pokemon.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/VNaiFUv2Y-4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Tất cả phim có Mewtwo từ năm 1998 đến Detective Pikachu năm 2019</p></center>

<center><img src="/upload/images/game/armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go-mewtwo-first-movie.jpg" width="100%" alt="Armored Mewtwo Pokemon GO" />

<img src="/upload/images/game/armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go-mewtwo-detective-pikachu.jpg" width="100%" alt="Armored Mewtwo Pokemon GO" />

<img src="/upload/images/game/armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go-armored-mewtwo-2.jpg" width="100%" alt="Armored Mewtwo Pokemon GO" />

<p>Mewtwo trong movie đầu tiên, Detective Pikachu và Armored Mewtwo</p></center>

',

            'date_post'         => '2019-07-04',
            'thumbnail_post'    => 'armored-mewtwo-xuat-hien-trong-su-kien-pokemon-go-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ',
            'url_post'        => 'boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio',
            'present_vi_post' => 'Truyền thống của Riot: đã nerf là phải nerf đến khi không dậy nổi thì thôi.',
            'content_vi_post' => '<p>Vào lúc 21g ngày 23/9/2019, lễ bốc thăm chia bảng giải đấu Chung Kết Thế Giới 2019 của Liên Minh Huyền Thoại đã diễn ra. 2 đại diện của khu vực VCS Việt Nam là Lowkey Esport và GAM Esport đã có kết quả.</p>

<p>Tại vòng khởi động, Lowkey Esport sẽ gặp MEGA của khu vực GPL Đông Nam Á và Hong Kong Attitude của LMS Đài Loan.</p>

<p>Tại vòng bảng, GAM Esport sẽ gặp FunPlus Phoenix của khu vực LPL Trung Quốc và J Team của LMS Đài Loan.</p>

<p>Danh sách <a href="http://lienminh360.vn/esports/diem-mat-cac-doi-tuyen-se-tranh-tai-tai-cktg-2019/" target="_blank" title="">các đội tuyển tham gia CKTG 2019.</a></p>

<center><img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-Lowkey-Esport.jpg" width="100%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>Lowkey Esport sẽ gặp MEGA của Thái Lan và Hong Kong Attitude của Đài Loan</p>

<img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-GAM-Esport.jpg" width="100%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>GAM Esport sẽ gặp FunPlus Phoenix của Trung Quốc và J Team của Đài Loan.</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/SqtWpeEAiVo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Live stream bốc thăm chia bảng CKTG 2019</p></center>

<h2>Đánh giá khả năng đi tiếp của 2 đội VCS</h2>

<p>Lowkey Esport sẽ vượt qua bảng C để đến với BO5. Đó là điều chắc chắn vì không thể nào VCS lại thua người anh em Thái Lan một thời từng đánh chung khu vực GPL được. Nền Liên Minh Huyền Thoại GPL nói chung và Thái Lan nói riêng đã không còn phát triển nữa. G4 và Lloyd vẫn thi đấu từ thời Bangkok Titans đến giờ, từ mùa 3 đến nay là mùa thứ 7. Khán giả Việt Nam nhớ rất rõ thời đỉnh cao phong độ của họ kinh khủng thế nào.</p>

<p>Điều quan trọng của Lowkey Esport là họ phải nhất bảng để tránh 3 đối thủ nhất bảng khác. Nhiều khả năng 3 đối thủ nhất bảng sẽ có đại diện LEC châu Âu là Splyce, đại diện LCS Bắc Mỹ là Clutch Gaming và đại diện LCK Hàn Quốc là DAMWON Gaming. Bảng C của Lowkey Esport là bảng dễ nhất của vòng khởi động. Họ cần phải hạng nhất để tránh 3 đội kia. Còn trong trường hợp Lowkey Esport hạng nhì, họ nên mong không gặp Hàn Quốc.</p>

<center><img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-Lowkey-Esport-1.jpg" width="100%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>Các trường hợp của Lowkey Esport</p></center>

<p>Tiếp đến là GAM Esport. Bảng của GAM đã có FunPlus Phoenix của LPL Trung Quốc và J Team của LMS Đài Loan. Đây cũng là bảng đấu tương đối nhẹ dành cho GAM vì lần đầu tiên trong 4 lần tham dự CKTG, Việt Nam không nằm chung bảng với Hàn Quốc.</p>

<center><img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-han-quoc.jpg" width="80%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>3 lần CKTG trước, lần nào Việt Nam cũng đánh với Hàn Quốc<br>
và chưa từng thắng trận nào.</p></center>

<p>Trung Quốc dù mạnh nhưng ít ra GAM cũng đã từng thắng World Elite trong kỳ MSI 2017 với Kha&apos;zik Quadrakill của Levi. Gần đây nhất là MSI 2019, Phong Vũ Buffalo đã suýt thắng đương kim vô địch CKTG 2018 Invictus Gaming khi đã phá tan 2 trụ bảo vệ nhà chính. Đó là những thành tích mà Việt Nam hoàn toàn có thể kỳ vọng vào 1 trận thắng trước Trung Quốc.</p>

<p>Đài Loan hiện đang là khu vực bị thụt lùi khá nghiêm trọng. Flash Wolf đã không còn độc tôn. Nhiều chuyên gia còn dự đoán Đài Loan sắp bị tước mất 1 suất trong 3 suất tham dự CKTG. Thậm chí có thể giải đấu LMS sẽ sát nhập vào VCS. Vì vậy, việc GAM có được 1-2 trận thắng trước J Team là điều hoàn toàn trong tầm tay.</p>

<p>Vị trí cuối cùng từ vòng khởi động lên, nhiều khả năng sẽ là Bắc Mỹ, Châu Âu hoặc Hàn Quốc. Một bảng không được có nhiều đội cùng khu vực, nghĩa là Hong Kong Attitude của Đài Loan và Lowkey Esport của Việt Nam sẽ không thể vào bảng B của GAM. Wildcard lại càng không vì xác suất Wildcard vượt qua vòng khởi động là cực kỳ khó. Dù có kỳ tích cũng khó có thể vào chung bảng với GAM nên chúng ta bỏ qua phương án này. Vậy bảng B của GAM sẽ có 3 trường hợp sau là khả thi nhất:</p>

<center><img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-GAM-Esport-1.jpg" width="100%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>3 trường hợp dễ xảy ra nhất trong bảng của GAM Esport</p></center>

<p>Nhìn vào 3 bảng này, chắc chắn ai cũng mong DAMWON Gaming sẽ không chung bảng với GAM Esport để Việt Nam thoát khỏi lời nguyền chung bảng với Hàn Quốc. Dù là hạt giống số 3, nhưng chỉ nghe danh Hàn Quốc cũng khiến các fan Việt Nam cảm thấy mất tự tin ít nhiều. Nếu bạn là người lạc quan, bạn vẫn có thể hy vọng vào kỳ tích 1 trận thắng vì đây là hạt giống số 3, khác với mọi năm Việt Nam gặp hạt giống số 1 và 2 của Hàn Quốc.</p>

<p>Kế đến là Clutch Gaming. Dù đây là một cái tên lạ nhưng bên trong là những tuyển thủ quen thuộc như Huni - cựu đường trên của SKT từng đấu với GAM 2017. Cody Sun - xạ thủ người Trung Quốc tham dự 3 kỳ CKTG liên tục. Cody Sun trong màu áo Immortals đã có 1 trận thắng 1 trận thua trước GAM 2017 và thất bại vào năm đó.  Nếu phải né, GAM nên né Clutch Gaming, nhất là khi Clutch Gaming đã có chiến thắng 3-2 trước Team Solomid để lấy chiếc vé cuối cùng đi CKTG 2019.</p>

<p>Cuối cùng là Splyce, đội tuyển ít tiếng tăm với dàn tuyển thủ cũng ít nổi tiếng đối với các fan hâm mộ Việt Nam. Tuyển thủ của họ không có Hàn hay Trung nào. Đây là đội tuyển mà các fan Việt Nam mong GAM gặp họ nhất.</p>

<center><img src="/upload/images/game/boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-Splyce.jpg" width="80%" alt="Bốc thăm chia bảng Chung Kết Thế Giới 2019: bây giờ hoặc không bao giờ" />

<p>Những cái tên xa lạ của Splyce</p></center>

<p>Vậy là cả Lowkey Esport và GAM Esport đã có thiên thời và địa lợi. Meta Đấu Sĩ hiện tại rất phù hợp với thế mạnh của cả 2 đội. Zeros mạnh với lối chơi hổ báo sẽ phù hợp với Renekton, Camille, Fiora vừa được buff. Levi với tướng tủ Leesin và lối chơi ăn thịt sẽ hỗ trợ cho Zeros gánh team. Lowkey Esport đã có bảng đấu với 2 đội yếu nhất của hạt giống số 1 và số 3. Như Hoàng Luân đã nói trong Biết Chọn Gì Đây: "bây giờ hoặc không bao giờ". Đội hình mạnh nhất mà VCS từng có, bảng đấu dễ thở, Đài Loan đang yếu, tâm lý và kinh nghiệm thi đấu dày dạn của Zeros và Levi. Tất cả những điều đó khiến mọi người hâm mộ Việt Nam nói chung và GAM nói riêng đều kỳ vọng rất lớn về thành tích lọt vào tứ kết của GAM.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/SPIavVoGeHQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>14:25 Hoàng Luân đã nói:<br>
"Bây giờ hoặc không bao giờ.<br>
Thật sự mà nói đây là đội hình mạnh nhất mà lịch sử VCS từng có"</p></center>

<p>Ngày bắt đầu thi đấu vòng khởi động là 2/10/2019. Ngày bắt đầu thi đấu vòng bảng là 12/10/2019. Việt Nam sẽ đấu tại Studio LEC, Berlin. Hãy cùng cổ vũ cho 2 đội tuyển Việt Nam đang là những đội tuyển trẻ nhất, giàu kinh nghiệm và kỹ năng cao nhất của VCS sẽ giành chiến thắng.</p>
',

            'date_post'   => '2019-09-23',
            'thumbnail_post'    => 'boc-tham-chia-bang-chung-ket-the-gioi-2019-bay-gio-hoac-khong-bao-gio-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,

            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'LMS sát nhập với GPL thành giải đấu mới từ năm 2020',
            'url_post'        => 'lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020',
            'present_vi_post' => 'Thêm một tin vui cho nền Liên Minh Huyền Thoại Việt Nam.',
            'content_vi_post' => '<p>Hai giải đấu League Master Series (LMS) của Đài Loan và Legends Southeast Asia Tour (LST) của Đông Nam Á sẽ được kết hợp thành một giải đấu mới mang tên Pacific Championship Series (PCS). Dự kiến, PCS sẽ có sự góp mặt của 10 đội tuyển và khởi tranh từ mùa giải 2020. Nguyên nhân là vì lý do thành tích và số lượt xem của cả LMS và LST.</p>

<center><img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-1.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" /></center>

<p>LMS của Đài Loan là khu vực đã từng vô địch CKTG 2012 với đội Taipei Assassins. Hàng năm, LMS có 3 suất tham gia CKTG. Sức mạnh của họ chính là đội Flash W olves, đội có thể thắng cả các đối thủ đến từ Hàn Quốc hay Trung Quốc. Tuy nhiên, thành tích của Flash Wolves lại chưa từng vượt qua vòng bảng CKTG. CKTG đáng quên nhất của Flash Wolves là năm 2017, họ thất bại 1-5, thắng 1 trận duy nhất với Team Solomid và gạt giò thành công đội này. MSI 2019, 2 nước chủ nhà là Đài Loan và Việt Nam đều bị loại tại vòng bảng.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/JihWgyRxfGo" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận thắng duy nhất của Flash Wolves tại CKTG 2017</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/Fxr-OwJFTUk" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Flash Wolves đánh bại SKT tại CKTG 2016</p></center>

<p>Thái Lan nói riêng và Đông Nam Á nói chung cũng đã qua thời hoàng kim. Thời Singapore Sentinels bá đạo với siêu xạ thủ Chawy, thời G4 là “Faker Đông Nam Á” của Bangkok Titans. Và cả CKTG 2015, Bangkok Titans may mắn được tham dự vì Việt Nam không có visa và được đối đầu với SKT. Tất cả ánh hào quang của Đông Nam Á dần dần bị bỏ lại phía sau khi thực tại phũ phàng là Đông Nam Á chỉ còn mỗi Thái Lan được giải cao. Các nước khác cứ mãi bết bát như vậy.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/IzDSIwxBvew" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Giải đấu Đi Tìm Huyền Thoại tham gia CKTG 2012 đáng nhớ</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/OlaMHEcl5g8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Bangkok Titans vs Saigon Fantasic 5</p></center>

<p>Vì lý do thành tích sa sút, một đội độc bá giải đấu liên tục khiến lượng người xem càng ngày càng giảm sút. Riot quyết định sát nhập 2 giải đấu vào làm một để tăng lượng người xem, làm mới lạ giải đấu. Tuy nhiên, làm thế này chỉ khiến các đội khác của Đông Nam Á ngoài Thái Lan càng thêm nản. Họ đã không thắng được Thái Lan, lại còn phải đụng độ Đài Loan. Có lẽ phong trào Liên Minh Huyền Thoại tại các nước này lụi tàn là điều sớm muộn.</p>

<center><img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-2.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" />

<p>Các đội khác ngoài Mega của Thái Lan có cửa nào đấu với Đài Loan?</p>

<img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-3.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" />

<p>Thông báo trên trang <a href="https://www.facebook.com/lolph/photos/a.154669697885999/2758969037456039/?type=3&eid=ARBcqAVPAc5G1-SNQrX6qKu53ZuqW96L_5g4x7n6KYdC3WfwtWwMtd2MvFByEycHnDgxH27wBIqdwSCX&__xts__%5B0%5D=68.ARBhpl7xocBk2N_NjPvoRYtD6xf1jzbD9kilCNIL4rrLBr5QzDDEDQ3i6krmVoS-hdR80M6EVzz1cwVSpHLNmt3FuEZsRkpAd6E-_da2xduhCrnsbFwBw37COe8dUqCmlQ1g1RYBxZnF0CPOHkpTvu07e3Ek811w1Dqv4yGIK42b7RZMtbLCaMqT8IGShEsAHx81dWwvTTOa1SCsWJS5AfzTK0v_Wyc5CXFDYCIywYcoXhL0u9O38RcG1svH_XeLILZhyInC3hWzOf6T1-cmWYpA2h01j1dh6rWh7faa8Vc8SfRqwxlecraXtdm5jZl6Xqa6lVhLzzvF1bK3tXZM3lUBnw&__tn__=EHH-R" target="_blank" rel="nowfollow">League of Legends - Philippines</a></p>

<img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-4.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" />

<p>Thông báo trên trang <a href="https://www.facebook.com/th.lol/photos/a.380870395262003/3038155132866836/?type=3&theater" target="_blank" rel="nowfollow">Garena League of Legends Thailand</a></p></center>

<p>Trên trang <a href="https://escharts.com/tournaments/lol" target="_blank" rel="nowfollow">escharts.com</a>, số lượt xem của LST chỉ có 6.240 lượt xem, còn LMS chỉ có 35.570 lượt xem. Trong khi MSI 2019 vừa rồi, VETV của Việt Nam đã lập kỷ lục 374.777 lượt xem. VCS các trận bình thường hơn 100.000 lượt xem. Trận chung kết VCS có thể hơn 200.000 lượt xem.</p>

<center><img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-ky-luc-luot-xem-VETV.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" />

<img src="/upload/images/game/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-5.jpg" width="100%" alt="LMS sát nhập với GPL thành giải đấu mới từ năm 2020" />

<p>Bấm vào menu Tournament, chọn game League of Legends<br>
và xem theo cột Peak Viewers</p></center>

<p>Đây là tin mà Việt Nam mong chờ từ năm 2018 đến nay. Năm 2017, màn thể hiện xuất sắc của GAM đã giúp Việt Nam tách ra khỏi Đông Nam Á. Việt Nam đã đặt mục tiêu vượt qua Đài Loan để vĩnh viễn có 2 vé tham dự CKTG. Nhiều người nghĩ rằng VCS và LMS sẽ sát nhập nhưng đây là tin rất bất ngờ khi khu vực rất mạnh là LMS lại sát nhập với khu vực rất yếu của Wildcard. Mọi lợi thế từ bốc thăm đến sát nhập đều có lợi cho Việt Nam. Thiên thời địa lợi, còn nhân hòa thì sao? Chỉ cần 1 trong 2 đội GAM Esport và Lowkey Esport có kết quả tốt thì 2 vé vĩnh viễn đến CKTG không còn là giấc mơ nữa.</p>
',

            'date_post'         => '2019-09-25',
            'thumbnail_post'    => 'lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Vấn đề Hồng Kông nổi lên trong giải đấu Hearthstone Grandmasters 2019',
            'url_post'        => 'van-de-hong-kong-noi-len-trong-giai-dau-hearthstone-grandmasters-2019',
            'present_vi_post' => 'Game không phải là nơi dành cho chính trị. Tuyển thủ Blitzchung người Hồng Kông cùng 2 caster ở Đài Bắc đều phải nhận án phạt.',
            'content_vi_post' => '<p>Hồng Kông hiện đang là vấn đề nổi lên trong những tuần vừa qua. Người dân Hồng Kông mong muốn độc lập khỏi Trung Hoa Đại Lục. Và tất nhiên Trung Quốc không đời nào chấp nhận điều đó. Những người biểu tình Hồng Kông nhiều lần đụng độ chính quyền Trung Quốc. Sự kiện này được Wikipedia ghi lại: "Biểu tình tại Hồng Kông năm 2019 còn gọi là Phong trào chống dẫn độ, là một loạt các cuộc biểu tình hiện đang diễn ra ở Hồng Kông và các thành phố khác trên thế giới chống lại dự luật dẫn độ do chính phủ Hồng Kông đề xuất vào năm 2019."</p>

<p>Sự kiện chính trị nóng hổi này đã lan sang giải đấu Hearthstone Grandmasters 2019. Ng "Blitzchung" Wai Chung sau khi chiến thắng trận đấu với DawN vào ngày 6/10/2019, khi lên phỏng vấn, anh này tuyên bố "Liberate Hong Kong, revolution of our age!" (Giải phóng Hồng Kông, cuộc cách mạng của thời đại chúng ta!). Chung đeo mặt nạ để nhắc đến đến lệnh cấm của chính phủ ban hành khi đeo mặt nạ trong các cuộc tuần hành. Blizzard rất nhanh tay đã xóa video đoạn phỏng vấn đấy, đồng thời ra hình phạt nặng với Blitzchung và 2 bình luận viên.</p>

<p>Blitzchung đã bị cấm tham gia Hearthstone esports trong 12 tháng bắt đầu từ ngày 5/10/2019. Cả hai caster cũng bị mất việc vì phỏng vấn Blitzchung.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">We have a statement from <a href="https://twitter.com/blitzchungHS?ref_src=twsrc%5Etfw">@blitzchungHS</a> “... I put so much effort in that social movement in the past few months, that I sometimes couldn&#39;t focus on preparing my Grandmaster match...”<a href="https://t.co/3AgQAaPioj">https://t.co/3AgQAaPioj</a></p>&mdash; 🎃 Inven Global 🎃 (@InvenGlobal) <a href="https://twitter.com/InvenGlobal/status/1180966383737196544?ref_src=twsrc%5Etfw">October 6, 2019</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Dòng Tweet của Inven Global</p></center>

<p>Theo Blizzard, hành động của Blitzchung trong cuộc phỏng vấn đã vi phạm Quy tắc phần 6.1 (o) có nội dung:</p>

<blockquote>"Tham gia vào bất kỳ hành động nào, theo quyết định của Blizzard, khiến bạn rơi vào tình trạng bất đồng công khai, xúc phạm một nhóm người hay toàn bộ nhóm người trong công chúng, hoặc làm hỏng hình ảnh của Blizzard sẽ dẫn đến việc bị loại khỏi Grandmasters và tổng giải thưởng của người chơi bị hạ xuống còn $ 0 USD..."</blockquote>

<p>Nội dung điều luật trên <a href="https://playhearthstone.com/en-us/blog/23179289?fbclid=IwAR0p3JStIGH1B_HVQz6edcIa5Y762cOen0sqViHBvRbQ2FwGtostg08shAY" target="_blank" rel="nowfollow">trang chủ Hearthstone</a></p>

<p>Đoạn phim về cuộc phỏng vấn chính thức của Blizzard với Blizchung bị gỡ bỏ sau khi người chơi bày tỏ sự ủng hộ đối với các cuộc biểu tình ở Hồng Kông. Nhưng một số tờ báo vẫn giữ lại đoạn video này.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/N7AhGrTBjZI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận đấu cuối cùng của Blitzchung với DawN vào Chủ Nhật 6/10/2019</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/GNNF12y3_0E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Video Blitzchung kêu gọi độc lập cho Hồng Kông</p></center>

<p>"Giải phóng Hồng Kông, cuộc cách mạng của thời đại chúng ta", Wai Chung hét vào webcam của mình bằng tiếng Trung theo bản dịch của trang Inven Global. Hai bình luận viên từ Đài Bắc đã chui xuống gầm bàn của họ, nói rằng "Ok, đó là Blitz bro". Đoạn clip về vụ việc, cũng như stream phát cả ngày, đã bị xóa khỏi kênh Hearthstone của Đài Loan, có nghĩa là người dùng không còn có thể xem đoạn video trên Twitch. Đoạn video thu hút rất nhiều sự chú ý trên Reddit và Twitter, với nhiều người bàn luận trước thông điệp của Wai Chung.</p>

<center><img src="/upload/images/game/van-de-hong-kong-noi-len-trong-giai-dau-hearthstone-grandmasters-2019.jpg" width="100%" alt="Vấn đề Hồng Kông nổi lên trong giải đấu Hearthstone Grandmasters 2019" /></center></center>

<p>Blizchung nói rằng anh không hề hối hận vì quyết định này của mình. Một số khán giả bày tỏ ý kiến trái chiều. Bên thì chỉ trích Blitzchung dại dột, người thì nói Blizzard ra án phạt vì lợi nhuận, muốn game tiếp tục được kinh doanh trên thị trường Trung Quốc.</p>

<p>Bài viết của <a href="https://www.invenglobal.com/articles/9242/hong-kong-player-blitzchung-calls-for-liberation-of-his-country-in-post-game-interview" target="_blank" rel="nowfollow">Inven Global</a></p>
',

            'date_post'   => '2019-10-07',
            'thumbnail_post'    => 'van-de-hong-kong-noi-len-trong-giai-dau-hearthstone-grandmasters-2019-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Chính trị đang ảnh hưởng đến các giải đấu thể thao điện tử',
            'url_post'        => 'chinh-tri-dang-anh-huong-den-cac-giai-dau-the-thao-dien-tu',
            'present_vi_post' => 'Các giải Hearthstone, Liên Minh Huyền Thoại cấp quốc tế hiện nay đang phải chịu ảnh hưởng từ những vấn đề chính trị giữa Trung Quốc và Hồng Kông.',
            'content_vi_post' => '<p>Năm 2019 là năm chính trị ảnh hưởng nhiều đến thể thao điện tử. Nếu vào đầu năm, chính trị ảnh hưởng tốt đến thể thao điện tử Việt Nam thì cuối năm, chính trị đang ảnh hưởng tiêu cực đến khu vực Trung Quốc và Hồng Kông. Hẳn mọi người còn nhớ đầu năm 2019, tổng thống Donald Trump gặp nhà lãnh đạo Triều Tiên Kim Jong Un tại Hà Nội. Sau đó, Riot đã tổ chức vòng khởi động và vòng bảng MSI 2018 tại Việt Nam. Đây là ảnh hưởng tích cực, cho thấy Việt Nam là điểm đến an toàn và thân thiện.</p>

<p>Bài viết: <a href="/post/msi-2019-to-chuc-tai-viet-nam-khang-dinh-uy-tin-cua-viet-nam" target="_blank" rel="nowfollow">MSI 2019 tổ chức tại Việt Nam khẳng định uy tín của Việt Nam</a></p>

<p>Tuy nhiên năm nay, chính trị lại ảnh hưởng tiêu cực đến cả thế giới. Hồng Kông đang phản đối dự luật dẫn độ của Trung Quốc. Người dân Hồng Kông lo sợ dự luật dẫn độ sẽ khiến những nhà hoạt động chính trị tại Hồng Kông, nếu làm trái ý Trung Quốc sẽ bị đưa về Trung Quốc. Vì vậy, hàng loạt các cuộc biểu tình diễn ra trên khắp Hồng Kông và các thành phố khác trên thế giới.</p>

<p>Tình cờ là sự kiện chính trị nóng bỏng này lại đúng vào khoảng thời gian các sự kiện thể thao điện tử được tổ chức. Vụ việc Ng "Blitzchung" Wai Chung kêu gọi độc lập trong giải Hearthstone Grandmasters 2019 đã thêm dầu vào lửa. Blizzard ngay lập tức phạt Blitzchung và 2 caster án phạt nặng. Blitzchung đã bị cấm tham gia Hearthstone esports trong 12 tháng bắt đầu từ ngày 5/10/2019. Cả hai caster cũng bị mất việc vì phỏng vấn Blitzchung và để anh này nói "Liberate Hong Kong, revolution of our age!" (Giải phóng Hồng Kông, cuộc cách mạng của thời đại chúng ta!).</p>

<p>Tuy nhiên, lúc 0h ngày 12/10 theo giờ Việt Nam, chính chủ tịch của công ty Blizzard Entertainment, J. Allen Brack, đã có đôi lời phát biểu về những sự kiện đã diễn ra trong tuần vừa rồi. Ông nói điều mà Blizzard thừa nhận đã hơi nóng vội khi quyết định, đó là mức phạt dành cho tuyển thủ Hồng Kông Blitzchung, và hai casters. <b>Và cả ba đều được giảm mức phạt đình chỉ xuống còn 6 tháng.</b></p>

<p>Sau vụ việc này, Blizzard đã bị cả Trung Quốc, Hồng Kông lẫn thế giới tẩy chay. Hồng Kông và thế giới nói Blizzard sợ Trung Quốc nên mới ra án phạt nặng Blizzard giảm án thì bị mang tiếng sợ cộng đồng thế giới. Tiến thoái lưỡng nan, tai bay vạ gió.</p>

<p>Qua Liên Minh Huyền Thoại, chúng ta đang có giải đấu được mong đợi nhất trong năm. Chung Kết Thế Giới 2019 của Liên Minh Huyền Thoại được tổ chức tại Đức với sự tham gia của các đội trên thế giới, trong đó có 3 đội Trung Quốc và 3 đội Hồng Kông, Đài Loan. Caster của Riot đã nhắc đến Hồng Kông Attitude nhưng sau đó đổi ngay thành HKA. Khán giả cảm thấy Riot có vẻ đang muốn tránh né việc này.</p>

<center><img src="/upload/images/game/chinh-tri-dang-anh-huong-den-cac-giai-dau-the-thao-dien-tu-4.jpg" width="100%" alt="Chính trị đang ảnh hưởng đến các giải đấu thể thao điện tử" /></center></center>

<p>Đứng trước những nghi ngờ của người chơi, Trưởng ban đối thoại của Riot Games là Ryan Rigney đã đứng ra giải thích:</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">To make this as explicit as possible, we aren&#39;t telling anyone to avoid saying &quot;hong kong.&quot; We&#39;d just rather the team be referred to by its full name. There&#39;s been some confusion internally about this as well and we&#39;re working to correct it.</p>&mdash; Ryan Rigney (@RKRigney) <a href="https://twitter.com/RKRigney/status/1182054106736652288?ref_src=twsrc%5Etfw">October 9, 2019</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Dòng Tweet giải thích của Ryan Rigney</p></center>

<p>Nhiều người cho rằng vì Riot đang làm việc với Tencent nên phải lên tiếng như vậy để tránh né việc chính trị. Trên các kênh chat live stream của Twitch, Hearthstone, CKTG 2019 tràn ngập những comment #FREEFORHONGKONG. Có lẽ những ảnh hưởng này sẽ còn kéo dài đến hết giải đấu.</p>
',

            'date_post'   => '2019-10-13',
            'thumbnail_post'    => 'chinh-tri-dang-anh-huong-den-cac-giai-dau-the-thao-dien-tu-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Những thành quả mà VCS đạt được sau CKTG 2019',
            'url_post'        => 'nhung-thanh-qua-ma-VCS-dat-duoc-sau-CKTG-2019',
            'present_vi_post' => 'Kết quả đáng thất vọng trong CKTG 2019 đã làm nản lòng nhiều người. Tuy nhiên, hãy cùng nhìn lại những điểm tích cực mà GAM Esport và LowKey Esport đã mang về cho LMHT Việt Nam.',
            'content_vi_post' => '<p>Chung kết thế giới 2019 đã qua, Lowkey Esport đã không qua được vòng khởi động. GAM Esport đã dừng chân với kết quả 1-5 rất đáng thất vọng. Có lẽ trong tương lai gần, VCS khó có thể mơ đến một lần được bước vào tứ kết CKTG. Tuy nhiên, hãy cùng nhìn lại CKTG 2019 đã qua để thấy VCS đã phát triển như thế nào. Mọi cuộc hành trình đều phải đi từng bước một.</p>

<h3>Lần đầu tiên VCS chiến thắng LCK</h3>

<p>Dù nguyên nhân thua trận vẫn có phần chủ quan từ phía Damwon Gaming, nhưng việc Lowkey Esport đã có một trận thắng với Damwon Gaming ở tình huống tưởng chừng cầm chắc phần thua cho thấy VCS đã tiến một bước tiến lớn, tạo niềm tin cho các trận đấu sau giữa VCS và LCK.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Kb0gfXlAGMA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận đấu đi vào lịch sử Liên Minh Huyền Thoại Việt Nam</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/Y7MPqcspybc" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Tất cả 4 trận đấu giữa Lowkey Esport với Damwon Gaming</p></center>

<p>So sánh với CKTG 2017, Young Generation (sau này là Phong Vũ Buffalo được đi CKTG 2018 và MSI 2019) cũng đã gặp đội World Elite của LPL và kết thúc với tỉ số 0-3. Trận này vừa chứng tỏ VCS đã tiến thêm một bước nữa, vừa là trận đấu đầu tiên VCS thắng LCK.</p>

<h3>VCS có thêm nhiều tuyển thủ chất lượng</h3>

<p>Lowkey Esport lần đầu tiên tham dự CKTG đã có thành tích bất ngờ với một dàn tuyển thủ trẻ. GAM Esport cũng có rất nhiều tuyển thủ trẻ chưa từng tham gia CKTG hay các giải đấu lớn như Kiaya, Zin... Sau chuyến đi này, chắc chắn những cái tên trẻ tuổi sẽ tiếp tục phát triển và khẳng định bản thân trong các giải đấu kế tiếp.</p>

<center><img src="/upload/images/game/chinh-tri-dang-anh-huong-den-cac-giai-dau-the-thao-dien-tu-4.jpg" width="100%" alt="Những thành quả mà VCS đạt được sau CKTG 2019" /></center>

<p></p>

<center>

<p></p></center>

<p></p>
',

            'date_post'   => '2019-10-13',
            'thumbnail_post'    => 'nhung-thanh-qua-ma-VCS-dat-duoc-sau-CKTG-2019-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => 0,
            'popular'           => 0,

            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!',
            'url_post'        => 'khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to',
            'present_vi_post' => 'Khán giả chỉ là những người coi chùa, không đóng góp tiền bạc hay công sức gì cho tuyển thủ nên không được phê bình, chỉ được im lặng xem? Đó là suy nghĩ rất sai lầm.',
            'content_vi_post' => '<p><b>Bài viết này muốn giải thích cho câu hỏi: khán giả làm được gì cho các đội tuyển? Xin trả lời: rất nhiều là đằng khác.</b></p>

<p>Cứ sau mỗi giải đấu Liên Minh Huyền Thoại, mỗi lần đội nhà thất bại, các fan hâm mộ ít nhiều buông lời cay nghiệt đến tập thể đội tuyển. Tùy vào mức độ thua có thể chấp nhận được hay không mà những lời chỉ trích nặng nhẹ khác nhau. Trong CKTG 2019 vừa rồi, LowKey Esport dù bị loại tại vòng khởi động vẫn kịp ghi dấu ấn bằng trận thắng đầu tiên của VCS trước LCK. Điều mà các game thủ kỳ cựu trước đó không làm được thì tân binh của CKTG 2019 lại làm được ngay trận đầu tiên với LCK. Đó là một thành tích không thể chê trách được. Vì vậy, LowKey Esport nhận được nhiều lời động viên cố gắng từ khán giả.</p>

<p>Ngược lại, GAM Esport được cả cộng đồng Việt Nam và quốc tế đánh giá cao nhờ vào thành tích 2 năm trước của GAM 2017. Tuy nhiên, màn trình diễn vô cùng thất vọng, bạc nhược và nhạt nhòa của GAM khiến cả Việt Nam lẫn thế giới sỉ vả không thương tiếc. Thất bại 1-5 là thất bại tệ hại nhất từ khi Việt Nam vào vòng bảng CKTG 2017 đến nay. Trước đó, VCS thường xuyên ra về với tỉ số 2-4 tại CKTG và 2-8 tại MSI. Thất bại 1-5 này tệ hại chỉ sau thất bại 0-8 của Saigon Joker năm 2016 khiến đội này phải giải tán.</p>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-IWCQ.jpg" width="100%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<p>Năm 2016, giải đấu IWCQ là giải đấu tệ hại nhất của LMHT Việt Nam<br>
với kết quả 0-8 của Saigon Joker</p>

<img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-cktg-2019.jpg" width="100%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<p>Chung kết thế giới 2019 là thất bại kế tiếp khi GAM 1-5 tại bảng đấu dễ nhất.<br>
Trước đó, VCS ra về với kết quả 2-4 tại các bảng có Hàn Quốc</p></center>

<p>Những chỉ trích thậm tệ nhắm thẳng vào mọi thành viên trong đội trừ Yoshino vì Yoshino không đánh trận nào. Những lời bào chữa cùn kiểu như “mày làm gì được cho GAM mà chỉ trích?” được nói ra. Họ nghĩ rằng fan hâm mộ không đóng góp gì cho đội tuyển, cho giải đấu sao? Nhầm rồi!</p>

<h3>Mối quan hệ 3 bên</h3>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-moi-quan-he.jpg" width="100%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<p>Mối quan hệ qua lại giữa 3 bên: nhà phát hành, game thủ/khán giả và nhà tài trợ</p></center>

<p>Nhìn vào sơ đồ, chúng ta thấy 3 bên đều có quan hệ chặt chẽ. Nhà phát hành làm sao để kiếm lợi nhuận từ một tựa game không tính phí? Vài bộ trang phục giá mấy trăm ngàn có nuôi sống được cả một công ty triệu đô không? Chắc chắn chỉ có thể là tiền đầu tư từ các đối tác, nhà tài trợ.</p>

<p>Vậy nhà tài trợ muốn gì? Dĩ nhiên là họ muốn thương hiệu của họ, logo của họ lọt vào mắt càng nhiều khán giả càng tốt. Và đó là lý do Wake Up 247, Clear Men, Phong Vũ mới đổ tiền triệu tài trợ cho giải đấu, cho đội tuyển. Họ muốn marketing và eSport là một kênh truyền thông đáng để họ cân nhắc. Hãy nhớ Phong Vũ, thương hiệu thành công nhất khi đầu tư vào Liên Minh Huyền Thoại. Tên của họ được xuất hiện tại 2 giải đấu lớn nhất thế giới là CKTG 2018 và MSI 2019. Trận đấu giữa Phong Vũ Buffalo và Vega Squadron đã đạt kỷ lục về lượt xem của VETV. Nhà tài trợ còn gì vui hơn?</p>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-clear-men.jpg" width="100%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<p>Clear Men tài trợ cho giải đấu VCS Xuân 2019, tặng sản phẩm cho game thủ.<br>
Tất cả là để marketing.</p></center>

<p>Vậy nhà tài trợ quảng cáo cho ai? Còn ai ngoài khán giả? Lượt xem của khán giả, thậm chí tiền khán giả mua sản phẩm của Clear Men, Phong Vũ vào túi ai? Vào túi của nhà tài trợ. Và nhà tài trợ lấy số tiền đó tài trợ lại cho game thủ. Vậy rõ ràng, ở một góc độ nào đó, khán giả và khách hàng của nhà tài trợ gián tiếp hỗ trợ game thủ để họ có đồ ăn thức uống, cơ sở luyện tập và cả đi nước ngoài.</p>

<center><img src="/upload/images/game/VETV-374777-views-PVB-VG-MSI-2019.jpg" width="70%" alt="VETV đạt kỷ lục 374.777 lượt xem" />

<p>VETV đạt kỷ lục 374.777 lượt xem.</p></center>

<p>Sự kiện gần đây nhất là một ví dụ điển hình. Giải đấu LMHT khu vực Đông Nam Á GPL và khu vực Đài Loan vừa sát nhập vào nhau do lượng người xem quá ít. Ít người xem, ít nhà tài trợ mặn mà với giải đấu, Riot phải sát nhập để mang màu sắc mới lạ cho khán giả. Do thành tích dậm chân tại chỗ của 2 khu vực này nên Riot phải đưa ra quyết định không ai mong muốn này. Khu vực VCS còn bị khán giả chỉ trích, buồn vui chứng tỏ VCS còn được nhiều người quan tâm. Còn GPL và LMS chắc giờ đang ước được như vậy mà không được vì chẳng còn ai quan tâm nữa.</p>

<h3>Những trường hợp eSport ít người quan tâm</h3>

<p>Overwatch Việt Nam: năm 2017, Overwatch Việt Nam vinh dự được tham gia giải đấu lớn nhất thế giới của game này. Kết quả là đội tuyển Việt Nam thua trắng trước Tây Ban Nha, Phần Lan, Nhật Bản.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/qA0T97azWLg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Overwatch Việt Nam vs Nhật Bản</p></center>

<p>Còn bây giờ thì sao? Overwatch sau vài năm nổi lên giờ tàn lụi trông thấy. Vì ít người quan tâm đến game nên nhà tài trợ cũng làm gì còn? Đi thi đấu tự lo mọi thứ. Những lúc này mới thấy, nếu game được nhiều sự quan tâm hơn - tất nhiên sẽ đi kèm với chỉ trích - thì đâu có như thế này.</p>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-overwatch-viet-nam.jpg" width="70%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" /></center>

<p>Liên Quân Mobile: có thể Liên Quân rất nổi tiếng tại Việt Nam và Trung Quốc. Nhưng ở các nước khác, Liên Quân giờ đã bị chính cha đẻ Tencent bỏ rơi do lượt người chơi quá ít. Nhà vô địch Liên Quân thế giới Sun người Hàn Quốc giờ có cuộc sống khá lận đận.</p>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-lien-quan-1.jpg" width="70%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-lien-quan-2.jpg" width="70%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" />

<p>Không còn người chơi, không còn tài trợ, <br>
giải đấu đóng cửa, game thủ thất nghiệp.</p></center>

<p>Nhìn tình cảnh của Sun, chắc giờ anh chỉ ước game Liên Quân có fan chỉ trích, buồn vui cùng mình. Nhưng không, game Liên Quân ở Hàn Quốc chẳng ai quan tâm cả. Giải đấu không còn, anh phải đi làm streamer để bớt khó khăn hơn.</p>

<h3>Nhà tài trợ cần khán giả, sẵn sàng đầu tư cho các đội gây sự chú ý</h3>

<p>Mọi người có thắc mắc tại sao Tinikun lại hay có những bình luận tiêu cực không? Là vì anh muốn GAM gây được nhiều sự chú ý. Chỉ khi GAM gây nhiều sự chú ý thì nhà tài trợ mới thích và đầu tư cho GAM. Nhưng với vị trí huấn luyện viên trưởng, nếu cứ phát ngôn như vậy có thể bị riot phạt nên Tinikun nhường cho Yuna làm huấn luyện viên trưởng.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/Oq-Pq5QYQW4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Hưng Hại Não phân tích về lý do Tinikun hay có phát ngôn gây chú ý<br>
để tạo sức hút cho GAM, kiếm tài trợ.</p></center>

<p>Chứng tỏ là Tinikun cố gắng gây chú ý cho GAM kể cả khi việc đó khiến mọi người nghĩ xấu mình. Chuyện bình thường! Đây là thời đại của drama. Đội nào nhiều drama hơn thì gây nhiều sự chú ý hơn. Nhà tài trợ thích hơn liền đầu tư cho họ. Vậy đó có phải khán giả đang kiếm tiền về cho đội tuyển không?</p>

<p>Tương tự như thầy giáo Ba. Dù chưa đánh giải VCSB nhưng baroibeo cũng khoe trên stream của mình là được hãng điện thoại Realme tặng cho 1 chiếc. Tại sao lại có sự ưu ái này? Vì thầy giáo Ba là chủ kênh Youtube gần 1 triệu subscribe. Họ phải tranh thủ cơ hội này để quảng cáo.</p>

<center><img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-sbtc.jpg" width="100%" alt="Khán giả không đóng góp gì cho các tuyển thủ nên không được phê bình? Nhầm to!" /></center>

<p><b>Tóm lại: bài viết này muốn giải thích cho câu hỏi: khán giả làm được gì cho các đội tuyển? Xin trả lời: rất nhiều là đằng khác.</b> Khán giả càng chú ý đến đội nào, giải nào thì nhà tài trợ càng đổ tiền cho đội đó. Vì vậy, các đội tuyển và các giải đấu ra sức gây sự chú ý như bình luận gây tranh cãi, drama… cốt cũng là để mang tiền về cho giải, cho đội mà thôi.</p>
',

            'date_post'   => '2019-10-20',
            'thumbnail_post'    => 'khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Overwatch 2 tung trailer Zero Hour giới thiệu chế độ PvE',
            'url_post'        => 'overwatch-2-tung-trailer-zero-hour-gioi-thieu-che-do-pve',
            'present_vi_post' => 'Trailer Zero Hour giới thiệu chế độ đánh với máy với những pha hành động kịch tính và đồng đội.',
            'content_vi_post' => '<p>Sau 3 năm, Overwatch đã trải qua nhiều thăng trầm. Từ một tựa game nóng hổi khi mới ra mắt với rất nhiều nhân vật nữ nóng bỏng như D.VA, Mercy, Widowmaker, Tracer... cho đến việc Overwatch Việt Nam được tham dự giải đấu Chung Kết Thế Giới 2016. Overwatch đang dần dần mất đi sức hút với game thủ thế giới nói chung và Việt Nam nói riêng do sự nổi lên của PUBG hay các tựa game thuộc thể loại Battle Royal. </p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/qA0T97azWLg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Overwatch Việt Nam vs Nhật Bản</p></center>

<p>Ngày 1/11/2019, Blizzard vừa tung trailer mang tên "Zero Hour" giới thiệu Overwatch 2 và gameplay trailer. Thời điểm này cũng là lúc PUBG đang bị chìm xuống. Nhiều đội đã rời khỏi PUBG.</p>

<p>Trang chủ <a href="https://blizzcon.playoverwatch.com/en-us/trailer" rel="nofollow" target="_blank" title="Overwatch 2">Overwatch 2</a></p>

<center><img src="/upload/images/game/overwatch-2-tung-trailer-zero-hour-gioi-thieu-che-do-pve-1.jpg" width="100%" alt="Overwatch 2 tung trailer Zero Hour giới thiệu chế độ PvE" />

<iframe width="560" height="315" src="https://www.youtube.com/embed/GKXS_YA9s7E" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Overwatch 2 "Zero Hour"</p></center>

<p>Nội dung trailer giới thiệu Tracer, Winstons và Mei chiến đấu với đội quân người máy trong thành phố. Khi gặp trùm cuối, họ được bạn bè đến hỗ trợ và tiêu diệt thành công đối thủ. Trailer muốn giới thiệu đến khán giả về chế độ PvE (Person versus Environment) người chơi với máy và bám sát cốt truyện, từ đó Overwatch sẽ cho game thủ trải nghiệm mới về thế giới Omnic. Chế độ PvE mới này sẽ có độ khó riêng với khả năng nâng cấp của Hero để tạo ra những kĩ năng mới lạ.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/dZl1yGUetjI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Gameplay Trailer</p></center>

<p>Theo <a href="https://blizzcon.com/en-us/news/23200875" rel="nofollow" target="_blank" title="Overwatch 2">nguồn tin từ Blizzard</a></p>

<blockquote><p>Ngoài việc đụng độ với các đối thủ trong chế độ PvP, người chơi sẽ tận mắt khám phá vũ trụ Overwatch theo những cách hoàn toàn mới trong các nhiệm vụ thách thức các anh hùng trong nhóm hợp sức, tăng sức mạnh và đối mặt với các mối đe dọa bùng nổ trên toàn cầu.</p></blockquote>

<p>Overwatch 2 sẽ được ra mắt tại triển lãm Blizzcon 2019. Hãy cùng đón xem sự trở lại của Overwatch nổi tiếng năm 2016 này.</p>
',

            'date_post'   => '2019-11-02',
            'thumbnail_post'    => 'overwatch-2-tung-trailer-zero-hour-gioi-thieu-che-do-pve-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nữ game thủ Trung Quốc VKLiooon vô địch giải Hearthstone Grandmaster 2019',
            'url_post'        => 'vkliooon-becomes-first-female-hearthstone-global-champion',
            'present_vi_post' => 'Phần thưởng 500.000 USD đã thuộc về nữ game thủ Xiaomeng "VKLiooon" Li đến từ Trung Quốc. Đây là nữ game thủ đầu tiên đoạt chức vô địch Hearthstone.',
            'content_vi_post' => '<p>Ngày 2 và 3/11/2019, vòng chung kết giải Hearthstone Grandmaster 2019 đã được tổ chức tại Anaheim, California. 8 đối thủ xuất sắc nhất đến từ 4 khu vực là Châu Á - Thái Bình Dương, Mỹ, Châu Âu và Trung Quốc gặp nhau tại Hearthstone Global Finals. Và game thủ nữ duy nhất trong vòng chung kết đã trở thành nữ game thủ đầu tiên vô địch. Cô tên là Xiaomeng “VKLiooon” Li. Đối thủ trong trận chung kết của cô là Brian "bloodyface" Eason.</p>

<p>Thông tin về giải đấu và lịch thi đấu tại <a href="https://playhearthstone.com/en-us/esports/tournament/global-finals-2019/" rel="nofollow" target="_blank" title="Hearthstone Grandmaster 2019 VKLiooon bloodyface">trang chủ Hearthstone</a></p>

<center><img src="/upload/images/game/lich-thi-dau-hearthstone-grandmaster-2019.jpg" width="100%" alt="Hearthstone Grandmaster 2019 VKLiooon bloodyface" /></center>

<h3>Thông tin về <a href="https://playhearthstone.com/en-us/esports/profile/11409/" target="_blank">VKLiooon</a></h3>

<center><img src="/upload/images/game/nu-game-thu-trung-quoc-vkliooon-vo-dich-giai-hearthstone-grandmaster-2019-VKLiooon.jpg" width="100%" alt="Hearthstone Grandmaster 2019 VKLiooon bloodyface" /></center>

<p>VKLiooon đã có mặt trong cộng đồng Hearthstone Trung Quốc một thời gian, nhưng bắt đầu kiếm được các vị trí đặc biệt cao vào năm 2019, bao gồm cả vòng chung kết của Hearthstone Global Finals. Cô ấy là một người chơi rất kiên định và có thể nắm bắt các vấn đề phức tạp của meta chỉ trong vài ngày. Con đường trở thành một người chơi chuyên nghiệp của cô bắt đầu với việc bình luận, stream và tạo nội dung.</p>

<center><img src="/upload/images/game/nu-game-thu-trung-quoc-vkliooon-vo-dich-giai-hearthstone-grandmaster-2019-VKLiooon-1.jpg" width="100%" alt="Hearthstone Grandmaster 2019 VKLiooon bloodyface" /></center>

<h3>Thông tin về <a href="https://playhearthstone.com/en-us/esports/profile/7762" target="_blank">bloodyface</a></h3>

<center><img src="/upload/images/game/nu-game-thu-trung-quoc-vkliooon-vo-dich-giai-hearthstone-grandmaster-2019-bloodyface.jpg" width="100%" alt="Hearthstone Grandmaster 2019 VKLiooon bloodyface" /></center>

<p>Bloodyface đã đủ điều kiện để trở lại giải Seasonal Championships năm 2018 và gần đây anh tham gia tại Giải vô địch thế giới HCT 2019 ở Đài Bắc vào ngày 5-8/3/2019. Anh ta coi sức mạnh lớn nhất của mình là kiến thức về trận đấu và metagame. Bloodyface có 4 con mèo (Holo, Happy, Jili và Tiny) và một tàu lượn đường có tên là Mochi.</p>

<center><img src="/upload/images/game/nu-game-thu-trung-quoc-vkliooon-vo-dich-giai-hearthstone-grandmaster-2019-bloodyface-1.jpg" width="100%" alt="Hearthstone Grandmaster 2019 VKLiooon bloodyface" /></center>

<h3>Diễn biến trận đấu</h3>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/tmPx1O1-t9k" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Chung kết Hearthstone Grandmaster 2019 giữa VKLiooon vs bloodyface</p></center>

<h3>Trận 1: bloodyface Druid vs VKLiooon Shaman (06:15 trong video)</h3>

<p>Lá Evolve giúp VKLiooon có 5 minions chỉ số đẹp trên bàn từ turn 4. Với việc liên tục duy trì lượng minions lớn trên bàn, cô dễ dàng triệu hồi Sea Giant. Trận đấu đã được định đoạt dễ dàng khi trên tay bloodyface không có lá nào để phòng thủ và chấp nhận đầu hàng trong turn 6. Một trận đấu may mắn của VKLiooon.</p>

<h3>Trận 2: bloodyface Shaman vs VKLiooon Druid (20:30 trong video)</h3>

<p>Trận đấu diễn ra suôn sẻ có đến turn 9, bloodyface bắt đầu dọn được bàn và Evolve. VKLiooon đã dọn được bàn do máu của minions đối thủ không cao như trận trước. Khi minions bị dọn hết và bài trên tay không còn, Shaman không thể đánh lại Druid top deck và bloodyface tiếp tục thua trận thứ 2.</p>

<h3>Trận 3: bloodyface Druid vs VKLiooon Hunter</h3>

<p>4 turn đầu, VKLiooon tiếp tục may mắn khi có bài tốt và làm bloodyface còn 18 máu. Tình thế bất lợi kéo đến turn 7, bloodyface được cứu bởi Hidden Oasis hồi máu và triệu hồi taunt 6/6. Nhưng VKLiooon đã dập tắt hy vọng nhỏ nhoi đó với lá secret Pressure Plate tiêu diệt taunt 6/6 đó ngay trong turn 7. Cuối cùng, lượng sát thương quá nhiều từ trên bàn và trên tay đã mang về chiến thắng dễ dàng thứ 3, giúp VKLiooon trở thành nữ game thủ đầu tiên vô địch một giải đấu Hearthstone.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/s88UNNpz9GQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Phỏng vấn game thủ Xiaomeng "VKLiooon" Li </p></center>

<p>Trong lúc phỏng vấn, cô đã khóc vì vui sướng. Cô được hỏi rằng cô muốn nói gì khi cô là người phụ nữ đầu tiên giành được giải thưởng lớn nhất của Hearthstone: "Tôi muốn nói với tất cả những cô gái ngoài kia có ước mơ thi đấu Esports, vì vinh quang, nếu bạn muốn làm điều đó và bạn tin vào chính mình, bạn chỉ cần quên đi giới tính của mình và đi theo nó."</p>
',
            'date_post'         => '2019-11-03',
            'thumbnail_post'    => 'vkliooon-becomes-first-female-hearthstone-global-champion-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Blazblue Cross Tag Battle giới thiệu Yumi trong Senran Kagura',
//             'url_post'        => 'blazblue-cross-tag-battle-gioi-thieu-yumi-trong-senran-kagura',
//             'present_vi_post' => 'Yumi trong Senran Kagura đã xuất hiện trong game Blazblue Cross Tag Battle',
//             'content_vi_post' => '<p>Blazblue Cross Tag Battle là game......................</p>

// <center><iframe width="100%" height="350" src="https://www.youtube.com/embed/PjypSC3fPd0" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

// <p>Video giới thiệu Yumi trong game Blazblue Cross Tag Battle</p></center>

// https://nichegamer.com/2019/08/04/blazblue-cross-tag-battle-adds-new-dlc-characters-yumi-blitztank-akatsuki-and-neopolitan/

// https://store.steampowered.com/app/702890/BlazBlue_Cross_Tag_Battle/


// <center><img src="/upload/images/game/blazblue-cross-tag-battle-gioi-thieu-yumi-trong-senran-kagura-1.jpg" width="70%" alt="Blazblue Cross Tag Battle giới thiệu Yumi trong Senran Kagura" /></center>

// <p></p>

// <p>Trang chủ <a href="https://blizzcon.playoverwatch.com/en-us/trailer" rel="nofollow" target="_blank" title="Overwatch 2">Overwatch 2</a></p>

// <center><iframe width="100%" height="350" src="https://www.youtube.com/embed/a2Qw-ztFrK4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

// <p>Trailer Blazblue Cross Tag Battle</p></center>

// <p></p>

// <p></p>

// <p></p>

// <p></p>
// ',

//             'date_post'   => '2019-11-03',
//             'thumbnail_post'    => 'nu-game-thu-trung-quoc-vkliooon-vo-dich-giai-hearthstone-grandmaster-2019-thumbnail.jpg',
//             'id_cat_post' => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'            => 0,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

//         posts::create([
//             'name_vi_post'    => 'Dragon Ball Z: Kakarot - Majin Buu Arc giới thiệu trailer',
//             'url_post'        => 'dragon-ball-z-kakarot-majin-buu-arc-gioi-thieu-trailer',
//             'present_vi_post' => 'Yumi trong Senran Kagura đã xuất hiện trong game Blazblue Cross Tag Battle',
//             'content_vi_post' => '<p>Blazblue Cross Tag Battle là game......................</p>

// <center><iframe width="100%" height="350" src="https://www.youtube.com/embed/_G-G71KEhuU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

// <p>Dragon Ball Z: Kakarot - Majin Buu Arc Trailer</p></center>






// <center><img src="/upload/images/game/blazblue-cross-tag-battle-gioi-thieu-yumi-trong-senran-kagura-1.jpg" width="70%" alt="Blazblue Cross Tag Battle giới thiệu Yumi trong Senran Kagura" /></center>

// <p></p>

// <center>

// <p>Trailer Blazblue Cross Tag Battle</p></center>

// <p></p>

// <p></p>

// <p></p>

// <p></p>
// ',

//             'date_post'   => '2019-11-17',
//             'thumbnail_post'    => 'dragon-ball-z-kakarot-majin-buu-arc-gioi-thieu-trailer-thumbnail.jpg',
//             'id_cat_post' => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'            => 0,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

        posts::create([
            'name_vi_post'    => "Navel ra mắt trailer Shuffle! episode 2",
            'url_post'        => 'navel-ra-mat-trailer-shuffle-episode-2',
            'present_vi_post' => 'Đội ngũ làm game phần 1 tiếp tục làm phần 2.',
            'content_vi_post' => '<p>Công ty game Navel đã tung trailer game Shuffle! episode 2 vào ngày 23/3/2020. Trước đó, vào năm 2019, công ty cũng đã thông báo game Shuffle! sẽ có phần 2.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/riM7-us-I64" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/cINKG3RpzZI" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer game SHUFFLE! phần 2 của Navel</p></center>

<p>Đội ngũ làm game phần 1 tiếp tục tham gia làm phần 2 này. Baria Ago tạo bản nháp, Takeuchi Kouta, Higashinosuke và Fuwabara Fumihiko viết kịch bản.</p>

<center><img src="/upload/images/game/navel-ra-mat-trailer-shuffle-episode-2-1.jpg" width="100%" alt="Shuffle! episode 2" /></center>

<p>Shuffle! là dự án visual novel đầu tiên của Navel. Game được đưa lên Steam vào năm 2016. Navel đã phát hành game đầu tiên trên PC vào năm 2004, trên PS2 vào năm 2005 và bản mở rộng trên PC vào năm 2009. MangaGamer phát hành game bằng tiếng Anh vào năm 2009. Shuffle! cũng có phiên bản Anime vào năm 2008 do Funimation công chiếu.</p>

<p>Trang chủ: <a href="https://project-navel.com/shuffle_ep2/" rel="nofollow" target="_blank" title="">Shuffle! episode 2</a></p>

<center><img src="/upload/images/game/navel-ra-mat-trailer-shuffle-episode-2-2.jpg" width="100%" alt="Shuffle! episode 2" /></center>

<p>Cốt truyện: khi thế giới loài người phát hiện ra cánh cổng nối với thế giới của các vị thần và thế giới của ác quỷ, 3 thế giới đã kết nối với nhau.

Nam chính Rin sống trong một thị trấn nhỏ cùng với 5 cô gái, những người đã yêu cậu từ nhỏ.
Nhiều năm trước, 2 cô gái đã gặp cậu chỉ trong một khoảnh khắc và không ai trong số họ có thể quên cuộc gặp gỡ định mệnh đó. Họ tiếp tục giữ hình ảnh cậu trong lòng. Họ chính là công chúa của vua của các vị thần và con gái quỷ vương.</p>

<p>"The man who can become either God, Demon, or Human." - Cậu ta có thể trở thành Thần, Quỷ hoặc Người.</p>

<p>Game sẽ được ra mắt vào tháng 5/2020.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/9GQF1_PUTqE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Opening Shuffle! bản anime</p></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2019-05-01/navel-makes-shuffle-episode-2-game/.146302" rel="nofollow" target="_blank" title="Shuffle! episode 2">Anime News Network</a></p>
',
            'date_post'    => '2019-11-28',
            'thumbnail_post'     => 'navel-ra-mat-trailer-shuffle-episode-2-thumbnail.jpg',
            'id_cat_post'  => GAME_POST,
            'signature'          => 0,
            'author'             => 'NVHAI',
            'views'              => random_int(50,500),
            'enable'             => ENABLE,
            'popular'            => 0,
			'update'             => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Esport Sea Games 30 Hearthstone ',
//             'url_post'        => 'esport-sea-games-30-hearthstone',
//             'present_vi_post' => 'Việt Nam có 2 đại diện tham gia Esport Sea Games 30 bộ môn Hearthstone.',
//             'content_vi_post' => '<p>Sea Games 30 được tổ chức tại Philippines là kỳ Sea Games đầu tiên Esports được tham gia thi đấu với 6 bộ môn: DOTA2, Tekken, StarCraft II và HearthStone, Mobile Legends: Bang Bang và Liên Quân Mobile. Trong đó, StarCraft II và Liên Quân Mobile được kỳ vọng sẽ đem về huy chương vàng cho Việt Nam.</p>




// <center><iframe width="560" height="315" src="https://www.youtube.com/embed/_G-G71KEhuU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

// <p></p></center>






// <center><img src="/upload/images/game/esport-sea-games-30-2019.jpg" width="70%" alt="Esport Sea Games 30 Hearthstone" /></center>

// <p></p>

// <center>

// <p></p></center>

// <p></p>

// <p></p>

// <p></p>

// <p></p>
// ',

//             'date_post'         => '2019-12-10',
//             'thumbnail_post'    => 'esport-sea-games-30-hearthstone-thumbnail.jpg',
//             'id_cat_post'       => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'            => 0,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

        posts::create([
            'name_vi_post'    => 'Pokémon Sword and Shield có 7 phim anime ngắn của Studio Colorio',
            'url_post'        => 'pokemon-sword-and-shield-co-7-phim-anime-ngan-cua-studio-colorio',
            'present_vi_post' => 'Một bộ anime khác về nhóm nhạc idol 10 thành viên đã có trailer.',
            'content_vi_post' => '<p>Nintendo đã tiết lộ vào ngày 13/12/2019 rằng trò chơi nhập vai Pokemon Sword and Shild trên Nintendo Switch của họ sẽ có 7 phim anime ngắn trong 5 phút với tiêu đề Hakumei no Tsubasa (Pokémon: Twilight Wings) của Studio Colorido. Tập đầu tiên sẽ ra mắt trên YouTube vào ngày 15/1/2020. Mỗi tập phim mới sẽ ra mắt mỗi tháng.</p>

<center><img src="/upload/images/game/pokemon-sword-and-shield-co-7-phim-anime-ngan-cua-studio-colorio-1.jpg" width="100%" alt="Pokémon Sword and Shield Studio Colorio" /></center>

<p>Công ty Pokémon International mô tả ngắn:</p>

<blockquote><p>Galar là một khu vực nơi các trận chiến Pokémon đã phát triển thành một cảm giác văn hóa. Trải qua bảy tập phim, Pokémon: Twilight Wings sẽ thể hiện chi tiết những giấc mơ của cư dân Galar, thực tế mà họ phải đối mặt, những thách thức họ phải vượt qua và những xung đột họ phải giải quyết. Ngoài những câu chuyện mới này, người hâm mộ có thể mong chờ được thấy nhiều loại Pokémon ban đầu được phát hiện ở vùng Galar xuất hiện trong series.</p></blockquote>

<p>Yamashita Shingo, đạo diễn của League of Legends: A New Journey, Yozakura Quartet, Fate/Apocrypha. Kinoshita Sawa viết kịch bản và Kishimoto Taku giám sát kịch bản.</p>

<p>Trò chơi đã được phổ biến trên toàn thế giới từ ngày 15/11/2019. Doanh số bán được tại Nhật trong tuần đầu tiên là 2 triệu bản. Đó cũng là doanh số tại Mỹ trong 2 ngày đầu tiên. Trò chơi đã bán được hơn 6 triệu bản trên toàn thế giới trong tuần đầu tiên. Pokémon Sword and Shield đã phá vỡ các kỷ lục về doanh số cao nhất trong tuần đầu tiên của một trò chơi trên nền tảng Switch.</p>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2019-12-13/pokemon-sword-shield-games-get-7-net-anime-shorts-by-studio-colorido/.154304" rel="nofollow" target="_blank" title="Pokémon Sword and Shield Studio Colorio">Anime News Network</a></p>
',
            'date_post'         => '2019-12-11',
            'thumbnail_post'    => 'pokemon-sword-and-shield-co-7-phim-anime-ngan-cua-studio-colorio-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Kandagawa Jet Girls ra mắt trailer hệ máy PS4',
            'url_post'        => 'kandagawa-jet-girls-ra-mat-trailer-he-may-ps4',
            'present_vi_post' => 'Đồ họa và lối chơi khá giống với series Senran Kagura. Game sẽ được ra mắt vào ngày 16/1/2020',
            'content_vi_post' => '<p>Sau thành công của bộ anime cùng tên ra mắt vào mùa Thu 2019, Kandagawa Jet Girls (tên tiếng Nhật là 神田川JET GIRLS) đã tung ra trailer game PS4 trên kênh của hãng Marvelous. Game sẽ được ra mắt vào ngày 16/1/2020</p>

<p>Game nói về các cô gái đua với nhau trên moto nước. Một người là Jetter (tay lái xe trượt nước) và Shooter (tay súng) trong một cuộc đua xe trượt nước trên dòng sông Kandagawa nổi tiếng của Tokyo, Nhật Bản.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/HqViKllrIv4" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Kandagawa JET GIRLS [ 神田川JET GIRLS ]</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/ce5j74K4-mQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Gameplay đầu tiên được ra mắt vào tháng 9/2019</p></center>

<p>Trò chơi sẽ có phiên bản giới hạn bao gồm một gói có nét vẽ của Hanaharu Naruko, bản đĩa Blu-ray của anime mang tên "Koko kara Hajimaru Tokyo Girls Promotion", 2 đĩa nhạc soundtrack, art book và mã DLC để thêm các nhân vật Yumi và Asuka trong series Senran Kagura vào trò chơi.</p>

<center><img src="/upload/images/game/kandagawa-jet-girls-ra-mat-trailer-he-may-ps4-yumi-asuka.jpg" width="100%" alt="Kandagawa Jet Girls ra mắt trailer hệ máy PS4" /></center>

<img src="/upload/images/game/kandagawa-jet-girls-ra-mat-trailer-he-may-ps4-yumi-asuka-1.jpg" width="100%" alt="Kandagawa Jet Girls ra mắt trailer hệ máy PS4" /></center>

<p>Yumi và Asuka trong Senran Kagura cũng có thể xuất hiện trong Kandagawa JET GIRLS</p></center>

<p>Dự án bắt đầu với 12 tập anime được chiếu vào ngày 8/10/2019. Sasahara Yuu và Kohara Riko, seiyuu của Namiki Rin and Aoi Misa cũng góp giọng vào bài hát chủ đề "Kyoukaisen Girls" (Boundary Line Girls).</p>

<center><img src="/upload/images/game/kandagawa-jet-girls-ra-mat-trailer-he-may-ps4-1.jpg" width="100%" alt="Kandagawa Jet Girls ra mắt trailer hệ máy PS4" /></center></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2020-01-08/kandagawa-jet-girls-ps4-game-prologue-video-streamed/.155129" rel="nofollow" target="_blank" title="Kandagawa Jet Girls ra mắt trailer hệ máy PS4">Anime News Network</a></p>
',
            'date_post'         => '2020-01-07',
            'thumbnail_post'    => 'kandagawa-jet-girls-ra-mat-trailer-he-may-ps4-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Joker xuất hiện trong MORTAL KOMBAT 11',
            'url_post'        => 'joker-xuat-hien-trong-mortal-kombat-11',
            'present_vi_post' => 'Ngoài ra còn có Killer Croc, Batman Who Laughs, Cat Woman và Darkside',
            'content_vi_post' => '<p>NetherRealm Studios đã phát hành đoạn trailer cho nhân vật DC thứ 5 trong game đối kháng đầy bạo lực Mortal Kombat 11. Bước ra khỏi các thành viên MK thông thường, kombatant tiếp theo không ai khác chính là anh chàng Clown Prince of Crime của DC Comics, Joker.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/DXjRFCPiFoA" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

<p>Được biết đến với hành vi tàn nhẫn, giết người, hài hước, tâm lý và 11 đề cử giải Oscar, Joker sẽ mang đến sự pha trộn độc đáo của riêng mình giữa hài kịch và bạo lực cực độ cho vũ trụ Mortal Kombat. Đây không phải là lần đầu Joker xuất hiện chung với MORTAL KOMBAT. Joker đã có mặt vào năm 2008 trong Mortal Kombat vs. DC Universe.</p>

<center><img src="/upload/images/game/joker-xuat-hien-trong-mortal-kombat-11-joker.jpg" width="100%" alt="Joker MORTAL KOMBAT 11" />

<p>Joker trong MORTAL KOMBAT 11</p></center>

<p>Chuyển động của Joker trông hoang dã, thú vị và sáng tạo với những chiêu hài hước như nắm đấm lò xo. Nhưng hoạt ảnh cơ thể của Joker rất cứng nhắc, đặc biệt là chuyển động của đầu và cổ.</p>

<p>Cùng với việc ra mắt Joker, các skin có nhân vật phản diện trong DC mới sẽ được cung cấp cho một số nhân vật. Những nhân vật này bao gồm Baraka trong vai Killer Croc, Kitana trong vai Cat Woman, Noob Saibot trong vai Batman Who Laughs và Geras trong vai Darkseid.</p>

<center><img src="/upload/images/game/joker-xuat-hien-trong-mortal-kombat-11-batman-who-laughs.jpg" width="100%" alt="Batman Who Laughs MORTAL KOMBAT 11" />

<p>Batman Who Laughs, Killer Croc và Cat Woman trong MORTAL KOMBAT 11</p></center>

<p>Các fan hâm mộ dù than vãn về việc cho nhiều nhân vật của các vũ trụ khác vào game, nhưng mỗi pack mới của MORTAL KOMBAT vẫn mang lại thành công nhất định về mặt tài chính. Năm 2019, game cũng cho một pack dành cho nhân vật T-800 Terminator do chính Arnold Schwarzenegger thủ vai.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/kVh8LojWtYQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<img src="/upload/images/game/joker-xuat-hien-trong-mortal-kombat-11-T800-Terminator.jpg" width="100%" alt="T-800 Terminator Arnold Schwarzenegger MORTAL KOMBAT 11" />

<p>"You will be terminated"</p></center>
',
            'date_post'         => '2020-01-16',
            'thumbnail_post'    => 'joker-xuat-hien-trong-mortal-kombat-11-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Ubisoft chuẩn bị mở studio mới tại Việt Nam',
            'url_post'        => 'ubisoft-prepares-to-open-new-studio-in-vietnam',
            'present_vi_post' => 'Studio mới sẽ được mở tại thành phố Đà Nẵng, với sức chứa hơn 100 nhân viên.',
            'content_vi_post' => '<p>Ubisoft mới đây đã công bố kế hoạch mở một studio tại thành phố Đà Nẵng, Việt Nam, tập trung vào việc tạo ra các game di động gốc và trò chơi tức thời cho các nền tảng truyền thông xã hội. Hãng phim có kế hoạch tuyển dụng khoảng 100 nhân viên trong 3 năm tới để hợp tác với các nhóm di động Ubisoft trên toàn thế giới, tạo ra các game đã được nhượng quyền trong một thành phố đang bùng nổ.</p>

<p>Trang chủ: <a href="https://www.ubisoft.com/en-us/" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Ubisoft</a></p>

<center><img src="/upload/images/game/ubisoft-prepares-to-open-new-studio-in-vietnam-1.jpg" width="100%" alt="Ubisoft chuẩn bị mở studio mới tại Việt Nam" />

<p>Không gian studio Ubisoft tại Đà Nẵng.</p></center>

<h3>Tại sao lại chọn Đà Nẵng?</h3>

<p>"Đà Nẵng là một nơi tuyệt vời để định cư, và người dân ở đây nổi tiếng về lòng tốt và sự hào phóng", giám đốc điều hành studio của hãng, Aurelien Palasse chia sẻ trong thời gian chuẩn bị cho việc khai trương studio. "Đó là một thành phố hiện đại, phát triển mỗi ngày, nhưng vẫn duy trì được cảm giác cộng đồng của một thị trấn nhỏ".</p>

<p>Trong những năm gần đây, Việt Nam - và đặc biệt là Đà Nẵng - đã chứng kiến sự bùng nổ trong thị trường công nghệ của mình, với sự đầu tư lớn trong khu vực của các công ty công nghệ và trò chơi. Khu vực này là quê hương của một số trường đại học khoa học và công nghệ hàng đầu của đất nước, bao gồm Đại học Đà Nẵng.</p>

<p>"Đại học Đà Nẵng là một trong những trường tốt nhất đất nước, và chính phủ địa phương cam kết phát triển ngành công nghệ ở đây là sự hấp dẫn lớn đối với nhiều công ty". Ông Palasse chia sẻ. "Vị trí này rất hoàn hảo, ngay giữa thủ đô Hà Nội và thành phố Hồ Chí Minh, vì vậy nơi đây thu hút rất nhiều nguồn tài năng lớn. Đà Nẵng cũng cung cấp những sự thay thế tuyệt vời cho các thành phố lớn, với sự cân bằng lý tưởng giữa chất lượng cuộc sống và công việc. Có rất nhiều lý do chính đáng và chúng tôi rất vui mừng là một phần của sự phát triển ở đây."</p>

<h3>Giữ vững giữa môi trường toàn cầu với dấu ấn địa phương</h3>

<center><img src="/upload/images/game/ubisoft-prepares-to-open-new-studio-in-vietnam-2.jpg" width="100%" alt="Ubisoft chuẩn bị mở studio mới tại Việt Nam" /></center>

<p>Thị trường game Đông Nam Á là một trong những thị trường phát triển nhanh nhất trên toàn thế giới. Các quán cà phê Internet ở Việt Nam đã trở thành các trung tâm phổ biến nơi mọi người đến chơi và gặp gỡ, và game di động ngày càng phổ biến do sự bùng nổ công nghệ gần đây. Điều này đặt Ubisoft Đà Nẵng vào trung tâm của một thị trường đang mở rộng, với một cộng đồng lớn dần lên cùng các trò chơi và công nghệ là một phần trong cuộc sống và văn hóa của họ.</p>

<p>"Chúng tôi đang nói chuyện với một số trường đại học địa phương và tìm ra cách để chúng ta có thể làm việc cùng nhau", Palasse nói. "Hợp tác và đầu tư vào chuyên môn địa phương là một phần cốt lõi của Ubisoft DNA. Tôi rất phấn khích vì nhóm của chúng tôi làm việc với cộng đồng địa phương, học hỏi từ họ và truyền đạt kiến thức của chúng tôi. Ví dụ, chúng tôi đã nói chuyện với Đại học Đà Nẵng về sự kiện Dev Days hàng năm của họ, nơi ngành công nghiệp công nghệ địa phương cùng nhau gặp gỡ và chia sẻ, để xem chúng tôi có thể đóng góp như thế nào. Từ các sự hợp tác với các công ty khởi nghiệp trên toàn thế giới như là một phần của Ubisoft Entrepreneur&apos;s Lab - gần đây đã mở rộng sang Singapore - để hỗ trợ sinh viên tốt nghiệp. Và sinh viên, giáo dục và hợp tác là trung tâm của tầm nhìn của Ubisoft cho tương lai của ngành giải trí. Gần đây, Ubisoft đã tổ chức một loạt các sự kiện mang tên Keys To Learn, làm sáng tỏ những nỗ lực hỗ trợ giáo dục, cải thiện xã hội và làm sao để các trò chơi có thể trở thành một lực lượng tốt đẹp".</p>

<center><img src="/upload/images/game/ubisoft-prepares-to-open-new-studio-in-vietnam-3.jpg" width="100%" alt="Ubisoft chuẩn bị mở studio mới tại Việt Nam" /></center>

<p>Văn phòng mới xây nằm ở trung tâm thành phố trên đường Trần Phú, là một không gian tràn đầy ánh sáng. Bên bờ sông Hàn, chỉ cách bờ biển Việt Nam và bãi biển Mỹ Khê xinh đẹp, một sân thượng nhìn ra thành phố sẽ là nơi thư giãn, ngắm cảnh núi non, rừng rậm và đại dương. Một giảng đường đã được thiết kế thành một không gian để tổ chức các bản cập nhật hàng tuần có chỗ cho đội nhóm hay cá nhân, minh chứng cho sự hợp tác sẽ là chìa khóa cho cả nhóm. Nơi đây được thiết kế với các khu vực thư giãn, vui chơi và giao lưu, bao gồm các không gian làm việc mở, hiện đại với tất cả các tiện nghi của một studio Ubisoft tiên tiến.</p>

<p>"Văn phòng đẳng cấp quốc tế như bất kỳ studio Ubisoft nào khác trên toàn thế giới", Palasse nói. "Đây là một nhóm hợp tác nhanh nhẹn và tôi rất vui mừng được chào đón tất cả mọi người! Chúng tôi vẫn tiếp tục đến phút chót để tạo nên một không gian độc đáo và thú vị, nơi các nhóm có thể làm việc với cảm giác thoải mái. Một phần trong số đó là cung cấp không gian giúp các team thư giãn và giao lưu với nhau, cũng như tạo ra các trò chơi tuyệt vời. Đây sẽ là một môi trường rất lành mạnh, một nơi thú vị để tạo ra các trò chơi team building."</p>

<p>Bạn quan tâm đến việc tham gia đội ngũ của Ubisoft Đà Nẵng? Hãy <a href="https://www.ubisoft.com/en-US/careers/search.aspx" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">kiểm tra các vị trí có sẵn</a> và ứng tuyển ngay bây giờ.
Theo dõi cuộc sống tại Ubisoft trên
<a href="https://twitter.com/LifeatUbisoft" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Twitter</a>,
<a href="https://www.instagram.com/lifeatubisoft/" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Instagram</a> và
<a href="https://www.facebook.com/LifeAtUbisoft/" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Facebook</a>

để biết thêm thông tin về của Ubisoft và tiếp tục kiểm tra lại tại đây để biết thêm tin tức về Ubisoft Đà Nẵng trong tương lai.</p>

<p>Ubisoft Entertainment S.A. là một hãng chuyên phát hành và phát triển game đa hệ máy, với trụ sở đặt tại Montreuil-sous-Bois, Pháp. Được thành lập vào năm 1986, Ubisoft là một hãng toàn cầu với các studio phát triển game trên 17 quốc gia và các công ty con tại 28 quốc gia.</p>

<p>Những tựa game của Ubisoft: <a href="/post/Heroes-of-Might-and-Magic-V" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Heroes of Might and Magic V</a>,
series Assassin&apos;s Creed, Tom Clancy nổi tiếng.</p>

<div class="td-post-source-via ">
    <div class="td-post-small-box"><span>Nguồn</span>
    <a href="https://news.ubisoft.com/en-us/article/2BrwkwYOOig6efinLAcnhp/ubisoft-prepares-to-open-new-studio-in-vietnam" rel="nofollow" target="_blank" title="Ubisoft chuẩn bị mở studio mới tại Việt Nam">Ubisoft</a>
    </div>
</div>
',

            'date_post'         => '2020-01-17',
            'thumbnail_post'    => 'ubisoft-prepares-to-open-new-studio-in-vietnam-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Những giải đấu eSport chịu ảnh hưởng vì virus Corona',
            'url_post'        => 'nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona',
            'present_vi_post' => 'LPL đã có thông tin chính thức, LCK đang chuẩn bị cho tình huống xấu. Vậy còn VCS?.',
            'content_vi_post' => '<p>Virus Corona đang hoành hành khắp Trung Quốc và đang dần lan sang các quốc gia khác, trong đó có Việt Nam. Một số giải đấu thể thao hay sự kiện mang tầm quốc tế tại Trung Quốc đã bị hoãn, đổi địa điểm hay hủy bỏ như vòng loại bóng đá nữ Olympic 2020 phải đổi địa điểm vì virus Corona, phim Tết tại Trung Quốc và Singapore hoãn chiếu hay cả dịp Tết Nguyên Đán của Trung Quốc cũng bị hủy. Vậy eSport đã bị ảnh hưởng ra sao bởi dịch virus Corona?</p>

<center><img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-infographic.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" /></center>

<h3>LPL Mùa Xuân 2020</h3>

<p>Theo kế hoạch, các đội tuyển LPL sẽ trở lại thi đấu vào ngày 5/2/2020, nhưng do sự bùng phát của dịch bệnh virus Corona, LPL sẽ bị tạm hoãn vô thời hạn cho đến khi có thông báo mới từ Riot Games.</p>

<p>Bên cạnh LPL, giải đấu cho các đội tuyển LMHT trẻ của Trung Quốc là LDL cũng sẽ bị hoãn ngày khai mạc. Theo như một số nguồn tin, rất có thể LPL Mùa Xuân 2020 sẽ bị hoãn đến tháng 3 hoặc tháng 4 năm nay. Nếu tình hình bệnh dịch xấu đi, LPL có thể làm trễ thời gian tổ chức MSI 2020. Thật may mắn khi MSI 2020 sẽ được tổ chức tại Hàn Quốc.</p>

<center><img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-ig-ning.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Nội dung của IG Ning trên Weibo</p>

<img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-ig.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Nội dung của IG trên Weibo</p></center>

<p>IG Ning đăng tải trên Weibo với nội dung: “Vũ Hán cố lên, mọi người ra đường nhớ đeo khẩu trang nhé”, nhằm hưởng ứng phong trào phòng chống đại dịch cúm Corona. Ảnh: iG - Invictus Gaming Vietnam Fanpage</p>

<p>Các bình luận viên nước ngoài tại Trung Quốc cũng đã rút khỏi nước này, bao gồm Jake "Hysterics" Osypenko, Oisin "Penguin" Molloy, Joe "Munchables" Fenny và Rob "Dagda" Price. Một số quốc gia châu Âu đã đề nghị Trung Quốc hỗ trợ công dân của họ rời Trung Quốc để tránh dịch virus Corona. 4 bình luận viên trên đều được các quốc gia châu Âu đề nghị,</p>

<center><img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-munch.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-munch-1.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Bình luận của Munch trên Twitter</p>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">An update from the <a href="https://twitter.com/lplenglish?ref_src=twsrc%5Etfw">@lplenglish</a> caster crew regarding the <a href="https://twitter.com/hashtag/coronarvirus?src=hash&amp;ref_src=twsrc%5Etfw">#coronarvirus</a>. <a href="https://twitter.com/PenguinCasts_?ref_src=twsrc%5Etfw">@PenguinCasts_</a> <a href="https://twitter.com/DagdaCasts?ref_src=twsrc%5Etfw">@DagdaCasts</a> <a href="https://twitter.com/HystericsCasts?ref_src=twsrc%5Etfw">@HystericsCasts</a> <a href="https://t.co/E0vKdsH4Ri">pic.twitter.com/E0vKdsH4Ri</a></p>&mdash; Munch (@HeyMunchables) <a href="https://twitter.com/HeyMunchables/status/1221737418014908416?ref_src=twsrc%5Etfw">January 27, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<h3>LCK Mùa Xuân 2020</h3>

<p>Theo <a href="http://world.kbs.co.kr/service/news_view.htm?lang=v&Seq_Code=44425" rel="nofollow" target="_blank" title="Những giải đấu eSport chịu ảnh hưởng vì virus Corona">KBS World Radio</a>, đã có bệnh nhân thứ 18 bị xác nhận là bị nhiễm phải virus này. Vì vậy, LCK 2020 cũng bị hoãn thi đấu. Ban tổ chức LCK cũng phải có những sự chuẩn bị cần thiết trước sự lan rộng trên phạm vi toàn cầu của virus Corona. Đại diện của LCK cho biết: "Chúng tôi đã có sự chuẩn bị kỹ lưỡng trong bối cảnh hiện tại và cân nhắc có thể sẽ tạm hoãn giải đấu để đảm bảo an toàn. Nếu có bất cứ thay đổi nào, BTC sẽ thông báo ngay lập tức."</p>

<center><img src="/upload/images/game/nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-lck-2020.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" /></center>

<p>Trước mắt, vào ngày 5/2/2020, trận đấu mở màn là T1 vs DWG vẫn sẽ được tổ chức. Nhưng nếu dịch Corona vẫn tiếp tục bùng phát, Riot Hàn Quốc cũng sẽ phải đưa ra những biện pháp nhằm đảm bảo an toàn cho người dân và các tuyển thủ.</p>

<h3>VCS Mùa Xuân 2020 không có khán giả</h3>

<p>Việc Việt Nam nằm ngay sát Trung Quốc và 14 người bị nhiễm virus Corona tại Việt Nam tính đến ngày 9/2/2020 hiện đang ở bệnh viện Chợ Rẫy đã khiến nhiều người lo ngại. Nhà nước khuyến cáo mọi người không nên lại gần những nơi đông người và đeo khẩu trang thường xuyên. </p>

<p>Vậy những giải đấu sắp tới của VCS Mùa Xuân sẽ ra sao? GG Stadium đã ra quyết định ngừng bán vé để tránh tụ tập đông người. Việc này gây ảnh hưởng không nhỏ đến doanh thu của ban tổ chức. Quyết định này đến từ khuyến cáo của Bộ Văn Hóa, Thể Thao và Du Lịch và Hội Thể Thao Điện Tử Giải Trí Việt Nam (VIRESA) về nguy cơ virus lây lan nhanh ở những nơi tập trung đông người. Và hình ảnh toàn bộ khán giả đeo khẩu trang trên khán đài sẽ khiến GG Stadium trông giống bệnh viện hơn là một giải đấu thể thao điện tử.</p>

<h3>DOTA2 cũng bị ảnh hưởng</h3>

<p>Vòng loại khu vực cho Los Angeles Major và Minor dự kiến sẽ diễn ra vào cuối tuần này trên tất cả các khu vực. Tuy nhiên, với tình trạng dịch corona đang bùng phát mạnh ở Trung Quốc, vòng loại ở khu vực này đã buộc phải tạm hoãn. Thông báo chính thức được Huomao TV đưa ra vào ngày 4/2.</p>

<p>Bên cạnh đó, các giải đấu Dota 2 như WESG APAC finals và Hainan Master Invitational được tổ chức ở Trung Quốc cũng đã bị hoãn vô thời hạn. Điều này thực sự rất đáng tiếc cho 496 Gaming, đại diện của Dota 2 Việt Nam đã giành vé tham dự vòng chung kết WESG APAC nhưng nay đứng trước nguy cơ không thể ra sân thi đấu.</p>

<h3>Overwatch hủy bỏ hàng loạt giải đấu</h3>

<p>Vào ngày 29/1, chỉ một ngày sau khi Mỹ quyết định tạm ngưng tất cả các chuyến bay đến từ Trung Quốc, Blizzard đã đưa ra thông báo hủy bỏ tất cả các trận đấu diễn ra tại Thượng Hải, Quảng Châu, Hàng Châu.</p>

<center><blockquote class="twitter-tweet"><p lang="und" dir="ltr"><a href="https://t.co/nLEPHrJZXS">pic.twitter.com/nLEPHrJZXS</a></p>&mdash; Overwatch League (@overwatchleague) <a href="https://twitter.com/overwatchleague/status/1222685865354285056?ref_src=twsrc%5Etfw">January 30, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Trước khi thông báo được đưa ra, các đội tuyển Guangzhou Charge và Shanghai Dragon đã chuyển cả Ban huấn luyện, tuyển thủ nước ngoài sang Hàn Quốc, còn những tuyển thủ Trung Quốc sẽ phải chờ đợi Visa mới có thể tập trung cùng đồng đội.</p>

<p>Guangzhou cũng cho hay, "tình hình hiện nay rất nghiêm trọng, khó lường và khẩn cấp, hy vọng người hâm mộ có thể thông cảm với tình trạng mà các đội Trung Quốc đang phải đối mặt."</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">We are saddened by the impact that the coronavirus has had in China and elsewhere.  We also understand our fans&apos; concerns about our plans and the safety of our team in China and would like to provide an update.<br>👇👇 <a href="https://t.co/y7cTmCFQ4R">pic.twitter.com/y7cTmCFQ4R</a></p>&mdash; Guangzhou Charge (@GZCharge) <a href="https://twitter.com/GZCharge/status/1222139385426010114?ref_src=twsrc%5Etfw">January 28, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Update regarding the safety of our team and our plan moving forward. <a href="https://t.co/VQRv7FlAuW">pic.twitter.com/VQRv7FlAuW</a></p>&mdash; Shanghai Dragons (@ShanghaiDragons) <a href="https://twitter.com/ShanghaiDragons/status/1222408537659396097?ref_src=twsrc%5Etfw">January 29, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>
',

            'date_post'   => '2020-01-27',
            'thumbnail_post'    => 'nhung-giai-dau-esport-chiu-anh-huong-vi-virus-corona-thumbnail.jpg',
            'id_cat_post' => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Game thủ mong muốn huyền thoại bóng rổ Kobe Bryant được vinh danh trong bản NBA 2021',
            'url_post'        => 'game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021',
            'present_vi_post' => 'Huyền thoại bóng rổ Kobe Bryant vừa mới qua đời vì tai nạn trực thăng. Anh đã từng được xuất hiện trong các phiên bản trước đó của dòng game NBA.',
            'content_vi_post' => '<p>Ngày 26/1/2020, cả thế giới bàng hoàng trước sự ra đi đột ngột của huyền thoại bóng rổ Kobe Bryant. Cựu danh thủ đội Los Angeles Lakers cùng 8 người khác, gồm cả con gái Gianna đều tử nạn sau vụ rơi trực thăng ở vùng Calabasas, California (Mỹ).</p>

<p>Kobe Bean Bryant là một cựu cầu thủ bóng rổ chuyên nghiệp người Mỹ. Cựu cầu thủ xấu số đã dành toàn bộ sự nghiệp 20 năm với đội LA Lakers. Anh đã 5 lần giành chức vô địch NBA và 18 danh hiệu All-Star trước khi giải nghệ vào năm 2016. Với bộ sưu tập danh hiệu đồ sộ, Bryant được coi là một trong những cầu thủ bóng rổ vĩ đại nhất.</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-1.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" /></center>

<p>Theo công bố của các nhà chức trách Mỹ, nguyên nhân tai nạn trực thăng Sikorsky xảy ra vừa qua cướp đi mạng sống của Kobe Bryant, cô con gái Gianna và 7 người khác là va chạm với vách núi, gây ra chấn động mạnh và bốc cháy. Tai nạn thảm khốc khiến 9 người (bao gồm cả phi công) đều thiệt mạng.</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-2.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Hiện trường vụ tai nạn</p></center>

<p>Sự mất mát này quá lớn, khiến rất nhiều danh thủ, CLB bóng rổ và cả bóng đá cùng nhau chia buồn. David Beckham đã viết về anh những lời thương tiếc sâu sắc. Tổng thống Donald Trump và Đệ nhất phu nhân Melania gửi lời chia buồn đến Vanessa Laine Bryant (vợ của ngôi sao bóng rổ kỳ cựu) và gia đình. Cựu Tổng thống Mỹ Barack Obama viết trên Twitter: "Kobe là một huyền thoại trên sàn đấu và đang có hướng đi đầy ý nghĩa sau khi giải nghệ. Là bậc bố mẹ, việc cô bé Gianna ra đi cũng khiến chúng tôi đau buồn. Michelle và tôi xin gửi lời yêu thương, cầu nguyện đến Vanessa cùng toàn thể gia đình Bryant vào một ngày không tưởng như thế này".</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-3.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Kobe Bryant và con gái Gianna</p>

<img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-4.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-5.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" /></center>

<p>Trong bản NBA 2021 sẽ được ra mắt vào tháng 9/2020, người hâm mộ hy vọng nhà phát triển Visual Concepts sẽ cho Kobe xuất hiện trên trang bìa để tưởng nhớ anh.</p>

<h3>Một số thông tin về dòng game NBA.</h3>

<p>NBA là dòng game của nhà sản xuất Visual Concepts và nhà phát hành Sega và Global Star Software. Đây là game bóng rổ rất nổi tiếng, đặc biệt là ở Mỹ, đất nước yêu thích bóng rổ và bóng chày hơn cả bóng đá. Đầu tiên là dòng NBA Live của EA Sports thống trị trong lĩnh vực trò chơi điện tử bóng rổ ở những năm đầu của thế kỷ 21. Tiếp đó đến giai đoạn mà NBA 2K dần chiếm ưu thế trước NBA Live. NBA 2K đã trải qua gần 21 năm ra đời và phát triển, trải qua 21 phiên bản chính, cùng 4 phiên bản phụ như Online 1, VR Experience, Online 2 và Playgrounds. Game có đồ họa chân thực và độ khó cao, đòi hỏi người người chơi phải hiểu biết về bóng rổ cũng như thuần thục các kỹ năng điều khiển tương tự như dòng game bóng đá FIFA.</p>

<p>Một phần lý do khác mà game thủ muốn tưởng nhớ đến Kobe Bryant trên hình bìa của game là vì game này có một lời nguyền. </p>

<p>Bắt đầu từ năm 2005, hình ảnh với hình ảnh trung phong Ben Wallace. Anh có 2 mùa giải All-Star, 2 lần đạt danh hiệu Cầu thủ phòng ngự của năm và trở thành nhà vô địch giải bóng rổ NBA năm 2004, vì vậy NBA 2K đã cho anh vinh dự được xuất hiện trên bìa đại diện NBA 2K5.</p>

<p>Vào năm đó, Wallace đang trong quá trình bảo vệ ngai vàng cùng với Detroit Pistons. Đội của anh vào trận chung kết NBA năm thứ 2 liên tiếp và thua San Antonio Spurs.</p>

<p>Năm 2009 là năm đáng sợ nhất với trường hợp của Kevin Garnett. Năm 2008 trước đó, tiền phong siêu sao của Celtics vừa đưa đội nhà lên đỉnh vinh quang sau khi đánh bại Lakers tại chung kết NBA. 2K đã chọn Garnett như hình ảnh đại diện của NBA 2K9.</p>

<p>Gartnett sau đó có một trong những mùa giải khó khăn nhất tại giải đấu. Chấn thương đầu gối của anh bị phát nặng ngoài dự tính khiến siêu sao này phải bỏ lỡ lỡ 25 trận đấu cuối mùa cùng cả vòng Playoff quan trọng. Kết quả là Celtics còn không tiến được tới chung kết NBA, làm ngắt đoạn thăng hoa của lứa thế hệ vàng.</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-6.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Ben Wallace và Kevin Garnett trên bìa game NBA 2K</p></center>

<p>Chỉ có năm 2010 với hình ảnh Kobe Bryant mới khiến người ta nghi ngờ về lời nguyền. Anh chẳng gặp vấn đề gì cả. Nhưng nhà sản xuất cũng phải nghiêm túc nhìn nhận vấn đề tâm linh này nên đã cho 2 phương án.</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-7.jpg" width="70%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" />

<p>Kobe Bryant đã từng xuất hiện trên bìa game NBA 2010</p></center>

<p>Phương án 1 là cho các ngôi sao đã nghỉ hưu lên bìa NBA 2012. Nhưng sức hút không tốt lắm khiến nhà phát hành chuyển qua phương án 2: in hình 3 người lên bìa NBA 2013. Kết quả là cả 3 đều gặp vận đen không thể tin được. Và các năm sau đó cũng vậy.

<p>Vì vậy, giải pháp mà các game thủ đưa ra trong năm 2020 này là đưa hình Kobe Bryant một lần nữa. Vừa để tưởng nhớ đến anh, vừa khỏi gây ra lời nguyền cho một ai khác. Còn gì tốt hơn thế?</p>

<center><img src="/upload/images/game/game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-8.jpg" width="100%" alt="Những giải đấu eSport chịu ảnh hưởng vì virus Corona" /></center>

<p>Xin chia buồn với tài năng Kobe Bryant và con gái Gianna.</p>
',
            'date_post'    => '2020-02-04',
            'thumbnail_post'     => 'game-thu-mong-muon-huyen-thoai-bong-ro-kobe-bryant-duoc-vinh-danh-trong-ban-nba-2021-thumbnail.jpg',
            'id_cat_post'  => GAME_POST,
            'signature'          => 0,
            'author'             => 'NVHAI',
            'views'              => random_int(50,500),
            'enable'             => ENABLE,
            'popular'            => 0,
            'update'             => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Overwatch sẽ trở thành dead game trong bao lâu nữa?',
            'url_post'        => '',
            'present_vi_post' => 'Một câu hỏi đáng buồn cho một tựa game được đầu tư rất công phu của Blizzard.',
            'content_vi_post' => '<p>Từ một game bắn súng của Blizzard được rất nhiều người mong đợi. Sau 3 năm, Overwatch dù vẫn duy trì những giải đấu, tổ chức Overwatch League thường niên, nhưng hiện tại có bao nhiêu người chơi Overwatch trên toàn thế giới khi độ hot đã giảm đáng kể? Liệu Overwatch 2 có giúp Blizzard lấy lại sức hút như trước.</p>

<h3>Những con số</h3>

<p>Blizzard thường kín tiếng về số lượng người chơi, nhưng đôi lúc họ cũng tiết lộ một vài số liệu. Trong tuần qua tại sự kiện BlizzCon 2019, giám đốc điều hành của Overwatch, Jeff Kaplan đã đề cập đến một con số ước tính sơ bộ về quy mô người chơi trong năm 2019.</p>

<p>Ông Kaplan cho biết: </p>

<blockquote><p>"Chúng tôi muốn đảm bảo rằng tất cả các vật phẩm Overwatch sẽ cùng bạn chuyển sang Overwatch 2. Không có gì bị bỏ lại phía sau. Chúng tôi đã làm việc rất chăm chỉ để xây dựng cộng đồng hơn 50 triệu người chơi vào thời điểm này. Điều chúng tôi đang cố gắng là làm bất cứ điều gì để tạo ra một cộng đồng tuyệt vời."</p></blockquote>

<p>Trong tháng 5/2018, Blizzard công bố số lượng người chơi Overwatch đạt 40 triệu người. Nhưng ngay sau đó, trong báo cáo thu nhập quý 2, con số đã giảm còn khoảng 37 triệu người chơi hoạt động hàng tháng.</p>

<p>Lý giải về sự suy giảm số lượng người chơi, ai cũng có thể thấy Overwatch sau một thời gian nổi bật, ngay lập tức đã bị PUBG và các game thể loại Battle Royal đánh bại. Mọi chuyện dần bình ổn hơn khi PUBG dần trở thành dead game nhưng Overwatch, một tựa game trả phí vẫn khiến nhiều người ngần ngại.</p>

<h3>Những sự ra đi</h3>

<p>(Viết về BLV và game thủ chuyên nghiệp)</p>


One Esport

Overwatch sở hữu bao nhiêu người chơi trên toàn thế giới?

Overwatch League đang chết dần

BLV DoA chia tay Overwatch League




<h3>Nỗ lực chuyển mình và kết quả</h3>

Huyền thoại Overwatch giải nghệ xong muốn quay lại

Overwatch 2

<p></p>

<p></p>

<p></p>

<center>

<p></p></center>

',
            'date_post'    => '2020-02-05',
            'thumbnail_post'     => '-thumbnail.jpg',
            'id_cat_post'  => GAME_POST,
            'signature'          => 0,
            'author'             => 'NVHAI',
            'views'              => random_int(50,500),
            'enable'             => 0,
            'popular'            => 0,

            'update'             => 0,
        ]);



		posts::create([
            'name_vi_post'    => 'Hearthstone đã trở thành game rất tốn kém để thắng',
            'url_post'        => 'hearthstone-da-tro-thanh-game-rat-ton-kem-de-thang',
            'present_vi_post' => 'Hãy quên ảo tưởng Free To Win với Hearthstone đi!',
            'content_vi_post' => '<p>Blizzard - công ty game tự hủy liên tục có những bước đi sai lầm cho các sản phẩm của mình. </p>

https://www.reddit.com/r/hearthstone/comments/a4oma5/hearthstone_is_too_expensive/

https://www.reddit.com/r/Artifact/comments/a4lxre/i_come_from_hearthstone_this_game_is_not_more/

https://us.forums.blizzard.com/en/hearthstone/t/hearthstone-has-become-crazy-expensive/12224

<p></p>

<h3>Nerf card Basic và Classic, xóa bỏ tất cả deck cần bài Basic</h3>

<p>Việc làm gây tranh cãi nhiều nhất là xóa bỏ deck Worgen Warrior OTK. OTK là viết tắt của One single Turn Kill. Trong Hearthstone có một số bộ bài có khả năng gây ra 22-28 damage, gần như có thể kết liễu đối thủ ngay trong turn đó.
Cách sử dụng deck là cố thủ bằng Taunt, buff giáp và kết liễu đối thủ với combo buff cho Worgen.</p>

<p>Nhưng vào đầu năm 2018, Blizzard quyết định xóa bỏ deck này. Đây là một quyết định rất gây tranh cãi vì điểm yếu của Worgen Warrior là phải thu thập đủ bài và đối thủ không được có các lá bài cản đường
như Taunt, Secret hay các lá bài buff giáp, bất tử...
Hay cách dùng chiến thuật phá hủy deck làm yếu hoặc hủy các lá bài quan trọng hay Aggro hạ gục đối thủ trước khi đủ bài. Rất nhiều cách khắc chế Worgen Warrior. Vậy tại sao phải nerf?</p>

<p>Câu trả lời là vì Worgen Warrior tập hợp nhiều lá Basic và Classic trong game cho sẵn miễn phí. Nghĩa là game thủ không cần mua nhiều pack bài để hoàn thành deck.
Blizzard sẽ chẳng thu được lợi lộc gì nếu chỉ sử dụng bài Basic và Classic đã có thể chiến thắng.</p>

<center>https://www.hiepsibaotap.com/otk-trong-hearthstone-mot-goc-nhin-lich-su/

<p>Những lá bài trong deck Worgen Warrior OTK trước và sau khi bị nerf</p></center>

<p>Thêm một deck OTK khác nhưng hơi đắt hơn một chút là Grim Patron. Neilyo của Việt Nam đã được vào Chung Kết Thế Giới nhờ deck này. Sau đó deck này cũng bị xóa bỏ vì Warsong Commander bị nerf.</p>

<p>Những năm sau, Blizzard vẫn tiếp tục tạo ra các deck OTK nhưng cần nhiều lá Legendary hơn. Điển hình là Exodia Mage với lá Archmage Antonidas là bắt buộc. Druid và Rogue với Alexstrasza và Malygos. Priest với Mecha&apos;thun và Hemet Jungle Hunter...</p>

<h3>Tạo ra meta Odd Even</h3>

<p>Odd (số lẻ) và Even (số chẵn) bắt đầu xuất hiện trong bản...</p>

<p>Các deck Odd và Even mạnh lên bao gồm Odd Paladin, Odd Hunter, . Blizzard đã quyết định nerf các deck này bằng cách rất khó hiểu: nerf những lá Basic.

Và trường hợp khổ đau nhất là lá Hunter Mark, từ một là Basic 0 mana lúc được sinh ra giờ đã lên thành 2 mana.</p>

<p>Cuối cùng là một quyết định khác của Blizzard để kết thúc Year of the : bỏ luôn meta Odd Even. Việc nghĩ ra meta Odd Even đã khiến việc buff nerf các lá bài khó khăn hơn rất nhiều.
Nhưng nếu hủy luôn meta Odd Even, vậy những lá bị nerf vì meta này thì sao? Blizzard vẫn giữ nguyên. Đây đúng là meta hủy diệt bài Basic.</p>

<h3>Thay đổi tier deck nhiều Legedary</h3>

<p>Hiện giờ, deck A với 3 lá Legendary đang thống trị. Sang tháng sau sẽ bị thay thế bằng deck B với 5 lá Legendary khác hoàn toàn. Tất nhiên đây là điều phải làm để thay đổi meta, nhưng cũng đồng nghĩa với việc game thủ tiếp tục nạp tiền để mua thêm pack bài, có đủ Legendary cho deck mới.</p>

<p></p>

<p>Thậm chí có những deck cần cố công dồn sức để build, nhưng sau một cú nerf thì tất cả biến thành dust mà không thể thay thế card này bằng card kia.
Ví dụ điển hình là Kingsbane của Rogue. Muốn chơi được deck này phải có lá Kingsbane và lá Leeching Poison hút máu. Nhưng chỉ sau 1 cú nerf Leeching Poison, Kingsbane đã biến thành 400 dust vì nếu không hút máu, Rogue khó trụ lại được.</p>

<h3>Aggro bị hủy hoặc cần Legendary</h3>

<p>Trước đây, người chơi thích Aggro vì cần ít Legendary. Tuy nhiên, khái niệm này giờ đã giảm bớt. Đúng là so với các deck Control, Aggro cần ít Legendary hơn nhưng vẫn nằm trong khoảng 2-3 lá Legendary nếu muốn deck hoàn hảo.</p>

<center>

<p>Lerroy là Legendary bắt buộc của mọi deck Aggro đấm vào mặt</p></center>

<p></p>

<p></p>

<h3>Ra mắt các Adventure không tặng bài cố định</h3>

<p>KINGDOM NVHAI bắt đầu chơi từ thời Curse of Naxxramas (CoN). Thời đó các Adventure như CoN, Blackrock Mountain (BM) hay League of Explorers (LoE) đưa người chơi vào cuộc hành trình săn boss lấy bài cố định được cho sẵn. KINGDOM NVHAI đã đầu tư toàn bộ gold để đánh hết các Adventure đó.</p>

<p>Nhưng các Adventure sau này chỉ có tác dụng lấy pack bài để mở và nhận card back (mặt sau của lá bài). Vậy nên các Adventure mất hẳn sức hấp dẫn. Sau này Blizzard mới mở lại với phiên bản ...
Nếu như các Adventure vẫn phải mở pack như các phiên bản bình thường thì cần gì phải tạo ra Adventure? Chỉ cần tặng free 10 pack để mở rồi đánh tiếp thôi.
Một bước đi tự hủy khác của Blizzard.</p>

<p>Blizzard càng ngày càng cho thấy ông lớn của thị trường game thế giới này liên tục tự hủy một cách khó hiểu. Nguyên nhân tại sao thì chỉ có nội bộ mới biết được. Overwatch cạnh tranh không lại, <a href="" target="_blank" title="phải trả lại tiền cho game thủ">Warcraft 3 Reforged phải trả lại tiền cho game thủ.</a> Phải chăng nên đặt ra thuyết âm mưu Blizzard bị cài người tự hủy từ bên trong?</p>

Nguồn: The Gamer https://www.thegamer.com/hearthstone-price-history-galakronds-awakening-adventure/

',
            'date_post'    => '2020-02-06',
            'thumbnail_post'     => 'hearthstone-da-tro-thanh-game-rat-ton-kem-de-thang-thumbnail.jpg',
            'id_cat_post'  => GAME_POST,
            'signature'          => 0,
            'author'             => 'NVHAI',
            'views'              => random_int(50,500),
            'enable'             => 0,
            'popular'            => 0,

            'update'             => 0,
        ]);

		posts::create([
            'name_vi_post'    => 'Warcraft 3 Reforged quá đáng thất vọng, Blizzard phải trả lại tiền cho game thủ',
            'url_post'        => 'warcraft-3-reforged-qua-dang-that-vong-blizzard-phai-tra-lai-tien-cho-game-thu',
            'present_vi_post' => 'Sau những chỉ trích và đòi trả lại tiền từ các game thủ, Blizzard đã phải trả lại tiền và việc này được thực hiện rất nhanh chóng.',
            'content_vi_post' => '<p>Warcraft 3 Reforged là phiên bản làm lại của trò chơi video chiến lược thời gian thực năm 2003 Warcraft III: Reign of Chaos và bản mở rộng The Frozen Throne. Blizzard đã tung trailer giới thiệu hoành tráng tại BlizzCon 2018, khiến các fan gạo cội của thể loại RTS nói chung và Warcraft 3 nói riêng cực kỳ vui sướng. Một tựa game thành công đã có sẵn, chỉ cần nâng cấp đồ họa. Còn gì dễ dàng hơn thế?</p>

https://www.youtube.com/watch?v=npqmabePSk8

<p>Sau khi Blizzard tung một trailer gameplay khác, lòng tin của các game thủ càng được củng cố. Rất nhiều đơn đặt hàng được tạo nhằm chờ được sở hữu tựa game huyền thoại một thời sắp được nâng cấp này. Nhưng người tính không bằng trời tính, cả hình ảnh được kỳ vọng lẫn gameplay mong được giữ đã không còn nguyên vẹn.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/sJWuMwz31qE" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Warcraft III Reforged Trailer tại BlizzCon 2018</p></center>

<p>Đầu tiên là phần hình ảnh trong gameplay. Yêu cầu của những tựa game chiến thuật là người chơi phải dễ dàng nhận ra các đơn vị quân giữa chiến trường hỗn loạn. Hình ảnh của Warcraft 3 Reforged đúng là đã đẹp và chi tiết hơn rất nhiều. Nhưng chỉ khi người chơi zoom sát vào nhân vật. Còn khi ở góc nhìn trên cao, các chi tiết của nhân vật bị trộn lại với nhau.</p>

<p>Chuyển động của các đơn vị vẫn bị gói gọn trong 20 khung hình như trước. Trong những tựa game người chơi có thể điều khiển hàng trăm đến hàng ngàn binh sĩ, đây không phải là một vấn đề quá lớn bởi chẳng ai rảnh rỗi mà xem kỹ các binh sĩ đang làm gì. Nhưng trong Warcraft 3: Reforged, người chơi phải kiểm soát từng đơn vị quân để sử dụng các kỹ năng đặc biệt của họ, và đây là một nhược điểm nghiêm trọng.</p>

<p>Tóm lại, hình ảnh của Warcraft 3 Reforged không quá tệ nếu nhìn đơn lẻ, nhưng tập hợp lại sẽ thành một mớ rối mắt, hoàn toàn không thể chấp nhận được vào năm 2020 hay những gì mà Blizzard quảng cáo.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/HbppzPzBM2M" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Warcraft III Reforged All Cinematics</p></center>

<p></p>

<p></p>

<p></p>

<p></p>
',
            'date_post'    => '2020-02-07',
            'thumbnail_post'     => 'warcraft-3-reforged-qua-dang-that-vong-blizzard-phai-tra-lai-tien-cho-game-thu-thumbnail.jpg',
            'id_cat_post'  => GAME_POST,
            'signature'          => 0,
            'author'             => 'NVHAI',
            'views'              => random_int(50,500),
            'enable'             => 0,
            'popular'            => 0,

            'update'             => 0,
        ]);


        posts::create([
            'name_vi_post'    => 'Death Stranding của Hideo Kojima thắng 2 giải D.I.C.E 2020',
            'url_post'        => 'death-straning-cua-hideo-kojima-thang-2-giai-dice-2020',
            'present_vi_post' => 'Ngoài ra còn có Control, Untitled Goose Game, Mortal Kombat 11, Apex Legends',
            'content_vi_post' => '<p>Giải D.I.C.E là giải thưởng game của  </p>

<p>Thành công nhất của năm nay chính là game Control có đến 4 giải: thiết kế đồ hoạ ấn tượng nhất, âm nhạc ấn tượng nhất, game hành động của năm, game được thiết kế ấn tượng nhất.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/hBSddvei2ZU" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trực Tiếp Game chơi Untitled Goose Game - Giả lập làm vịt</p></center>

<p>Untitled Goose Game, một game giả lập làm vịt bất ngờ được giành đến 3 giải: Game của năm, Nhân vật game ấn tượng nhất và Game độc lập ấn tượng nhất</p>

<center><img src="/upload/images/game/death-straning-cua-hideo-kojima-thang-2-giai-dice-2020-1.jpg" width="100%" alt="Death Stranding của Hideo Kojima thắng 2 giải D.I.C.E 2020" /><br><br></center>

<p>Death Stranding của nhà làm game thiên tài Hideo Kojima đã có 2 giải: Thiết kế âm thanh ấn tượng nhất và kỹ thuật làm game ấn tượng nhất.</p>

<p>Các game có 1 giải thưởng bao gồm:</p>
<ul>
<li>Sayonara Wild Hearts - Game Portable ấn tượng nhất
<li>Mortal Kombat 11 - Game đối kháng của năm
<li>Apex Legends - Game online của năm
<li>Star Wars Jedi: Fallen Order - Game phiêu lưu của năm
<li>Super Mario Maker 2 - Game gia đình của năm
<li>Mario Kart Tour - Game đua xe của năm
<li>The Outer Worlds - Game nhập vai của năm
<li>FIFA 20 - Game thể thao của năm
<li>Fire Emblem: Three Houses - Game chiến thuật/giả lập của năm
<li>Blood & Truth - Game thực tế ảo ấn tượng nhất
<li>Pistol Whip - Game thực tế ảo của năm
<li>Apex Legends - Game online của năm
<li>Baba Is You - Game được thiết kế ấn tượng nhất
<li>Luigi&apos;s Mansion 3 - Hoạt hoạ ấn tượng nhất
<li>Disco Elysium - Cốt truyện ấn tượng nhất
</ul>

<center><img src="/upload/images/game/death-straning-cua-hideo-kojima-thang-2-giai-dice-2020-disco-elysium.jpg" width="100%" alt="Death Stranding của Hideo Kojima thắng 2 giải D.I.C.E 2020" /><br><br>

<img src="/upload/images/game/death-straning-cua-hideo-kojima-thang-2-giai-dice-2020-fire-emblem-three-houses.jpg" width="100%" alt="Death Stranding của Hideo Kojima thắng 2 giải D.I.C.E 2020" /></center>

<p>Tổng cộng có 65 giải thưởng D.I.C.E được đề cử. D.I.C.E là viết tắt của Design Innovate Communicate Entertain (Thiết kế Đổi mới Giao tiếp Truyền thông).</p>

<p>Đồng giám đốc Nintendo và thành viên công nghệ Genyo Takeda đã nhận được giải thưởng Thành Tựu Trọn Đời tại lễ trao giải năm 2018.
Viện Hàn Lâm Khoa Học và Nghệ Thuật Tương Tác đã giới thiệu nhà sáng tạo series trò chơi Metal Gear Kojima vào Đại Sảnh Danh vọng năm 2016.</p>
',
            'date_post'         => '2020-02-14',
            'thumbnail_post'    => 'death-straning-cua-hideo-kojima-thang-2-giai-dice-2020-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
			'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Những điểm báo trong game về dịch COVID-19',
            'url_post'        => 'nhung-diem-bao-trong-game-ve-dich-Covid19',
            'present_vi_post' => 'Những sự trùng hợp đến khó tin và đáng sợ như điểm báo trước về dịch COVID-19',
            'content_vi_post' => '<h3>Phòng thí nghiệm Vũ Hán có biểu tượng giống Umbrela trong Resident Evil</h3>

<p>Thảm họa COVID-19 xuất phát từ thành phố Vũ Hán. Chính phủ Trung Quốc đã ban bố tình trạng khẩn cấp, phong tỏa toàn thành phố Vũ Hán. Không biết các nhà lãnh đạo Trung Quốc có chơi game Resident Evil không nhưng chuyện này xảy ra giống với cốt truyện trong game. Thành phố Racoon là thành phố đầu tiên bị dịch Zombie tấn công. Cả thành phố bị phong tỏa, người dân không ai ra vào được.</p>

<p>Trùng hợp thay, cái tên đầu tiên của COVID-19 là Corona do WHO đặt tên. Và các game thủ đã khám phá ra 2 sự trùng hợp đáng sợ: chữ CORONA có thể sắp xếp lại thành RACOON, thành phố đầu tiên bị dịch Zombie tấn công. Đây là điểm báo hay do các nhà lãnh đạo WHO thích game Resident Evil?</p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-corona-racoon.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" /></center>

<p>Điểm báo đáng sợ của game chưa dừng lại tại đây. Phòng thí nghiệm Vũ Hán có logo hình chiếc ô với hai màu trắng - xanh. Biểu tượng của Umbrella cũng là chiếc ô với hai màu đỏ - trắng nổi bật. Nếu là phòng thí nghiệm ở thành phố khác thì không cần bàn. Nhưng đây lại là thành phố Vũ Hán, nơi đầu tiên xảy ra dịch bệnh. Không thể nào đây lại là sự trùng hợp.</p>

<p>Từ đó, các game thủ nghĩ ra thuyết âm mưu rất thuyết phục: phòng thí nghiệm Vũ Hán giống như tập đoàn Umbrella, đã để virus thoát ra ngoài và lây lan dịch khắp thành phố. Chính quyền giống như tập đoàn Umbrella, ra sức bưng bít thông tin nhưng quá muộn. Virus đã lan khắp thế giới. Tưởng chừng kịch bản này chỉ có trong game nhưng nó đang hiện ra trước mắt loài người.</p>

<h3>Học tập các Hikikomori của Nhật Bản</h3>

<p>Bạn đã từng nghĩ Hikikomori hay còn gọi là NEET (not in education, employment, or training) là những thành phần ăn bám vô tích sự, chỉ biết ngồi trong nhà chơi game và ù lỳ đến mức không dám bước ra khỏi nhà? Đúng là vậy! Đã có vụ việc một Hikikomori để bà mẹ qua đời trong nhà suốt 2 năm chỉ vì không biết phải xử lý thế nào. Những thành phần này rất phổ biến trong xã hội Nhật Bản nói riêng và các nước phát triển nói chung do sự bao bọc quá nhiều của phụ huynh và sự phát triển của Internet.</p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-hikikomori.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" /></center></center>

<p>Tuy nhiên, trong thời buổi dịch COVID-19 đang lan rộng khắp nơi thế này, mọi người lại đang bị ép trở thành Hikikomori. Hạn chế ra đường, không được ra ngoài, giới nghiêm là những câu thường xuyên được báo đài đưa tin. Chuyện đó có thể rất khó khăn với mọi người nhưng với các Hikikomori, đó là sinh hoạt thường ngày trong suốt nhiều năm trời. Chưa kể đến việc, bạn ở nhà thì bạn sẽ làm gì? Chơi game chắc chắn là hình thức giải trí mà nhiều người nghĩ đến ngay. Nói cách khác: cả thế giới đang phải học tập các Hikikomori. </p>

<h3>Mỹ và các nước châu Âu chống đỡ yếu ớt trước thảm họa dịch bệnh.</h3>

<p>Chắc hẳn mọi người từng nghĩ: Resident Evil, The Walking Dead hay những game về chủ đề zombie, đại dịch virus thường lấy bối cảnh ở Mỹ. Liệu đó chỉ đơn thuần là do các nhà phát triển game thích lấy bối cảnh ở Mỹ. Không phải vậy! Họ có thể lấy bối cảnh ở bất kỳ đâu trên thế giới, từ những thành phố hiện đại của châu Âu, Nhật Bản, Hàn Quốc cho đến những vùng hẻo lánh như châu Phi. Tại sao họ chỉ xoay quanh nước Mỹ là chủ yếu? Ngay cả series game Resident Evil của Capcom, một hãng game nổi tiếng của Nhật Bản cũng lấy bối cảnh ở Mỹ. Chỉ một số game Zombie lấy bối cảnh châu Âu hay Nhật Bản như Zombie Army.</p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-zombie-army.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Hitler trong Zombie Army</p></center>

<p>Sau khi virus COVID-19 tràn đến nước Mỹ, chúng ta đã có được lời giải đáp. Người chết như ngả rạ, dịch bệnh bùng phát khắp nơi dù nước Mỹ và Châu Âu đã có đến 2 tháng chuẩn bị. Xe cấp cứu chạy xuôi ngược. Số người chết và nhiễm bệnh đã vượt xa Trung Quốc gấp mấy lần. Rõ ràng, nước Mỹ là miếng mồi ngon của các thảm họa. Kế đến là châu Âu cũng đã thất thủ trước COVID-19. Game và phim ảnh đã chứng minh điều đó. </p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-my.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" /></center></center>

<p>Vậy nguyên nhân tại sao? Mỹ và các nước châu Âu rất tự hào về hệ thống y tế cũng như khả năng phòng bệnh của mình. Môi trường trong lành, chế độ ăn tốt. khả năng xảy ra bệnh dịch lớn như Cái Chết Đen là chuyện khó xảy ra. Và giờ COVID-19 đã cho Mỹ và các nước châu Âu thấy họ phòng dịch yếu y như trong game. </p>

<h3>2 cách có thể đánh bại nước Mỹ</h3>

<p>Các nhà làm game đã nghĩ ra rất nhiều cách để làm về chủ đề nước Mỹ sụp đổ. Trong đó có 3 cách chính:</p>

<p>Cách 1: người ngoài hành tinh xâm chiếm. Đây là cách chỉ có trong phim viễn tưởng nên có thể bỏ qua.</p>

<p>Cách 2: khủng bố. Đây là lý do gián tiếp khiến nước Mỹ lơ là với dịch bệnh. Nguồn lực của họ dồn vào việc chống khủng bố nhiều hơn là chống dịch, nhất là sau những vụ xả sung và sự kiện 11/9. Trong nhiều game như Call Of Duty, bối cảnh nước Mỹ gặp khủng bố rất nhiều.</p>

<p>Tuy nhiên, viễn cảnh nước Mỹ điêu tàn vì khủng bố là rất khó. Mỹ có số lượng súng đạn trong dân là 121 khẩu/100 dân. Vì vậy, khả năng khủng bố xảy ra ở châu Âu chứ khó xảy ra ở Mỹ.</p>

<p>Cách 3: bệnh dịch. Đây chính là điểm yếu của Mỹ đã được dự báo trước trong game. Những đại dịch Zombie khiến nước Mỹ thất thủ nhanh chóng. Người chết trong dịch COVID-19 được đưa từng bao lên xe khiến game thủ tưởng tượng ra cảnh trong game. Tổng thống Donald Trump cũng đã nói vào ngày 31/3/2020 rằng 2 tuần kế tiếp sẽ rất u ám với hơn 240.000 người chết. Có khác gì thảm họa Zombie trong game? Thậm chí súng đạn cũng chẳng thể cứu họ giống trong game.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/AWFaj4IQ4ro" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Dead Island 2</p>

<img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-new-york-dead.jpg" width="50%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Cảnh tượng không khác trong các game Zombie.</p></center>

<p>Rất nhiều phim và game đã nghĩ đến viễn cảnh hậu tận thế. Những nơi sầm uất, nhộn nhịp giờ không bóng người. Người dân sẽ vơ vét nhu yếu phẩm, lo giữ tính mạng mình, mặc kệ đồng loại chết. Dù trước đây họ có văn minh thế nào đi nữa thì khi thảm họa đến, mọi lương tri sẽ bị vứt bỏ để giữ lại mạng sống. Những cảnh tượng trong phim đó đang xảy ra trước mặt chúng ta.</p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-japan.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Nhật Bản nổi tiếng văn minh, nhưng siêu thị vẫn bị vét sạch vì COVID-19</p>

<img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-australia.jpg" width="70%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Cụ bà giữa những kệ hàng trống trơn<br>
trong siêu thị thành phố Melbourne, Australia ngày 19/3.</p>

<img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-DUSK.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Cảnh hoang vắng, điêu tàn trong game <a href="https://youtu.be/l2OPCWRlnCQ" rel="nofollow" target="_blank" title="DUSK - I am legend game">DUSK - I am legend game</a></p></center>

<h3>Trái Đất cần được thanh lọc</h3>

<p>Tưởng như chỉ có trong phim, thế nhưng người ta đang đặt ra giả thuyết virus COVID-19 là do con người tạo ra. Chưa biết thông tin này là thật hay giả nhưng kịch bản này rất quen thuộc. Trong game Resident Evil nổi tiếng, tập đoàn Umbrella đã để T-Virus thoát ra ngoài, gây ra dịch Zombie. Hàng loạt thuyết âm mưu được tô vẽ ra với đủ các mục đích chính trị, truyền thông. </p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-T-Virus.jpg" width="70%" alt="Những điểm báo trong game về dịch COVID-19" /></center>

<p>Nhưng mục đích mà nhiều người nghĩ đến nhất là: Trái Đất đã quá sức chịu đựng. Đúng là vậy! Ô nhiễm môi trường, chiến tranh, rất nhiều thứ do con người gây ra đã khiến khí hậu biến đổi, động vật tuyệt chủng, rừng bị chặt phá. Mới cuối năm 2019, cả thế giới còn hoảng loạn khi tổng thống Brazil chặt phá rừng Amazon. Vì vậy, một cuộc thanh lọc ngẫu nhiên dân số Trái Đất, nghe tàn nhẫn nhưng bắt buộc phải thực hiện, giống như cái búng tay của Thanos trong phim Avenger vậy.</p>

<center><img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-amazon.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Rừng Amazon cháy năm 2019 là sự kiện về môi trường nghiêm trọng,<br>
trước khi có dịch COVID-19 vào tháng 1/2020</p>

<img src="/upload/images/game/nhung-diem-bao-trong-game-ve-dich-Covid19-thanos.jpg" width="100%" alt="Những điểm báo trong game về dịch COVID-19" />

<p>Có khi nào Thanos đã đúng?</p></center>

<p>Trong một tựa game tên là The Division, những tình tiết trong game The Division y hệt với thế giới hiện nay:</p>

<ul>
<li>Một chủng virus lạ xuất hiện và lây nhiễm qua tiền. Lúc đầu ai cũng nghĩ là bệnh cúm mùa. Nhưng sau đó đã khiến cả một thành phố rơi vào hoảng loạn và bị cô lập.
<li>Nguồn gốc của virus là do tiến sĩ Gordon Amherst tạo ra với phương châm kẻ mạnh là kẻ sống sót. Ông ta nói rằng Trái Đất đã đến giới hạn và cần được cứu.
<li>Virus không phát bệnh ngay mà ẩn trong cơ thể một thời gian dài mới phát bệnh.
<li>Quân đội phải tham gia, người dân đánh nhau giành nhu yếu phẩm.
</ul>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/FaknrhmnGpg" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Cốt truyện game The Division</p></center>

<p>Hy vọng dịch COVID-19 sẽ sớm trôi qua, các bác sĩ sẽ sớm tìm ra vaccine phòng bệnh và cuộc sống của thế giới sẽ trở lại như trước.</p>
',
            'date_post'         => '2020-04-01',
            'thumbnail_post'    => 'nhung-diem-bao-trong-game-ve-dich-Covid19-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
			'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Konami đổi tên lá bài vì lý do phân biệt chủng tộc',
            'url_post'        => 'konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc',
            'present_vi_post' => 'Rồng Đen Mắt Đỏ đổi tên thành... Rồng Đen Mắt Đỏ?',
            'content_vi_post' => '<p>Lá bài mạnh nhất của Jonouchi là lá bài Rồng Đen Mắt Đỏ, tên tiếng Anh là Red-Eyes B.Dragon vừa được Konami đổi tên thành Red-Eyes Black Dragon. Đúng vậy! Chỉ là thay chữ viết tắt thành chữ viết hoàn chỉnh. Vậy tại sao trong suốt 18 năm, Konami lại không làm điều này?</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/ikS2WeoHeUQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe><br><br>

<p>M2 DUEL CHANNEL nói về sự kiện</p></center>

<p>Mọi chuyện bắt đầu từ việc phân biệt chủng tộc tại Mỹ. Người da trắng là người xây dựng nên nước Mỹ. Còn người da đen lại có nguồn gốc là nô lệ Châu Phi. Vì vậy, vấn đề phân biệt chủng tộc rất nhạy cảm tại Mỹ. Khi Yugi-oh! cập bến nước Mỹ, Blue-Eyes White Dragon và Red-Eyes Black Dragon dễ bị hiểu lầm là đại diện của 2 màu da trắng và đen.</p>

<p>Vấn đề ở chỗ, chủ nhân của Blue-Eyes White Dragon là Kaiba, công tử nhà giàu. Còn chủ nhân của Red-Eyes Black Dragon là Jounouchi, một học sinh quê mùa, nhà nghèo, cha bê tha nhậu nhẹt. Điều này đã khiến nhà phát hành Yugi-Oh! tại Mỹ lo ngại sẽ dấy lên làn sóng phân biệt chủng tộc nên đã tránh né bằng cách sửa chữ Black thành chữ B viết tắt.</p>

<center><img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-blue-eyes-white-dragon.jpg" width="70%" alt="Blue-Eyes White Dragon Rồng Trắng Mắt Xanh" /><br><br>

<p>Rồng Trắng nhưng màu lại là màu xanh trắng</p></center>

<p>Ngoài ra, lá bài Rồng Trắng Mắt Xanh cũng đã có sự thay đổi lớn từ rất lâu, đó là đổi màu da. Dù gọi là Rồng Trắng, nhưng màu da lại hơi xanh. Trong pack bài nhân dịp Movie The Darkside of Dimensions ra mắt, màu da của Blue-Eyes White Dragon đã được sửa lại thành màu trắng. Và đến năm 2020, sự kiện Black Lives Matter về người đàn ông da màu George Floyd bị cảnh sát Mỹ đè lên cổ trong 8 phút dẫn đến thiệt mạng dẫn đến làn sóng biểu tình gây hỗn loạn khắp nước Mỹ. Konami đã có nước đi khôn ngoan, vừa để xoa dịu, vừa để quảng bá sản phẩm. Đó là trả lại cái tên Red-Eyes Black Dragon.</p>

<center><img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-george-floyd.jpg" width="70%" alt="Blue-Eyes White Dragon Rồng Trắng Mắt Xanh" /><br><br>

<p>Người da màu George Floyd bị cảnh sát đè chết tại Mỹ<br>
đã kích động nạn phân biệt chủng tộc bấy lâu.</p>

<img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-red-eyes-black-dragon.jpg" width="100%" alt="Red-Eyes Black Dragon Rồng Đen Mắt Đỏ" />

<p>Konami tận dụng thời cơ, đổi tên lá bài Red-Eyes B.Dragon thành Red-Eyes Black Dragon</p></center>

<p>Bổ sung thêm, lá bài Dark Magician chủ lực của Yugi-Oh! có tên gốc là Black Magician. Lý do sửa tên có lẽ cũng vì phân biệt chủng tộc. 2 nhân vật sở hữu 2 lá bài có chữ Black đều là con nhà nghèo, kinh tế bình thường. Còn Kaiba sở hữu lá bài có chữ White thì lại là trẻ mồ côi được nhà giàu nhận nuôi, trở thành chủ tịch tập đoàn Kaiba khi còn rất trẻ. Chắc chắn không ai muốn điều này liên tưởng đến nạn phân biệt chủng tộc.</p>

<center><img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-yugi-dark-magician.jpg" width="100%" alt="Red-Eyes Black Dragon Rồng Đen Mắt Đỏ" /><br><br>

<p>Yugi, học sinh bình thường, sở hữu lá bài Dark Magician</p>

<img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-jounouchi-red-eyes-black-dragon.jpg" width="100%" alt="Red-Eyes Black Dragon Rồng Đen Mắt Đỏ" /><br><br>

<p>Jounouchi, học sinh nhà nghèo, sở hữu lá bài Red-Eyes B.Dragon.</p>

<img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-kaiba-blue-eyes-white-dragon.jpg" width="100%" alt="Blue-Eyes White Dragon Rồng Trắng Mắt Xanh" /><br><br>

<p>Kaiba, từ trại trẻ mồ côi thành công tử nhà giàu, sở hữu lá bài Blue-Eyes White Dragon</p></center>

<center><img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-judai-manjoume.jpg" width="100%" alt="Neos Armed Dragon" /><br><br></center>

<p>Và có lẽ cũng vì lý do phân biệt chủng tộc này mà các phần Yugi-Oh! sau này, khi lựa chọn chủ nhân sở hữu sức mạnh ánh sáng và bóng tối, Konami đã cân nhắc về gia cảnh của họ hơn. Trong Yugi-Oh! GX, Judai sở hữu bộ bài Neo Hero thuộc tính ánh sáng, có gia cảnh bình thường. Còn Manjoume với bộ bài Armed Dragon là em út trong 3 anh em nhà giàu, biết phấn đấu đi lên sau thất bại.</p>

<center><img src="/upload/images/game/Konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-jack-yusei.jpg" width="100%" alt="Shooting Star Dragon" /><br><br></center>

<p>Hay như Yugi-Oh! 5Ds, Yusei sở hữu Shooting Star Dragon thuộc tính ánh sáng xuất thân từ khu ổ chuột. Còn Jack sở hữu Red Dragon Archfiend cũng từ khu ổ chuột, nhưng tham gia các giải đấu và được gọi là King. Và tên các lá bài sau này, dù vẫn là cuộc chiến giữa ánh sáng và bóng tối nhưng không ghi tên là Black và White nữa.</p>
',

            'date_post'         => '2020-06-29',
            'thumbnail_post'    => 'konami-doi-ten-la-bai-vi-ly-do-phan-biet-chung-toc-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Fall Guys: Ultimate Knockout bắt đầu xuất hiện hack, Devolver Digital sẽ làm gì?',
            'url_post'        => 'fall-guys-ultimate-knockout-bat-dau-xuat-hien-hack-devolver-digital-se-lam-gi',
            'present_vi_post' => 'Fall Guys bắt đầu xuất hiện hack. Liệu nhà phát hành sẽ làm quyết liệt đến đâu?',
            'content_vi_post' => '<p>Fall Guys là thể loại game Battle Royal nổi tiếng gần đây, được phát triển bởi Mediatonic vào năm 2020 và được xuất bản bởi Devolver Digital. Trò chơi được rất nhiều streamer và game thủ trên khắp thế giới cày cuốc để lên top 1.

Không khốc liệt và bạo lực như các tựa game bắn súng, không cần cấu hình máy quá cao như PUBG, Fall Guys giống như một chuỗi những bộ môn thể thao với các nhân vật hài hước, dễ thương và đáng yêu, phù hợp mọi lứa tuổi.</p>

<p>Trang chủ <a href="https://fallguys.com/" target="_blank" title="Fall Guys homepage">Fall Guys</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/JwxN7OKTbMU" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<pCác VTuber của Hololive chơi Fall Guys</p></center>

<p>Nhưng sự vui vẻ này đang dần bị đánh mất bởi những tên hacker bắt đầu xuất hiện. Hack nhân vật bay khắp nơi. Kênh Trực Tiếp Game cũng đã gặp phải hack. Đứng trước tình trạng hacker xuất hiện, các nhà sản xuất và nhà phát hành sẽ làm gì?</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/fep-ZgpeN_I" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>1:58 hacker bay khắp sân</p></center>

<p>Để giải quyết vấn đề, Mediatonic cho biết họ sẽ cập nhật một bản sửa lỗi nhằm khắc phục vấn đề gian lận tạm thời. Fall Guy sẽ sử dụng hệ thống chống hacker tương tự Fortnite để chống hacker.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">We&#39;re really sorry about the cheating problem!<br><br>We&#39;re expanding the current detection system this week to improve things<br><br>We also have a BIG update in the next couple of weeks that adds the same anti-cheat used by games such as Fortnite<br><br>Thanks for bearing with us!<br><br>[Not BeanBot]</p>&mdash; Fall Guys 👑 (@FallGuysGame) <a href="https://twitter.com/FallGuysGame/status/1302680927605338113?ref_src=twsrc%5Etfw">September 6, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Phần mềm Easy Anti-Cheat và BattlEye của Epic Game sử dụng cho Fortnite đã giúp Fortnite giảm hack đáng kể. Nếu Fall Guys có thể cập nhật hệ thống này, game sẽ cải thiện hacker rất nhiều.</p>

<p>Một điểm hay khác của Fall Guys là có những phần thi đồng đội và những phần thi cá nhân. Nếu kẻ hacker vào phần thi đồng đội, đồng đội của hacker có thể chấp nhận thua để tên hacker thua theo. Nếu giúp tên hacker thắng thì trong phần thi cuối cùng, tên hacker cũng sẽ giành top 1.

Trong stream của Trực Tiếp Game, đoạn <b>1:09:55</b>, màn chơi đầy tính fair play của đội xanh đã bắt tên hacker phải chịu thua. Đội xanh biết nếu giúp tên hacker thắng, hắn sẽ lấy luôn top 1.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/gw3oSgMuR5g" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Buổi stream có hack của Trực Tiếp Game, đoạn <b>1:09:55</b></p></center>

<p>Hay như một trường hợp của tài khoản Twitter tên là @OldManGroucHy. Trong màn chơi Fall Ball, @OldManGroucHy liên tục theo đuôi để tóm lấy tên hacker, kẻ có vẻ đang sử dụng hack tốc độ. Kết quả là trận đấu đó bạn thua nhưng tên hacker đã được ngăn chặn.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr"><a href="https://twitter.com/hashtag/FallGuys?src=hash&amp;ref_src=twsrc%5Etfw">#FallGuys</a> Unspoken Rule #1: &quot;When you have a hacker on your team, you must throw.&quot; <a href="https://twitter.com/FallGuysGame?ref_src=twsrc%5Etfw">@FallGuysGame</a> <a href="https://t.co/v4Ok8wLzCh">pic.twitter.com/v4Ok8wLzCh</a></p>&mdash; J. Mooar (@OldManGroucHy) <a href="https://twitter.com/OldManGroucHy/status/1297566389042065418?ref_src=twsrc%5Etfw">August 23, 2020</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Đó chính là điểm hay của Fall Guys. Game làm giảm tính cạnh tranh, thắng thua và thay vào đó là một cộng đồng chơi game để giải trí, hoàn toàn lành mạnh.</p>

<p>Một chiến thuật thất bại nhưng đáng học hỏi của Fall Guys là Cheater Island, đưa các hacker vào cùng một danh sách để các hacker này chơi với nhau. Cách làm này trước đây Call of Duty Warzone đã từng áp dụng.</p>

<p>Tuy nhiên, hệ thống không biết vì lý do gì đã đưa những người chơi vô tội vào đảo, dẫn đến cảnh tượng xem các hacker bay như siêu nhân. Dù chưa kiểm chứng những kiến nghị đó có thật hay không, nhưng Cheater Island đã phải đóng cửa.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/jL07NfVI69I" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Phê Game nói về Cheater Island của Fall Guys</p></center>

<p>Vấn đề khác của game là Mediatonic chưa thêm hệ thống báo cáo vào trò chơi. Hiện có hai cách báo cáo: qua email và Discord.

Người chơi có thể gửi tin nhắn về hacker tới support@fallguys.com. Tại thời điểm viết bài, kênh Discord để báo cáo tin tặc đã bị đóng cửa để tránh "vô tình quảng cáo chỗ để lấy phần mềm hack". Skylite, một trong những quản trị viên cho biết.</p>

<p>Hướng dẫn cách <a href="https://dotesports.com/news/how-to-report-hackers-and-players-in-fall-guys" target="_blank" title="Fall Guys homepage">report hacker trong Fall Guys</a></p>

<p>Mediatonic nên sớm tạo chế độ report để báo cáo các tài khoản sử dụng tool hack và phạt thật nặng. Có như vậy, môi trường game Fall Guys mới thật sự là nơi mọi người vào để xả stress nhẹ nhàng, thoải mái.</p>
',

            'date_post'         => '2020-09-15',
            'thumbnail_post'    => 'fall-guys-ultimate-knockout-bat-dau-xuat-hien-hack-devolver-digital-se-lam-gi-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nguyên nhân Among Us được tìm kiếm nhiều trong các trang web đen',
            'url_post'        => 'nguyen-nhan-among-us-duoc-tim-kiem-nhieu-trong-cac-trang-web-den',
            'present_vi_post' => 'Một nguồn tài nguyên phong phú về tentacle.',
            'content_vi_post' => '<p>Sau những game có nhiều nhân vật nữ xinh đẹp như Overwatch, Valorant, League of Legend. Chúng ta đều nghĩ: làm sao các nhân vật dễ thương như Among Us hay Fall Guys lại có thể xuất hiện trong các trang web đen? Thật là mất hình tượng</p>

<p>Tuy nhiên, càng thắc mắc, càng tò mò. Lưu lượng tìm kiếm về Among Us trên web đen tăng rất cao, đạt gần 700.000 lượt tìm kiếm trong 1 ngày.</p>

<center><img src="/upload/images/game/nguyen-nhan-among-us-duoc-tim-kiem-nhieu-trong-cac-trang-web-den-pornhub-among-us.jpg" width="100%" alt="Among Us Pornhub" /></center>

<h3>Kích thích trí tò mò, sáng tạo nhưng vẫn muốn giữ hình tượng.</h3>

<p>Chính vì Among Us hay Fall Guys rất khó để trở thành chủ đề nhạy cảm, thậm chí không nên biến thành chủ đề nhạy cảm nên lại càng kích thích trí tò mò. Thời buổi hiện nay, bất kỳ phim ảnh nào trở nên nổi tiếng đều có thể có phiên bản người lớn.</p>

<p>Trước đây, các nhân vật trông rất dễ thương như Pokémon cũng đã có phiên bản người lớn. Tuy nhiên, người xem chỉ xem một khoảng thời gian rồi bỏ vì đơn giản, họ không muốn mất hình tượng dễ thương, trong sáng mà các nhân vật này mang lại. Vậy nên Among Us hay Fall Guys chỉ là xu hướng tạm thời. Bằng chứng là trong biểu đồ, số lượng tìm kiếm chỉ dồn vào vài ngày.</p>

<p>Tất cả nhân vật được tạo ra với tính cách riêng. Hiền lành, dịu dàng, trong sáng hay nóng nảy, bộc trực hoặc suy nghĩ đen tối. Khán giả khi nhìn vào nhân vật đó, tính cách của họ đã gắn liền với hình mẫu nhân vật. Vì vậy, tìm kiếm hình ảnh người lớn chỉ là tò mò nhất thời. Khán giả biết và không thích một nhân vật hiền lành, dịu dàng đột nhiên lật mặt 180 độ, trở thành nhân vật nghiện chuyện đó. Làm thế rất mất hình tượng.</p>

<h3>Tentacle, Threesome, Foursome</h3>

<p>Nếu ai thích 2 thể loại này thì chắc chắn sẽ hiểu. Bối cảnh của Among Us là một con tàu không gian bị sinh vật ngoài vũ trụ tấn công. Theo mô tả trong game, sinh vật có cái miệng to, lưỡi dài đâm xuyên đầu nạn nhân. Những phiên bản phim Among Us, sinh vật này còn có xúc tu.</p>

<p>Mà nhắc đến xúc tu là phải nhắc đến thể loại Tentacle. Thể loại này mô tả cảnh các sinh vật có xúc tu như mực hay quái vật sẽ quấn lấy nạn nhân, giao phối với họ và sinh ra trứng, đẻ con.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/L-dRVVy7rJ4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>KINGDOM NVHAI đánh giá cao nhất fanart Among Us này</p></center>

<p>Còn tag Threesome, Foursome thì nhẹ nhàng hơn. Vì có 2 Imposters nên chúng ta có thể hình dung ra cảnh 3-4 người làm chuyện đó với nhau. Chưa kể, các Imposters phải tìm chỗ kín, góc khuất để ám sát nạn nhân. Chi tiết này giống với các bộ phim làm chuyện đó ở nơi đông người.</p>

<h3>Xu hướng tìm kiếm những thứ đang nổi tiếng</h3>

<p>Khi trên mạng có hiện tượng gì đó nổi tiếng, nhất là về game, anime hay các nhân vật hư cấu, chắc chắn sẽ có những lưu lượng tìm kiếm từ khóa đó đổ về các trang web đen.</p>

<p>Thứ 1: game, anime hay các nhân vật hư cấu có thể được vẽ bởi bất kỳ ai, miễn là càng giống càng tốt. Đây là điểm khác biệt với nhân vật người thật.</p>

<p>Thứ 2: đây là tín hiệu tốt đối với diễn viên lồng tiếng và nhà sản xuất. Nhiều người vẽ về nhân vật game, anime đồng nghĩa với việc game, anime của họ đang rất được tìm kiếm, hâm mộ. Lưu lượng tìm kiếm và số lượng fanart quan trọng không kém số lượt tải về hay lượt xem tại các trang chính thống.</p>

<h3>Đơn giản vì rảnh rỗi khi đang ngồi ở nhà</h3>

<p>COVID19 chỉ là một phần lý do. Dù có COVID19 hay không, bạn vẫn sẽ có những thời gian rảnh, thời gian chơi game Among Us. Và khi đó, bạn sẽ đột nhiên có những suy nghĩ liên kết giữa cái cũ là phim đen với cái mới là game Among Us. </p>

<p>Và khi liên kết như vậy, mọi người sẽ tò mò và quay lại với lý do đầu tiên: kích thích trí tò mò, sáng tạo, tìm tòi cái mới.</p>
',

            'date_post'         => '2020-10-09',
            'thumbnail_post'    => 'nguyen-nhan-among-us-duoc-tim-kiem-nhieu-trong-cac-trang-web-den-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'DAMWON Gaming vô địch Chung kết thế giới 2020',
            'url_post'        => 'damwon-gaming-vo-dich-chung-ket-the-gioi-2020',
            'present_vi_post' => 'Sau 2 năm thất bại, LCK đã giành lại cúp vô địch Chung Kết Thế Giới. Việt Nam cũng đã có đại diện đầu tiên vào đến trận chung kết.',
            'content_vi_post' => '<p>Trận chung kết Liên Minh Huyền Thoại giữa DAMWON và Suning diễn ra tại Thượng Hải vào ngày 31/10/2020 đã kết thúc với tỉ số 3-1. DAMWON đã lấy lại chức vô địch về cho Hàn Quốc sau 2 năm mất ngôi về tay Châu Âu và Trung Quốc. Đây cũng là mốc đánh dấu 6 năm kể từ lần đối đầu cuối cùng tại Chung Kết giữa 2 khu vực LPL và LCK. Và đặc biệt nhất, đây là bước tiến xa nhất, thành công nhất của Sofm, niềm tự hào của Việt Nam sau 4 năm vất vả ở Trung Quốc dưới 2 màu áo đội tuyển Snake Esports và Suning.</p>

<center><img src="/upload/images/game/damwon-gaming-vo-dich-chung-ket-the-gioi-2020-1.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<iframe width="560" height="315" src="https://www.youtube.com/embed/XE9B17fvAHc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trận đấu giữa DAMWON Gaming và Suning</p></center>

<p>Game 1: con bài khống chế cứng Ashe và Pantheon xuất hiện ở đường dưới của DAMWON. Sofm tiếp tục sử dụng Shen đi rừng và có chỉ số kda rất tốt 3/0/1 trước phút 20. Nhưng vấn đề là Shen là tank, không có khả năng gánh team tốt. DAMWON đánh kiểm soát và dần dần có đủ 4 rồng. Những pha giao tranh quanh hang rồng và hang Baron thất bại khiến lợi thế tuột dần khỏi tay Suning. Đội hình quá nhiều khống chế của DAMWON phát huy lợi thế tốt trong giao tranh và kết thúc trận đấu sau 44 phút thi đấu.</p>

<center><img src="/upload/images/game/damwon-vs-suning-game-1.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<p>Shen của Sofm có kda 3/0/1 trước phút 20</p></center>

<p>Game 2: Ormn tiếp tục xuất hiện. Và phương án Suning đưa ra là Fiora. Sofm có chiến thuật mới là Rengar tank, tướng bị thất truyền trong meta hiện tại. Rengar vùng vậy trong giao tranh rất tốt. Fiora của Bin đầu game thoải mái thì cuối game rất khỏe, 3/0/2 vào phút 27. 2 pha highlight kinh khủng nhất của Fiora là dứt điểm Lucian trước khi Lucian kịp dịch chuyển và Pentakill kết thúc trận đấu.</p>

<center><img src="/upload/images/game/damwon-vs-suning-game-2-1.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<p>ShowMaker quá chủ quan khi dịch chuyển trước mặt Bin</p>

<img src="/upload/images/game/damwon-vs-suning-game-2-2.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<p>Pentakill của Bin</p></center>

<p>Game 3: Sofm được chơi Nidalee nhưng Canyon đánh Graves đã sớm có 2 mạng hạ gục. Jax của Bin đã bị gây khó khăn từ sớm. DAMWON lại trở lại với phong cách kiểm soát của Hàn Quốc nên chiến thuật Akali và Jax đẩy lẻ không có tác dụng. Sau 30 phút, DAMWON có 4 rồng. Đội hình đẩy lẻ, cấu rỉa của Suning không đánh lại đội hình giao tranh tổng của DAMWON. Và thất bại đã hiện lên sau khi hỗ trợ SwordArt bị 3 người đuổi đánh, DAMWON tiến vào hang Baron và giao tranh hơn người với Suning. Trận đấu kết thúc sau 35 phút.</p>

<center><img src="/upload/images/game/damwon-vs-suning-game-3.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<p>Alistar ít kháng phép bị Kennen giật điện mất gần nửa cây máu.<br>
Sau đó DAMWON vào hang Baron và thắng giao tranh.</p></center>

<p>Game 4: Trận đấu cuối cùng, sai lầm đến từ Suning khi chọn Gangplank, một tướng ít cơ động bị Kindred hỏi thăm. Bin và Sofm đã có một pha thất bại chí mạng vào 6 phút 47 giây khi cho Canyon 2 mạng quý giá. Phút 15, Kindred 4 mạng, Gangplank 1/3/0 và trận đấu đã có kết quả sớm. 27 phút, Kindred 8/0/6.</p>

<center><img src="/upload/images/game/damwon-vs-suning-game-4.jpg" width="100%" alt="DAMWON Gaming Suning 2020" />

<p>Kindred của Canyon quá mạnh</p></center>

<p>Khác với 3 đội Top Esports, JD Gaming và LGD Gaming, Suning không hề nhận bất kỳ lời chỉ trích nào. Lần đầu tiên tham gia Chung Kết Thế Giới, Suning với tư cách là hạt giống số 3 đã vào đến trận chung kết. LPL vẫn rất mạnh, chỉ là LCK đã cải thiện bản thân. Sofm và các đồng đội đã làm rất tốt, một kỳ tích ngoài mong đợi của bất kỳ cổ động viên nào, kể cả khán giả Việt Nam. </p>

<p>
Hạt Giống Số 1: Top Esports<br>
Hạt Giống Số 2: JD Gaming<br>
Hạt Giống Số 3: Suning<br>
Hạt Giống Số 4: LGD Gaming<br>
</p>

<p>Việt Nam chỉ hy vọng Sofm vào đến Tứ Kết, điều mà chưa đội tuyển Việt Nam nào làm được, đã là một thành công của riêng Sofm. Nhưng Sofm đúng là một thần đồng. Là người Việt Nam đầu tiên xuất ngoại và xuất ngoại thành công, là người Việt Nam đầu tiên vượt qua vòng bảng Chung Kết Thế Giới và giờ là người Việt Nam đầu tiên đánh trận chung kết và thắng 1 trận. Đây là kết quả quá xứng đáng sau nhiều mùa giải không thành với Snake Esports.</p>

<p>Xin chúc mừng Suning và Sofm!</p>
',

            'date_post'         => '2020-10-31',
            'thumbnail_post'    => 'damwon-gaming-vo-dich-chung-ket-the-gioi-2020-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Vampire Lady trong Resident Evil 8 nhanh chóng có NSFW',
            'url_post'        => 'vampire-lady-in-resident-evil-8-has-nsfw',
            'present_vi_post' => 'Nhân vật Vampire Lady giống Hachishakusama đang gây xôn xao cộng đồng game thủ',
            'content_vi_post' => '<p>Vào ngày 22/1/2021, Capcom đã tung ra bản demo Resident Evil 8 kèm theo trailer. Game sẽ được ra mắt bản chính thức vào ngày 7/5/2021.</p>

<p>Bối cảnh trong một căn biệt thự lớn đầy rẫy các nữ ma cà rồng. Người chơi xuất hiện trong hầm ngục của căn biệt thự. Trong biệt thự có rất nhiều câu đố, những bức tranh, bức tượng cổ và xác người bị mất nửa thân dưới. Đến cuối game, một ma cà rồng xuất hiện, cắn người chơi bị trọng thương. Khi người chơi chạy trốn đến cửa ra của biệt thự thì 1 quý bà cao lớn với móng tay dài như Lady Deathstrike trong X-men xuất hiện và kết liễu người chơi. Ngay lập tức, bộ ngực khủng của bà đã làm các game thủ không khỏi ngỡ ngàng.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/btFclZUXpzA" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer Resident Evil 8: Village</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/Udnu2LBPdRc" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Gameplay của Gamespot</p>

<img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-lady-deathstrike.jpg" width="100%" alt="Vampire Lady Resident Evil 8 Lady Deathstrike" />

<p>Móng tay giống Lady Deathstrike</p></center>

<p>Tạo hình của Vampire Lady rất giống với nhân vật Hachishakusama (Eight Foot Tall) trong hentai. Hachishakusama, dịch ra là Cao 8 Feet (khoảng 2,5 mét) là một con ma nữ rất cao, bộ ngực lớn và chuyên đi dụ dỗ các bé trai. Con ma này hay phát ra âm thanh "Po... Po... Po... Po... Po... Po..." với giọng nam trầm. Cách duy nhất để thoát khỏi con ma này là tìm cách chạy trốn khỏi ngôi làng nơi con ma này hoành hành.</p>

<center><img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady-hachishakusama.jpg" width="100%" alt="Vampire Lady Resident Evil 8 Hachishakusama" />

<p>Từ bộ ngực, chiều cao đến nước da, miệng rộng.<br>
Thậm chí là cả chiếc mũ vành đều rất giống nhau.</p>

<img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady.jpg" width="100%" alt="Vampire Lady Resident Evil 8" /></center>

<p>Vì tạo hình giống nhân vật trong hentai, cùng với trào lưu nữ quyền đang nở rộ trong giới điện ảnh và làm game, Vampire Lady nhanh chóng có hàng loạt bức vẽ fanart gắn tag Milf. Chỉ trong vài ngày, một loạt hình ảnh NSFW (Not safe for work) đã xuất hiện tràn ngập trên mạng.
Các game thủ cảm thấy háo hức hơn là sợ hãi khi "được" sống trong một biệt thự cổ cùng với các mỹ nữ xinh đẹp. Ngay cả các cosplayer có bộ ngực lớn cũng tranh thủ hóa trang thành Vampire Lady.</p>

<p>NSFW là viết tắt của từ Not safe for work, ám chỉ những hình ảnh khỏa thân, tình dục, không phù hợp ở nơi đông người, nơi làm việc.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">dont make me come down there and grab you, ethan 😈💕<br><br>wanted to try out the tall lady from re8! im excited to see more of her soon, and i hope shes as terrifying as Mr X was<br><br>as always... spicy vampire milf pics on OF 💀<a href="https://twitter.com/hashtag/ResidentEvilVillage?src=hash&amp;ref_src=twsrc%5Etfw">#ResidentEvilVillage</a> <a href="https://twitter.com/hashtag/re8?src=hash&amp;ref_src=twsrc%5Etfw">#re8</a> <a href="https://twitter.com/hashtag/REVillage?src=hash&amp;ref_src=twsrc%5Etfw">#REVillage</a> <a href="https://twitter.com/hashtag/REBHFun?src=hash&amp;ref_src=twsrc%5Etfw">#REBHFun</a> <a href="https://t.co/pkOTMZN0VY">pic.twitter.com/pkOTMZN0VY</a></p>&mdash; striderscribe 💕 (@striscribe) <a href="https://twitter.com/striscribe/status/1351611389505372161?ref_src=twsrc%5Etfw">January 19, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">hey kids you want some... uhhhhhhh.... flies 🪰<br><br>back at it again with another resident evil village makeup test, just wanted to see if i could get the overall look down 😇 did you guys get to see the demo yet?<a href="https://twitter.com/hashtag/re8?src=hash&amp;ref_src=twsrc%5Etfw">#re8</a> <a href="https://twitter.com/hashtag/residentevil?src=hash&amp;ref_src=twsrc%5Etfw">#residentevil</a> <a href="https://twitter.com/hashtag/ResidentEvilVillage?src=hash&amp;ref_src=twsrc%5Etfw">#ResidentEvilVillage</a> <a href="https://twitter.com/hashtag/ResidentEvil8?src=hash&amp;ref_src=twsrc%5Etfw">#ResidentEvil8</a> <a href="https://t.co/vXk0dnEnXm">pic.twitter.com/vXk0dnEnXm</a></p>&mdash; striderscribe 💕 (@striscribe) <a href="https://twitter.com/striscribe/status/1353077647744622593?ref_src=twsrc%5Etfw">January 23, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<center><img src="/upload/images/game/lady-dimitrescu-1.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /><br><br>

<img src="/upload/images/game/lady-dimitrescu-2.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /><br><br>

<img src="/upload/images/game/lady-dimitrescu-3.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /><br><br>

<img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady-nsfw-1.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /><br><br>

<img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady-nsfw-2.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /><br><br>

<img src="/upload/images/game/hachishaku-sama-1.jpg" width="70%" alt="Vampire Lady Resident Evil 8 NSFW" /></center>

<p>Cốt truyện trong trailer Resident Evil 8: Village chưa rõ ràng. Sau đây là một số thông tin được hé lộ trong trailer:</p>

<p>Tại một ngôi làng hoang gần tòa lâu đài cổ, có một bà lão có vẻ là một thầy bói mù nói rằng: "They will coming again". Có lẽ đây là câu nói ám chỉ ma cà rồng.</p>

<p>Sau đó là cảnh một nhóm tôn giáo nắm tay nhau quanh biểu tượng trông giống bào thai có 4 cánh chim. Trong trailer mới nhất, biểu tượng này xuất hiện trong tòa lâu đài.</p>

<center><img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-logo.jpg" width="70%" alt="Vampire Lady Resident Evil 8" /></center>

<p>Quý bà Vampire Lady có tên là Lady Dimitrescu. Trong trailer mới, Lady Dimitrescu có cuộc gọi với một người tên là mẹ Miranda. Nội dung cuộc gọi như sau:</p>

<p>"Thưa mẹ Miranda, con rất tiếc khi phải báo tin rằng Ethan Winters đã trốn thoát khỏi tay của tên ngốc Heisenberg… vì hắn ta đang trong lâu đài của con và có vẻ quá sức đối với những đứa con gái của con. Khi con tìm được hắn… không… Vâng, dĩ nhiên. Con biết buổi lễ quan trọng như thế nào".</p>

<center><img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady-1.jpg" width="100%" alt="Vampire Lady Resident Evil 8" />

<p>Cuộc gọi của Vampire Lady với mẹ Miranda</p></center>

<p>Dựa vào cuộc gọi, chúng ta có thể đoán được: Lady Dimitrescu và các nữ ma cà rồng đang cần Ethan Winters - nhân vật chính - cho một nghi thức nào đó. Chắc chắn nó có liên quan đến biểu tượng bào thai có 4 cánh. Heisenberg chính là người đàn ông cầm cây búa to hình chữ thập. Và dân làng cũng đã tham gia vào giáo phái đó.</p>

<center><img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-Heisenberg.jpg" width="100%" alt="Vampire Lady Resident Evil 8" /></center>

<p>Tuy nhiên, còn một câu hỏi khác. Đó là mối quan hệ giữa tôn giáo này với tập đoàn Umbrella. Trong tòa lâu đài có logo của Umbrella. Xung quanh là 4 biểu tượng khác. Liệu Umbrella có liên quan đến những người sói bao vây làng trong trailer?</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/arEdruKxrQ8" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/CNpIfP4vtrE" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer năm 2020 và trailer mới</p></center>

<p>Các fan hâm mộ rất mong đến tháng 5/2021 để được mua bản chính thức của Resident Evil 8: Village để tiếp tục được chiêm ngưỡng Vampire Lady với bộ ngực milf hoành tráng.</p>
',

            'date_post'         => '2021-01-25',
            'thumbnail_post'    => 'vampire-lady-in-resident-evil-8-has-nsfw-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Cover Corp ra mắt Hololive Alternative với đồ họa đáng kinh ngạc',
            'url_post'        => 'cover-corp-ra-mat-hololive-alternative-voi-do-hoa-dang-kinh-ngac',
            'present_vi_post' => 'Mong ước của các fan về một phiên bản game phong cách anime của Hololive đang dần trở thành sự thật.',
            'content_vi_post' => '<p>Một đoạn trailer do Cover Corp thực hiện đã giới thiệu một vũ trụ song song dành cho các tài năng Hololive của công ty, nơi họ được giải phóng khỏi các buổi stream, có tên là dự án game Hololive Alternative.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/DlZYG2NVaqo" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>"Hololive Alternative" Teaser PV</p>

<img src="/upload/images/anime/hololive-alternative-homepage-bg.jpg" width="100%" alt="Hololive Alternative Homepage background" /></center>

<p>Bản xem trước giới thiệu một loạt các thành viên idol Hololive trong nhiều môi trường khác nhau. Có những cảnh quay với cảnh đô thị hay đồng cỏ, cảnh chiến đấu với rồng hay cảnh lau dọn trong biệt thự rộng lớn. Bài hát do streamer của Hololive EN Mori Calliope hát.  Thật khó để xác định chính xác nội dung cụ thể là gì, nhưng chất lượng và phong cách hoạt ảnh thì thật tuyệt vời.</p>

<center><img src="/upload/images/anime/Hololive-Alternative-Mori-Calliope.jpg" width="70%" alt="Hololive Alternative Mori Calliope" />

<p>Mori Calliope - một trong năm streamer đầu tiên của Hololive EN</p></center>

<p>Trong trailer, khán giả có thể thấy Tokino Sora, thần tượng đầu tiên của Hololive có vẻ sẽ đóng vai chính trong phim. Cặp đôi Flare và Noel xuất hiện với cảnh chiến đấu hoành tránh. Noel ném một con rồng lên trời, nhiều khả năng là Coco. Thuyền trưởng Marine đứng trên cao hướng mắt nhìn bãi biển. Aqua với bộ đồ hầu gái truyền thống đang dọn dẹp một biệt thự lộng lẫy. Fubuki đứng quay mặt đi cùng Mio. Roboco và Choco không rõ đang làm gì và ở đâu. Ayame, Matsuri, Korone, Okayu, Pekora.</p>

<center><img src="/upload/images/anime/hololive-alternative-shirogane-noel.jpg" width="100%" alt="Hololive Alternative Shirogane Noel" />

<p>Con rồng bị Shirogane Noel ném lên trời là Kiryu Coco</p>

<img src="/upload/images/anime/hololive-alternative-houshou-marine.jpg" width="100%" alt="Hololive Alternative Houshou Marine" />

<p>Houshou Marine trước cảnh biển tuyệt đẹp</p>

<img src="/upload/images/anime/hololive-alternative-amane-kanata.jpg" width="100%" alt="Hololive Alternative Amane Kanata" />

<p>Amane Kanata rơi từ trên cao</p>

<img src="/upload/images/anime/hololive-alternative-yuzuki-choco.jpg" width="100%" alt="Hololive Alternative Yuzuki Choco" />

<p>Yuzuki Choco-sensei</p></center>

<p>Đặc biệt, trong trailer có một chi tiết thú vị: ở đầu trailer, Sora đứng ở thế giới hiện đại với các tòa nhà cao tầng. Nhưng cuối trailer, Sora đứng ở đồng cỏ, bên phải là một con tàu và bên trái là một cột điện. Vì vậy, KINGDOM NVHAI đặt ra 2 giả thuyết:</p>

<p>Tokino Sora xuyên không sang thế giới khác<br>
2 thế giới va chạm vào nhau, kết nối với nhau</p>

<center><img src="/upload/images/anime/hololive-alternative-tokino-sora-1.jpg" width="100%" alt="Hololive Alternative Tokino Sora" />

<img src="/upload/images/anime/hololive-alternative-tokino-sora-2.jpg" width="100%" alt="Hololive Alternative Tokino Sora" />

<p>Sora đứng ở 2 thế giới khác nhau</p></center>

<p>Nhưng nếu ai đã từng xem qua trailer của Fate/Grand Order thì sẽ nhận ra ngay những điểm tương đồng. Vì vậy, nhiều khả năng game Hololive Alternative và Fate/Grand Order cũng sẽ có nhiều điểm giống nhau. Không biết trailer như vậy có vi phạm bản quyền hay không.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/f8kvjyzmEJ4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></center>

<p>Tài khoản chính thức của Hololive đã tiết lộ rằng dự án sẽ có “nhiều loại công trình”. Bản xem trước dài 36 giây chỉ ra một loạt cảnh tiềm năng trong tác phẩm. Truyện tranh trên Twitter dựa trên “câu chuyện gốc” cũng đã được công bố, với các bản phát hành sẽ ra mắt trong thời gian tới.</p>

<p> Motoaki Tanigo, Giám đốc điều hành của Cover, được biết với nickname YAGOO, trước đây đã đăng thông báo tuyển dụng kỹ sư và nghệ sĩ cho Hololive Metaverse, một dịch vụ trực tuyến nơi các tài năng và người hâm mộ của công ty có thể tương tác trong thế giới 2D và một game tiềm năng.</p>

<p>Để biết thêm thông tin cập nhật, bạn có thể theo dõi tài khoản Twitter Hololive Alternative và truy cập trang web chính thức. Đặc biết, có một lời kêu gọi rất cởi mở dành cho các nhà sáng tạo, từ họa sĩ minh họa đến nhà văn ở cuối trang web, mặc dù hoàn toàn bằng tiếng Nhật.</p>

<p>Trang chủ <a href="https://alt.hololive.tv/" rel="nofollow" target="_blank" title="Hololive Alternative Twitter">Hololive Alternative</a></p>
<p>Twitter <a href="https://twitter.com/hololivealt" rel="nofollow" target="_blank" title="Hololive Alternative Homepage">Hololive Alternative</a></p>

<center><img src="/upload/images/anime/hololive-alternative-homepage.jpg" width="100%" alt="Hololive Alternative Homepage" />

<p>Logo ở trên góc hơi kỳ lạ của trang chủ Hololive Alternative</p></center>

<p>Các fan hâm mộ còn đùa rằng: "YAGOO có xuất hiện trong Hololive Alternative không?" Hy vọng câu trả lời sẽ có trong thời gian sớm nhất. Chúc Hololive sẽ thành công với sản phẩm lớn đầu tiên và chúc các cô gái tiếp tục phát triển, giữ vững thế giới Hololive này luôn là nơi cộng đồng fan có thể gắn kết với nhau.</p>
',

            'date_post'         => '2021-02-19',
            'thumbnail_post'    => 'cover-corp-ra-mat-hololive-alternative-voi-do-hoa-dang-kinh-ngac-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Trước khi qua đời, fan gửi tặng Hololive map Minecraft lớn nhất từng tạo',
            'url_post'        => 'truoc-khi-qua-doi-fan-gui-tang-hololive-map-minecraft-lon-nhat-tung-tao',
            'present_vi_post' => 'Một đồng chí, một fan hâm mộ đã dành tặng những phút giây quý giá cuối cùng cho các cô gái Hololive',
            'content_vi_post' => '<p>Một Youtuber tên là Kelanduo đã tạo map Minecraft lớn nhất anh từng tạo để dành tặng các cô gái Hololive trước khi qua đời.</p>

<p>Anh ta đã tạo bức tranh Coco với 3.932.160 khối vuông, phá vỡ kỷ lục bức tranh lớn nhất Minecraft trước đây và tự vượt qua kỷ lục của chính mình khi tạo ra kiệt tác này với hơn 11 triệu khối vuông. Kiệt tác 11 triệu khối vuông được anh tạo ra trong bệnh viện.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/BKJU5w3AoDk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Toàn bộ kiệt tác của Youtuber Kelanduo</p></center>

<p>Anh đã chiến đấu với bệnh tật và qua đời vào 7 giờ tối ngày 11/5/2021. Ca phẫu thuật cứu anh đã thất bại. Nếu trong trường hợp anh không hoàn thành được kiệt tác, bạn của anh sẽ tiếp tục. Và cuối cùng, anh đã làm được cho đến hơi thở cuối cùng.</p>

<p><a href="https://twitter.com/DygliaL/status/1390871012779065349?s=20&fbclid=IwAR3WMdgHDw_nmoaRk1j4cllZMxa4fzmeCwGWVUn_8Y7KLHcDgjq4lUUhLho" target="_blank">Link bài viết Twitter</a></p>

<p><a href="https://www.reddit.com/r/Hololive/comments/n9x907/kelanduo_the_legend_who_made_the_worlds_larggest/" target="_blank">Link bài viết Reddit</a></p>

<center><img src="/upload/images/website/truoc-khi-qua-doi-fan-gui-tang-hololive-map-minecraft-lon-nhat-tung-tao-1.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/truoc-khi-qua-doi-fan-gui-tang-hololive-map-minecraft-lon-nhat-tung-tao-2.jpg" width="70%" alt="Kelanduo give Hololive map Minecraft" />

<p>Những bình luận thể hiện sự tiếc thương một đồng chí tuyệt vời</p></center>

<p>Như một ẩn ý, video bắt đầu là bức vẽ Aloe, VTuber đã tốt nghiệp chỉ sau một tháng do bị những kẻ xấu trên mạng chỉ trích. <a href="/post/cac-drama-cua-hololive" title="các drama của Hololive">Aloe là VTuber thế hệ thứ 5.</a> Do để lộ hình ảnh model nhân vật trong buổi stream thử nghiệm nên đã bị Hololive phạt. Nhưng những lời lẽ trên mạng mới là nguyên nhân khiến cô xin tốt nghiệp. Có lẽ anh đã rất thương tiếc Aloe nên đã để bức vẽ của cô xuất hiện đầu tiên trong video và cũng vẽ cô ấy nhiều nhất.</p>

<p>Những bình luận thể hiện sự tiếc thương anh, một đồng chí, một fan hâm mộ đã dành tặng những phút giây quý giá cuối cùng cho các cô gái Hololive xuất hiện trên Reddit, Twitter và Facebook. Kênh Kelanduo giờ đã được bàn giao lại cho người bạn của anh.</p>

<p>Hãy cùng ngắm nhìn kiệt tác của anh:</p>

<center><img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-1.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-2.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-3.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-4.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-5.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-6.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-7.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<img src="/upload/images/website/fan-hololive-kelanduo-biggest-minecraft-art-8.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" /></center>

<p>Sau khi những bài viết về Kelanduo được chia sẻ khắp Internet, kênh Youtube Kelanduo đã tăng số subcribe một cách thần tốc. Một Youtuber khác đã làm video tặng Kelanduo. Và điều đặc biệt đã đến với anh: Matsuri đã bình luận vào video của anh. Hy vọng kênh Youtube của Kelanduo sẽ đạt 100.000 subcribe để anh có thể mỉm cười nơi chín suối.</p>

<center><img src="/upload/images/website/truoc-khi-qua-doi-fan-gui-tang-hololive-map-minecraft-lon-nhat-tung-tao-matsuri.jpg" width="100%" alt="Kelanduo give Hololive map Minecraft" />

<p>Bình luận của Matsuri</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/EaZAlU-PmWc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Video có bình luận của Matsuri</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/kr_i31aZbxQ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Một video dành tặng Kelanduo</p></center>

<p>Anh đã làm rất tốt! Cảm ơn anh và chúc anh yên nghỉ!</p>
',

            'date_post'         => '2021-05-13',
            'thumbnail_post'    => 'truoc-khi-qua-doi-fan-gui-tang-hololive-map-minecraft-lon-nhat-tung-tao-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Diablo 2: Resurrected tại BlizzConlin 2021 liệu có giống Warcraft 3 Reforged?',
            'url_post'        => 'Diablo-2-Resurrected-tai-BlizzConlin-2021-lieu-co-giong-Warcraft-3-Reforged',
            'present_vi_post' => 'Thảm họa Warcraft 3 Reforged năm 2020 liệu có được Blizzard rút kinh nghiệm trong Diablo 2: Resurrected?',
            'content_vi_post' => '<p>Năm 2020 là một năm đáng quên của Blizzard với Warcraft 3 Reforged. Đồ họa hoàn toàn khác so với bản demo được quảng cáo tại Blizzcon 2018, trục trặc kỹ thuật, những bất cập của phần chơi mạng và đặc biệt là những map do người chơi tạo ra, nhà phát hành sẽ lấy hết doanh thu. Warcraft 3 Reforged là một nỗi thất vọng đáng quên của các fan hâm mộ</p>

<p>Ngày 20/2/2021, BlizzConlin 2021 công bố đoạn trailer của game huyền thoại khác là Diablo 2: Resurrected. Bản làm lại của Diablo 2 sẽ được ra mắt trong năm 2021. Năm nay, vì đại dịch COVID nên Blizzcon không tổ chức trực tiếp mà tổ chức online. Vậy nên tên sự kiện đã được đổi thành BlizzConlin.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/W41NvIgeKX0" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Diablo 2: Resurrected - Official Reveal Trailer | BlizzConlin 2021</p></center>

<p>Nếu như ai đã từng sử dụng Window XP với dàn máy tính màn hình dày ngày xưa chắc chắn vẫn còn nhớ tựa game Diablo 2 huyền thoại này. Đặc biệt là thế hệ 8x 9x, không ít thanh niên đã từng trải nghiệm game này trong list game offline tại quán net, ở nhà. Giờ đây, Diablo 2: Resurrected sẽ có đồ họa 4K, lối chơi được giữ nguyên.</p>

<p>Các game thủ có thể đăng ký chơi bản Alpha tại <a href="https://diablo2.blizzard.com/en-us/" rel="nofollow" target="_blank" title="Blizzard Diablo 2 Resurrected">trang chủ của Blizzard</a></p>

<p>Tuy nhiên, thảm họa Warcraft 3 Reforged vừa hiện hữu vào đầu năm ngoái đã khiến không ít fan nghi vấn: liệu Diablo 2: Resurrected có lặp lại sai lầm này? 1 năm có đủ để đội ngũ sản xuất kiểm tra kỹ lưỡng trước khi ra mắt? Chắc chắn số lượng Pre Order lần này sẽ thấp hơn số lượng Pre Order của Warcraft 3 Reforged vì các fan không muốn mắc sai lầm như năm ngoái.</p>

<p>Bản Pre Order của Diablo 2: Resurrected có giá 39.99USD</p>

<center><img src="/upload/images/game/diablo-2-resurrected-1.jpg" width="100%" alt="Diablo 2 Resurrected" />

<img src="/upload/images/game/diablo-2-resurrected-2.jpg" width="100%" alt="Diablo 2 Resurrected" />

<img src="/upload/images/game/diablo-2-resurrected-3.jpg" width="100%" alt="Diablo 2 Resurrected" />

<p>Một số hình ảnh trong trailer</p>

<img src="/upload/images/game/diablo-2-resurrected-logo-png.png" width="70%" alt="Diablo 2 Resurrected" />

<p>Logo PNG</p></center>
',
            'date_post'         => '2021-02-20',
            'thumbnail_post'    => 'Diablo-2-Resurrected-tai-BlizzConlin-2021-lieu-co-giong-Warcraft-3-Reforged-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Doki Doki Literature Club Plus! - CLB Văn học phần mở rộng',
            'url_post'        => 'doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong',
            'present_vi_post' => 'Phần mở rộng của game visual novel kinh dị nổi tiếng đã ra mắt vào tháng 6/2021',
            'content_vi_post' => '<p>Sau 4 năm làm dậy sóng cộng đồng anime nói chung và những ai thích chơi game visual novel nói riêng, studio game Team Salvato đã ra mắt phiên bản mở rộng của tựa game Doki Doki Literature Club mang tên Doki Doki Literature Club Plus! Trailer của game đã được ra mắt vào ngày 13/6/2020.</p>

<p><a href="https://ddlc.plus/" target="_blank" title="Doki Doki Literature Club Plus!">Trang chủ Doki Doki Literature Club Plus!</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/rCSnFSfed5A" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="560" height="315" src="https://www.youtube.com/embed/soEwoP20Bw8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer rất dễ thương của Doki Doki Literature Club Plus!</p>

<iframe width="560" height="315" src="https://www.youtube.com/embed/rBu5V31pp58" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer gameplay</p></center>

<p>Doki Doki Literature Club! là một visual novel được phát triển bởi Team Salvato, được phát hành vào ngày 22/9/2017 cho PC, và được đưa lên Steam vào ngày 6/10/2017.
Ban đầu, mọi người đều nghĩ đây chỉ là tựa game visual novel theo dạng hẹn hò, tìm waifu cho mình. Cho đến khi những cảnh tượng kinh dị xuất hiện.
Và đáng sợ nhất là khi game đã phá vỡ bức tường thứ 4, khi nhân vật trong game là Monika có thể chào người chơi hay chào cả <b>NHỮNG NGƯỜI ĐANG THEO DÕI TRÒ CHƠI.</b> Người chơi không thể điều khiển được game theo ý muốn, giống như Monika đang điều khiển thế giới game và cả máy tính của người chơi vậy.</p>

<p>Và cách để thoát khỏi sự kiểm soát của Monika là xóa hẳn file game của Monika khỏi thư mục cài đặt của máy. Sau đó, game sẽ chơi lại được như bình thường. Nhưng dù vậy, cảnh tượng kinh dị vẫn xuất hiện. Sayori sẽ la hét rồi ngay lập tức bị treo cổ chết. Màn hình với cảnh cô bé treo cổ cứ đứng yên tới 10 phút, một dòng chữ nhỏ sẽ hiện ra "Now everyones can be happy" (Bây giờ tất cả mọi người có thể hạnh phúc).</p>

<center><img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-1.jpg" width="100%" alt="Doki Doki Literature Club Plus!" /></center>

<p>Ngày 30/6/2021, trailer thứ 2 game Doki Doki Literature Club Plus! xuất hiện. Một trailer rất dễ thương, nhạc êm dịu và đầy màu sắc.
Đó cũng chính là điểm hay tuyệt vời của game. Hoàn toàn không có bất cứ một cảnh kinh dị máu me nào trong trailer.
Chỉ có tiếng nhạc êm dịu, những cô gái anime dễ thương, xấu hổ. Nàng Monika đang đàn piano thật tuyệt vời.
Mọi thứ đều rất yên bình <b>ngoại trừ 5 giây đầu tiên của trailer cảnh bảo nội dung game có máu, bạo lực và không phù hợp với trẻ em.</b> Cộng thêm một cái click chuột vào chữ <b>Horror</b> trong quyển vở.</p>

<center><img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-2.jpg" width="70%" alt="Doki Doki Literature Club Plus!" />

<p>Một trailer rất dễ thương, trừ 5 giây đầu tiên</p>

<img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-3.jpg" width="100%" alt="Doki Doki Literature Club Plus!" />

<p>Imagination: Trí tưởng tượng<br>
Cute: Dễ thương<br>
Pleasure: Vui vẻ<br>
Anxiety: Lo lắng<br>
Disaster: Tai họa</p>

<p>Destiny: Định mệnh<br>
<b>Horror: Kinh dị</b><br>
Landscape: Phong cảnh<br>
Agonizing: Đau đớn<br>
Desire: Khao khát</p>
</center>

<p>Trong bản Doki Doki cũ, mặc dù game đã cảnh báo "không dành cho trẻ em hoặc những người dễ cảm thấy lo lắng", đồng thời yêu cầu người chơi xác nhận độ tuổi trên 13 nhưng Doki Doki vẫn không thể ngăn những ám ảnh kinh hoàng của nó đến người chơi. Và một vụ án nghiêm trọng xảy ra khi một cậu bé 15 tuổi sống tại Manchester, Anh đã tự sát vào tháng 2/2018. Cậu đã thay đổi tâm lý sau khi chơi game này.</p>

<p>Đó là lý do trong bản Plus mới ra mắt, studio Team Salvato đã nâng cấp cảnh báo lên 17 tuổi. Doki Doki Literature Club Plus! là phần mở rộng với nhiều câu chuyện hơn, âm nhạc và hình ảnh được thêm vào. Cụ thể trang chủ của game nói rõ:</p>

<ul>
<li>Mind-Shattering Horror (Kinh dị làm tan nát tâm trí)
<li>Full HD Visuals (Hình ảnh Full HD)
<li>6 New Side Stories (6 câu chuyện bên lề mới)
<li>13 Additional Music Tracks (bổ sung 13 bản nhạc)
<li>100+ Unlockable Images (Hơn 100 hình ảnh có thể mở khóa)
</ul>

<center><img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-4.jpg" width="100%" alt="Doki Doki Literature Club Plus!" />

<p>Bên trái là những thông tin bổ sung trong bản Plus!</p>

<img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-yuri.jpg" width="100%" alt="Doki Doki Literature Club Plus!" /><br><br>

<img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-monika.jpg" width="100%" alt="Doki Doki Literature Club Plus!" /></center>

<p>Game đã được bán trên Steam, Epic Game Store, Xbox và nhiều nền tảng khác. Hãy cùng quay trở lại với CLB Văn học và "Xóa bỏ sai lầm của bạn", cũng như "nhận được cái kết hoàn hảo" nhé!</p>

<center><img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-5.jpg" width="100%" alt="Doki Doki Literature Club Plus!" />

<p>Hình Yuri bị xóa đi và dòng chữ "Xóa bỏ sai lầm của bạn" hiện lên.</p>

<img src="/upload/images/game/doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-6.jpg" width="100%" alt="Doki Doki Literature Club Plus!" /></center>
',
            'date_post'         => '2021-07-01',
            'thumbnail_post'    => 'doki-doki-literature-club-plus-clb-van-hoc-phan-mo-rong-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Lewd Idol Project bị Paypal chặn tiền ủng hộ',
            'url_post'        => 'lewd-idol-project-developer-toffer-team-banned-on-paypal',
            'present_vi_post' => 'Tương lai của game eroge visual novel này chưa biết đi về đâu',
            'content_vi_post' => '<p>Toffer Team, nhóm làm game 18+ đã ra mắt game visual novel Lewd Idol Project volume 1. Họ đã kêu gọi ủng hộ trên Kickstarter và mọi người đã chuyển khoản cho họ qua Paypal. Số tiền lên đến hơn 35000 USD</p>

<p>Nguồn: <a href="https://www.lewdgamer.com/2021/07/07/lip-lewd-idol-project-developer-toffer-team-banned-on-paypal" target="_blank" title="Lewd Idol Project Paypal">Lewdgame</a></p>

<center><img src="/upload/images/game/lewd-idol-project-fund.jpg" width="100%" alt="Lewd Idol Project Paypal" /></center>

<p>Tuy nhiên, Paypal lại chặn tất cả tiền của họ vì lý do "dịch vụ tình dục". Theo Paypal, tất cả mục đích chuyển tiền vì những lý do như thanh toán cho các trang web khiêu dâm đều sẽ bị chặn.</p>

<h3>Nội quy của Paypal</h3>

<p>Nguồn: <a href="https://www.paypal.com/us/smarthelp/article/what-is-paypal%E2%80%99s-policy-on-transactions-that-involve-sexually-oriented-goods-and-services-faq569" target="_blank" title="Lewd Idol Project Paypal">Paypal</a></p>

<blockquote>
<p>Chúng tôi không cho phép chủ tài khoản PayPal mua hoặc bán:</p>
<ul>
<li>Hàng hóa hoặc nội dung kỹ thuật số có khuynh hướng tình dục được phân phối thông qua phương tiện kỹ thuật số. Hình ảnh hoặc video có thể tải xuống và đăng ký trang web là những ví dụ về hàng hóa kỹ thuật số.
<li>Hàng hóa hoặc dịch vụ có khuynh hướng liên quan đến tình dục hoặc có thể liên quan đến trẻ vị thành niên.
<li>Các dịch vụ có mục đích tạo điều kiện cho các cuộc gặp mặt có hoạt động liên quan đến tình dục.
</blockquote>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">PayPal has permanently locked our account and remaining Kickstarter raised funds for LIP! Lewd Idol Project.<br><br>Today it was us, tomorrow it could be you or any of your favorite lewd content creators.<br><br>Please read and RT to spread the word, we can&#39;t let this things keep happening. <a href="https://t.co/QiQ3k5Z3Li">pic.twitter.com/QiQ3k5Z3Li</a></p>&mdash; Toffer Team 🔞✨ (@TofferTeam) <a href="https://twitter.com/TofferTeam/status/1412436128716763137?ref_src=twsrc%5Etfw">July 6, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Như vậy, Lewd Idol Project đã phạm cả 3 luật cấm của Paypal. Paypal không chấp nhận thanh toán bằng dịch vụ của họ. Điều này rất khó khăn cho Toffer Team. Họ sẽ không có tiền trả cho các lập trình viên và thời gian ra mắt volume 2 cũng bị hoãn vô thời hạn.</p>

<p>Chủ sở hữu của Toffer Team và là lập trình viên chính của Lewd Idol Project cho biết:</p>
<blockquote>
<p>PayPal đã khóa cả 2 tài khoản của chúng tôi để gửi/nhận bất kỳ loại tiền nào, đồng thời khóa số tiền huy động từ cộng đồng [rất khó để kiếm được] của chúng tôi thông qua Kickstarter vì doanh nghiệp của chúng tôi hướng tới "tài liệu hoặc dịch vụ tình dục"</p>
</blockquote>

<p>Nguồn: <a href="https://techraptor.net/gaming/news/lewd-idol-project-paypal-account-locked-kickstarter-funds" target="_blank" title="Lewd Idol Project Paypal">Techraptor</a></p>

<h3>Cốt truyện</h3>

<p>Kairi là một cô gái trẻ trung và hoạt bát có một ước mơ: trở thành thần tượng nổi tiếng! Cô đến Akihabara, thánh địa anime Nhật Bản để thực hiện giấc mơ. Nhưng cô đã bị 15 công ty khác nhau từ chối.</p>

<p>Vốn đã thiếu tiền, số nợ ngày càng tăng, và sau một cuộc thử giọng khác, cô tiếp tục thất bại. Cô đã gặp Ranko, một "producer - nhà sản xuất" tự xưng là người giới thiệu Idol ngây thơ muốn tham gia dự án đầy tham vọng: Dự an Idol khiêu dâm - Lewd Idol Project. Người chơi sẽ cùng Kairi khám phá khu phố Akihabara tuyệt vời, gặp gỡ và tuyển dụng các cô gái mới cho dự án, đồng thời giúp cô ấy thực hiện ước mơ của mình.</p>

<center><img src="/upload/images/game/lewd-idol-project-kairi.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kanako.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-yuki.png" width="70%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-3.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-4.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-5.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-6.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-ranko-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-ranko-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-kairi-ranko-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-1.jpg" width="100%" alt="Lewd Idol Project Paypal" /><br><br>

<img src="/upload/images/game/lewd-idol-project-2.jpg" width="100%" alt="Lewd Idol Project Paypal" /></center>
',
            'date_post'         => '2021-07-08',
            'thumbnail_post'    => 'lewd-idol-project-developer-toffer-team-banned-on-paypal-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Activision Blizzard bị kiện vì quấy rối tình dục nhân viên nữ',
            'url_post'        => 'activision-blizzard-sexual-harassment-lawsuit',
            'present_vi_post' => 'Activision Blizzard bị California kiện vì văn hóa quấy rối tình dục nơi công sở.',
            'content_vi_post' => '<p>Bộ Việc làm Công bằng và Nhà ở California (The California Department of Fair Employment and Housing - DFEH) đã đệ đơn kiện Blizzard và chủ sở hữu Activision Blizzard vào ngày 20/7/2021, cáo buộc văn hóa "quấy rối tình dục" tồn tại tại công ty. Theo đó, các cáo buộc nói về các nhân viên nam uống rượu và quấy rối tình dục các nhân viên nữ mà không có bất kỳ trừng phạt nào.</p>

<p>Nguồn: <a href="https://www.theverge.com/2021/7/24/22591611/activision-blizzard-brack-sexual-harassment-lawsuit-california" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">Theverge</a></p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-1.jpg" width="100%" alt="Activision Blizzard sexual harassment" /></center>

<p>Chủ tịch của Blizzard Entertainment, J. Allen Brack đã gửi một email tới nhân viên gọi những cáo buộc quấy rối tình dục tại công ty là "cực kỳ đáng lo ngại".
Được báo cáo lần đầu tiên bởi Jason Schreier tại Bloomberg, Allen Brack đã viết rằng "cuộc chiến vì sự bình đẳng là vô cùng quan trọng đối với tôi".</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Blizzard president J. Allen Brack sent out an email to staff last night addressing the allegations from this week&#39;s explosive lawsuit, calling them &quot;extremely troubling&quot; and saying that he&#39;d be &quot;meeting with many of you to answer questions and discuss how we can move forward.&quot; <a href="https://t.co/NsMV6CNdTE">pic.twitter.com/NsMV6CNdTE</a></p>&mdash; Jason Schreier (@jasonschreier) <a href="https://twitter.com/jasonschreier/status/1418512291218264065?ref_src=twsrc%5Etfw">July 23, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Theo đơn khiếu nại của DFEH, "các nhân viên nam chơi điện tử trong giờ làm việc, đùa cợt về các cuộc gặp tình dục của họ,
nói chuyện cởi mở về cơ thể phụ nữ và đùa cợt về việc quấy rối". Các nhân viên nam sẽ ngẫu nhiên bắt gặp phụ nữ và bình luận về bộ ngực của cô ấy.</p>

<p>Nguồn: <a href="https://www.polygon.com/22588407/activision-blizzard-sexual-harassment-sexism-california-lawsuit" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">Polygon</a></p>

<p>"Phụ nữ da màu là mục tiêu đặc biệt dễ bị tổn thương của các hoạt động phân biệt đối xử của Activision Blizzard,".
DFEH cũng cáo buộc rằng nhân viên "không được khuyến khích phàn nàn vì nhân viên nhân sự cho là đã gần gũi với những kẻ bị cáo buộc quấy rối."</p>

<p>Thậm chí, Alex Afrasiabi, cựu Giám đốc Sáng tạo cấp cao của World of Warcraft tại Blizzard Entertainment, đã được phép tham gia vào các hành vi
quấy rối tình dục trắng trợn mà ít hoặc không có hình phạt nào. Trong một sự kiện của công ty (một hội nghị thường niên có tên là Blizz Con),
Afrasiabi đã đánh các nhân viên nữ, nói rằng anh muốn kết hôn với họ, cố gắng hôn họ và ôm eo họ.
Việc này rõ ràng là các nhân viên nam khác, bao gồm cả giám sát phải can thiệp và kéo anh ta ra khỏi các nhân viên nữ.</p>

<center><img src="/upload/images/game/sexual-harassment-1.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<p>Về lương thưởng, phụ nữ trong công ty cũng bị cho lương thấp hơn và khó thăng tiến hơn. Trong cuộc phỏng vấn với báo Polygon, Activision Blizzard đã phủ nhận các cáo buộc về văn hóa phân biệt giới tính,
gọi các cáo buộc này là "bị bóp méo và trong nhiều trường hợp là sai sự thật."</p>

<blockquote>
<p>Chúng tôi đã nỗ lực rất nhiều trong việc tạo ra các gói và chính sách đãi ngộ công bằng và xứng đáng, phản ánh văn hóa và doanh nghiệp của chúng tôi.
Đồng thời chúng tôi cố gắng trả lương công bằng cho tất cả nhân viên cho những công việc tương đương hoặc công việc cơ bản.
Chúng tôi thực hiện nhiều bước chủ động khác nhau để đảm bảo rằng việc trả lương được thúc đẩy bởi các yếu tố không phân biệt đối xử.
Ví dụ: chúng tôi khen thưởng và bồi thường cho nhân viên dựa trên hiệu suất của họ và chúng tôi tiến hành các khóa đào tạo chống phân biệt đối xử sâu rộng,
bao gồm cả những người làm việc trong quy trình bồi thường.</p>

<p>Chúng tôi tự tin vào khả năng thể hiện các hoạt động của mình với tư cách là một nhà tuyển dụng có cơ hội bình đẳng,
thúc đẩy một nơi làm việc hỗ trợ, đa dạng và hòa nhập cho mọi người và chúng tôi cam kết tiếp tục nỗ lực này trong những năm tới.
Thật tiếc khi DFEH không muốn tham gia với chúng tôi về những gì họ nghĩ họ đã thấy trong cuộc điều tra của họ.</p>
</blockquote>

<center><img src="/upload/images/game/sexual-harassment-2.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<p>Phó chủ tịch điều hành Activision Blizzard, Fran Townsend đã gọi vụ kiện là "xuyên tạc và không đúng sự thật",
mô tả vụ kiện DFEH là "thực sự bật công và vô trách nhiệm".
Các nhân viên hiện tại và nhân viên cũ đều bắt đầu đăng bài trên các mạng xã hội, yêu cầu Townsend và các lãnh đạo khác từ chức.
Hơn 800 nhân viên của Activision Blizzard thấy "ghê tởm và xúc phạm" trước phản hồi của công ty.
Nhất là khi Fran Townsend là một phụ nữ nhưng lại bênh vực cho hành động quấy rối tình dục của công ty.</p>

<p>Nguồn: <a href="https://www.cnbc.com/2021/07/28/activision-blizzard-ceo-calls-for-investigation-amid-discrimination-suit-walkout.html" rel="nofollow" target="_blank" title="Activision Blizzard sexual harassment">CNBC</a></p>

<p>Townsend đã gửi một email cho toàn công ty, gọi đây là "một vụ kiện thực sự vô ích và vô trách nhiệm"
trong đó "trình bày một bức tranh sai lệch và không đúng sự thật về công ty chúng ta, bao gồm những câu chuyện sai sự thật, cũ kỹ và lạc lõng".</p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-fran-townsend.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br>

<p>Fran Townsend là một phụ nữ nhưng lại bênh vực cho hành động quấy rối tình dục của công ty</p></center>

<center><img src="/upload/images/game/activision-blizzard-sexual-harassment-lawsuit-scandal.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<p>Vẫn chưa biết kết quả thế nào, nhưng có lẽ tình hình này đã tác động xấu đến những game mà Blizzard đang sở hữu. Cụ thể, tất cả mọi hoạt động của Hearthstone đều bị tạm dừng.</p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-fanpage.jpg" width="70%" alt="Activision Blizzard sexual harassment" />

<p>Một fanpage Việt Nam đăng bài về tình hình Hearthstone</p></center>
',
            'date_post'         => '2021-07-26',
            'thumbnail_post'    => 'activision-blizzard-sexual-harassment-lawsuit-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Hololive ERROR - trailer game kinh dị của Hololive',
            'url_post'        => 'hololive-error-trailer-horror-game-hololive',
            'present_vi_post' => 'Phần mở rộng của game visual novel kinh dị nổi tiếng đã ra mắt vào tháng 6/2021',
            'content_vi_post' => '<p>Sau 2 trailer Hololive Alternative, các fan tưởng rằng Hololive sẽ tiếp tục ra mắt thêm trailer mới. Tuy nhiên, ngày 1/8/2021, một trailer kinh dị mang tên Hololive ERROR đã được ra mắt cộng đồng fan hâm mộ VTuber.</p>

<p>Trang chủ <a href="https://hololiveerror.hololivepro.com" target="_blank" title="Hololive ERROR">Hololive ERROR</a></p>
<p>Twitter <a href="https://twitter.com/hololivetv" target="_blank" title="Hololive ERROR">Hololive ERROR</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/iHekCdRagR8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer đầu tiên của Hololive ERROR</p></center>

<p>Hololive là công ty con của COVER, một công ty về các idol streamer mang phong cách anime, gọi là VTuber. Hololive hiện đang phát triển rất mạnh với các streamer đến từ đất nước mặt trời mọc, Indonesia và mới nhất là Hololive English gồm những VTuber nói tiếng Anh.</p>

<p>Trong trailer Hololive ERROR, nhân vật chính bị lạc vào giữa trường học hiện tại và trường học cũ. Trường học cũ đã xảy ra điều gì đó rất khủng khiếp.
Nhân vật chính nhìn thấy một cô nữ sinh hỏi "Will you forever be my friend?" (Bạn sẽ làm bạn của mình mãi mãi chứ?). Đó là Tokino Sora, VTuber đầu tiên của Hololive, cũng là VTuber có sở thích chơi game kinh dị và có tâm hồn trong sáng, lành mạnh nhất của Hololive.</p>

<center><img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-1.jpg" width="100%" alt="Hololive ERROR" /><br><br>

<img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-2.jpg" width="100%" alt="Hololive ERROR" /></center>

<p>Nhân vật chính bỏ chạy và đột nhiên được quay trở lại thế giới thật. Nhưng trong thế giới thật là một trường học, nhân vật chính vẫn thấy Sora đi theo mình.
Nhân vật chính bỏ chạy và nhặt được một nút mũi tên trên bàn. Và trên laptop của mình hiện lên trang chủ của Hololive ERROR.</p>

<p>Vào ngày 6/8/2021, kênh Youtube của Hololive tiếp tục có một video mới về Hololive ERROR, sẽ công chiếu vào ngày 15/8/2021. Trong hình là 4 VTuber khác gồm: Matsuri, Fubuki, Nene và Lamy. Có lẽ họ sẽ tiết lộ thêm thông tin về Hololive ERROR.</p>

<center><img src="/upload/images/game/hololive-error-trailer-game-kinh-di-hololive-3.jpg" width="100%" alt="Hololive ERROR" /><br><br>

<iframe width="560" height="315" src="https://www.youtube.com/embed/WQQAwozBg94" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer tiếp theo của Hololive ERROR</p></center>

<p>Theo dự đoán của KINGDOM NVHAI, đây sẽ là một tựa game thực tế ảo. Trong trailer, chúng ta đã thấy nhân vật chính bị hút vào thế giới ảo giống Sword Art Online hay Accel World. Chưa kể Hololive còn có khả năng tạo các VTuber 3D nên việc làm game thực tế ảo không phải chuyện khó.</p>

<p>KINGDOM NVHAI đã download video và nhạc trên trang chủ Hololive ERROR.</p>

<center>
<video width="100%" controls="" preload="" controlslist="nodownload" poster="http://kingdomnvhai.info/upload/images/video/hololive-error-website-bgm-thumbnail.jpg">
<source src="http://kingdomnvhai.info/upload/video/hololive-error-bg-home.mp4" type="video/mp4">
</video>
</center>
',

            'date_post'         => '2021-08-07',
            'thumbnail_post'    => 'hololive-error-trailer-game-kinh-di-hololive-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nữ diễn viên lồng tiếng cho Mercy bị sát hại',
            'url_post'        => 'nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai',
            'present_vi_post' => 'Một tin đáng buồn dành cho Overwatch, League of Legends và Halo phiên bản tiếng Brazill',
            'content_vi_post' => '<p>Christiance Louise, nữ diễn viên lồng tiếng phiên bản Brazil cho Cortana trong game Halo, Sivir trong game League of legends và Mercy trong game Overwatch đã bị sát hại tại Rio De Janeiro. Cái chết của cô được phát hiện vào ngày 6/8/2021. Louise hưởng thọ 49 tuổi.</p>

<p>Nguồn: <a href="https://www.nme.com/news/gaming-news/man-arrested-for-murder-of-overwatch-voice-actress-christiane-louise-3019239" rel="nofollow" target="_blank" title="Hololive ERROR">NME</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/--wmZZraAGU" title="Christiance Louise Overwatch Mercy" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Giọng lồng tiếng của Mercy bản tiếng Brazil</p></center>

<p>Người đàn ông bị bắt vì liên quan đến vụ giết người là nhà kinh tế học Pedro Paulo Goncalves Vasconcellos da Costa. Có thông tin cho rằng Costa đã sát hại Louise tại nhà riêng, cứa vào chân và cổ cô.</p>

<p>Costa đã ở cùng Louise khi cô hỗ trợ anh ta vượt qua sức khỏe tâm lý. Họ là bạn bè gặp nhau vào năm 2017 trong một phòng khám tâm lý. Costa được cho là có ý định giữ đồ đạc và tài sản của Louise khi họ chuyển đến sống ở nhà của mẹ anh ta. Người mẹ hiện đang bị truy nã. Costa khai anh ta hành động vì tự vệ. Nhưng theo điều tra, anh ta và mẹ đã để thi thể trong nhà 2 ngày trước khi giấu cô.</p>

<center><img src="/upload/images/game/nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai-pedro-paulo-goncalves-vasconcellos-da-costa-christiane-louise.jpg" width="70%" alt="Overwatch Mercy Christiance Louise" />

<p>Pedro Paulo Goncalves Vasconcellos da Costa và Christiane Louise de Paula da Silva</p>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Man Arrested in Rio de Janeiro, Brazil for killing the brazilian voice actress for Mercy (Overwatch), Cortana (Halo), Sivir (League of Legends) Christiane Louise.<a href="https://twitter.com/hashtag/Overwatch?src=hash&amp;ref_src=twsrc%5Etfw">#Overwatch</a> <a href="https://twitter.com/hashtag/LeagueofLegends?src=hash&amp;ref_src=twsrc%5Etfw">#LeagueofLegends</a> <a href="https://twitter.com/hashtag/Halo?src=hash&amp;ref_src=twsrc%5Etfw">#Halo</a> <a href="https://twitter.com/hashtag/HaloInfinite?src=hash&amp;ref_src=twsrc%5Etfw">#HaloInfinite</a> <a href="https://twitter.com/hashtag/news?src=hash&amp;ref_src=twsrc%5Etfw">#news</a> <a href="https://twitter.com/hashtag/Brazil?src=hash&amp;ref_src=twsrc%5Etfw">#Brazil</a> <a href="https://t.co/03LUsG6wIl">pic.twitter.com/03LUsG6wIl</a></p>&mdash; Draug (@Draugoth) <a href="https://twitter.com/Draugoth/status/1426281588631932929?ref_src=twsrc%5Etfw">August 13, 2021</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Tất cả các fan hâm mộ Overwatch nói riêng và những game của Blizzard nói chung đều cảm thấy thương tiếc và chia buồn sâu sắc. Câu nói “Heroes Never Die” nổi tiếng của Mercy được chia sẻ khắp các trang mạng xã hội.</p>

<center><img src="/upload/images/game/nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai-christiane-louise.jpg" width="100%" alt="Overwatch Mercy Christiance Louise" /></center>

<p>Overwatch là tựa game giành giải game hay nhất năm 2016. Tuy nhiên, những sai lầm của Blizzard khi không chịu đổi mới game đã làm game mất lượng lớn người chơi. Overwatch 2 bị trì hoãn ngày ra mắt vì Blizzard bị cáo buộc quấy rối tình dục. Và giờ thì diễn viên lồng tiếng bản tiếng Brazil bị sát hại. Thật là một tựa game có số phận đen đủi. </p>

<center><img src="/upload/images/game/nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai-mercy.jpg" width="70%" alt="Overwatch Mercy Christiance Louise" /></center>
',

            'date_post'         => '2021-08-15',
            'thumbnail_post'    => 'nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Activision Blizzard yêu cầu DMCA hủy bỏ tất cả phim khiêu dâm Overwatch trong vụ kiện quấy rối tình dục',
            'url_post'        => 'activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit',
            'present_vi_post' => 'Một nước đi tự hủy nữa của Blizzard. Một hành động "rút ống thở" tựa game sắp lụi tàn',
            'content_vi_post' => '<p>Lại thêm một tin động trời dành cho tựa game khốn khổ Overwatch. Sau khi diễn viên lồng tiếng bản tiếng Brazill cho Mercy, Christiane Louise bị sát hại tại nhà riêng, Overwatch lại hứng chịu sự ảnh hưởng từ chính cha đẻ của mình là Activision Blizzard. Công ty yêu cầu DMCA, luật bảo vệ quyền tác giả gỡ bỏ hết tất cả phim khiêu dâm của Overwatch trên các web đen.</p>

<p>Nguồn: <a href="https://pissdaily.com/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit/" rel="nofollow" target="_blank" title="Overwatch DMCA">Piss Daily</a></p>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-mercy.jpg" width="100%" alt="Overwatch Mei" /></center>

<p>DMCA, viết tắt của "Digital Millennium Copyright Act", luật bảo vệ bản quyền tác giả. Luật này do tổng thống Mỹ Bill Clinton thông qua và ban hành chính thức từ ngày 28/11/1998. Mục tiêu là nhằm bảo vệ bản quyền của tất cả các sản phẩm công nghệ tránh khỏi việc bị ăn cắp, sao chép, bẻ khóa (crack), kinh doanh sản phẩm công nghệ trái phép...</p>

<p>Các nội dung được DMCA bảo vệ</p>
<ul>
<li>Hình ảnh của bạn hoặc do bạn chụp.
<li>Đồ họa tự thiết kế.
<li>Video của bạn hoặc do chính bạn dựng.
<li>Ứng dụng do bạn thiết kế.
<li>Chương trình bạn tự viết.
<li>Văn bản chính bạn viết, soạn thảo.
</ul>

<p>Vậy nếu áp dụng luật DMCA vào những video khiêu dâm của Overwatch, có lẽ Activision Blizzard sẽ thắng kiện. Nhưng đồng thời cũng là hành động "rút ống thở" tựa game đang hấp hối này.</p>

<center><img src="/upload/images/game/mei-1.jpg" width="100%" alt="Overwatch Mei" /><br><br></center>

<p>Được ra mắt vào năm 2016, Overwatch không chỉ nhận được giải thưởng Game Of The Year 2016, game còn được các fan chế rất nhiều phim ảnh khiêu dâm. Sau 1 tháng, từ khóa Overwatch và các nhân vật nữ trong game được tìm kiếm rất nhiều trên các trang web khiêu dâm.</p>

<p>Nhưng dần dần, Overwatch đã trở nên suy tàn vì nhiều lý do. Nhà sản xuất Activision Blizzard không cập nhật thêm lối chơi mới, chỉ xoay quanh lối chơi cũ suốt 5 năm nay.
Overwatch 2 có trailer hoành tráng nhưng thời gian ra mắt liên tục bị hoãn. Vụ bê bối Blizzard quấy rối tình dục nữ nhân viên gây ra vụ kiện tập thể gây chấn động đã ảnh hưởng đến tất cả game của Blizzard.
Gần đây nhất là ngày 8/6/2021, <a href="/post/nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai">nữ diễn viên lồng tiếng cho Mercy bản tiếng Brazil đã bị sát hại tại nhà riêng.</a></p>

<center><img src="/upload/images/game/nu-dien-vien-long-tieng-cho-mercy-bi-sat-hai-christiane-louise.jpg" width="100%" alt="Overwatch Mercy Christiance Louise" />

<p>Christiane Louise, nữ diễn viên lồng tiếng cho Mercy bị sát hại</p></center>

<p>Tưởng chừng tựa game khốn khổ này không thể lụi tàn hơn nữa, Blizzard xuất hiện và kiện DMCA xóa tất cả phim khiêu dâm của Overwatch trên các web đen. Rất nhiều người chơi đến với game nhờ vào những bộ phim khiêu dâm của Overwatch. Nhưng có lẽ vì muốn lấy lại hình ảnh một công ty không liên quan đến bê bối tình dục, Blizzard lại có thêm nước đi sai lầm. Đây cũng là cách để Blizzard kiếm lại một chút tiền sau vụ kiện chấn động.</p>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-ana.jpg" width="100%" alt="Overwatch Mei" /><br><br>

<img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-brigitte-sombra.jpg" width="100%" alt="Overwatch Sombra" /></center>

<p>Cộng đồng game thủ Overwatch Việt Nam đương nhiên không hề vui về quyết định này. Họ chắc chắn rằng: nếu Blizzard thắng kiện, Overwatch chính thức trở thành dead game. Blizzard có lẽ chưa học được bài học từ Warcarft 3 Reforged. Hãng này đã lấy hết tất cả bản mod, các màn chơi mà game thủ tự tạo nhằm mục đích không chia cho game thủ 1 đồng nào từ những bản mod do chính họ tạo ra. Và giờ họ cũng muốn hủy luôn những video khiêu dâm do cộng đồng làm ra. Nhưng hành động này sẽ chẳng mang lại 1 đồng nào cho Blizzard mà chỉ khiến hình ảnh công ty xấu hơn, game thủ mới ít hơn mà thôi.</p>

<center><img src="/upload/images/game/activision-blizzard-yeu-cau-dmca-huy-bo-tat-ca-phim-khieu-dam-overwatch-trong-vu-kien-quay-roi-tinh-duc-overwatch-vietnam.jpg" width="100%" alt="Overwatch Vietnam" /></center>

<p>Ellowas, một nhân viên thiết kế đồ họa của studio Source Filmmaker (SFM) đã nhận thông báo bị gỡ các video khỏi trang pornhub. Anh cho biết: "Tất cả nội dung của tôi đã biến mất". Mặc dù Ellowas không nghĩ Blizzard công bằng trong việc này, nhưng anh thừa nhận họ "tuân thủ các quyền hợp pháp của mình".</p>

<p>Ellowas biết điều này có thể xảy ra. “Tôi cho rằng ngành công nghiệp khiêu dâm có thể loại bỏ những tác phẩm nhái của họ, vì họ thay đổi vừa đủ để tránh những kiện tụng, chúng tôi thì không.” Do bản chất của SFM, người dùng có thể dễ dàng tách nội dung trò chơi ngay từ nguồn. Nghĩa là rất nhiều nội dung được tạo bằng cách sử dụng các mô hình gốc, điều này có thể làm phức tạp việc sử dụng hợp pháp. Nếu đúng như vậy, Blizzard có thể thắng kiện với các mô hình do họ làm ra. Nhưng với mô hình nhân vật do các họa sĩ làm ra thì không.</p>

<p>Nguồn: <a href="https://www.lewdgamer.com/2016/05/29/blizzard-allegedly-targeting-overwatch-sfm-dmcas" rel="nofollow" target="_blank" title="Overwatch DMCA">lewdgamer</a></p>

<center><img src="/upload/images/game/activision-blizzard-yeu-cau-dmca-huy-bo-tat-ca-phim-khieu-dam-overwatch-trong-vu-kien-quay-roi-tinh-duc-dva.jpg" width="100%" alt="Overwatch DVA" /></center>

<p>"Blizzard không thể ngây thơ đến mức nghĩ rằng họ có thể chấm dứt vĩnh viễn phim khiêu dâm Overwatch theo cách này. Họ phải biết rằng nhờ chúng mà Overwatch mới có sự nổi tiếng như hiện tại". Ellowas nói. Rõ ràng các họa sĩ, thiết kế phải rất thích tựa game này, thích các nhân vật nữ nên họ mới bỏ thời gian, công sức để vẽ và làm phim.</p>

<center><img src="/upload/images/game/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit-dva-model.jpg" width="100%" alt="Overwatch DVA" />

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Color: <a href="https://t.co/HfYIWEBl9c">https://t.co/HfYIWEBl9c</a><br>B/W: <a href="https://t.co/5kdT8Rm7r6">https://t.co/5kdT8Rm7r6</a><br><br>8K and Project File: <a href="https://t.co/jI08PTP3xK">https://t.co/jI08PTP3xK</a><br><br>Before (Left) and After (RIght) <a href="https://t.co/ct7sJ6L2RP">pic.twitter.com/ct7sJ6L2RP</a></p>&mdash; Seven (@7GraphicsNSFW) <a href="https://twitter.com/7GraphicsNSFW/status/1521836126264336390?ref_src=twsrc%5Etfw">May 4, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Những model nhân vật này nhất định là fanart, designer bên ngoài tự tạo<br>
Blizzard không có quyền cấm họ thiết kế.</p></center>

<p>Đó là chưa kể thể loại parody, thể loại phim người đóng các nhân vật trong game, truyện tranh làm chuyện người lớn. Những bộ phim này có được mua bản quyền không? Họ có bị Blizzard hay bất kỳ hãng game, anime, truyện tranh nào kiện không? Có 2 trường hợp:
<ul>
<li>Các công ty phim người lớn đã mua bản quyền. Vậy thì Blizzard sẽ làm gì với những bộ phim HỢP PHÁP được bán? Nếu để mặc thì mọi thứ Blizzard làm để cải thiện hình ảnh trong vụ kiện quấy rối tình dục trở nên vô nghĩa.
<li>Các công ty phim người lớn chưa mua bản quyền. Khả năng này khó xảy ra vì họ có thể bị tất cả công ty game, truyện tranh, phim ảnh ở khắp nơi trên thế giới kiện.
</ul>

<center><img src="/upload/images/game/activision-blizzard-yeu-cau-dmca-huy-bo-tat-ca-phim-khieu-dam-overwatch-trong-vu-kien-quay-roi-tinh-duc-widowmaker-1.jpg" width="100%" alt="Overwatch Widowmaker" />

<p>Nếu chỉ cấm các model 3D mà không cấm parody thì chẳng giải quyết được gì</p></center>

<p>Đây không phải lần đầu Activision Blizzard lên tiếng về vấn đề phim khiêu dâm Overwatch. Sau khi ra mắt game được 1 tháng, trên trang Pornhub đã đưa ra lưu lượng những từ khóa tìm kiếm phim liên quan đến Overwatch. Blizzard lập tức lên tiếng phản đối fan làm quá nhiềm phim ảnh khiêu dâm về game. Điều này có thể ảnh hưởng đến hình ảnh game trở nên xấu đi.</p>

<center><img src="/upload/images/game/overwatch-sau-1-thang-open-beta-10.jpg" width="70%" alt="Overwatch Pornhub" />

<img src="/upload/images/game/overwatch-sau-1-thang-open-beta-11.jpg" width="70%" alt="Overwatch Pornhub" />

<p>Sau 1 tháng Open Beta, Overwatch được tìm kiếm rất nhiều trên Pornhub</p></center>

<p>Ellowas hy vọng chuyện này sẽ qua đi. "Hy vọng rằng trong vài tuần nữa, mọi thứ sẽ trở lại bình thường". Anh ấy cảm thấy tất cả chỉ là một
"phản ứng nông nổi đối với việc đưa tin của các phương tiện truyền thông chính thống".
Phân tích của Pornhub đã được các cửa hàng chính thống như Kotaku đưa tin đầy đủ, điều này có thể khiến Blizzard chú ý.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Summer is close 🌶🌶🌶<br><br>720p <a href="https://t.co/yvtwJL34QK">https://t.co/yvtwJL34QK</a><br><br>Support me on <a href="https://t.co/f9yxSP1Zua">https://t.co/f9yxSP1Zua</a><br><br>Voice Acting by <a href="https://twitter.com/_PixieWillow?ref_src=twsrc%5Etfw">@_PixieWillow</a> <a href="https://t.co/Sz0gVewl6x">pic.twitter.com/Sz0gVewl6x</a></p>&mdash; HydraFXX (@HydraFXX) <a href="https://twitter.com/HydraFXX/status/1129767783875653632?ref_src=twsrc%5Etfw">May 18, 2019</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<img src="/upload/images/game/dva-2.jpg" width="100%" alt="Overwatch Brigitte Sombra" /><br><br>

<img src="/upload/images/game/tracer-dva-1.jpg" width="100%" alt="Overwatch Brigitte Sombra" /></center>

<p>Tóm lại, Blizzard đang dần lụi tàn và các lãnh đạo càng đi những nước đi sai lầm. Khả năng Blizzard sẽ sụp đổ và thuộc về Trung Quốc không còn xa.
Blizzard đã từng nổi tiếng về việc sa thải cả ngàn nhân viên Mỹ để tuyển dụng nhân công Trung Quốc.
Tiền là thứ quan trọng nhất đối với lãnh đạo Blizzard, còn nhân viên hay game thủ có hay không không quan trọng.</p>

<center><img src="/upload/images/game/activision-blizzard-yeu-cau-dmca-huy-bo-tat-ca-phim-khieu-dam-overwatch-trong-vu-kien-quay-roi-tinh-duc-widowmaker.jpg" width="100%" alt="Overwatch Widowmaker" /></center>

<p>Xem thêm: <a href="/post/activision-blizzard-sexual-harassment-lawsuit">Activision Blizzard bị kiện vì quấy rối tình dục nhân viên nữ</a></p>
',

            'date_post'         => '2021-08-18',
            'thumbnail_post'    => 'activision-blizzard-yeu-cau-dmca-huy-bo-tat-ca-phim-khieu-dam-overwatch-trong-vu-kien-quay-roi-tinh-duc-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Trung Quốc tự bắn vào chân mình khi áp lực Tencent và các hãng công nghệ?',
            'url_post'        => 'trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe',
            'present_vi_post' => 'Trung Quốc đã đăng một bài báo nói về việc các hãng game như là liều "thuốc phiện tinh thần"',
            'content_vi_post' => '<p>Mọi chuyện bắt đầu trong một hội nghị tài chính ở Thượng Hải hôm 24/10, tỉ phú Mã Vân (Jack Ma), nhà sáng lập tập đoàn Alibaba có phát biểu Jack Ma chỉ trích giới lãnh đạo Trung Quốc, cụ thể là hệ thống ngân hàng Trung Quốc. Jack Ma ví cách chúng vận hành với "tiệm cầm đồ". Tthẳng thừng chỉ trích cơ quan quản lí Trung Quốc, nói rằng các qui định tài chính cũ kĩ của nước này là lực cản đối với sự đổi mới công nghệ. Chính quyền Trung Quốc lập tức triệu tập Jack Ma và có nhiều động thái đàn áp các công ty công nghệ. Jack Ma từ một thần tượng tại Trung Quốc, ngay lập tức bị giới trẻ gọi là "con ma hút máu".</p>

<p>Ngày 30/8/2021, Trung Quốc đã đăng một bài báo nói về việc các hãng game như là liều "thuốc phiện tinh thần" làm hỏng thế hệ trẻ. Sau những đòn trừng phạt mạnh lên các ông lớn công nghệ (hay còn gọi là Big Tech) như Alibaba, giờ Trung Quốc chuyển sang vùi dập Tencent. WeChat, TikTok cũng chịu tình cảnh tương tự.</p>

<p>Trung Quốc cũng vừa ra luật kiểm tra khuôn mặt người chơi. Sau 12 giờ, thiết bị của Tencent sẽ bắt phải kiểm tra khuôn mặt. Nếu đó là trẻ vị thành niên, hệ thống sẽ bắt thoát game. Nếu game thủ không cho nhận diện, hệ thống cũng sẽ bắt thoát game. Một biện pháp cứng rắn nhưng cần thiết. Mặc dù nhiều người lo ngại đây là cách thu thập dữ liệu người chơi.</p>

<center><img src="/upload/images/game/trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe-jack-ma.jpg" width="100%" alt="China Tencent Alibaba" /></center>

<p>Mới đây nhất, Trung Quốc đã siết chặt quy định giờ chơi game của các thanh niên nước này xuống còn... 3 tiếng 1 tuần. 3 tiếng đó chỉ được chơi trong ngày thứ 6, thứ 7 và Chủ Nhật. Động thái này nhận được sử ủng hộ nhiệt liệt từ các bậc phụ huynh và... cả các công ty công nghệ, hãng game như Tencent. Thậm chí, hãng điện thoại Huawei cũng đã loại bỏ toàn bộ ứng dụng của Tencent khỏi cửa hàng ứng dụng của mình.</p>

<p>Vậy hành động tự vùi dập các Big Tech của mình có phải hành động đúng đắn?</p>

<h3>Tây quảng cáo, Đông sản xuất</h3>

<p>Bài viết trên <a href="https://vnexpress.net/ly-do-trung-quoc-tu-ban-vao-chan-khi-siet-cac-cong-ty-internet-4336111.html" target="_blank" title="VnExpress">VnExpress</a></p>

<p>Theo bình luận của Wall Street Journal, Chủ tịch Trung Quốc Tập Cận Bình phân chia công nghệ thành hai loại: "có thì tốt" và "cần phải có". Theo quan điểm của ông, sự vĩ đại của quốc gia không phụ thuộc vào việc sở hữu các nền tảng trò chuyện hay gọi xe tốt nhất thế giới. Lý do đơn giản: <b>nếu không sản xuất ra xe thì làm sao có xe để gọi?</b></p>

<center><img src="/upload/images/game/trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe-1.jpg" width="100%" alt="China Tencent Alibaba" />

<p>Phương Đông sản xuất, phương Tây quảng cáo</p></center>

<p>Các hãng công nghệ phương Tây tập trung vào quảng cáo, marketing. Facebook, Google tồn tại là nhờ quảng cáo. Các Big Tech phương Tây có thể được định giá hàng tỷ USD nhưng họ sống nhờ vào đâu? Đó là các công ty sản xuất được định giá nhỏ hơn gấp trăm lần. Các công ty sản xuất lúa gạo, thiết bị điện tử, xe... cần được quảng cáo. Các Big Tech cung cấp cho họ nền tảng để quảng cáo. Đó là quy luật hiện nay. Phương Đông sản xuất, phương Tây quảng cáo.</p>

<p>Trung Quốc muốn đẩy mạnh công nghệ về sản xuất thay vì tập trung vào mảng giải trí, trái ngược hẳn với phương Tây tập trung vào Facebook, Google hay các công ty game, thậm chí là… công nghiệp phim người lớn như Pornhub. Chắc chắn chẳng có quốc gia nào tạo ra lúa gạo, máy móc nhờ vào việc xem phim đen, chơi game hay lên Facebook chém gió chuyện thế sự, lên Youtube làm những video nhảm nhí cả. Trái ngược với Mỹ, quốc gia đã chuyển hết dây chuyền sản xuất qua các nước khác để có giá thành rẻ hơn. Trung Quốc tập trung đẩy mạnh sản xuất, giữ vững vị trí công xưởng của thế giới. Vì vậy, không thể để thanh niên đắm chìm vào game hay các mạng xã hội nhảy nhót như TikTok được. Ngay cả các lệnh siết chặt việc đào tiền ảo cũng là để tránh việc nhân lực Trung Quốc kiếm tiền mà khong chịu lao động sản xuất.</p>

<p>Đặc biệt là khi đại dịch COVID-19 hoành hành, các quốc gia đã dần rút nhà máy khỏi Trung Quốc để đến các nước khác. Trung Quốc đang thật sự lo sợ vấn đề này. Họ cần giải quyết bài toán những người thất nghiệp trước khi quá muộn. Bắt thanh niên rời khỏi máy chơi game, tập trung học hành là việc làm cần thiết. Chưa kể, dân Trung Quốc không muốn sinh con vì hậu quả từ chính sách một con và vì áp lực cuộc sống. Một tương lai cực kỳ khủng khiếp sẽ đến với Trung Quốc trong 10-20 năm nữa, khi lực lượng lao động dần cạn kiệt.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/kjwFrKGazWY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trung Quốc Không Kiểm Duyệt nói rằng: nước Mỹ không còn sản xuất nữa.<br>
Họ chuyển hết dây chuyền cho Trung Quốc.</p></center>

<h3>Khuyết khích sinh con</h3>

<p>Trung Quốc đang thiếu hụt lao động trầm trọng. Các bậc phụ huynh và cả các thanh niên đến tuổi lập gia đình đã có quá nhiều lo lắng về tương lai của mình nên đã quyết định không lập gia đình, không sinh con. Cá biệt còn có nam thanh niên quyết định tự triệt sản.</p>

<p>Mối lo này đến từ việc khoảng cách giàu nghèo ngày càng lớn, thanh niên giờ không thích đi học mà đi làm game thủ chuyên nghiệp do ảnh hưởng bởi các thần tượng game thủ như siêu xạ thủ Uzi của Liên Minh Huyền Thoại. Thêm các vấn đề về công việc như trên khiến tình hình tài chính, công việc của người dân ngày càng khó khăn.</p>

<center><img src="/upload/images/game/trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe-uzi-faker.jpg" width="100%" alt="China Tencent Alibaba Uzi Faker" />

<p>Siêu xạ thủ Uzi đã giải nghệ và Faker là các thần tượng của giới trẻ Trung Quốc</p></center>

<p>Trung Quốc quyết định ra một loạt các chính sách như "Thịnh vượng chung", bắt các công ty công nghệ nói riêng và các đại gia nói chung phải đi làm từ thiện, chia sẻ của cải cho người dân. Giờ chơi của các thanh niên bị siết chặt để thanh niên tập trung học hành cũng như không tốn tiền vào các trò chơi vô bổ. Điều này khiến các bậc phụ huynh và những người đang trong độ tuổi đi làm, sắp lập gia đình cảm thấy thoải mái hơn.</p>

<h3>Nhìn thấy mặt tiêu cực của Big Tech</h3>

<p>Các Big Tech của Mỹ như Google, Facebook, Twitter, Amazon, Apple... đang gần như nắm giữ toàn bộ mọi thông tin, truyền thông của nước Mỹ và người dân Mỹ. Cả 2 đảng Dân Chủ và Cộng Hòa đều đồng thuận phải kiện chống độc quyền các Big Tech. Tuy nhiên, vụ kiện có lẽ còn lâu mới có kết quả. Ở đất nước tư bản, rất khó để ép các công ty công nghệ tách ra thành những công ty nhỏ hơn.</p>

<p>Các Big Tech cũng rất khôn ngoan khi chọn lĩnh vực kinh doanh chính tập trung vào điện thoại như Android và iOS. Trên máy vi tính, bạn có thể không sử dụng Google mà chuyển sang trình duyệt Brave, công cụ tìm kiếm Bing hay cài hệ điều hành Ubuntu. Nhưng khi sử dụng điện thoại, bạn chỉ có 2 lựa chọn: dùng hệ điều hành được cài sẵn hoặc cài song song nhiều hệ điều hành. Vì vậy, Android và iOS cứ thế thống trị tất cả.</p>

<center><img src="/upload/images/game/trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe-2.jpg" width="100%" alt="China Tencent Alibaba" />

<p>Điện thoại chỉ có cài thêm hệ điều hành,<br>
không gỡ được hệ điều hành cũ như máy vi tính</p></center>

<p>Trung Quốc không thích điều này. Họ sử dụng lợi thế kiểm soát mọi thứ của chế độ Cộng Sản để ép công ty công nghệ Alibaba phải chia nhỏ. Trung Quốc yêu cầu Alipay - ứng dụng thuộc Ant Group - tách 2 đơn vị cho vay Huabei, Jiebei thành một liên doanh mới do Nhà nước sở hữu. Ant sẽ không phải là người cho vay trực tuyến duy nhất của Trung Quốc bị ảnh hưởng bởi các quy tắc mới. Mục đích rõ ràng là để chống độc quyền. Và cách làm của Trung Quốc rất nhanh gọn, không mất thời gian kiện tụng mà không đi đến kết quả như Mỹ.</p>
',

            'date_post'         => '2021-09-02',
            'thumbnail_post'    => 'trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Fan hâm mộ Yugioh có thể đóng vai Kaiba Seto với chiếc vali của nhân vật',
            'url_post'        => 'wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase',
            'present_vi_post' => 'Chiếc vali với 3 lá bài Blue-Eyes White Dragon tuyệt đẹp.',
            'content_vi_post' => '<p>Series manga Yu-Gi-Oh! kỷ niệm 25 năm thành lập bằng cách phát hành "Ultimate Kaiba Set". Gói cao cấp này có giá 33.000 yên (khoảng 301 USD), đi kèm với chiếc cặp mang tính biểu tượng của Kaiba Seto, cùng với toàn bộ bộ bài của anh ấy với tác phẩm nghệ thuật bản gốc. Trong đó bao gồm 3 bản sao của Blue-Eyes White Dragon phiên bản chỉ tồn tại trong manga hoặc anime.</p>

<center><img src="/upload/images/game/wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase-1.jpg" width="70%" alt="Yugioh Kaiba Seto Briefcase" title="Yugioh Kaiba Seto Briefcase" /><br><br>

<img src="/upload/images/game/wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase-2.jpg" width="100%" alt="Yugioh Kaiba Seto Briefcase" title="Yugioh Kaiba Seto Briefcase" /><br><br>

<img src="/upload/images/game/wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase-first-look.jpg" width="70%" alt="Yugioh Kaiba Seto Briefcase" title="Yugioh Kaiba Seto Briefcase" /><br><br>

<p>3 lá bài Blue-Eyes White Dragon phiên bản manga anime</p></center>

<p>3 lá bài Blue-Eyes White Dragon (Secret Rare), được đóng khung trong hộp trưng bày. Bên ngoài có logo "kỷ niệm 25 năm tác phẩm gốc"<br>
Bộ bài của Kaiba Seto: 58 lá, cộng thêm 3 lá mới (tất cả đều là Ultra Rare)<br>
Chiếc cặp có thể chứa khoảng 7.000 lá bài. Nắp đi kèm với một dây đai có thể giữ hai thảm trò chơi<br>
3 lá bài mới khác đã có bản chính thức. Đó là Attack Guidance Armor, Life Shaver, và Magical Trick Mirror.</p>

<center><img src="/upload/images/game/wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase-3-cards.jpg" width="100%" alt="Yugioh Kaiba Seto Briefcase" title="Yugioh Kaiba Seto Briefcase" /><br><br></center>

<p>Chức năng của 3 lá bài:</p>
<ul>
<li>Attack Guidance Armor: gắn chiếc áo giáp lên 1 quái vật đang ngửa bài. Quái vật đó thu hút đòn tấn công.
<li>Life Shaver: đối thủ loại 1 lá bài từ trên tay ra khỏi cuộc chơi mỗi lượt lá bài này hoạt động.
<li>Magical Trick Mirror: kích hoạt khi đối thủ tấn công. Bạn có thể kích hoạt 1 lá bài phép dưới mộ.
</ul>

<p>Các đơn đặt hàng trước được mở tại Nhật Bản từ ngày 21/9/2021 đến ngày 31/10/2021. Sản phẩm dự kiến sẽ được giao vào tháng 4/2022.</p>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/interest/2021-09-16/wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase/.177384" rel="nofollow" target="_blank" title="Yugioh Kaiba Seto Briefcase">Anime News Network</a></p>
',
            'date_post'         => '2021-09-17',
            'thumbnail_post'    => 'wealthy-yu-gi-oh-fans-can-emulate-seto-kaiba-with-his-briefcase-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Trung Quốc kiểm duyệt game gắt gao, ngành game anime chính thức thua Nhật Bản',
            'url_post'        => 'trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban',
            'present_vi_post' => 'Liệu ngành giải trí Trung Quốc sẽ đi về đâu?',
            'content_vi_post' => '<p>Vào đầu tháng 9, Trung Quốc đã bắt đầu cuộc "Cách mạng văn hóa" tổng thể trên đất nước này với 2 mục tiêu chính: các ông lớn công nghệ, được gọi chung là Big Tech và các nghệ sĩ. Mục tiêu là dọn dẹp những văn hóa mà Trung Quốc xem là lệch lạc, không phù hợp và khiến thanh thiếu niên Trung Quốc bị sa ngã. Đây vừa là tin tốt, vừa là tin xấu đối với các công ty game, anime, phim ảnh của nước ngoài. Họ khó du nhập sản phẩm của họ vào thị trường tỷ dân nhưng lại giảm bớt đối thủ cạnh tranh từ đất nước này.</p>

<p>Về ngành game, Trung Quốc đã ra nhiều điều luật cực kỳ khó khăn, nếu không muốn nói là bất khả thi đối với đa số tựa game đối kháng, MOBA, cày level. Những yêu cầu của chính quyền rất nhiều, nhưng có thể kể ra một số điểm chính như:</p>

<p>Ngôn ngữ:</p>
<ul>
<li>Không có từ ngữ chém giết, nói tục, tình dục.
<li>Không đặt tên các lãnh tụ hay nói về những vấn đề chính trị nhạy cảm.
</ul>

<p>Hình ảnh:</p>
<ul>
<li>Không có máu đỏ
<li>Không lộ nội y kể cả khi di chuyển
<li>Không có những hình ảnh về những vấn đề chính trị nhạy cảm.
<li>Không có tình yêu đồng tính
<li>Không có nam giới ẻo lả, nữ lồng tiếng cho nam, nam mặc quần áo nữ…
<li>Phải thông tin rõ bối cảnh của game.
</ul>

<p>Gameplay:</p>
<ul>
<li>Không được nhập vai chém giết
<li>Không tôn vinh văn hóa nước ngoài, các anh hùng như Nhật, phương Tây.
<li>Không sử dụng hình ảnh anh hùng hay kẻ xấu, độc tài có thật ngoài đời.
<li>Không thể hiện anh hùng này mạnh hơn anh hùng kia.
<li>Không được quay gacha, đánh bạc.
<li>Không có cốt truyện người dân lật đổ nhà nước, đứng lên khởi nghĩa hay nhà nước làm hại người dân.
<li>Không có cốt truyện làm lây lan dịch bệnh.
</ul>

<p>Những cái tên được nêu đích danh là Genshin Impact, Azur Lane. Những hình ảnh "fan service" chắc chắn bị rơi vào vùng cấm. Luật cấm này áp dụng lên cả game offline như...</p>

<center><img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-baal-genshin-impact.jpg" width="70%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>Baal trong Genshin Impact</p>

<img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-kms-peter-strasser-azur-lane-1.jpg" width="70%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" /><br><br>

<img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-kms-peter-strasser-azur-lane-2.jpg" width="100%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>KMS Peter Strasser trong Azur Lane</p>

<img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-raiden-mei-honkai-impact.jpg" width="100%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>Raiden Mei trong Honkai Impact</p></center>

<h3>Trung Quốc chính thức thua Nhật Bản trong mảng game - anime - manga?</h3>

<p>Xem thêm: <a href="/post/lieu-trung-quoc-co-the-thong-tri-nganh-cong-nghiep-anime" rel="nofollow" target="_blank" title="anime trung quốc">Liệu Trung Quốc có thể thống trị ngành công nghiệp anime?</a></p>

<p>Cách đây 3 năm, cộng đồng yêu thích phong cách anime Nhật Bản đã xôn xao vì sự phát triển vượt bậc của anime Trung Quốc. Cụ thể, Kantai Collection của Nhật Bản đã bị Azur Lane của Trung Quốc vượt xa về doanh thu. Rất nhiều nhà làm anime tại Nhật Bản lo lắng rằng: trong tương lai không xa, Trung Quốc chính thức vượt qua Nhật Bản, thống trị thế giới về mảng game - anime - manga phong cách Nhật Bản.</p>

<p>Tuy nhiên, với những quyết sách từ chính quyền Trung Quốc, chúng ta có thể đảm bảo rằng tương lai đó sẽ không xảy ra, ít nhất là trong thời gian gần. Những chính sách mang phong cách "Cách mạng văn hóa" của Trung Quốc sẽ cấm hoàn toàn phong cách anime Nhật, những nội dung tôn vinh văn hóa Nhật hay phương Tây. Các nhà làm game sẽ chỉ làm game tôn vinh Trung Quốc và lịch sử Trung Quốc. Nhưng những tựa game đó sẽ không hề làm hài lòng game thủ nước ngoài.</p>

<p>Ví dụ như game Azur Lane lấy hình ảnh các tàu chiến Nhật, Mỹ như USS Enterprise, USS New Jersey, KMS Peter Strasser, Kaga, Akagi, Yamato... và biến thành những cô gái anime dễ thương. Điều này sẽ khiến các game thủ thích thú, tìm hiểu những loại tàu chiến này và lịch sử của chúng, dẫn đến việc giới trẻ thích lịch sử nước ngoài hơn lịch sử Trung Quốc. Nhưng nếu như game chỉ toàn là tàu chiến Trung Quốc như Ning Hai và Ping Hai thì số lượng tàu sẽ rất hạn chế. Chắc chắn chẳng game thủ nào muốn chơi một tựa game đơn điệu như vậy, dù là game thủ Trung Quốc.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/3bmvDbjqex0" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>PV USS New Jersey của Azur Lane</p>

<img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-uss-new-jersey-azur-lane.jpg" width="100%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>Skin Bunny Girl của USS New Jersey</p>

<img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-azur-lane-dragon-empery.jpg" width="100%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>Phe Dragon Empery phong cách Trung Quốc</p></center>

<p>Vì vậy, hãng Yostar đã tính trước điều này và mở chi nhánh tại Nhật Bản. Nếu game bị cấm tại Trung Quốc, họ sẽ chuyển sang chi nhánh Nhật Bản và tiếp tục phát triển. Điều này sẽ tạo điều kiện cho nguồn nhân lực tại Nhật Bản phát triển mạnh.</p>

<h3>Game và phim ảnh sẽ trở về đúng giá trị ban đầu</h3>

<p>Một chi tiết mà những ai xem phim, chơi game đều cảm thấy nhức nhối trong nhiều năm trở lại đây. Đó là việc phim và game quá tập trung vào việc xu nịnh Trung Quốc để được bước chân vào thị trường tỷ dân này. Hollywood, những hãng sản xuất game phương Tây và cả Nhật Bản đều tìm cách làm hài lòng Trung Quốc. Vì vậy, rất nhiều nội dung phim và game bị chia làm 2 phiên bản: phiên bản quốc tế (Global) và phiên bản Trung Quốc (China) với những hình ảnh, cảnh quay được thay đổi.</p>

<p>Ví dụ thì có rất nhiều. Marvel thay đổi phim Doctor Strange (2016) để tránh bị Trung Quốc phản đối bởi những xung đột tại khu tự trị Tây Tạng. Honkai Impact 3 và Azur Lane bị sửa và xóa nhân vật nữ, các bộ đồ thỏ khoe ngực gợi cảm.</p>

<p>Tuy nhiên, xu thế "Chiều lòng Trung Quốc" này sẽ sớm bị thay đổi nhờ đợt "Cách mạng văn hóa" mới này. Khi thanh niên không còn được chơi game thoải mái nữa và các tập đoàn công nghệ lớn như Alibaba, Tencent bị chính quyền ngăn chặn sự ảnh hưởng quá mức. Các nghệ sĩ, ca sĩ nổi tiếng nhờ lưu lượng, mang phong cách đồng tính, xinh trai, ẻo lả sẽ bị cấm thẳng tay.</p>

<p>Xem thêm: <a href="/post/trung-quoc-tu-ban-vao-chan-minh-khi-ap-luc-tencent-va-cac-hang-cong-nghe" rel="nofollow" target="_blank" title="anime trung quốc">Trung Quốc tự bắn vào chân mình khi áp lực Tencent và các hãng công nghệ</a></p>

<center><img src="/upload/images/game/trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-taric-ezreal.jpg" width="70%" alt="Trung Quốc kiểm duyệt game gắt gao, ngành anime chính thức thua Nhật Bản" />

<p>Taric, Ezreal, Varus là những nhân vật bị nghi ngờ giới tính</p></center>

<p>Nguyên nhân là vì Trung Quốc muốn cứu vãn giới trẻ và kinh tế nước này. Tỉ lệ sinh thấp, các thanh niên làm những nghề như nghề game thủ, nghề streamer. Các Big Tech như Alibaba phát triển mạnh đến mức Jack Ma có phát ngôn chê bai hệ thống ngân hàng Trung Quốc. Đối với Trung Quốc, cần đẩy mạnh công nghệ sản xuất chứ không phải đẩy mạnh các công nghệ giải trí, dịch vụ. Bạn không thể sử dụng ứng dụng gọi xe nếu như không sản xuất ra xe để gọi.</p>

<p>Tóm lại, Trung Quốc đang dần "bế quan tỏa cảng" nền văn hóa của họ. Đây là thời cơ rất tốt để Nhật Bản phát triển ngành anime để củng cố vị thế của mình.</p>
',
            'date_post'         => '2021-09-29',
            'thumbnail_post'    => 'trung-quoc-kiem-duyet-gat-gao-nganh-game-anime-chinh-thuc-thua-nhat-ban-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);


//         posts::create([
//             'name_vi_post'    => 'Pornhub Game Awards 2021',
//             'url_post'        => 'pornhub-game-awards-2021',
//             'present_vi_post' => '"chiếc cúp trong lòng người hâm mộ" liên quan đến mảng game đã thuộc về tựa game nào?',
//             'content_vi_post' => '<p></p>



// <p></p>

// ',
//             'date_post'         => '2021-12-24',
//             'thumbnail_post'    => 'pornhub-game-awards-2021-thumbnail.jpg',
//             'id_cat_post'       => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'        	=> ENABLE,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

        posts::create([
            'name_vi_post'    => 'The Elder Scrolls Online ra mắt thế giới "chưa từng thấy trước đây" vào năm 2022',
            'url_post'        => 'the-elder-scrolls-online-is-going-to-a-never-before-seen-world-in-2022',
            'present_vi_post' => 'Những câu chuyện mới, một thế giới mới và cả chủng tộc mới.',
            'content_vi_post' => '<p>The Elder Scrolls Online đang triển khai một câu truyện hoàn toàn mới cho năm 2022. Bethesda Softworks cho biết sẽ giới thiệu với người chơi "một thế giới, những câu chuyện và nền văn hóa chưa từng thấy trước đây" trong thế giới rực rỡ của The Elder Scrolls.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/P2e8SCyb2mc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>The Elder Scrolls Online: 2022 Cinematic Teaser</p></center>

<p>Người chơi có thể đi đến đâu trong cuộc phiêu lưu mới đầy thú vị này? Bethesda đã có đoạn giới thiệu điện ảnh ở trên. Có ba con tàu - mỗi con tàu đại diện cho một trong ba phe của TESO - đang tiến đến bờ biển đầy đá, dưới sự giám sát của một người mặc bộ giáp khá nghiêm túc.</p>

<p>Có một số dự đoán trên Reddit rằng bản mở rộng mới sẽ có sự góp mặt của Bretons, một chủng tộc có tổ tiên là Tiên được biết đến với khả năng thành thạo ma thuật và giả kim thuật. Có vị trí địa lý phù hợp: High Rock, tỉnh nhà của họ, là tỉnh Tây Bắc của Tamriel, một bán đảo với bờ biển dài, nhiều đá, địa hình hiểm trở và một số hòn đảo.</p>

<p>Đặc biệt, bộ giáp của người quan sát ở cuối video, nếu để ý kỹ sẽ có một biểu tượng kỳ lạ. Biểu tượng này không có trong bất kỳ chủng tộc nào trong trò chơi. Chứng tỏ nhiều khả năng, đây là biểu tượng của chủng tộc mới.</p>

<center><img src="/upload/images/game/the-elder-scrolls-online-ra-mat-the-gioi-chua-tung-thay-truoc-day-vao-nam-2022-1.jpg" width="100%" alt="The Elder Scrolls Online Bethesda Softworks" title="The Elder Scrolls Online Bethesda Softworks" /><br><br></center>

<p>Câu truyện tiếp theo của The Elder Scrolls Online sẽ được tiết lộ vào ngày 27/1/2022 trên nền tảng Twitch.</p>

<p>Nguồn: <a href="https://www.pcgamer.com/the-elder-scrolls-online-is-going-to-a-never-before-seen-world-in-2022/" rel="nofollow" target="_blank" title="The Elder Scrolls Online Bethesda Softworks">pcgamer</a></p>

',
            'date_post'         => '2022-01-09',
            'thumbnail_post'    => 'the-elder-scrolls-online-is-going-to-a-never-before-seen-world-in-2022-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Cuộc họp của chính phủ Italia bị gián đoạn bởi phim Final Fantasy VII Khiêu dâm',
            'url_post'        => 'italian-government-meeting-interrupted-by-final-fantasy-vii-porn',
            'present_vi_post' => 'Nhân vật chính trong phim NSFW đó là Tifa Lockheart',
            'content_vi_post' => '<p>Ngày 19/1/2022, trong cuộc họp của chính phủ Italia được tổ chức online qua Zoom, đột nhiên cảnh phim khiêu dâm 3D của Tifa Lockheart xuất hiện khiến các quan chức, nghị sĩ sững sờ.</p>

<p>Trong 30 phút đầu tiên, cuộc họp diễn ra khá suôn sẻ với báo cáo của ANSA. Tuy nhiên, khi đến phần giới thiệu Giorgio Parisi,
một trong những người đoạt giải Nobel vật lý năm 2020, được giới thiệu trong cuộc họp. Đoạn video kéo dài khoảng 30 giây.</p>

<center>

<p></p></center>

<p>Video full trên <a href="https://www.reddit.com/r/PublicFreakout/comments/s80ktg/final_fantasy_porn_interrupts_government_meeting/?rdt=58636" rel="nofollow" target="_blank" title="tifa italian government">Reddit</a></p>

<p>Tifa Lockheart là nhân vật nữ của Final Fantasy. Cô rất nổi tiếng trong bản remake mới nhất của Final Fantasy VII Remake. Tifa và Aerith là 2 nữ thần của tựa game. Tifa mang phong cách châu Á, Aerith mang phong cách phương Tây.</p>

<p>Sau scandal này, các game thủ ngay lập tức đã chế hình Tifa mặc bộ đồ nghị sĩ sang trọng với một ghế trong quốc hội Italia.</p>

<center><img src="/upload/images/game/tifa-italian-government.jpg" width="100%" alt="tifa italian government" title="The Elder Scrolls Online Bethesda Softworks" /><br><br></center>

<p></p>

<p>Nguồn: <a href="https://sea.ign.com/final-fantasy-vii-remake/180941/news/italian-government-meeting-interrupted-by-final-fantasy-vii-porn" rel="nofollow" target="_blank" title="tifa italian government">IGN</a></p>
',
            'date_post'         => '2022-01-19',
            'thumbnail_post'    => 'italian-government-meeting-interrupted-by-final-fantasy-vii-porn-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nier: Automata sẽ được chuyển thể thành Anime',
            'url_post'        => 'nier-automata-anime-teaser',
            'present_vi_post' => 'Liệu vòng 3 của 2B có xuất hiện trong anime không?',
            'content_vi_post' => '<p>Những Android quen thuộc 2B, 9S và A2 trong game Nier: Automata sẽ xuất hiện trên anime. Đó là xác nhận của hãng Aniplex trên Twitter.</p>

<p>Trang chủ <a href="https://nierautomata-anime.com/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Nier: Automata anime</a></p>
<p>Trang chủ <a href="https://www.jp.square-enix.com/nierautomata/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Nier: Automata Game</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/2Bh-3CUNH4s" title="Nier: Automata game anime" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">It&#39;s actually happening.<br><br>A <a href="https://twitter.com/hashtag/NieR?src=hash&amp;ref_src=twsrc%5Etfw">#NieR</a>:Automata anime is on the way! <a href="https://t.co/3yIx2IWuVU">https://t.co/3yIx2IWuVU</a> <a href="https://t.co/jiDp4u61NB">pic.twitter.com/jiDp4u61NB</a></p>&mdash; NieR Series (@NieRGame) <a href="https://twitter.com/NieRGame/status/1496476859822972942?ref_src=twsrc%5Etfw">February 23, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Nier: Automata trailer anime và tweet của Aniplex</p></center>

<p>Nier: Automata là trò chơi nhập vai được phát hành vào ngày 23/2/2017, được phát triển bởi Platinum Games và Square Enix. Game đã bán được hơn 6 triệu bản trên toàn cầu.</p>

<p>Lấy bối cảnh ở thế giới hậu tận thế, câu chuyện kể về những chiến binh Android được giao nhiệm vụ chống lại những người máy ngoài hành tinh đã chiếm lấy Trái đất.
Ngay từ khi ra mắt, tựa game đã trở nên rất nổi tiếng vì gameplay, cốt truyện và đồ họa hậu tận thế hấp dẫn. Và đặc biệt, yếu tố làm nên thương hiệu Nier: Automata chính là yếu tố ecchi. Với cặp mông của Android 2B, cô đã làm điên đảo các game thủ yêu thích anime. Vô số những fanart ecchi về 2B xuất hiện khắp Internet.</p>

<center><img src="/upload/images/game/nier-automata-anime-teaser-1.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-2.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-3.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br>

<img src="/upload/images/game/nier-automata-anime-teaser-4.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br></center>

<p>Hãng Aniplex đã sản xuất Demon Slayer: Kimetsu no Yaiba , Bleach, Blue Exorcist và Fullmetal Alchemist. Với những thành công như vậy, khán giả và các game thủ đang rất háo hức chờ xem studio sẽ thể hiện phiên bản anime như thế nào.</p>

<center><img src="/upload/images/game/nier-automata-anime-teaser-bg.jpg" width="100%" alt="Nier: Automata game anime" title="Nier: Automata game anime" /><br><br></center>

<p>Nguồn: <a href="https://www.cnet.com/culture/entertainment/nier-automata-anime-adaptation-in-development/" rel="nofollow" target="_blank" title="Nier: Automata game anime">Anime News Network</a></p>
',
            'date_post'         => '2022-02-23',
            'thumbnail_post'    => 'nier-automata-anime-teaser-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Teaser trailer gọi vốn game 300475 đã được ra mắt',
            'url_post'        => 'teaser-trailer-game-300475',
            'present_vi_post' => 'Liệu 300475 có thành công hơn so với 7554?',
            'content_vi_post' => '<p>Ngày 22/2/2022, Hiker Games Studio, tiền thân là Emobi Games đã cho ra mắt đoạn phim teaser của game 300475 với mục tiêu kêu gọi vốn từ cộng đồng. KINGDOM NVHAI sẽ phân tích về trailer này cũng như những bình luận của cộng đồng về tương lai của game.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/LZunC-jAD8w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Teaser Trailer dự án gọi vốn cộng đồng cho game 300475</p></center>

<p>Emobi Games là studio đã sản xuất ra game 7554 vào ngày 16/12/2011. Mặc dù được nhiều game thủ kỳ vọng về game Việt sẽ được đón nhận nồng nhiệt. Tuy nhiên, game đã thất bại hoàn toàn về mặt doanh thu khi chỉ thu về hơn 1 tỷ VND, trong khi kinh phí bỏ ra là hơn 17 tỷ VND.</p>

<p>Sau này, Hiker Game Studio được thành lập năm 2009, cũng chính là Emobi Games sau này. Game 300475 đã được Hiker Game Studio thông báo từ năm 2021 rằng game sẽ được ra mắt. Ngày 22/2/2022, teaser trailer của game 300475 đã được ra mắt trên kênh YouTube của Hiker Game Studio. Game lấy bối cảnh lịch sữ Việt Nam kháng chiến chống Mỹ.</p>

<p>Trang chủ <a href="http://www.hikergames.com/" rel="nofollow" target="_blank" title="300475 Hiker Game Studio">Hiker Game Studio</a></p>

<p><b>Review teaser</b></p>

<p>Bắt đầu teaser là cảnh bên trong một chiếc xe buýt bị tấn công. Nón lá, súng bắn qua cửa kính được làm rất tốt. Khi nhìn khung cảnh bên ngoài, ngọn lửa, những chiếc xe ô tô, xích lô, xe tăng bị bắn hỏng, tất cả đều được thể hiện rất tốt. Tuy nhiên, điểm trừ là thời tiết. Không rõ đây là miền Bắc hay miền Nam, buổi chiều hay buổi tối mà thời tiết có nhiều sương mù. Cảm giác như đang ở miền Bắc trong một ngày đầy sương gió mưa mù vậy. Nhưng nếu vậy thì phải có mưa. <b>Đó là điểm trừ đầu tiên: ánh sáng không rõ ràng.</b> Với Unreal Engine 4 thì chắc chắn không phải do engine mà là do studio chưa để ý.</p>

<center><img src="/upload/images/game/teaser-trailer-game-300475-1.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<img src="/upload/images/game/teaser-trailer-game-300475-2.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<img src="/upload/images/game/teaser-trailer-game-300475-3.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<img src="/upload/images/game/teaser-trailer-game-300475-4.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<p>Cảnh sương mù không rõ đây là buổi sáng hay buổi chiều</p></center>

<p>Tiếp đến là cảnh 4 người lính và 1 chiếc xe tăng từ từ di chuyển vào thành phố. Dù không nhìn rõ mặt nhưng có thể nhìn bộ râu để nhận ra đây là lính Mỹ, người Mỹ, kèm theo khẩu M16 đặc trưng. Có lĩnh Mỹ thì có lính Việt Cộng. Lính Việt Cộng với khẩu AK47 huyền thoại, trang phục được làm rất chi tiết. Tuy nhiên, mặt người lính này lại có chân mày lớn, thẳng xéo trông không tự nhiên lắm. Mặc dù hơi vô lý khi với số lượng lính ít ỏi như vậy mà đi vào thành phố, rất dễ bị phục kích nhưng đây là phim nên mục tiêu chủ yếu để thể hiện hình ảnh và âm thanh.</p>

<center><img src="/upload/images/game/teaser-trailer-game-300475-5.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<img src="/upload/images/game/teaser-trailer-game-300475-6.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<img src="/upload/images/game/teaser-trailer-game-300475-7.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br>

<p>Khán giả dễ dàng phân biệt được lính của 2 phe</p></center>

<p>Đoạn gameplay mặc dù không thể hiện tâm ngắm khi bắn bình thường, nhưng đã thể hiện độ giật của súng, khói bốc lên trông tốt hơn 7554 rất nhiều. Nhưng trong gameplay, vấn đề về ánh sáng lại xuất hiện. Bên ngoài trời đã âm u, vào trong nhà lại càng khó nhìn hơn vì thiếu sáng. Trong khi tia lửa thì lại quá sáng. Khẩu AK47 trên tay người chơi không chi tiết bằng khẩu AK47 trước đó.</p>

<center><img src="/upload/images/game/teaser-trailer-game-300475-AK47.jpg" width="100%" alt="Teaser trailer 300475" title="Teaser trailer 300475" /><br><br></center>

<p>Teaser cũng cho chúng ta thấy súng phóng lựu, súng ngắm. Cả 2 đều được thể hiện tốt. Tuy nhiên, cảnh tên lửa bắn nổ xe tăng, chúng ta lại không được thấy xe tăng nổ. Đó là cảnh mà KINGDOM NVHAI muốn xem nhất để thấy được cảnh cháy nổ được studio thể hiện ra sao.

<p>Cuối cùng là dàn máy bay tiêm kích và những quả bom rơi xuống. Máy bay dù ở xa nhưng vẫn thấy được độ chi tiết. Ở cảnh nhìn lên trời này, chúng ta lại thấy mặt trời rất sáng rõ. Những quả bom cũng được làm chi tiết với chữ và những con số. Nhưng KINGDOM NVHAI khi nhìn những quả bom này lại thấy có vẻ như chúng đang lơ lửng, không phải đang rơi. Và khi bom nổ, chúng chẳng gây thiệt hại gì. Nhà cửa, cây cối không hề bị thổi bay bởi áp suất khủng khiếp do những quả bom gây ra.

<p>Thêm một điểm đáng lưu ý: tại sao bom lại rơi cao hơn tầng mây? Trong các bộ phim tài liệu chiến tranh Việt Nam, góc quay cho thấy máy bay ném bom không cao hơn tầng mây vì như thế sẽ khó chính xác. Kể cả các game bắn máy bay cũng không bay cao hơn tầng mây để ném bom như vậy.

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/KiFIiWnmqk4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Attack On Pearl Harbor - Trân Châu Cảng</p></center>

<p>Về âm thanh, sau khi đã rút kinh nghiệm từ những video review game 7554, Hiker Games Studio đã đầu tư âm thanh chân thực và mạnh mẽ hơn so với tiếng súng yếu ớt của game gốc. Tiếng máy bay rít qua nghe rất thật. Tuy nhiên, tiếng bom nổ lại như tiếng pháo, nghe khá yếu ớt.</p>

<h3>Những ý kiến tiêu cực</h3>

<p>Rất nhiều ý kiến tiêu cực được đưa ra. KINGDOM NVHAI sẽ tổng hợp ý chính:</p>

<p><strong>Người Việt bắn người Việt</strong></p>

<p>Nhiều ý kiến cho rằng, game đang làm sai vì trong giai đoạn chống Mỹ, chính quyền tay sai của Mỹ dựng lên là người Việt Nam nắm quyền. Vì vậy, việc cho người Mỹ vào chiến đấu là sai lầm. Lẽ ra phải là người Việt của Việt Nam Cộng Hòa đánh với người Việt của Cộng Sản.</p>

<p>Câu trả lời là đúng nhưng chưa đủ. Nếu xem những bộ phim tài liệu về chiến tranh Việt Nam, chúng ta có thể biết về lính dù Mỹ bị bắt, những người Mỹ đã bị bắt đi lính và trở về Việt Nam với hội chứng Việt Nam (Vietnam Syndrome). Kể cả thống kê cũng cho thấy: khoảng 58.200 lính Mỹ tử trận tại Việt Nam, hơn 304.000 bị thương. Như vậy, việc người Việt chiến đấu với lính Mỹ là đúng với lịch sử.</p>

<p><strong>Game sẽ không được nhiều người mua, bị crack</strong></p>

<p>Những ý kiến khác nói rằng game sẽ không bán được vì crack, vì dở hơn Call of Duty và phải sử dụng lòng yêu nước như một giải pháp kích cầu.</p>

<p>Câu trả lời là sai. Thời bây giờ, game đã được bán trên rất nhiều nền tảng online như Steam. So với cách đây 11 năm, game được bán qua hộp đĩa thì lợi thế này là rất lớn. Những người Việt đang sống ở nước ngoài cũng có thể mua được mà không cần băn khoăn về giá.</p>

<p>Với nhận thức về game bản quyền như hiện nay, cộng với rất nhiều streamer, KOL nổi tiếng như Dũng CT, Độ Mixi ủng hộ và kêu gọi, việc game thủ bỏ tiền mua game 300475 là rất khả thi. Hiker Games Studio có thể trả tiền cho các streamer ủng hộ game. Hay các streamer, reviewer, các kênh Youtube hoàn toàn có thể quảng cáo miễn phí cho tựa game này. Nói cách khác, marketing trong thời đại bây giờ hoàn toàn khác với 11 năm trước.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/YabdHZI0JaM" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>REACTION TRAILER 300475 của Trực Tiếp Game</p></center>
',
            'date_post'         => '2022-02-24',
            'thumbnail_post'    => 'teaser-trailer-game-300475-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Square Enix và Bandai Namco Entertainment quyên tiền ủng hộ Ukraine',
            'url_post'        => 'square-enix-bandai-namco-entertainment-donate-ukraine',
            'present_vi_post' => 'Ngoài ra còn có nhiều công ty game của Nhật khác cũng quyên góp cho Ukraine',
            'content_vi_post' => '<p>Ngày 24/2/2022, Nga đã xâm lược Ukraine. Rất nhiều quốc gia, trong đó có Nhật Bản đã ra lệnh trừng phạt kinh tế đối với Nga. Đồng thời, cả thế giới cũng quyên góp, ủng hộ Ukraine rất nhiều.</p>

<p>Square Enix và Bandai Namco Entertainment đã công bố các khoản quyên góp trong tuần này để viện trợ nhân đạo cho Ukraine. Square Enix sẽ tặng 500.000 USD cho Cao ủy Liên hợp quốc về người tị nạn (UNHCR). Bandai Namco Entertainment sẽ quyên góp 100 triệu YEN (tương đương 845.000 USD) cho tổ chức từ thiện Save the Children.</p>

<p>Ngoài ra, các công ty thuộc tập đoàn Square Enix đã tổ chức chương trình quyên góp và tặng quà cho nhân viên của mình. Số tiền thu được sẽ được chuyển đến Ủy ban Chữ thập đỏ Quốc tế, UNICEF và Tổ chức Bác sĩ không biên giới.</p>

<p>Ngoài ra, còn rất nhiều công ty game khác cũng quyên góp cho các tổ chức nhân đạo cho Ukraine.</p>

<p>Tuần trước, KOEI Tecmo thông báo họ đã quyên góp 500.000 USD cho UNHCR để hỗ trợ Ukraine. Công ty cũng đang chấp nhận các khoản đóng góp bên ngoài và sẽ gộp chúng lại với những khoản đóng góp từ nhân viên của mình. Tập đoàn Sony Group thông báo rằng họ đang tài trợ 2 triệu USD cho Cao ủy Liên hợp quốc về người tị nạn và tổ chức phi chính phủ quốc tế, Save the Children. Sony Group cũng có cách trừng phạt Nga của riêng mình. Họ tạm ngừng bán phần mềm và phần cứng PlayStation tại Nga.</p>

<p>Sega thông báo rằng họ có kế hoạch quyên góp cho các hoạt động nhân đạo tập trung vào Ukraine, và cũng sẽ kết hợp các khoản quyên góp của nhân viên.</p>

<p>Pokémon Company International đã quyên góp 200.000 USD cho GlobalGiving để cứu trợ nhân đạo. Niantic thông báo họ đã quyên góp 200.000 USD cho các tổ chức từ thiện như United Help Ukraine, Razom Inc., Quỹ từ thiện Tiếng nói của trẻ em, Ủy ban Cứu hộ Quốc tế, Hội đồng Người tị nạn Na Uy, Hướng dương Hòa bình, Quân đoàn Y tế Quốc tế và UNICEF. Các nhân viên đã quyên góp được hơn 75.000 USD với các khoản quyên góp tương ứng của Niantic.</p>

<p>Square Enix là hãng làm game sản xuất ra series Final Fantasy nổi tiếng. Bandai Namco Entertainment sản xuất series Dragon Ball.</p>

<center><img src="/upload/images/game/square-enix-bandai-namco-entertainment-donate-ukraine-final-fantasy-tifa.jpg" width="100%" alt="Square Enix Bandai Namco Entertainment Ukraine" title="Square Enix Bandai Namco Entertainment Ukraine" /><br><br>

<img src="/upload/images/game/square-enix-bandai-namco-entertainment-donate-ukraine-dragon-ball-legends.jpg" width="100%" alt="Square Enix Bandai Namco Entertainment Ukraine" title="Square Enix Bandai Namco Entertainment Ukraine" /><br><br></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/interest/2022-03-15/square-enix-bandai-namco-ent-donate-to-ukraine/.183608" rel="nofollow" target="_blank" title="Square Enix Bandai Namco Entertainment Ukraine">Anime News Network</a></p>
',
            'date_post'         => '2022-03-20',
            'thumbnail_post'    => 'square-enix-bandai-namco-entertainment-donate-ukraine-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '300475 gửi lời chia tay cộng đồng game thủ vì gọi vốn thất bại',
            'url_post'        => '300475-have-canceled-because-funding-fail',
            'present_vi_post' => 'Sau 2 tháng gọi vốn và 1 teaser, dự án 300475 đã chính thức khép lại.',
            'content_vi_post' => '<p>Ngày 22/2/2022, Hiker Games Studio, tiền thân là Emobi Games đã cho ra mắt đoạn phim teaser của game lấy chủ đề lịch sử Việt Nam 300475 với mục tiêu kêu gọi vốn từ cộng đồng.</p>

<p>Emobi Games là studio đã sản xuất ra game 7554 vào ngày 16/12/2011. Mặc dù được nhiều game thủ kỳ vọng về game Việt sẽ được đón nhận nồng nhiệt. Tuy nhiên, game đã thất bại hoàn toàn về mặt doanh thu khi chỉ thu về hơn 1 tỷ VND, trong khi kinh phí bỏ ra là hơn 17 tỷ VND. Vì vậy, game 300475 lần này đã quyết định gọi vốn 20 tỷ VND trong vòng 2 tháng.</p>

<p>Xem thêm: <a href="/post/teaser-trailer-game-300475" rel="nofollow" target="_blank" title="300475 Hiker Game Studio">[Review] Teaser trailer gọi vốn game 300475 đã được ra mắt</a></p>

<p>Trang chủ <a href="http://www.hikergames.com/" rel="nofollow" target="_blank" title="300475 Hiker Game Studio">Hiker Game Studio</a></p>

<p>Sau 2 tháng, thống kê số tiền ủng hộ vốn như sau:</p>

<ul>
<li>100000 VND: 59 người
<li>500000 VND: 532 người
<li>1000000 VND: 88 người
<li>2000000 VND: 37 người
<li>3000000 VND: 23 người
<li>5000000 VND: 40 người
<li>30000000 VND: 0 người
<li>50000000 VND: 7 người
</ul>

<p>Tổng cộng đã có 786 người ủng hộ với số tiền 1 tỷ 73 triệu, chỉ bằng 5.37% so với số tiền 20 tỷ cần huy động. Vì vậy, vào ngày 2/5/2022, Hiker Game đã quyết định gửi lời chào tạm biệt và sẽ hoàn trả số tiền đã huy động vốn cho mọi người.</p>

<center><img src="/upload/images/game/300475-gui-loi-chia-tay-cong-dong-game-thu-vi-goi-von-that-bai-1.jpg" width="100%" alt="300475 Hiker Game Studio" title="300475 Hiker Game Studio" /><br><br>

<p>Lời chia tay của Hiker Games gửi đến mọi người</p></center>

<p>Thật sự, số tiền 20 tỷ VND là quá lớn để có thể xin ủng hộ quyên góp, nhất là khi 7554 trước đây đã tiêu tốn 7 tỷ VND nhưng vẫn thất bại. Sau khi xem đoạn teaser trailer gọi vốn, nhiều người dù đã cảm thấy tin tưởng hơn nhưng vẫn còn rất e dè. Lý do chính là vì teaser chiếm quá nhiều thời lượng là phim, quá ít gameplay.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/LZunC-jAD8w" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Teaser Trailer dự án gọi vốn cộng đồng cho game 300475</p></center>

<p>Riêng KINGDOM NVHAI cảm thấy, việc hãng Hiker Games đã quyết định từ bỏ dự án cho thấy họ không quá tâm huyết với dự án này. KINGDOM NVHAI đã hy vọng sẽ có thêm 1 đoạn trailer nữa với nhiều gameplay hơn. Việc tung ra thêm teaser vừa tạo thêm hiệu ứng truyền thông, vừa giúp mọi người có thêm niềm tin về game sẽ có những cải thiện.</p>

<p>Nhưng sau 2 tháng, họ đã làm thêm được những gì? Có thêm gameplay mới, hình ảnh mới, hay ít nhất là các đoạn phim mới không? Chẳng có gì cả. Hiker Games đóng cửa dự án quá nhanh, khiến KINGDOM NVHAI cảm thấy họ không dành đủ tâm huyết cho tựa game.</p>

<p>Một điểm sai lầm khác là thời gian làm game. Hiker Game muốn game sẽ được ra mắt vào kỷ niệm 40 năm ngày giải phóng miền nam 30/4/1975 - 30/4/2022. Tuy nhiên, thời game 3 năm là quá ngắn nếu muốn làm một tựa game chất lượng. Từ video teaser không quá chất lượng, số tiền gọi vốn quá lớn và thời gian làm game quá ngắn, tất cả những thông tin bất khả thi đó đã khiến nhiều người chùn bước, không muốn quyên góp tiền ủng hộ. Nếu Hiker Games kêu gọi vốn trong 6 tháng, 1 năm, ra mắt thêm vài teaser nữa thì số tiền huy động vốn chắc chắn sẽ lớn hơn rất nhiều.</p>

<center><img src="/upload/images/game/300475-gui-loi-chia-tay-cong-dong-game-thu-vi-goi-von-that-bai-2.jpg" width="70%" alt="300475 Hiker Game Studio" title="300475 Hiker Game Studio" /><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/ROWR-itCBww" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/jR4I3-6DIGE" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Những bình luận về thông tin game 300475 ngừng phát triển.</p></center>

<p>Dù sao, việc Hiker Games đã dám làm và dám thất bại là một việc đáng khen. Có thể dự án sẽ bị hoãn lại, nhưng biết đâu sẽ được khởi động lại vào một ngày nào đó. Có thể game sẽ được hoàn thành để kỷ niệm 45 năm, 50 năm ngày giải phóng miền nam. Chúng ta hãy cùng chờ xem.</p>
',
            'date_post'         => '2022-05-02',
            'thumbnail_post'    => '300475-gui-loi-chia-tay-cong-dong-game-thu-vi-goi-von-that-bai-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Hệ thống rank mới của Hearthstone',
//             'url_post'        => 'hearthstone-new-ranking-system-rewards-bonus-stars',
//             'present_vi_post' => 'Hearthstone tạo hệ thống rank giống Liên Minh Huyền Thoại.',
//             'content_vi_post' => '<p></p>

// <h3>Hệ thống rank cũ</h3>

// <p>Hệ thống rank cũ của Hearthstone được tính từ rank 25 đến rank Master. Từ rank 25 đến rank 20, các game thủ sẽ không bị xuống hạng. Từ rank 20 trở lên, các game thủ sẽ bị xuống hạng.</p>

// <p>Các rank có các ngôi sao cần hoàn thành. Từ rank 20 đến 15, số sao là 3 cho mỗi rank. Rank 15 đến 10, số sao là 4. Rank 10 đến 5, số sao là 5.</p>

// <p>Mỗi trận thắng, game thủ được nhận 1 sao. Phần thưởng cho việc thắng 2 ván liên tiếp là sẽ được thưởng bonus 2 sao. Hoàn thành đủ số sao sẽ được lên rank.</p>

// <h3>Hệ thống rank mới</h3>

// <p>Hearthstone sẽ có hệ thống rank với các bậc: Đồng, Bạc,  và Master.</p>

// <p></p>



// <p>Nguồn: <a href="https://esports.gg/guides/hearthstone/hearthstone-ranking-system-rewards-bonus-stars/" rel="nofollow" target="_blank" title="Hearthstone new ranking system">Esports.gg</a></p>
// ',
//             'date_post'         => '2022-05-06',
//             'thumbnail_post'    => 'hearthstone-new-ranking-system-rewards-bonus-stars-thumbnail.jpg',
//             'id_cat_post'       => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'        	=> ENABLE,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

        posts::create([
            'name_vi_post'    => 'Overwatch 2 beta ra mắt vào ngày 28/6 với Junker Queen và bản đồ mới',
            'url_post'        => 'overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map',
            'present_vi_post' => 'Junker Queen, bản đồ mới và các nhân vật cũ được thiết kế lại.',
            'content_vi_post' => '<p>Overwatch 2 Beta bắt đầu vào ngày 28/6 và sẽ có nhân vật mới nhất của trò chơi, Junker Queen, cũng như một bản đồ mới. Tuyệt vời hơn nữa, các máy chủ sẽ không chỉ mở cho người chơi PC mà cả những người chơi trên console.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/r8k0eQ2yjns" title="Overwatch 2 Beta Junker Queen" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer về Junker Queen</p></center>

<p>Blizzard đã thông báo trên tài khoản Twitter chính thức của Overwatch, tiết lộ ngày ra mắt bản beta,
các tính năng mới mà người chơi sẽ được thử nghiệm và ngày đăng ký bắt đầu từ 16/6/2022.
Nhà phát triển cũng chia sẻ thêm về bản beta sẽ được công bố vào ngày 16/6, nghĩa là những tiết lộ thú vị hơn nữa có thể sẽ xuất hiện.</p>

<p>Nguồn: <a href="https://www.gamespot.com/articles/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map/1100-6504595/" rel="nofollow" target="_blank" title="manga is booming north america">Publishers Weekly</a></p>

<p>Overwatch 2 cũng sẽ ra mắt nhiều sự thay đổi về tạo hình của các nhân vật.</p>

<center><img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-bastion.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Bastion cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-sombra.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Sombra cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-baptiste.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Baptiste cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-torbjorn.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Torbjorn cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-cassidy.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Cassidy cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-pharah.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Pharah cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-reaper.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Reaper cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-widowmaker.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Widowmaker cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-mei.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Mei cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-genji.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Genji cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-tracer.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Tracer cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-winston.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Winston cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-reinhardt.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Reinhardt cũ (trái) và mới (phải)</p>

<img src="/upload/images/game/overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-lucio.jpg" width="100%" alt="Overwatch 2 beta" title="Overwatch 2 beta" /><br><br>

<p>Lucio cũ (trái) và mới (phải)</p>
</center>

<p>Chỉ còn 1 tuần để đăng ký chơi Overwatch 2 Beta. Hãy nhanh tay đăng ký để trải nghiệm Overwatch 2 Beta, Junker Queen và bản đồ mới.</p>

<p>Nguồn: <a href="https://www.gamespot.com/gallery/overwatch-2-hero-redesigns-see-how-characters-looks-have-changed/2900-3150/" rel="nofollow" target="_blank" title="manga is booming north america">Gamespot</a></p>
',
            'date_post'         => '2022-06-23',
            'thumbnail_post'    => 'overwatch-2-beta-begins-june-28-will-feature-junker-queen-and-a-new-map-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Game thế giới mở Terminator đang được lập trình',
            'url_post'        => 'open-world-terminator-game-in-development',
            'present_vi_post' => 'Game sinh tồn thế giới mở về Ngày Phán Quyết và Kẻ Hủy Diệt.',
            'content_vi_post' => '<p>Series Kẻ Hủy Diệt Terminator sẽ trở lại dưới dạng game sinh tồn thế giới mở. Trong trailer mới nhất, Terminator Survival Game xuất hiện cảnh T-800, người máy Kẻ Hủy Diệt nổi tiếng của series mở cánh cửa một nhà kho. Trong phim, T-800 là Kẻ Hủy Diệt mang lớp da bên ngoài là ngôi sao cơ bắp Arnold Schwarzenneger.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/HCWueOM4q-U" title="Open World Terminator Game" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Untitled Terminator Survival Game - Official Reveal Trailer</p></center>

<p>Terminator đã có những tựa game trước đây như Terminator: Resistance. Đó là game bắn súng góc nhìn thứ nhất, được ra mắt vào năm 2019.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/KZSW_9ihCb8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Gameplay của Terminator: Resistance</p></center>

<p>Kẻ hủy diệt (The Terminator) là một bộ phim điện ảnh ra mắt khán giả vào năm 1984 thuộc thể loại hành động, khoa học viễn tưởng của đạo diễn James Cameron.
Câu chuyện nói về một trí thông minh nhân tạo tên là Skynet điều khiển tất cả máy móc trên thế giới hủy diệt nhân loại. John Connor lãnh đạo phe kháng chiến loài người chống lại Skynet.
Để giết John Connor, Skynet đã đưa Kẻ Hủy Diệt T-800 (Arnold Schwarzenneger thủ vai) quay về quá khứ giết mẹ của John Connor, bà Sarah Connor.
Kyle Reese, một người lính của phe kháng chiến đi ngược thời gian để bảo vệ Sarah. Hóa ra, Kyle Reese đã cùng Sarah Connor sinh ra John Connor.</p>

<p>Nguồn: <a href="https://www.gamespot.com/videos/open-world-terminator-game-in-development/2300-6458858/" rel="nofollow" target="_blank" title="Open World Terminator">Gamespot</a></p>
',
            'date_post'         => '2022-07-08',
            'thumbnail_post'    => 'open-world-terminator-game-in-development-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Nintendo bị cáo buộc quấy rối tình dục nơi làm việc',
            'url_post'        => 'nintendo-sexual-harassment-and-discrimination-claims-investigation',
            'present_vi_post' => 'Lại thêm một nhà sản xuất game tại Mỹ bị cáo buộc quấy rối tình dục và phân biệt giới tính',
            'content_vi_post' => '<p>Nintendo chi nhánh Mỹ đang điều tra các cáo buộc về việc quấy rối các nữ tester, theo tin nhắn nội bộ mà Kotaku đã phát hiện ra.</p>

<p>Theo Kotaku, chủ tịch Nintendo của Mỹ, Doug Bowser đã gửi email cho nhân viên thừa nhận các khiếu nại vào ngày 16/8/2022, cùng ngày các báo cáo được công bố.
Trong thông báo, Bowser nhấn mạnh rằng công ty đang xem xét các cáo buộc một cách nghiêm túc: "Chúng tôi đã và sẽ luôn điều tra mọi cáo buộc mà chúng tôi biết được và chúng tôi đang tích cực điều tra những khiếu nại gần đây nhất này."</p>

<p>Bowser cũng nhấn mạnh rằng Nintendo có "các chính sách nghiêm ngặt được thiết kế để bảo vệ nhân viên và cộng sự của chúng tôi khỏi hành vi không phù hợp và yêu cầu tất cả những người làm việc cho hoặc với chúng tôi tuân thủ đầy đủ các chính sách này".</p>

<p>Nguồn: <a href="https://www.theverge.com/2022/8/18/23311202/nintendo-harassment-and-discrimination-claims-investigation" rel="nofollow" target="_blank" title="nintendo sexual harassment">Theverge</a></p>

<p>Điều đáng lưu ý là: khi <a href="/post/activision-blizzard-sexual-harassment-lawsuit">Activision Blizzard bị kiện vì quấy rối tình dục</a> vào năm 2021,
Doug Bowser được cho là đã bày tỏ lo ngại về tình hình đang diễn ra tại Activision Blizzard trong một email gửi tới toàn công ty,
gọi các cáo buộc là "đáng lo ngại và đáng lo ngại."</p>

<p>Ông giải thích: "Cùng với tất cả các bạn, tôi đã theo dõi những diễn biến mới nhất với Activision Blizzard và các báo cáo liên tục về quấy rối tình dục và môi trường độc hại tại công ty.
Tôi thấy những tài khoản này thật đau khổ và đáng lo ngại. Chúng đi ngược lại các giá trị của tôi cũng như niềm tin, giá trị và chính sách của Nintendo".</p>

<p>Giám đốc điều hành của Activision, Bobby Kotick, thừa nhận mình đang chịu áp lực phải từ chức và đã nói với công ty rằng ông sẽ cân nhắc từ chức nếu không nhanh chóng khắc phục các vấn đề đang diễn ra.</p>

<p>Nguồn: <a href="https://www.ign.com/articles/nintendo-joins-sony-and-xbox-calling-activision-blizzard-reports-disturbing" rel="nofollow" target="_blank" title="nintendo sexual harassment">Theverge</a></p>

<h3>Nintendo đã phản hồi như thế nào?</h3>

<p>Nguồn: <a href="https://earlygame.com/news/nintendo-america-sexual-harassment" rel="nofollow" target="_blank" title="nintendo sexual harassment">Early Game</a></p>

<p>Nintendo đã không phản ứng công khai trước các cáo buộc quấy rối tình dục. Nhưng trong một văn bản nội bộ, cấp trên đã yêu cầu nhân viên lên tiếng
nếu họ cảm thấy không thoải mái. Văn bản cố gắng làm rõ các quy tắc có sẵn, nhưng nó không chủ động như một số người mong muốn:</p>

<blockquote>
<p>Chúng tôi có các chính sách nghiêm ngặt được thiết kế để bảo vệ nhân viên và cộng sự của mình khỏi hành vi không phù hợp và mong muốn tất cả những người làm việc cho hoặc với chúng tôi tuân thủ đầy đủ các chính sách này.</p>

<p>Nếu bạn đã trải qua, chứng kiến hoặc đã chứng kiến bất kỳ điều gì liên quan đến hành vi trái với Chuẩn mực Ứng xử, sổ tay nhân viên hoặc Giá trị Công ty của chúng ta,
vui lòng liên hệ ngay với Đối tác Kinh doanh Nhân sự của bạn.</p>
</blockquote>

<h3>Activision Blizzard từng vướng vào vụ việc tương tự</h3>

<p>Vào năm 2021, Activision Blizzard đã vướng vào vụ kiện quấy rối tình dục. Vụ việc đã khiến nhiều người biểu tình phẫn nộ, cộng thêm những vấn đề về các game của họ đã khiến nhiều lãnh đạo phải rời ghế.</p>

<center><img src="/upload/images/game/activision-blizzard-bi-kien-vi-quay-roi-tinh-duc-nhan-vien-nu-fran-townsend.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br>

<p>Fran Townsend là một phụ nữ nhưng lại bênh vực cho hành động quấy rối tình dục của công ty</p>

<img src="/upload/images/game/sexual-harassment-2.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

<p>Những phụ nữ làm việc tại Nintendo của Mỹ cáo buộc một số đồng nghiệp nam làm "những trò đùa và bình luận thực sự thô thiển",
đồng thời bị đe dọa trả thù nếu họ báo cáo sự việc với HR - kể cả bị sa thải. Những câu chuyện này đã được đề cập trong một báo cáo Kotaku ngày 16/8/2022.</p>

<p>Báo cáo cũng nêu tên Melvin Forrest, một trong những tester hàng đầu của công ty, vì đã khuyến khích văn hóa này.
Một người tester cho biết: "Người ta biết rằng anh ấy sẽ đưa ra những nhận xét đánh vào mọi người, thích nói với các cộng sự rằng "Ồ cô ấy thật xinh đẹp" ".</p>

<p>Nguồn: <a href="https://www.dexerto.com/gaming/nintendo-addresses-sexual-harassment-claims-american-office-1907213/" rel="nofollow" target="_blank" title="nintendo sexual harassment">Dexerto</a></p>

<p>Nintendo là hãng sản xuất game đến từ Nhật Bản, rất nổi tiếng với dòng game The Legend of Zelda, Animal Crossing: New Horizons, Super Smash Bros, Fall Guys và đặc biệt là Pokémon và Mario. Hãng cũng có cho mình hệ máy Nintendo Switch riêng.</p>

<p>Nintendo và Blizzard là 2 trong số những hãng làm game có nhân vật xuất hiện nhiều trên các trang web người lớn như: công chúa Zelda, Mario, Bayonetta và đặc biệt là Pokémon (?).</p>

<center><img src="/upload/images/game/the-legend-of-zelda-princess-1.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<img src="/upload/images/game/the-legend-of-zelda-princess-2.jpg" width="100%" alt="The legend of Zelda princess" /><br><br>

<p>Công chúa Zelda trong game The Legend of Zelda</p></center>
',
            'date_post'         => '2022-08-18',
            'thumbnail_post'    => 'nintendo-sexual-harassment-and-discrimination-claims-investigation-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Cyberpunk 2077 được cập nhật liên kết với anime Edgerunners',
            'url_post'        => 'cyberpunk-2077-game-gets-update-linking-to-edgerunners-anime',
            'present_vi_post' => 'Dòng nhiệm vụ mới có vũ khí, vật phẩm, câu chuyện liên kết',
            'content_vi_post' => '<p>CD PROJEKT RED, studio sản xuất game Cyberpunk 2077 đã khởi động bản cập nhật vào ngày 6/9/2022,
có thêm tuyến nhiệm vụ mới, vũ khí, vật phẩm cho anime Cyberpunk: Edgerunners của Studio Trigger.</p>

<p>Theo Giám đốc Nhiệm vụ Paweł Sasko, nhiệm vụ bao gồm một đoạn clip từ anime, được trình bày thông qua cơ chế trò chơi Braindance.
Bản cập nhật cũng bao gồm các bản sửa lỗi và cải thiện chất lượng, chẳng hạn như tiến trình chéo giữa các nền tảng.</p>

<center><img src="/upload/images/game/cyberpunk-2077-game-gets-update-linking-to-edgerunners-anime-1.jpg" width="70%" alt="Cyberpunk 2077 Edgerunners" /><br><br></center>

<p>Anime sẽ được ra mắt vào ngày 13/9/2022, với 30 phút mỗi tập.</p>

<p>Motoaki Tanigo, CEO của Hololive cũng đã có tweet về Cyberpunk Edgerunners với nội dung: "Cyberpunk Edgerunners, hay quá!"</p>

<center><blockquote class="twitter-tweet"><p lang="ja" dir="ltr">Cyberpunk Edgerunners、良かった！<a href="https://t.co/11xjCAgVwu">https://t.co/11xjCAgVwu</a></p>&mdash; YAGOO / Motoaki Tanigo (@tanigox) <a href="https://twitter.com/tanigox/status/1574003834862841856?ref_src=twsrc%5Etfw">September 25, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<img src="/upload/images/game/cyberpunk-2077-game-gets-update-linking-to-edgerunners-anime-motoaki-tanigo.jpg" width="70%" alt="Cyberpunk 2077 Edgerunners Motoaki Tanigo" /><br><br></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/interest/2022-09-08/cyberpunk-2077-game-gets-update-linking-to-edgerunners-anime/.189438" rel="nofollow" target="_blank" title="Cyberpunk 2077 Game Gets Update Linking to Edgerunners Anime">Anime News Network</a></p>
',
            'date_post'         => '2022-09-08',
            'thumbnail_post'    => 'cyberpunk-2077-game-gets-update-linking-to-edgerunners-anime-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Fatal Frame: Mask of the Lunar Eclipse phát triển qua phương Tây vào năm 2023',
            'url_post'        => 'fatal-frame-mask-of-the-lunar-eclipse-horror-game-heads-west-2023',
            'present_vi_post' => 'Bản Remaster của năm 2008 sẽ có trên PS4, PS5, XBox One, Xbox Series X | S, Nintendo Switch và Steam',
            'content_vi_post' => '<p>Loạt trò chơi video kinh dị Fatal Frame sẽ có mặt ở Bắc Mỹ lần đầu tiên vào đầu năm 2023.
Ngày 13/9/2022, Nintendo Direct đã thông báo trò chơi Fatal Frame: Mask of the Lunar Eclipse Wii sẽ có mặt trên hệ máy Nintendo Switch với đồ họa được nâng cấp.
Kênh YouTube KOEI Tecmo đã phát trực tuyến thông báo trò chơi cũng sẽ được phát hành cho PlayStation 4, PlayStation 5, XBox One, Xbox Series X | S và Windows PC thông qua Steam.</p>

<p>Fatal Frame: Mask of the Lunar Eclipse (Project Zero: Mask of the Lunar Eclipse) đã được ra mắt trên hệ máy Wii vào năm 2008.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/XwxRTmO_lrY" title="Fatal Frame: Mask of the Lunar Eclipse Horror Game" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<img src="/upload/images/game/fatal-frame-mask-of-the-lunar-eclipse-horror-game-heads-west-2023-1.jpg" width="100%" alt="Fatal Frame: Mask of the Lunar Eclipse Horror Game" /><br><br></center>

<p>Cốt truyện kể về chị em đi lạc vào ngôi làng bí ẩn trong khu rừng sâu. Ngôi làng đã bị biến mất một cách bí ẩn. Họ phải thoát ra khỏi ngôi làng bằng thứ vũ khí duy nhất: máy ảnh Obscura có khả năng chụp hình những bóng ma và xua đuổi chúng.</p>

<p>KOEI Tecmo đã phát hành phiên bản cập nhật của trò chơi Fatal Frame: Maiden of Black Water trên nhiều nền tảng vào tháng 10/2021.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/eZ_a-iBDZ7I" title="Fatal Frame 2: crimson butterfly" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Fatal Frame II: crimson butterfly</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/cixCNxoo1T8" title="Fatal Frame: Mask of the Lunar Eclipse Horror Game" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Fatal Frame: Maiden of Black Water</p></center>

<p>Trước đó, vào năm 2003, Fatal Frame II: Crimson Butterfly hay còn được biết đến ở Châu Âu với tên gọi Project Zero II: Crimson Butterfly đã được hãng Tecmo phát triển và công bố năm 2003 cho hệ máy PlayStation 2.</p>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2022-09-13/fatal-frame-mask-of-the-lunar-eclipse-horror-game-heads-west-in-2023/.189626" rel="nofollow" target="_blank" title="Cyberpunk 2077 Game Gets Update Linking to Edgerunners Anime">Anime News Network</a></p>
',
            'date_post'         => '2022-09-14',
            'thumbnail_post'    => 'fatal-frame-mask-of-the-lunar-eclipse-horror-game-heads-west-2023-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Project EVE ra mắt vào năm 2023 với tên mới là Stellar Blade',
            'url_post'        => 'project-eve-will-finally-debut-in-2023-as-stellar-blade',
            'present_vi_post' => 'Game sẽ được phát hành trên hệ máy PS5',
            'content_vi_post' => '<p></p>

<p></p>

<p>Xem thêm: <a href="/post/trailer-4K-project-eve-shiftup" rel="nofollow" target="_blank" title="">Trailer 4K Project EVE đẹp mê hồn của Shiftup.</a></p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/vLsSuuSAIys" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer đẹp mê hồn của Project EVE năm 2019</p></center>

<p>Trang chủ <a href="http://shiftup.co.kr/EVE/" rel="nofollow" target="_blank" title="Shiftup Project EVE">Project EVE của Shiftup</a></p>



<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/ayek3ZzWb1E?si=zRV22-3VwnKjbH2u" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Stellar Blade (previously Project EVE) - State of Play Sep 2022 Story Trailer | PS5 Games</p></center>

<p></p>

<p></p>

<p>Nguồn: <a href="https://www.engadget.com/project-eve-stellar-blade-release-date-143421300.html" rel="nofollow" target="_blank" title="">Engadget</a></p>
',
            'date_post'         => '2022-09-15',
            'thumbnail_post'    => 'project-eve-will-finally-debut-in-2023-as-stellar-blade-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Nintendo Switch cấm game khỏa thân không che',
//             'url_post'        => 'nintendo-switch-bans-uncensored-nudity-nsfw-content',
//             'present_vi_post' => 'Hệ máy Nintendo Switch cấm các game có hình ảnh khỏa thân.',
//             'content_vi_post' => '<p>Nintendo đã quyết định không cho phép bất kỳ ảnh khoả thân chưa được kiểm duyệt trong các trò chơi trên hệ máy Nintendo Switch.</p>

// <p>Nguồn: <a href="https://comicbook.com/gaming/news/nintendo-switch-bans-uncensored-nudity-nsfw-content-hot-tentacles-shooter/" rel="nofollow" target="_blank" title="nintendo bans uncensored nudity">Comicbook</a></p>

// <center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">So, the bad news first:<br><br>We received an answer from Nintendo and now we have a confirmation that they do not allow uncensored boobs on their consoles now.<br><br>👇 <a href="https://t.co/fQBcGWDFEw">https://t.co/fQBcGWDFEw</a></p>&mdash; Gamuzumi (@gamuzumi) <a href="https://twitter.com/gamuzumi/status/1575862637438517248?ref_src=twsrc%5Etfw">September 30, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

// <p></p></center>

// <center><img src="/upload/images/game/sexual-harassment-2.jpg" width="100%" alt="Activision Blizzard sexual harassment" /><br><br></center>

// <p>Nguồn: <a href="https://www.thegamer.com/nintendo-bans-uncensored-female-breasts-switch/" rel="nofollow" target="_blank" title="nintendo bans uncensored nudity">Thegamer</a></p>

// <p>Nintendo là hãng sản xuất game đến từ Nhật Bản, rất nổi tiếng với dòng game Animal Crossing: New Horizons, Super Smash Bros, Fall Guys
// và đặc biệt là Pokémon và Mario. Hãng cũng có cho mình hệ máy Nintendo Switch riêng.</p>

// <center><img src="/upload/images/game/the-legend-of-zelda-princess-1.jpg" width="100%" alt="The legend of Zelda princess" /><br><br></center>
// ',
//             'date_post'         => '2022-08-18',
//             'thumbnail_post'    => 'nintendo-switch-bans-uncensored-nudity-nsfw-content-thumbnail.jpg',
//             'id_cat_post'       => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'        	=> ENABLE,
//             'popular'           => 0,
//             'update'            => 0,
//         ]);

        posts::create([
            'name_vi_post'     => 'Blue Archive sẽ tách ra phiên bản dành cho người lớn',
            'url_post'         => 'blue-archive-will-split-into-separately-age-rated-versions',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p> tựa game gacha RPG Blue Archive sẽ tách ra thành 2 version.</p>









https://www.siliconera.com/blue-archive-will-split-into-separately-age-rated-versions/
',
            'date_post'         => '2022-10-07',
            'thumbnail_post'    => 'blue-archive-will-split-into-separately-age-rated-versions-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Overwatch 2 nhận nhiều ý kiến trái chiều sau khi ra mắt',
//             'url_post'        => '',
//             'present_vi_post' => 'Liệu đây có phải là Overwatch 2 hay "bình mới rượu cũ"',
//             'content_vi_post' => '<p>Sau khi trailer đầu tiên được ra mắt vào năm..., các game thủ đã ngóng chờ Overwatch 2 ra mắt. Cuối cùng, ngày 4/10/2022, các game thủ đã có thể chính thức download miễn phí trò chơi.</p>

// <p></p>

// <center><iframe width="560" height="315" src="https://www.youtube.com/embed/XwxRTmO_lrY" title="Fatal Frame: Mask of the Lunar Eclipse Horror Game" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

// <img src="/upload/images/game/fatal-frame-mask-of-the-lunar-eclipse-horror-game-heads-west-2023-1.jpg" width="100%" alt="Fatal Frame: Mask of the Lunar Eclipse Horror Game" /><br><br></center>

// <p></p>

// <p></p>

// <h3>Đồ họa: sự lựa chọn an toàn</h3>

// <center></center>

// <p>Overwatch 2 quyết định giữ lại đồ họa tươi sáng cũ. Việc này là do đồ họa Overwatch rất được ưa thích và quen thuộc. Những cặp chân dài của các nhân vật nữ, những cơ bắp cuồn cuộn của các nhân vật nam, những tòa nhà, khung cảnh đã trở thành thương hiệu. Tất cả đều được giữ lại.</p>

// <p>Chính vì sự không chắc chắn liệu thay đổi đồ họa quá nhiều có giúp thu hút người chơi hay không, quyết định giữ lại đồ họa cũ là sự lựa chọn an toàn nhất.</p>

// <h3>Gameplay: </h3>

// <p></p>

// <p></p>

// <center></center>

// <p></p>

// <p></p>
// ',
//             'date_post'      => '2022-10-14',
//             'thumbnail_post' => 'overwatch-2-thumbnail.jpg',
//             'id_cat_post'    => GAME_POST,
//             'signature'      => 0,
//             'author'         => 'NVHAI',
//             'views'          => random_int(50,500),
//             'enable'         => ENABLE,
//             'popular'        => 0,
//             'update'         => 0,
//         ]);

        posts::create([
            'name_vi_post'     => 'Eva Elfie phỏng vấn các tuyển thủ Dota 2, ủng hộ Navi và Tundra',
            'url_post'         => 'eva-elfie-interview-dota-2-support-causes-tundra-navi-win',
            'present_vi_post'  => 'Khả năng buff sức mạnh của Elfie là có thật',
            'content_vi_post'  => '<p>Eva Elfie là một nữ diễn viên phim người lớn, người mẫu khỏa thân và là YouTuber người Nga. Cô đã chiến thắng giải thưởng AVN ở hạng mục Ngôi sao nước ngoài mới xuất sắc nhất năm 2021.</p>

<p>YouTube: <a href="https://www.youtube.com/channel/UCulpMq-W5E_OYziBJhxdUpg" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Instagram: <a href="https://www.instagram.com/theevaelfie/" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Twitter: <a href="https://twitter.com/evaelfie" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>

<center><img src="/upload/images/game/eva-elfie-1.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>

<p>Cô đã phỏng vấn với các game thủ Dota 2 và chụp hình với tấm khiên Aegis of the Immortal. Cách chụp hình của cô tạo cảm giác cô đang khỏa thân. Nhưng thực tế cô đang mặc quần áo bình thường.</p>

<center><img src="/upload/images/game/eva-elfie-dota-2-1.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO" /><br><br>

<img src="/upload/images/game/eva-elfie-dota-2-2.jpg" width="100%" alt="Eva Elfie Dota 2 CSGO" /><br><br>

<p>Eva Elfie chụp hình với tấm khiên Aegis of the Immortal trong Dota 2</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/uC3dWk3LhXU" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/iVyp2z87AC8" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Eva Elfie phỏng vấn các tuyển thủ Dota 2.</p></center>

<p>Tuy nhiên, điều đặc biệt nhất là việc cô có năng lực buff sức mạnh rất tuyệt vời.
Cô đã cổ vũ cho 2 đội: Tundra của game Dota 2 và Navi của game Counter-Strike: Global Offensive. Và cả 2 đội đều có những chiến thắng tuyệt đối.</p>

<p>Nguồn: <a href="https://clutchpoints.com/eva-elfies-support-causes-tundra-navi-win" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Clutch Points</a></p>

<p>Cô đã mặc áo của đội Tundra. Và trong ngày thi đấu cuối cùng của The International 11, Tundra đã chiến thắng trước Team Secret, trở thành nhà vô địch mới của Dota 2 thế giới.</p>

<center><img src="/upload/images/game/eva-elfie-dota-2-tundra.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO" /><br><br>

<p>Eva Elfie mặc áo đội Tundra của game Dota 2</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/UhQmAfzaw7c" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Dota 2 The International 2022 - Main Event - Final Day</p></center>

<p>Trước đó, vào ngày 8/11/2021, Eva Elfie cũng đã tham dự CSGO Major tại Riocentro, Brazil để cổ vũ cho đội CSGO Natus Vincere, thường được gọi là Navi.
Navi đã thắng Berlin International Gaming với tỉ số 2-0. Mọi người thật sự tin rằng Elfie đã tiếp thêm sức mạnh cho họ, nhất là khi đội Navi đang có phong độ không tốt.</p>

<p>Lịch thi đấu của <a href="https://www.4gamers.vn/news/detail/2218/lich-thi-dau-va-cap-nhat-ket-qua-cua-csgo-iem-rio-major-2022-moi-nhat" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Navi tại CSGO Major tại Riocentro, Brazil</a></p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Adult Star Eva Elfie is at the CSGO Major and cheering for NAVI and S1mple<br><br>They won today <a href="https://t.co/800tOk8CZ2">pic.twitter.com/800tOk8CZ2</a></p>&mdash; Jake Lucky (@JakeSucky) <a href="https://twitter.com/JakeSucky/status/1589696877091749889?ref_src=twsrc%5Etfw">November 7, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/zlFmD1-bnw0" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Ngày 8/11/2022, Navi thắng BIG</p></center>

<p>Trên Twitter, họ còn nói rằng khả năng buff sức mạnh của Elfie là có thật.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Eva Elfie buff is real</p>&mdash; Out of Context Dota 2 (@NoContextDota2) <a href="https://twitter.com/NoContextDota2/status/1586702677219901440?ref_src=twsrc%5Etfw">October 30, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Nguồn: <a href="https://www.dexerto.com/dota2/eva-elfie-shocked-esports-pros-prefer-dota-2-over-sex-1981824/" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Dexerto</a></p>

<p>Cô cũng từng tham dự sự kiện CSGO năm 2021</p>

<p>Video trên <a href="https://twitter.com/EvaElfie/status/1591135479637811200" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Twitter Eva Elfie</a></p>

<center><img src="/upload/images/game/eva-elfie-brazil-1.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br>

<p>Eva Elfie mặc áo Brazil tham dự sự kiện CSGO năm 2021</p></center>

<p>Bạn có tin vào khả năng buff sức mạnh của cô diễn viên phim người lớn này không?</p>

<center><img src="/upload/images/game/eva-elfie-4.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>
',
            'date_post'         => '2022-10-31',
            'thumbnail_post'    => 'eva-elfie-interview-dota-2-support-causes-tundra-navi-win-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Subverse - chinh phục không gian',
            'url_post'        => 'subverse-chinh-phuc-khong-gian',
            'present_vi_post' => 'Hãy cùng chinh phục vũ trụ với dàn harem của bạn.',
            'content_vi_post' => '<p>Subverse là tựa game của Studio FOW, một studio chuyên làm những bộ phim 18+ đồ họa 3D dựa theo những bộ phim, tựa game nổi tiếng như Lara Croft. Năm 2021, hãng đã gọi vốn trên Kickstater và có được hơn 2 triệu USD để làm tựa game đầu tay: Subverse.</p>

<p>Trang chủ FOW: <a href="https://studiofow.com/subverse/" rel="nofollow" target="_blank" title="Subverse Studio FOW">Studio FOW</a></p>

<p>Kickstarter: <a href="https://www.kickstarter.com/projects/990500595/subverse" rel="nofollow" target="_blank" title="">Subverse</a></p>

<p>Game khi mới ra mắt, nghĩa là phiên bản 0.0.0, bạn sẽ vào vai một nhân vật chuyên lái phi thuyền không gian với tên gọi là The Captain. Trợ lý Demi, một android, cũng là cô vợ đầu tiên của bạn sẽ hướng dẫn bạn những bước đi đầu tiên.</p>

<center><img src="/upload/images/game/subverse-demi-1.jpg" width="100%" alt="Subverse Demi" /><br><br></center>

<p>Sau đó, bạn sẽ được gặp cô tiến sĩ Lily, cũng là cô vợ thứ 2. Cô là một tiến sĩ có thể lai tạo DNA của nhiều sinh vật khác nhau, tạo ra các sinh vật kỳ dị được gọi là Mantics và điều khiển chúng.</p>

<center><img src="/upload/images/game/subverse-mantics-1.jpg" width="100%" alt="Subverse Lily" /><br><br></center>

<p>Cuối cùng, bạn gặp Killision, một tướng lĩnh mang hình dáng nữ quỷ, đeo miếng băng che mắt và có sừng như mũ cướp biển.</p>

<center><img src="/upload/images/game/subverse-killision-1.jpg" width="100%" alt="Subverse Killision" /><br><br></center>

<p>Các phiên bản sau này, game cho thêm nhiều nhân vật mới như Taron thú nhân, Sova người lùn, Elaisha trông giống tộc Elf.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/0hnqph5pg7I" title="Subverse Trailer" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

<p>Trailer phiên bản 0.6.0</p></center>

<p>Về phần gameplay, trận chiến sẽ được diễn ra tại 2 nơi: vũ trụ và trên mặt đất. Trên vũ trụ, The Captain sẽ lái phi thuyền và bắn máy bay theo phong cách Space Shooter. Còn ở dưới mặt đất, những cô gái cùng những sinh vật mantics sẽ được đưa ra để chiến đấu theo phong cách dàn trận theo lượt.</p>

<center><img src="/upload/images/game/subverse-fight-fly-1.jpg" width="100%" alt="Subverse Fight" /><br><br>

<img src="/upload/images/game/subverse-fight-ground-1.jpg" width="100%" alt="Subverse Fight" /><br><br>

</center>




<p>Điểm nhấn đầu tiên của game là phần đồ họa. Những cảnh cutscene các phi thuyền chiến đấu với nhau ngoài vũ trụ được thể hiện rất tốt. Hình ảnh của các nhân vật đa dạng, phong phú. Giọng lồng tiếng được các diễn viên phim 18+ càng tăng mức độ chân thực của các nhân vật.</p>

<p>Hình ảnh vũ trụ và hình ảnh trên mặt đất cũng đa dạng. Những hành tinh, thiên thạch, vùng tuyết, vùng núi lửa, những hầm mỏ cũ. Studio FOW rất đầu tư vào sự đa dạng của bối cảnh.</p>

<p>Tuy nhiên, khuyết điểm đầu tiên là việc miệng nhân vật không mở miệng khi nói. Mặc dù điều này cũng tương tự như việc bạn chơi các game visual novel. Nhưng hiện tại, đã có nhiều game visual novel nhân vật 2D có thể mở miệng. Subverse sử dụng nhân vật 3D nên việc mở miệng càng quan trọng hơn. Giọng lồng tiếng tốt bao nhiêu, việc nhân vật không mở miệng khiến độ chân thực giảm bấy nhiêu. Việc studio FOW đầu tư rất nhiều vào sự đa dạng của hình ảnh nhưng lại thiếu mất phẩn miệng nhân vật là một điều khó hiểu.</p>

<p>Và điều mà các game thủ mong chờ nhất, cũng là điều mà studio FOW có nhiều kinh nghiệm nhất: cảnh nóng. Nếu đã xem qua
<a href="https://studiofow.com/shorts/" rel="nofollow" target="_blank" title="Subverse Studio FOW">những bộ phim mà FOW sản xuất,</a>
chúng ta có thể thấy FOW thiên về sở thích... mặn và dị như: quan hệ với người ngoài hành tinh và các sinh vật giống động vật, phong cách BDSM.
Nói chung, Subverse có những cảnh nóng mang phong cách rất hardcore, có lẽ sẽ không phù hợp với một số người thích sự nhẹ nhàng, tình cảm.</p>

<center><img src="/upload/images/game/subverse-demi-2.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<img src="/upload/images/game/subverse-demi-killision-1.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<img src="/upload/images/game/subverse-demi-sova-1.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br></center>

<p>Những cảnh nóng cần được mở khóa bằng cách kiếm điểm PP. Càng về sau, yếu tố BDSM ngày càng được thể hiện mạnh mẽ hơn như: người ngoài hành tinh, dùng máy móc...
Nhưng điều đáng tiếc nhất là những cảnh nóng này không có cốt truyện. Chúng chỉ đơn giản là những cảnh các nhân vật làm tình với nhau mà không cần lý do gì cả.</p>

<p>Ban đầu, những cảnh nóng vẫn có cốt truyện. Ví dụ như Demi thổi kèn cho thuyền trưởng để giải tỏa căng thẳng sau trận chiến khốc liệt. Đó cũng có thể xem là một cốt truyện.
Nhưng những cảnh người ngoài hành tinh, xúc tu hay các cô gái làm tình với nhau mà chẳng cần lý do hay mối quan hệ nào cả.
Đó giống như phần thưởng đính kèm theo trò chơi vậy.</p>

<center><img src="/upload/images/game/subverse-demi-3.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<img src="/upload/images/game/subverse-demi-4.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<img src="/upload/images/game/subverse-elaisha-1.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<p>Không cần cốt truyện, game cho các nhân vật làm tình với nhau<br>
như một phần thưởng trong trò chơi.</p></center>

<p>Nói đến cốt truyện, game vẫn có điểm cộng là nói về nguồn gốc các nhân vật rõ ràng. Demi được thuyền trưởng giải thoát từ một tay cướp biển khác.
Lily là nhà khoa học của thuyền trưởng. Đó cũng có thể xem như một cách tóm tắt cốt truyện, giải đáp cho game thủ rằng mối quan hệ của họ đã được xây dựng từ trước.
Vì vậy việc họ làm tình với nhau cũng là điều có thể hiểu được.</p>

<p>Tuy nhiên, dù các nhân vật có nhiều chủng tộc khác nhau như con người, người máy, các sinh vật ngoài hành tinh, đặc điểm chung của họ đều là chân dài, 3 vòng chuẩn.
Trừ nhân vật Sova có ngoại hình giống người lùn, các nhân vật còn lại trông khá giống nhau. Đặc biệt, Demi giống như Cortana, trợ lý ảo của Microsoft.</p>

<center><img src="/upload/images/webste/microsoft-cortana-halo-master-chief.jpg" width="100%" alt="Subverse Porn Hentai" /><br><br>

<p>Cortana, trợ lý ảo của Microsoft</p></center>

<p>Nhìn chung, Subverse chỉ là một game ở mức trung bình, từ gameplay đến yếu tổ 18+. Điểm mạnh nhất của game là phần đồ họa. Nếu bạn muốn có một tựa game bắn máy bay để giải trí, Subverse rất phù hợp dành cho bạn.</p>
',
            'date_post'      => '2022-12-14',
            'thumbnail_post' => 'subverse-chinh-phuc-khong-gian-thumbnail.jpg',
            'id_cat_post'    => GAME_POST,
            'signature'      => 0,
            'author'         => 'NVHAI',
            'views'          => random_int(50,500),
            'enable'         => ENABLE,
            'popular'        => 0,
            'update'         => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Pornhub Game Awards 2022',
            'url_post'        => 'pornhub-game-awards-2022',
            'present_vi_post' => '"chiếc cúp trong lòng người hâm mộ" liên quan đến mảng game đã thuộc về tựa game nào?',
            'content_vi_post' => '<p>The Game Awards 2022 được tổ chức vào ngày 9/12/2022, là chương trình trao giải vinh danh những trò chơi điện tử hay nhất năm 2022.</p>

<p>Ngay sau khi lễ trao giải The Game Awards 2022 kết thúc, Pornhub, nền tảng phim 18+ lớn nhất thế giới cũng đã có giải Game Awards riêng của mình.
Đây có thể xem là "chiếc cúp trong lòng người hâm mộ" liên quan đến mảng game. Giải Game Awards này dựa trên thống kê lượt xem, lượt truy cập mà Pornhub công bố.</p>

<p>Nguồn: <a href="https://www.reddit.com/r/hiphopheads/comments/9dqc0w/game_thread_pornhub_awards/" rel="nofollow" target="_blank" title="Pornhub Game Awards">Reddit</a></p>

<h2>Những tựa game được nhiều người xem trên Pornhub nhất.</h2>

<center><img src="/upload/images/game/pornhub-game-awards-2022-most-searched-video-games.jpg" width="100%" alt="Pornhub Game Awards" /><br><br>

<p>Fortnite đã giành được "chiếc cúp trong lòng người hâm mộ" trên PornHub</p></center>

<p>Bảng xếp hạng này có những cái tên rất bất ngờ như Minecraft, Pokémon, Splatoon.
Nếu như Pokémon và Splatoon có thể giải thích được do một số người có khẩu vị cực mặn thì Minecraft lại là một hiện tượng lạ.
Tại sao lại có người thích nhìn những khối vuông trong phim người lớn?</p>

<h2>Những nhân vật trong game được nhiều người xem nhất.</h2>

<center><img src="/upload/images/game/pornhub-game-awards-2022-most-searched-video-game-characters.jpg" width="100%" alt="Pornhub Game Awards" /><br><br>

<p></p></center>

<p><strong>#1 D.Va (Overwatch)</strong></p>

<p>Nữ phi công trẻ đẹp người Hàn Quốc luôn là tâm điểm của game kể từ khi xuất hiện. Phong cách trẻ trung năng động, dễ thương nhưng cũng rất mạnh mẽ, cô là tanker được yêu thích bậc nhất trong tựa game Overwatch.</p>

<center><img src="/upload/images/game/dva-1.jpg" width="70%" alt="Pornhub Game Awards Widowmaker" /><br><br></center>

<p><strong>#2 Jenny Mod (Minecraft)</strong></p>

<p>Mod bạn gái ảo trong Minecraft, Jenny, được thêm vào game trong phiên bản 1.12.2. Đây là một mod mô phỏng bạn gái ảo dựa trên nhân vật Jenny từ chương trình truyền hình My Life as a Teenage Robot.</p>

<p>Jenny có thể làm những chức năng như chiến đấu, trang bị áo giáp. Đặc biệt, cô có thể theo bạn nếu bạn có viên kim cương trong tay.</p>

<p><strong>#3 Widowmaker (Overwatch)</strong></p>

<center><img src="/upload/images/game/widowmaker-1.jpg" width="70%" alt="Pornhub Game Awards Widowmaker" /><br><br></center>

<p>Tiếp tục là một nhân vật trong Overwatch. Widowmaker là nữ thiện xạ xuất hiện trong những ngày đầu của tựa game. Widowmaker, tên thật là Amélie Lacroix, 33 tuổi. Cô hoạt động tại Annecy, Pháp.
Khẩu súng bắn tỉa của WidowMaker được thiết kế hoàn hảo để xử lý những mục tiêu tầm xa.</p>

<p><strong>#4 Lady Dimitrescu (Resident Evil Village)</strong></p>

<center><img src="/upload/images/game/lady-dimitrescu-1.jpg" width="70%" alt="Pornhub Game Awards Lady Dimitrescu" /><br><br></center>

<p>Được ra mắt vào năm 2021 trong tựa game Resident Evil Village, quý bà Dimitrescu đã gây ấn tượng mạnh với các game thủ bằng chiều cao khổng lồ của mình.</p>

<p>Tạo hình của Lady Dimitrescu rất giống với nhân vật Hachishakusama (Eight Foot Tall) trong hentai. Hachishakusama, dịch ra là Cao 8 Feet (khoảng 2,5 mét) là một con ma nữ rất cao, bộ ngực lớn và chuyên đi dụ dỗ các bé trai. Con ma này hay phát ra âm thanh "Po... Po... Po... Po... Po... Po..." với giọng nam trầm. Cách duy nhất để thoát khỏi con ma này là tìm cách chạy trốn khỏi ngôi làng nơi con ma này hoành hành.</p>

<center><img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-vampire-lady-hachishakusama.jpg" width="100%" alt="Lady Dimitrescu Resident Evil 8 Hachishakusama" />

<p>Từ bộ ngực, chiều cao đến nước da, miệng rộng.<br>
Thậm chí là cả chiếc mũ vành đều rất giống nhau.</p>

<img src="/upload/images/game/vampire-lady-trong-resident-evil-8-nhanh-chong-co-nsfw-lady-deathstrike.jpg" width="100%" alt="Lady Dimitrescu Resident Evil 8 Lady Deathstrike" />

<p>Móng tay giống Lady Deathstrike</p></center>

<p>Vì tạo hình giống nhân vật trong hentai, cùng với trào lưu nữ quyền đang nở rộ trong giới điện ảnh và làm game, Lady Dimitrescu nhanh chóng có hàng loạt bức vẽ fanart gắn tag Milf. Chỉ trong vài ngày, một loạt hình ảnh NSFW (Not safe for work) đã xuất hiện tràn ngập trên mạng.
Các game thủ cảm thấy háo hức hơn là sợ hãi khi "được" sống trong một biệt thự cổ cùng với các mỹ nữ xinh đẹp. Ngay cả các cosplayer có bộ ngực lớn cũng tranh thủ hóa trang thành Lady Dimitrescu.</p>

<center><img src="/upload/images/game/lady-dimitrescu-2.jpg" width="70%" alt="Pornhub Game Awards Lady Dimitrescu" /><br><br>

<img src="/upload/images/game/lady-dimitrescu-3.jpg" width="70%" alt="Pornhub Game Awards Lady Dimitrescu" /><br><br>

<img src="/upload/images/game/lady-dimitrescu-4.jpg" width="70%" alt="Pornhub Game Awards Lady Dimitrescu" /><br><br></center>

<p><strong>#5 Mercy (Overwatch)</strong></p>

<p>Mercy là hỗ trợ được yêu thích nhất Overwatch. Cô có khả năng hồi máu cho toàn bộ đồng minh và hồi sinh một đồng minh với câu nói nổi tiếng: "Heroes never die!".
Thậm chí, khi mới ra mắt, cô đã từng quá bá đạo khi có thể hồi sinh toàn bộ đồng minh.</p>

<center><img src="/upload/images/game/mercy-1.jpg" width="70%" alt="Overwatch Mercy" /></center>

<p><strong>#6 Tracer (Overwatch)</strong></p>

<p>Tracer là một cô gái năng động. Cô di chuyển rất nhanh và có khả năng đảo ngược, tự đưa bản thân quay trở về vị trí cô vừa di chuyển.</p>

<center><img src="/upload/images/game/tracer-dva-1.jpg" width="100%" alt="Overwatch Tracer DVA" /></center>

<p>Cô thường được làm phim cùng với DVA.</p>

<p></p>

<p></p>

<p><strong>#7 Mona (Genshin Impact)</strong></p>

<p>Astrologist Mona Megistus là nhân vật hệ Thủy 5 sao trong game Genshin Impact. Cô là một thuật sĩ chiêm tinh với tài năng và lòng kiêu hãnh cao.</p>

<center><img src="/upload/images/game/astrologist-mona-megistus-1.jpg" width="100%" alt="Astrologist Mona Megistus Genshin Impact" /></center>

<p><strong>#8 Ruby (Fortnite)</strong></p>

<p>Ruby là trang phục hiếm trong tựa game Fortnite: Battle Royale. Người chơi có thể mua trong cửa hàng vật phẩm với giá 1200 V-Bucks.
Ruby lần đầu tiên được xuất hiện trong Fortnite Chương 1 Phần 10.</p>

<center><img src="/upload/images/game/ruby-fortnite-1.jpg" width="100%" alt="Ruby Fortnite" /><br><br>

<img src="/upload/images/game/ruby-fortnite-2.jpg" width="70%" alt="Ruby Fortnite" /><br><br></center>

<p></p>

<p></p>

<p><strong>#9 Mei (Overwatch)</strong></p>

<p></p>

<center><img src="/upload/images/game/mei-2.jpg" width="100%" alt="Overwatch Mei" /><br><br></center>

<p></p>

<p><strong>#10: Slime (Genshin Impact)</strong></p>

<p>Nếu bạn xem quá nhiều hentai, chắc hẳn bạn đã biết sinh vật được gọi là slime. Chúng là một sinh vật giống như một khối chất lỏng, có một hạt nhân ở trong chất lỏng đó.
Nếu đánh trúng, chúng sẽ tan chảy. Slime có nhiều loại: slime nước, slime chất độc, slime dung nham... Những con slime level cao có thể mọc ra các xúc tu hoặc kích cỡ to lớn.</p>

<p>Trong hentai hay anime, slime có khả năng làm tan chảy quần áo. Vì vậy, không có gì ngạc nhiên khi slime được tìm kiếm nhiều trên Pornhub.</p>

<center><img src="/upload/images/game/genshin-impact-slime-1.jpg" width="70%" alt="Slime Genshin Impact" />

<p>Slime trong Genshin Impact</p>

<img src="/upload/images/anime/highschool-dxd-rias-akeno.jpg" width="70%" alt="Highschool DxD Trường học ác quỷ" />

<p>Rias và Akeno trong Highschool DxD bị dính slime.</p></center>

<p>Viẹc slime có trong danh sách nhân vật xuất hiện thường xuyên trên Pornhub khiến nhiều người ngạc nhiên. Tuy vậy, với năng lực của slime thì điều này cũng hợp lý. Còn lý do tại sao lại là slime của Genshin Impact, có lẽ do game này nhiều nhân vật nữ.</p>

<p></p>

<p></p>

<p><strong>#11: Aura (Fortnite)</strong></p>

<p></p>

<center><img src="/upload/images/game/aura-fortnite-1.jpg" width="70%" alt="Aura Fortnite" /><br><br>

<img src="/upload/images/game/aura-fortnite-2.jpg" width="70%" alt="Aura Fortnite" /><br><br></center>

<p></p>

<p></p>

<p></p>

<p><strong>#12: Chun-li (Street Fighter)</strong></p>

<p>Chun-Li, chữ Hán tên của cô là "Xuân Lệ". Chun-Li trong phiên bản gốc của Street Fighter II là một trong tám nhân vật chơi được và là nhân vật nữ duy nhất.
Cô muốn trả thù cho cái chết của người cha trong khi ông đang điều tra tổ chức của M. Bison nên đã tham gia làm điệp viên bí mật của Interpol và tham gia giải đấu Street Fighter.</p>

<p>Cô có tạo hình là một phụ nữ với đôi chân khỏe mạnh, mặc bộ sườn xám màu xanh lam. Nơ buộc dài làm cột tóc để nói về việc tang gia của cha mình.
Những đòn thế của Chun-Li là những đòn cước đầy uy lực.</p>

<p>Trong tựa game Street Fighter, cô là nhân vật nữ nổi tiếng, bên cạnh Mai Shiranui. Nhưng rất tiếc khi Mai không có trong danh sách năm nay.</p>

<center><img src="/upload/images/game/chun-li-1.jpg" width="70%" alt="Chun-li Street Fighter" /><br><br></center>

<p><strong>#13: Jett (Valorant)</strong></p>

<p>Tựa game FPS non trẻ Valorant của Riot đã có một đại diện trên Pornhub. Đó là Jett, vị tướng quốc dân Valorant, Yasuo phiên bản nữ. </p>

<p>Ninja Hàn Quốc sử dụng gió để bay nhảy, lả lướt, tạo nên những pha highlight mang đầy tính kỹ thuật như Yasuo của League of Legends.</p>

<center><img src="/upload/images/game/jett-1.jpg" width="100%" alt="Overwatch Jett" /><br><br></center>

<p></p>

<p></p>

<p><strong>#14: Hu Tao (Genshin Impact)</strong></p>

<p></p>

<p></p>

<p></p>

<p></p>

<p>Các nhân vật còn lại trong bảng xếp hạng:</p>

<p><strong>#15: Eula (Genshin Impact)</strong></p>

<p><strong>#16: Lynx (Fortnite)</strong></p>

<center><img src="/upload/images/game/lynx-fortnite-1.jpg" width="70%" alt="Pornhub Game Awards Ashe Overwatch" /><br><br></center>

<p><strong>#17: Lisa (Genshin Impact)</strong></p>

<p><strong>#18: Evie (Fortnite)</strong></p>

<p><strong>#19: Ashe (Overwatch)</strong></p>

<center><img src="/upload/images/game/ashe-overwatch-1.jpg" width="70%" alt="Pornhub Game Awards Ashe Overwatch" /><br><br>

<img src="/upload/images/game/ashe-overwatch-2.jpg" width="70%" alt="Pornhub Game Awards Ashe Overwatch" /><br><br></center>

<p><strong>#20: Tristana (League of Legends)</strong></p>

<center><img src="/upload/images/game/tristana-1.jpg" width="70%" alt="Pornhub Game Awards Tristana" /><br><br></center>
',
            'date_post'         => '2022-12-20',
            'thumbnail_post'    => 'pornhub-game-awards-2022-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'        	=> ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]); // https://www.kakuchopurei.com/2022/12/most-popular-videogame-characters-pornhub-2022/


        posts::create([
            'name_vi_post'     => 'Sau Navi và Tundra, Argentina là đội tiếp theo được nhận "bùa lợi" Eva Elfie',
            'url_post'         => 'after-tundra-navi-argentina-gets-power-from-eva',
            'present_vi_post'  => 'Khả năng buff sức mạnh của Elfie là có thật',
            'content_vi_post'  => '<p>Eva Elfie là một nữ diễn viên phim người lớn, người mẫu khỏa thân và là YouTuber người Nga. Cô đã chiến thắng giải thưởng AVN ở hạng mục Ngôi sao nước ngoài mới xuất sắc nhất năm 2021.</p>

<p>YouTube: <a href="https://www.youtube.com/channel/UCulpMq-W5E_OYziBJhxdUpg" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Instagram: <a href="https://www.instagram.com/theevaelfie/" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>
<p>Twitter: <a href="https://twitter.com/evaelfie" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO">Eva Elfie</a></p>

<p>Xem thêm: <a href="/post/eva-elfie-interview-dota-2-support-causes-tundra-navi-win" rel="nofollow" target="_blank" title="Eva Elfie Dota 2 CSGO Argentina">
Eva Elfie phỏng vấn các tuyển thủ Dota 2, ủng hộ Navi và Tundra</a></p>

<center><img src="/upload/images/game/eva-elfie-2.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>

<p>Năm 2021, cô đã tham dự CSGO Major tại Riocentro, Brazil để cổ vũ cho đội CSGO Natus Vincere, thường được gọi là Navi.
Navi đã thắng Berlin International Gaming với tỉ số 2-0. Mọi người thật sự tin rằng Elfie đã tiếp thêm sức mạnh cho họ, nhất là khi đội Navi đang có phong độ không tốt.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">Adult Star Eva Elfie is at the CSGO Major and cheering for NAVI and S1mple<br><br>They won today <a href="https://t.co/800tOk8CZ2">pic.twitter.com/800tOk8CZ2</a></p>&mdash; Jake Lucky (@JakeSucky) <a href="https://twitter.com/JakeSucky/status/1589696877091749889?ref_src=twsrc%5Etfw">November 7, 2022</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/zlFmD1-bnw0" title="Eva Elfie Dota 2 CSGO" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Ngày 8/11/2022, Navi thắng BIG</p></center>

<p>Sau đó, cô đã mặc áo của đội Tundra. Và trong ngày thi đấu cuối cùng của The International 11, Tundra đã chiến thắng trước Team Secret, trở thành nhà vô địch mới của Dota 2 thế giới.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/UhQmAfzaw7c" title="Eva Elfie Dota 2 CSGO Argentina" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Dota 2 The International 2022 - Main Event - Final Day</p></center>

<p>Và vào ngày 18/12/2022, Argentina đã vô địch World Cup 2022 trước đội tuyển Pháp với tỉ số 3-3.
Sau 120 phút thi đấu và phải phân định bằng loạt sút luân lưu 11m, chiến thắng "mỉm cười" với đội bóng Nam Mỹ với tỉ số 4-2.
Argentina lần thứ 3 vô địch thế giới trong kỳ World Cup cuối cùng của Messi.</p>

<p>Một số người nhớ tới những tấm hình cổ vũ đội Argentina của Elfie. Và trên kênh YouTube của cô, cô cũng đã đăng video xem trận chung kết.
Phải chăng cô thực sự có khả năng buff sức mạnh cho đội mà cô cổ vũ?</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/mEKVQrgGVd4" title="Eva Elfie Dota 2 CSGO Argentina" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<img src="/upload/images/game/eva-elfie-argentina-1.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br>

<img src="/upload/images/game/eva-elfie-argentina-2.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br>

<img src="/upload/images/game/eva-elfie-argentina-3.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br>

<p>Eva Elfie mặc áo đội tuyển Argentina xem trận chung kết World Cup 2022</p></center>

<p>Cô diễn viên xinh đẹp người Nga giờ đã có thêm một năng lực mới. Đó là bùa lợi tăng sức mạnh. Đội tuyển nào sẽ may mắn nhận được buff của cô? Chúng ta hãy cùng chờ xem.</p>

<center><img src="/upload/images/game/eva-elfie-3.jpg" width="70%" alt="Eva Elfie Dota 2 CSGO Argentina" /><br><br></center>
',
            'date_post'         => '2022-12-21',
            'thumbnail_post'    => 'after-tundra-navi-argentina-gets-power-from-eva-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Thời đại phim ảnh bị đổ lỗi',
            'url_post'        => 'blame-violent-movies-instead-of-games',
            'present_vi_post' => 'Không còn đổ lỗi cho game nữa. Các quốc gia chuyển qua đổ lỗi cho phim ảnh trên mạng xã hội.',
            'content_vi_post' => '<p>Cách đây hơn 10 năm, thời kỳ mọi người còn xa lạ với mạng xã hội và bắt đầu chơi game online như Võ Lâm Truyền Kỳ, MU Việt Nam, Thiên Long Bát Bộ... </p>

<h3>Đổ lỗi tại game online</h3>

<p>Ngày xưa, mỗi khi có những vụ án thanh niên đâm chém, giết người thì game bị đem ra làm vật tế để đổ lỗi. Từ những vụ trộm cắp nhỏ đến vụ án gây chấn động của Lê Văn Luyện. Nhiều báo chí đều nói game online là nguyên nhân.</p>

<p>Sát thủ teen nghiện game online: <a href="https://thanhphohaiphong.gov.vn/sat-thu%CC%89-teen-nghie%CC%A3n-game-online.html" rel="nofollow" target="_blank" title="nghiện game online">thanhphohaiphong</a></p>

<p>Game online và những ảnh hưởng tới sức khỏe: <a href="https://vtv.vn/suc-khoe/game-online-va-nhung-anh-huong-toi-suc-khoe-2016121910433701.htm" rel="nofollow" target="_blank" title="nghiện game online">VTV</a></p>

<p>Nhưng ngày nay, ngay cả VTV cũng phải nói về thể thao điện tử, SEA Games cũng có bộ môn thể thao điện tử. Vậy việc đem game ra làm vật tế liệu có còn phù hợp?</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/poQ2mOruX3c" title="VTV thể thao điện tử" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/C6TCCmBll64" title="VTV thể thao điện tử" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>VTV nói về thể thao điện tử</p></center>

<h3>Đổ lỗi tại phim trên mạng xã hội</h3>

<p>Quay lại thời điểm hiện tại, khi các phụ huynh không những không ngăn con đi đến các tiệm net (vì các tiệm net đóng cửa do điện thoại lên ngôi), lại còn đưa điện thoại cho con chơi game online. Vậy nếu có những vụ việc xảy ra, thứ gì sẽ bị mang ra để đổ lỗi? Câu trả lời là phim ảnh. Hay nói chinh xác hơn là <strong>phim trên mạng xã hội như YouTube, TikTok.</strong></p>

<p>Khi muốn đưa một tựa game lên thị trường, các bộ phận quản lý, các nền tảng phát hành game như Steam, Google Play đã kiểm duyệt theo từng quốc gia. Chưa kể đến cấu hình máy, thời gian chơi game...
Nhưng những bộ phim, MV ca nhạc trên các nền tảng mạng xã hội rất khó kiểm soát. Yêu cầu duy nhất là mạng Internet. Người ở quốc gia này có thể xem video ở các quốc gia khác. Nếu chặn IP, người dân có thể dễ dàng vượt tường lửa, fake IP...</p>

<p>Tối 28/4, kênh YouTube chính thức của Sơn Tùng M-TP đăng tải MV tiếng Anh "There&apos;s No One At All". Sản phẩm gây tranh cãi dữ dội vì hình ảnh u ám, thông điệp tiêu cực, nhân vật chính gây rối, hút thuốc và sau cùng là tự tử. Đây là một trong số rất nhiều vụ việc đình đám về phim ảnh, MV trong năm 2022.</p>

<center><img src="/upload/images/game/MV-son-tung-1.jpg" width="100%" alt="MV Sơn Tùng " /><br><br></center>

<p>Mặc dù việc cảnh báo về phim ảnh đã xảy ra cùng thời với game online. Tuy nhiên, cách đây hơn 10 năm, smartphone hay live stream là khái niệm rất xa vời. Trong khi game online có thể dễ tiếp cận bằng cách ra quán net. Vì vậy, game online là đối tượng chính bị đổ lỗi thời đó.</p>

<p>Còn hiện tại, từ người nghèo đến người giàu, từ học thức đến giang hồ đều có thể live stream, quay video và kiếm nhiều tiền từ những video gây shock này. Vì vậy, tội lỗi được chuyển từ game online sang video.</p>

<center><img src="/upload/images/website/there-is-no-more-social-network-just-advertising-adult-video-5.jpg" width="100%" alt="there is no more social media adult 16+ 18+" /><br><br>

<img src="/upload/images/website/there-is-no-more-social-network-just-advertising-adult-video-1.jpg" width="100%" alt="there is no more social media adult 16+ 18+" /><br><br>

<p>Từ khi Facebook học theo TikTok, những video nội dung 16+ xuất hiện rất nhiều trên Facebook.</p></center>

<p>Phim ảnh trên mạng xã hội còn có một lợi thế. Đó là không có biên giới. Khác với game có thể ngăn chặn, thay đổi tùy theo mỗi quốc gia, mỗi thị trường, video trên mạng xã hội hay các website chỉ cần tuân thủ đất nước mà mạng xã hội này hoạt động.
Bạn có thể tạo một website người lớn tại một đất nước hợp pháp việc mở website người lớn. Sau đó mọi người trên khắp thế giới có thể xem video của bạn.</p>

<p>Thời game bị đổ lỗi đã qua rồi. Các quốc gia chuyển qua đã đổ lỗi cho phim ảnh trên mạng xã hội.</p>
',
            'date_post'      => '2023-01-03',
            'thumbnail_post' => 'blame-violent-movies-instead-of-games-thumbnail.jpg',
            'id_cat_post'    => GAME_POST,
            'signature'      => 0,
            'author'         => 'NVHAI',
            'views'          => random_int(50,500),
            'enable'         => ENABLE,
            'popular'        => 0,
            'update'         => 0,
        ]);
        // https://voz.vn/t/phim-viet-co-am-thanh-loi-thoai-truy-lac-bi-phat-40-den-50-trieu-dong.694472/page-4
        // https://tienphong.vn/phim-viet-co-am-thanh-loi-thoai-truy-lac-bi-phat-40-den-50-trieu-dong-post1500711.tpo
        // https://www.psychiatrictimes.com/view/violence-media-what-effects-behavior

        posts::create([
            'name_vi_post'    => 'Blizzard cấm các game thủ Hearthstone chuyên nghiệp của Trung Quốc',
            'url_post'        => 'blizzard-banning-pro-hearthstone-players-residing-mainland-china',
            'present_vi_post' => 'Sau những năm ưu ái cho thị trường Trung Quốc, Blizzard đã có hành động khá gay gắt với game thủ thị trường này.',
            'content_vi_post' => '<p>Blizzard đã công bố lộ trình của Hearthstone cho năm 2023. Nhưng có một tin buồn cho những người chơi Hearthstone cư trú tại Trung Quốc:
họ chính thức bị cấm tham gia các sự kiện trò chơi chuyên nghiệp.</p>

<p>Câu chuyện bắt đầu từ NetEase, một công ty công nghệ Internet của Trung Quốc cung cấp các dịch vụ trực tuyến. NetEase và Blizzard hợp tác với nhau kể từ năm 2008. Chuyện tình dài 14 năm này đã đến hồi kết thúc.</p>

<p>Blizzard đã hết hạn hợp đồng với NetEase. Theo Blizzard, họ đã liên lạc với NetEase nhưng không đạt được thỏa thuận.
Còn theo NetEase, họ không thể chấp nhận những yêu cầu vô lý của Blizzard.</p>

<p>Nguồn: <a href="https://www.gamesindustry.biz/activision-blizzard-claims-netease-rejected-proposal-to-extend-china-partnership" rel="nofollow" target="_blank" title="Hearthstone China">Games Industry</a></p>

<p>Giám đốc điều hành NetEase, William Ding cho biết công ty của ông đã "nỗ lực rất nhiều và cố gắng hết sức chân thành để đàm phán với Activision Blizzard"
nhưng cặp đôi không thể đạt được thỏa thuận do "sự khác biệt lớn về lợi ích"</p>

<p>Câu chuyện phức tạp hơn khi NetEase tung ra thương hiệu Blizzard Green Tea (Trà Xanh Bão Tuyết).
Một đoạn video cho thấy một nhóm người đập bức tượng cây rìu Gorehowl (Gorehowl Axe).</p>

<p>Nguồn: <a href="https://news.yahoo.com/net-ease-livestreams-demolition-of-blizzard-offices-in-china-113500462.html" rel="nofollow" target="_blank" title="Hearthstone China">Yahoo News</a></p>

<p>NetEase đưa ra một số lời giải thích như sau:</p>

<p>Nguồn: <a href="https://www.wowhead.com/news/netease-response-to-blizzard-entertainment-local-orc-statue-torn-down-331041" rel="nofollow" target="_blank" title="Hearthstone China">wowhead</a></p>

<blockquote>
<p><b>Đầu tiên, giải thích "NetEase đã từ chối gia hạn dịch vụ 6 tháng do Blizzard đề xuất".</b></p>

<p>Blizzard Trung Quốc đã đưa ra một tuyên bố cập nhật vào ngày hôm nay (17/1/2023), nói rằng trong giai đoạn này, Blizzard đã bắt đầu tìm kiếm đối tác mới.</p>

<p>Vì những lý do không biết trước, tuần trước Blizzard đã tìm kiếm NetEase với lời đề nghị về cái gọi là gia hạn 6 tháng dịch vụ trò chơi và các điều khoản khác.
Đồng thời nói rõ rằng họ sẽ không ngừng đàm phán với các đối tác tiềm năng khác trong thời gian gia hạn hợp đồng.</p>

<p>Và theo những gì chúng tôi biết, các cuộc đàm phán của Blizzard với các công ty khác trong cùng thời gian đều có thời hạn hợp đồng 3 năm.
Do không công bằng và thêm các điều khoản khác đi kèm với việc hợp tác nên cuối cùng, các bên không đạt được thỏa thuận.</p>

<p>Theo quan điểm của chúng tôi, đề xuất của Blizzard - bao gồm cả thông báo bất ngờ ngày hôm nay - là thô lỗ, không phù hợp và phi logic về mặt thương mại.</p>

<p><b>Thứ hai, các phương tiện truyền thông đưa tin rằng tuyên bố "NetEase muốn kiểm soát IP"</b></p>

<p>Chúng tôi lo ngại một số phương tiện truyền thông đã biết tin đồn NetEase muốn kiểm soát Blizzard IP.
Trong 14 năm hợp tác lâu dài vừa qua, NetEase đã sử dụng và cấp phép cho bất kỳ IP Blizzard nào theo các điều khoản của hợp đồng
và đã nhận được sự đồng ý và chấp thuận của Blizzard. Mọi hợp tác với các đối tác khác cũng dựa trên nguyên tắc này.</p>

<p><b>Thứ ba, một số mẹo về kho lưu trữ tiến trình của người chơi trò chơi World of Warcraft.</b></p>

<p>Blizzard Trung Quốc trong tuyên bố của mình có đề cập về việc ra mắt tính năng lưu trữ tiến trình trò chơi "World of Warcraft" vào ngày mai (giờ Bắc Kinh).
Chúng tôi có nghĩa vụ phải nhắc nhở tất cả người chơi rằng, tính năng này do Blizzard đơn phương đề xuất và phát triển trực tuyến mà không có bên NetEase thử nghiệm, sử dụng,
có thể có những rủi ro bảo mật. Nếu tính năng này làm mất tài sản ảo hoặc không chơi được, Blizzard sẽ chịu hoàn toàn trách nhiệm.</p>
</blockquote>

<center><img src="/upload/images/game/blizzard-banning-pro-hearthstone-players-residing-mainland-china-gorehowl-axe-1.jpg" width="100%" alt="Hearthstone China" /><br><br>

<img src="/upload/images/game/blizzard-banning-pro-hearthstone-players-residing-mainland-china-blizzard-green-tea-1.jpg" width="70%" alt="Hearthstone China" /><br><br>

<video width="80%" controls preload controlsList="nodownload"
poster="http://kingdomnvhai.info/upload/images/video/blizzard-banning-pro-hearthstone-players-residing-mainland-china-thumbnail.jpg">
<source src="http://kingdomnvhai.info/upload/video/netease-orc-teardown.mov" type="video/mp4">
</video>

<p>Trà sữa Bão Tuyết và cảnh nhóm người đập bức tượng</p></center>

<p>Blizzard quyết định đáp trả bằng cách cấm các game thủ Hearthstone chuyên nghiệp của Trung Quốc trong giải đấu Hearthstone.</p>

<p>Nguồn: <a href="https://hearthstone.blizzard.com/en-us/news/23904520/climb-the-ladder-with-hearthstone-esports-in-2023" rel="nofollow" target="_blank" title="Hearthstone China">Blizzard</a></p>

<blockquote>
<p><b>Phải chăng giải thưởng giảm vì NetEase mất tư cách nhà phát hành Trung Quốc?</b></p>

<p>Không, chúng tôi đã bắt đầu đánh giá quy mô của chương trình trước khi hiểu rằng chúng tôi sẽ không thể đạt được thỏa thuận với NetEase.
Như chúng tôi đã chia sẻ, chúng tôi cam kết với người chơi Trung Quốc và đang tích cực khám phá các giải pháp thay thế
để đưa các trò chơi của chúng tôi trở lại Trung Quốc trong tương lai.</p>

<p><b>Hiện tình trạng của người chơi từ Trung Quốc đại lục như thế nào?</b></p>

<p>Thật không may, mặc dù chúng tôi muốn mời họ, nhưng Gold Series - chương trình Hearthstone cạnh tranh của Trung Quốc đại lục - được điều hành bởi nhà phát hành địa phương từ trước đó,
đã gửi lời mời cho người chơi thi đấu trong chương trình Hearthstone Esports bên ngoài Trung Quốc đại lục.
Khi các thỏa thuận của chúng tôi kết thúc, hoàn cảnh đã thay đổi. Chúng tôi hy vọng sẽ cho phép người chơi Trung Quốc cạnh tranh
trên toàn cầu khi chúng tôi tìm ra các giải pháp thay thế để đưa Hearthstone trở lại.</p>
</blockquote>

<p>Năm nay sẽ có tổng cộng 7 sự kiện - 3 Giải vô địch Masters Tour theo mùa để tiến đến Giải vô địch thế giới năm 2023,
3 giải đấu Battlegrounds: Lobby Legends - tất cả đều được phát sóng trên YouTube và Twitch!</p>
',
            'date_post'      => '2023-01-20',
            'thumbnail_post' => 'blizzard-banning-pro-hearthstone-players-residing-mainland-china-thumbnail.jpg',
            'id_cat_post'    => GAME_POST,
            'signature'      => 0,
            'author'         => 'NVHAI',
            'views'          => random_int(50,500),
            'enable'         => ENABLE,
            'popular'        => 0,
            'update'         => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Overwatch 2 collab One Punch Man vào tháng 3',
            'url_post'        => 'overwatch-2-launches-one-punch-man-collab-in-march',
            'present_vi_post' => 'Doomfist có bộ skin Saitama. Các nhân vật khác có các skin phong cách Nhật Bản.',
            'content_vi_post' => '<p>Blizzard thông báo về season 3 của trò chơi bắn súng góc nhìn thứ nhất Overwatch 2.
Game sẽ có sự hợp tác với bộ truyện tranh và anime One-Punch Man của tác giả ONE và Yuusuke Murata.</p>

<p>Nguồn: <a href="https://overwatch.blizzard.com/en-us/news/23912175/" rel="nofollow" target="_blank" title="Overwatch 2 collab One Punch Man in March">Blizzard</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/MNX1wV9UfL4" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">Earnable Rewards 💪<br>New Control Map 🧊<a href="https://twitter.com/hashtag/OnePunchMan?src=hash&amp;ref_src=twsrc%5Etfw">#OnePunchMan</a> Collab 👊<br>Seasonal Events 💘<a href="https://twitter.com/hashtag/Overwatch2?src=hash&amp;ref_src=twsrc%5Etfw">#Overwatch2</a> Season 3 and an all new Battle Pass arrive Feb 7! Free to play for everyone on console &amp; PC. <a href="https://t.co/FxiHOk4Lnj">pic.twitter.com/FxiHOk4Lnj</a></p>&mdash; Overwatch (@PlayOverwatch) <a href="https://twitter.com/PlayOverwatch/status/1622653719996243985?ref_src=twsrc%5Etfw">February 6, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Tweet của</p></center>

<p>Collab sẽ bắt đầu vào ngày 7/3/2023 và kéo dài đến ngày 6/4/2023. Blizzard đã tiết lộ skin Saitama Doomfist và sắp tới sẽ có thêm nhiều skin khác mang phong cách Nhật Bản.</p>

<center><img src="/upload/images/game/overwatch-2-collab-one-punch-man-saitama-doomfist.jpg" width="100%" alt="Overwatch 2 collab One Punch Man in March" /><br><br></center>

<p>Saitama Doomfist</p>

<img src="/upload/images/game/overwatch-2-collab-one-punch-man-kiriko.jpg" width="100%" alt="Overwatch 2 collab One Punch Man in March" /><br><br>

<p>Kiriko</p></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/interest/2023-02-06/overwatch-2-launches-one-punch-man-collab-in-march/.194585" rel="nofollow" target="_blank" title="Hearthstone China">Anime News Network</a></p>
',
            'date_post'         => '2023-02-06',
            'thumbnail_post'    => 'overwatch-2-launches-one-punch-man-collab-in-march-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
			'update'            => 0,
        ]);

//         posts::create([
//             'name_vi_post'    => 'Hogwarts Legacy có 200 mods',
//             'url_post'        => 'hogwarts-legacy-have-200-mods',
//             'present_vi_post' => 'VTuber Hololive cũng xuất hiện trong Hogwarts Legacy.',
//             'content_vi_post' => '<p>Hogwarts Legacy là tựa game mới được ra mắt vào ngày ... của hãng...</p>

// <p>Riêng trên trang <a href="https://www.nexusmods.com/hogwartslegacy" rel="nofollow" target="_blank" title="Hogwarts Legacy Mods Hololive">Nexus Mods</a>, có hơn 200 mod.</p>

// <p></p>

// <p>Được tạo bởi modder xBloodTigerx, bản mod Moving Frams - Anime VTubers - Hololive bổ sung nhiều hình ảnh và gif của các Hololive VTuber như Usada Pekora,
// Inugami Korone và Oozora Subaru vào các khung ảnh trang trí trường Hogwarts.</p>

// <p>Nguồn: <a href="https://www.dexerto.com/hogwarts-legacy/hogwarts-legacy-now-has-hololive-vtubers-in-it-thanks-to-pc-modders-2059359/" rel="nofollow" target="_blank" title="Hogwarts Legacy Mods Hololive">Dexerto</a></p>

// <center><img src="/upload/images/game/hogwarts-legacy-have-200-mods-hololive.jpg" width="100%" alt="Hogwarts Legacy có 200 mods" />

// <p>Mods VTuber Hololive</p></center>

// <p></p>

// <p></p>

// <p></p>

// <p></p>

// <p></p>
// ',

//             'date_post'         => '2023-02-17',
//             'thumbnail_post'    => 'hogwarts-legacy-have-200-mods-thumbnail.jpg',
//             'id_cat_post'       => GAME_POST,
//             'signature'         => 0,
//             'author'            => 'NVHAI',
//             'views'             => random_int(50,500),
//             'enable'            => ENABLE,
//             'popular'           => 0,
//             'update'            => 0,
//         ]); // https://www.youtube.com/watch?v=IJfVSuxR0NA

        posts::create([
            'name_vi_post'    => 'Trans Vtubers kêu gọi Twitch chấm dứt các cuộc tấn công thù địch liên quan đến Hogwarts Legacy',
            'url_post'        => 'trans-vtubers-urge-twitch-to-shut-down-hate-raids-amid-hogwarts-legacy-controversy',
            'present_vi_post' => 'VTuber Hololive cũng xuất hiện trong Hogwarts Legacy.',
            'content_vi_post' => '<p>Hogwarts Legacy là tựa game mới được ra mắt vào tháng 2/2023 của hãng Avalanche Software, thuộc thể loại nhập vai. Trò chơi lấy bối cảnh thế giới phù thủy trong tiểu thuyết Harry Potter, được phát hành trên hệ máy PlayStation 5, Windows và Xbox Series X/S</p>

<p>Câu chuyện bắt đầu từ nhà văn J.K Rowling, tác giả của tiểu thuyết Harry Potter. Bà là một người theo phong trào nữ quyền, nhưng không chấp nhận những người chuyển giới là phụ nữ. Vì vậy, bà trở thành đối tượng bị chỉ trích của LGBT, cộng đồng những người đồng tính.</p>

<p>Khi Hogwarts Legacy được ra mắt, tựa game này đã trở thành một hiện tượng. Rất nhiều streamer trên thế giới đã chơi game này. Tuy nhiên, cộng đồng LGBT đã chỉ trích tựa game này vì nội dung được lấy từ tiểu thuyết Harry Potter của J.K Rowling. Họ chỉ trích, tấn công những streamer chơi tựa game này, bao gồm cả các VTuber.</p>

<p>Điều này khiến các fan của các streamer, đặc biệt là các fan VTuber, quyết định chiến đấu bảo vệ cho waifu của mình. Họ truy tìm địa chỉ IP, địa chỉ nhà của những kẻ tấn công.</p>

<p>Sau khi ra mắt Hogwarts Legacy, có thông tin cho rằng các streamer đang bị tấn công dữ dội trên Twitch. Tuy nhiên, kể từ sự cố này, hơn chục Vtubers chuyển giới
đã nói chuyện với Dexerto về sự lạm dụng mà họ đã nhận được trên Twitch trong nhiều năm, các cuộc tấn công vẫn tiếp tục sau khi trò chơi ra mắt.</p>

<p>Vtuber Marina đã nói: "Tôi không nghĩ những cuộc tấn công thù địch này và những điều tương tự đang xảy ra vì Hogwarts Legacy. Chúng luôn xảy ra với chúng tôi.
Tôi nghĩ rằng sự sợ hãi về giọng nói chuyển giới trên Twitter xung quanh Hogwarts Legacy đã khiến những kẻ lừa đảo và những kẻ xấu này muốn hành động mạnh mẽ hơn trong thời gian gần đây."</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">I haven&#39;t seen any proof of harassment or death threats coming from trans people at the most just things like &quot;I no longer respect you and I&#39;m unfollowing&quot;<br><br>You know what I have seen proof of?<br><br>The actual death threats and hate WE GET. <a href="https://t.co/T2I6tUIxKv">https://t.co/T2I6tUIxKv</a> <a href="https://t.co/f5Ydx3wbJ2">pic.twitter.com/f5Ydx3wbJ2</a></p>&mdash; Klavinmour 🏳️‍⚧️ Vtuber 🏳️‍⚧️ (@Klavinmour) <a href="https://twitter.com/Klavinmour/status/1623097691311050752?ref_src=twsrc%5Etfw">February 7, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<p>Tweet của VTuber Klavinmour</p></center>

<h3>Các cuộc tấn công thù địch nhắm vào các streamer trên Twitch</h3>

<p>Ngay sau khi phát hành Hogwarts Legacy, các Vtubers đã trải qua các cuộc tấn công thù địch gần giống nhau.</p>

<p>Họ được yêu cầu thực hiện những hành vi tự làm hại bản thân, cùng với những lời lẽ thù địch từ các tài khoản mới theo dõi kênh stream của họ.</p>

<p></p>

<p></p>



<p></p>


<p>"Tôi nhận được nhiều lời dọa giết". Twitch VTuber Silvervale suy sụp khi kể lại hành vi quấy rối khi chơi Hogwarts Legacy trên stream của mình.</p>

<p>Nguồn: <a href="https://www.sportskeeda.com/esports/news-i-ve-received-many-death-threats-twitch-vtuber-silvervale-breaks-recounting-harassment-playing-hogwarts-legacy-stream" rel="nofollow" target="_blank" title="Hogwarts Legacy Mods Hololive">Sports Keeda</a></p>

<p>Nguồn: <a href="https://games.yahoo.com.tw/news/vshojo-silvervalehog-030550601.html" rel="nofollow" target="_blank" title="Hogwarts Legacy Mods Hololive">Yahoo News</a></p>

<center><img src="/upload/images/game/twitch-vtuber-silvervale-hogwarts-legacy-1.jpg" width="100%" alt="anime sống chung với ma Doukyo Hito ga Konoyo no Mon janai"><br><br>

<iframe src="https://clips.twitch.tv/embed?clip=MagnificentBoringSpaghettiTBCheesePull-SywKRTtt30dqx0yk&parent=www.example.com" frameborder="0" allowfullscreen="true" scrolling="no" height="378" width="620"></iframe>

<p>Twitch VTuber Silvervale khóc lóc kể về sự việc</p></center>

<p></p>

<blockquote>
<p>"I&apos;ve received so many death threats and harassment and doxing, people doxing my friends. And, like, so much horrible, vile things. All for streaming a f*cking video game."</p>
</blockquote>

<blockquote>
<p>"Tôi đã nhận được rất nhiều lời đe dọa giết người, quấy rối và chơi xấu. Mọi người chơi xấu bạn bè của tôi. Và cũng như rất nhiều điều kinh khủng, hèn hạ. Tất cả chỉ vì buổi stream một trò chơi điện tử chết tiệt."</p>
</blockquote>

<p></p>

<p></p>

<p>Nguồn: <a href="https://www.dexerto.com/entertainment/trans-vtubers-urge-twitch-to-shut-down-hate-raids-amid-hogwarts-legacy-controversy-2060133/" rel="nofollow" target="_blank" title="Hogwarts Legacy Mods Hololive">Dexerto</a></p>

<p>Ngược lại, vẫn có các VTuber muốn thách thức nhóm LGBT. Vtuber Pippa tuyên bố cô sẽ stream Hogwarts Legacy.
VTuber Kobo Kanaeru của Hololive cũng đã quyết định stream tựa game này. Các fan từ Indonesia và nhiều nước khác đều ủng hộ. Họ quyết tâm bảo vệ cô trước làn sống woke.</p>

<center><img src="/upload/images/game/pippa-hogwarts-legacy-1.jpg" width="100%" alt="anime sống chung với ma Doukyo Hito ga Konoyo no Mon janai"><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/LDxB4tfYF_k?si=OpVUN13Add1tjaoO" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>
',

            'date_post'         => '2023-02-18',
            'thumbnail_post'    => 'trans-vtubers-urge-twitch-to-shut-down-hate-raids-amid-hogwarts-legacy-controversy-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Hermione và các giáo sư trong Hogwarts Legacy nổi tiếng trên... Rule34',
            'url_post'        => 'hermione-and-professors-on-hogwarts-legacy-is-famous-of-rule-34',
            'present_vi_post' => 'Một bài viết xứng đáng được đăng vào ngày 8/3',
            'content_vi_post' => '<p>Hogwarts Legacy là tựa game mới được ra mắt vào tháng 2/2023 của hãng Avalanche Software, thuộc thể loại nhập vai. Trò chơi lấy bối cảnh thế giới phù thủy trong tiểu thuyết Harry Potter, được phát hành trên hệ máy PlayStation 5, Windows và Xbox Series X/S</p>

<p>Trang chủ <a href="https://www.hogwartslegacy.com/en-us" rel="nofollow" target="_blank" title="Hogwarts Legacy Official Website">Hogwarts Legacy</a></p>

<p>Sau khi Hogwarts Legacy được ra mắt, game đã tạo nên một hiện tượng trong làng game. Game được đánh giá rất cao, nhưng cũng đầy drama liên quan đến cộng đồng LGBT và các VTuber.</p>

<p>Xem thêm: </p>

<p>Và như một quy luật tất yếu: game nổi tiếng, ắt hẳn có trên Rule34. Hogwarts Legacy dần dần xuất hiện trên các web đen với những hình ảnh về các nhân vật nữ.
Nổi tiếng nhất, không ai khác chính là Hermione Granger, do diễn viên Emma Watson thủ vai trong series phim Harry Potter. Một số bức vẽ do AI tạo nên.</p>

<center><img src="/upload/images/game/emma-watson-hermione-1.jpg" width="100%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-1.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-2.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-3.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-4.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<img src="/upload/images/game/hogwarts-legacy-hermione-5.jpg" width="90%" alt="Hogwarts Legacy Hermione"><br><br>

<p>Hermione Granger do diễn viên Emma Watson thủ vai</p></center>

<p>Không chỉ có vậy, Hogwarts Legacy còn có nhiều nhân vật nữ khác. Đó là các giáo sư giảng dạy trong trường Hogwarts. Nổi tiếng nhất là Mirabel Garlick, giáo viên môn Thảo Mộc Học.</p>



<p>Hiện tại, Emma Watson chưa có bình luận gì về hiện tượng này.</p>
',

            'date_post'         => '2023-03-08',
            'thumbnail_post'    => 'hermione-and-professors-on-hogwarts-legacy-is-famous-of-rule-34-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]); // https://www.youtube.com/watch?v=QU7sfCk51kc https://rule34.xxx/index.php?page=post&s=list&tags=hermione_granger+

        posts::create([
            'name_vi_post'    => 'Date a live Spirit Pledge server Global thông báo đóng cửa',
            'url_post'        => 'date-a-live-spirit-pledge-server-global-will-be-officially-closed',
            'present_vi_post' => 'Ngày đóng cửa vào tháng 5/2023',
            'content_vi_post' => '<p>Date a live Spirit Pledge (DALSP) là tựa game gacha dựa theo series anime nổi tiếng Date a live. Server Trung Quốc được ra mắt vào năm 2018, server Global năm 2020 và server Nhật Bản năm 2022.</p>

<p>Trang chủ <a href="https://www.datealive.com/" rel="nofollow" target="_blank" title="Date a live Spirit Pledge">Date a live Spirit Pledge</a></p>

<p>Group Facebook: <a href="https://www.facebook.com/groups/dalspvietnam" rel="nofollow" target="_blank" title="Date a live Spirit Pledge">Date a live Spirit Pledge Việt Nam</a></p>

<p></p>

<p>Nhà phát hành Hot Game Studio đã ra thông báo:</p>

<blockquote>
<h3>Date A Live: Spirit Pledge - End of Service Announcement</h3>

<p>Dear Player,</p>

<p>Thank you for your continuous support of our game "Date A Live: Spirit Pledge". We regret to announce that the game "Date A Live: Spirit Pledge" will be officially closed at 21:00 on May 20, 2023 (UTC-7)</p>

<p>We hereby inform you as follows:</p>

<p>1. 21:00 on March 20, 2023 (UTC-7) : The registration of new accounts will not be accepted and the game will be removed from all stores. Thereafter, the game will not be accepting any in-app payments or refunds.</p>

<p>2. 21:00 May 20, 2023 (UTC-7) : The game server will be closed and all players will not be able to log in and play the game;</p>

<p>【 Note 】</p>

<p>a. You can still use your recharged items and play the game before the server is officially closed at 21:00 on May 20, 2023 (UTC-7) ;</p>

<p>b. After the server is closed, all your account data and character info (such as diamonds, props, etc.) in the game will be cleared;</p>

<p>Thank you again for your support and love for "Date A Live: Spirit Pledge".</p>
</blockquote>

<p>Nguyên nhân của việc này bắt đầu từ đợt remastered lớn vào năm 2022. Date A Live: Spirit Pledge HD là bản remastered của Date A Live: Spirit Pledge Global.
Không biết vì lý do gì, game đã thay đổi hoàn toàn giao diện, lối chơi cũ. Người chơi phải học lại gần như tất cả. Số lượng người chơi suy giảm nghiêm trọng.</p>

<p>Sau 1 năm từ ngày remastered, game đã mất hoàn toàn sức hút ban đầu và dần bị người chơi bỏ rơi. Thật đáng tiếc cho một tựa game ... năm tuổi từng được rất nhiều người mong đợi.</p>

<p></p>

<p>Sau đây là những điểm khiến bản remastered bị chê trách so với bản gốc.</p>

<h3>Tinh Linh thiếu chiêu thức</h3>

<p>Trước khi remaster, mỗi Tinh Linh sẽ có 3 skill chính và 1 skill phụ. Ví dụ: Kurumi có skill phụ là kết giới và 3 skill chính.</p>

<p>Nhưng sau khi remaster, Tinh Linh chỉ được nâng tối đa level 15 và bị mất 1 skill, cũng là skill mạnh nhất. Để nâng được skill này, người chơi phải nâng lên level 25 bằng cách cày các nguyên liệu của phần daily quest.</p>

<p>Nghĩa là giai đoạn khởi đầu của người chơi sẽ khó hơn. Mặc dù người chơi có thể cày, nhưng mục đích của thay đổi này thì ai cũng thấy rõ: nạp tiền nếu không muốn cày.</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-spirit-skill.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Giới hạn level 15 và bị mất 1 skill</p></center>

<h3>Tinh Linh yếu đi</h3>

<p>Đây là sự thay đổi rõ rệt mà ai cũng có thể nhận ra khi game được sửa lại.</p>

<p>Trong DALSP, phần cốt truyện có 3 độ khó: story, hard, hell. Mỗi phần sẽ có 3 nhiệm vụ nhỏ để tặng 3 ngôi sao. Hoàn thành số ngôi sao nhất định sẽ được tặng 1 hộp quà.</p>

<p>Trước chỉnh sửa, người chơi có thể tự cày nhân vật, không cần nạp tiền mà vẫn dễ dàng vượt qua cốt truyện game với 3 sao đầy đủ. Thậm chí, người chơi có thể quay lại chinh phục mức hard và hell sau này.</p>

<p>Nhưng sau khi chỉnh sửa, ngay cả độ khó story cũng rất khó để hoàn thành 3 ngôi sao.</p>

<p>KINGDOM NVHAI ví dụ bằng đội hình sau:</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-team-1.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Đội hình của KINGDOM NVHAI</p></center>

<p>Trong đội hình này, Tokisaki Kurumi là Tinh Linh mạnh nhất với lực chiến hơn 4000, có nhiều đồ, nâng cấp level 35. Nhưng để đạt được 3 sao mỗi nhiệm vụ là điều không hề dễ dàng. Thậm chí, đôi khi Kurumi thua trận và được thay bằng nhân vật khác.</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-yamai-story-15.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-yamai-story.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Vượt qua độ khó Story nhưng không hoàn thành 3 sao.</p></center>

<h3>Nâng cấp theo hệ</h3>

<p>Thay đổi khác của DALSP là việc mỗi nhân vật có một hệ khác nhau. Trong phiên bản cũ, game phân ra làm 3 loại: Tinh Linh (Spirit), Con Người (Human) và Máy Móc (Mecha). Khi nâng cấp kỹ năng, sẽ có những kỹ năng gây sát thương cao hơn với mỗi loại.</p>

<p>Còn trong phiên bản làm lại, game cho mỗi nhân vật một hệ. Kurumi là Bóng Tối (Dark), Yoshino là Băng (Frost), Origami là Ánh Sáng (Light).
Điều này nghe có vẻ là một tính năng mới khá hay của game. Nhưng thật ra, đây là một cách kiếm tiền.</p>

<p>Trong các nhiệm vụ, màn chơi khác nhau sẽ yêu cầu hệ khác nhau. Vậy điều gì sẽ xảy ra khi Tinh Linh của bạn không có hệ phù hợp? Bạn sẽ bị bất lợi. Vậy nên để có nhân vật hệ phù hợp, bạn phải nâng cấp nhiều nhân vật hơn, đồng nghĩa bạn phải cày nhiều hơn và nạp tiền nhiều hơn.</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-endless-corridor-1.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Mỗi màn chơi đề xuất các hệ có lợi thế</p>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-tohka.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-rinne.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-origami-angle.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Mỗi Tinh Linh có một hệ riêng</p></center>

<h3>Không còn phần hẹn hò</h3>

<p>Cuối cùng là điểm đáng trách nhất của game sau khi thay đổi: <b>bỏ phần hẹn hò.</b></p>

<p>Date a live có nội dung chính là Itsuka Shidou sẽ hẹn hò với các Tinh Linh và khiến họ yêu cậu. Trong game, phần Daily Date hẹn hò sẽ giúp mở khóa các hình ảnh CG, tăng sức mạnh. Nếu không hẹn hò, các Tinh Linh sẽ buồn và giảm sức mạnh. Game đầu tư cả một thành phố với các Tinh Linh trong dạng chibi rất đáng yêu.</p>

<p>Thậm chí, game còn bám sát cốt truyện đến mức có phần nấu ăn. Shidou (hoặc Shiori nếu dùng skin) sẽ tạo ra các món ăn như bánh plan, bánh mì kinako để tặng các Tinh Linh. Khi tìm ra món mà các Tinh Linh thích, họ sẽ vui hơn và tăng sức mạnh.</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-date-tohka-1.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-date-tohka-2.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Phần hẹn hò trong game</p></center>

<p>Tuy nhiên, sau khi chỉnh sửa, tính năng hẹn hò này đã bị hủy bỏ. Cả hình ảnh CG người chơi đã kiếm ra trước đó cũng bị hủy luôn. Thật đáng tiếc cho một tựa game hay.</b></p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-cg-list.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Không còn hình ảnh CG phần hẹn hò.</p></center>

<p>Một người chơi còn tạo hẳn cả 1 trang web trên Github cho phần Daily Date. Nhưng trong web này chưa có Shiori, Reine, Rinne, Rio, Maria, Marina.</p>

<p>Trang web <a href="https://respectz.github.io/date-a-live/dailydate.html" rel="nofollow" target="_blank" title="Date a live Spirit Pledge">Daily Date Guide của respectz</a></p>

<p>Dù sao, DALSP được làm dựa trên series Date a live. Light Novel đã kết thúc sau 22 volume, anime sắp ra season 5. Các game thủ thất vọng với quyết định này, nhưng không có gì bất ngờ. Chúng ta hãy cùng nhìn lại những hình ảnh của game DALSP trước khi chia tay.
Game vẫn tiếp tục hoạt động tại server Trung Quốc và server Nhật Bản.</p>

<center><img src="/upload/images/game/date-a-live-spirit-pledge-bg-1.png" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-banner-1.png" width="100%" alt="Date a live Spirit Pledge"><br><br>

<p>Background và banner trên trang chủ</p>

<img src="/upload/images/game/date-a-live-spirit-pledge-loading-screen-mayuri.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<p>Màn hình loading</p>

<img src="/upload/images/game/date-a-live-spirit-pledge-tohka-1.jpg" width="100%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-tohka-2.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-tohka-3.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-rinne.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-maria.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-marina.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-mayuri.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-origami-angle.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-crimson-nightmare.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-yoshino-daily-date.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-spirit-kurumi-daily-date.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-gacha-kurumi.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-gacha-origami-spirit-2.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<img src="/upload/images/game/date-a-live-spirit-pledge-gacha-origami-spirit-1.jpg" width="90%" alt="Date a live Spirit Pledge"><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/XJP_D87R7Sg" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>
',

            'date_post'         => '2023-03-22',
            'thumbnail_post'    => 'date-a-live-spirit-pledge-server-global-will-be-officially-closed-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

// https://www.animenewsnetwork.com/interest/2023-03-21/konosuba-megumin-spinoff-gets-explosive-tie-in-with-spicy-beef-soup-brand/.196207

// https://www.animenewsnetwork.com/news/2023-03-19/tekken-8-game-trailer-highlights-character-king/.196120



        posts::create([
            'name_vi_post'    => 'Uma Musume ra mắt manga mới vào ngày 10/4',
            'url_post'        => 'uma-musume-pretty-derby-star-blossom-manga-launches-on-april-10',
            'present_vi_post' => 'Manga dựa trên game nổi tiếng.',
            'content_vi_post' => '<p>Kênh YouTube của tựa game Uma Musume đăng video giới thiệu về manga Uma Musume Pretty Derby: Star Blossom. Video tiết lộ tác giả và họa sĩ của manga, đồng thời nói rằng manga sẽ ra mắt trên tạp chí YanJan, Shonen Jump+ và Tonari no Young Jump vào ngày 10/4/2023.</p>

<p>Trang chủ <a href="https://umamusume.jp/" rel="nofollow" target="_blank" title="Uma Musume Pretty Derby: Star Blossom">Uma Musume</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Wa-NYaNu6QI" title="Hololive Uma Musume" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Video giới thiệu manga Uma Musume Pretty Derby: Star Blossom</p></center>

<p>Bên cạnh đó, Uma Musume cũng sắp ra mắt anime mang tên Uma Musume Pretty Derby: Road to the Top sẽ ra mắt trên YouTube vào ngày 16/4/2023.</p>

<center><img src="/upload/images/game/uma-musume-pretty-derby-road-to-the-top-bg.jpg" width="100%" alt="Uma Musume Pretty Derby Star Blossom"><br><br>

<p>Background trên trang chủ</p></center>

<p>Uma Musume là tựa game di động về chủ đề đua ngựa của hãng Cygames, ra mắt vào ngày 24/2/2021. Các ngựa đua được anime hóa thành các cô gái, gọi lã Mã Nương. Người chơi chọn 1 team 3 ngựa đua để đua với các đối thủ khác.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/HYrVKLBhitE" title="Uma Musume Pretty Derby Star Blossom" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/S3Uig87OgIk" title="Uma Musume Pretty Derby Star Blossom" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>PV Uma Musume</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/4SdTGYyeb1k" title="Hololive Uma Musume" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>VTuber Sakura Miko chơi Uma Musume</p></center>

<p>Uma Musume đã có bản manga năm 2021 mang tên Uma Musume: Cinderella Gray. Các seiyuu cũng có một kênh YouTube đóng vai VTuber và chơi các game khác nhau để diễn hài cho các fan.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/WavEuFUPrRU" title="Uma Musume Pretty Derby Star Blossom" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-03-29/uma-musume-pretty-derby-star-blossom-manga-launches-on-april-10/.196545" rel="nofollow" target="_blank" title="Anime News Network">Anime News Network</a></p>
',
            'date_post'         => '2023-03-29',
            'thumbnail_post'    => 'uma-musume-pretty-derby-star-blossom-manga-launches-on-april-10-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => '[Review] Operation Lovecraft: Fallen Doll - Búp Bê Sa Ngã',
            'url_post'        => 'operation-lovecraft-fallen-doll-chien-dich-lovecraft-bup-be-sa-nga',
            'present_vi_post' => 'Game 18+ đang nổi tiếng trên Steam, cho phép download bản demo miễn phí.',
            'content_vi_post' => '<p>Operation Lovecraft: Fallen Doll là trò chơi 3D thể loại 18+ được làm bằng Unreal Engine, hỗ trợ PC và VR.</p>

<p>Trang chủ <a href="https://www.projecthelius.com/index.html" rel="nofollow" target="_blank" title="Operation Lovecraft Fallen Doll">Project Helius</a></p>

<center><img src="/upload/images/game/operation-lovecraft-fallen-doll-chien-dich-lovecraft-bup-be-sa-nga-1.jpg" width="70%" alt="Operation Lovecraft Fallen Doll"><br><br></center>

<p>Nội dung tương tự như game Subverse của hãng FOW, kể về chủ đề ngoài không gian. Người chơi sẽ vào vai chỉ huy mạnh mẽ của SPES ()

cùng với các cô gái android (nửa người nửa máy) chống lại các thế lực ngoài hành tinh như quái vật, ...</p>

<p>Xem thêm: <a href="/post/subverse-chinh-phuc-khong-gian" rel="nofollow" target="_blank" title="Subverse">Subverse</a></p>

<p>Operation Lovecraft: Fallen Doll có nhiều cách chiến đấu như chiến đấu theo lượt, thu thập thẻ bài, khám phá các khu vực mới.</p>

<p>Về cảnh nhạy cảm, game dự kiến có hàng trăm cảnh nóng khác nhau. Những cảnh nóng trong Subverse gây thất vọng vì những cảnh nóng chỉ có 1 góc nhìn và không tương tác được.
Trong Operation Lovecraft, game thủ có thể tương tác với các cảnh nóng đó. Từ việc chọn góc nhìn cho đến chọn tư thế. Từ việc chọn quần áo cho đến chọn xuất tinh bên trong hay ngoài.</p>

<center><img src="/upload/images/game/operation-lovecraft-erika-anya-1.jpg" width="100%" alt="Operation Lovecraft Fallen Doll"><br><br>

<img src="/upload/images/game/operation-lovecraft-alet-great-race-1.jpg" width="100%" alt="Operation Lovecraft Fallen Doll"><br><br>

<img src="/upload/images/game/operation-lovecraft-alet-great-race-2.jpg" width="70%" alt="Operation Lovecraft Fallen Doll"><br><br>

<p></p></center>

<p>Đặc biệt hơn, sau mỗi bản cập nhật sẽ có thêm nhiều sinh vật ngoài hành tinh mới như sinh vật giống ngựa, sinh vật giống heo... Mỗi sinh vật được cập nhật trên Twitter của Project Helius.
Các game thủ rất háo hức được nhìn thấy các sinh vật này và xem các cô gái đóng cảnh nóng với chúng.</p>

<center><img src="/upload/images/game/operation-lovecraft-hippokampai.jpg" width="100%" alt="Operation Lovecraft Fallen Doll"><br><br>

<img src="/upload/images/game/operation-lovecraft-corkscrews.jpg" width="100%" alt="Operation Lovecraft Fallen Doll"><br><br>

<p>Các sinh vật mới được giới thiệu trên Twitter.</p></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-03-29/uma-musume-pretty-derby-star-blossom-manga-launches-on-april-10/.196545" rel="nofollow" target="_blank" title="Anime News Network">Anime News Network</a></p>
',
            'date_post'         => '2023-04-01',
            'thumbnail_post'    => 'operation-lovecraft-fallen-doll-chien-dich-lovecraft-bup-be-sa-nga-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Xạ thủ "bê đê" trong LMHT',
            'url_post'         => 'best-ADCs-to-play-as-ap',
            'present_vi_post'  => 'Ezreal chắc chắn có tên trong danh sách.',
            'content_vi_post'  => '<p></p>

<p><b>Điểm mạnh</b></p>
<ul>
<li>Có thể thay đổi linh hoạt giữa AD và AP
<li>Phù hợp với những ai quen chơi Pháp Sư muốn tập đánh Xạ Thủ
<li>Nếu muốn lên đồ dị, các xạ thủ "bê đê" có thể mua Đồng Hồ Cát, đảm bảo an toàn mà vẫn có sát thương.
</ul>

<p><b>Điểm yếu</b></p>
<ul>
<li>Nếu build theo hướng AD, khả năng cao sẽ bị thiếu mana.
<li>Nếu build theo hướng AP, những đòn đánh thường khá yếu.
</ul>

<p>Trong phiên bản 13.10 hậu MSI 2023, Dao Điện Statikk mới được ra mắt. Món đồ này có mọi chỉ số dành cho những tướng sử dụng cả sát thương vật lý và sát thương phép.
Vì vậy, KINGDOM NVHAI sẽ giới thiệu những vị tướng Xạ Thủ phù hợp với Dao Điện Statikk mới này.</p>

<h3>Ezreal</h3>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/SrG_hqgh5g8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Ezreal AD và AP</p></center>

<p></p>

<p></p>

<center><img src="/upload/images/game/ezreal-build-ad-ap.jpg" width="100%" alt="Ezreal Build" /></center>

<p><b>Hỗ trợ thích hợp:</b></p>

<h3>Kog&apos;maw</h3>

<center>

<p>Kog&apos;maw AD và AP</p></center>

<p></p>

<p></p>

<center><img src="/upload/images/game/kogmaw-build-ad-ap.jpg" width="100%" alt="Kogmaw Build" />

<p></p></center>




<h3>Miss Fortune</h3>

<p>Sarah Fortune, sinh ra tại Bilgewater, sống cuộc đời hải tặc và muốn trả thù Gangplank.
Cô sống như một kẻ thợ săn tiền thưởng, nổi tiếng trong các tửu quán và sòng bài, nhưng chỉ được biết đến thông qua cái tên "Miss Fortune".</p>

<p>Sức mạnh của cô được thể hiện rõ vào đầu game, và yếu dần về cuối game. Cô vừa có khả năng rỉa máu, vừa có chiêu cuối Bão Đạn trứ danh, rất mạnh trong giao tranh.
Cô có thể lên sát thương phép và sát thương vật lý, đi cùng Hỗ Trợ hay đi đường đơn rất tốt.</p>

<center><img src="/upload/images/game/miss-fortune-build-ad-ap.jpg" width="100%" alt="Miss Fortune Build" />

<p>Miss Fortune AD và AP</p></center>

<p>Điểm yếu nhất của Miss Fortune là cô không cơ động, rất dễ bị sát thủ khắc chế.</p>


<h3>Kai&apos;sa</h3>

<p>Được sinh ra là một Xạ Thủ, Kai&apos;sa lại được xây dựng để trở thành một Pháp Sư với lối lên trang bị có tốc độ bắn rất nhanh.</p>

<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/oEg_l1qiwIs" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Kai&apos;sa AD và AP</p></center>

<p></p>

<p></p>

<center><img src="/upload/images/game/kaisa-build-ad-ap.jpg" width="100%" alt="Kaisa Build" />

<p></p></center>



<h3>Corki</h3>

<p>Ông già lái máy bay Corki là Xạ Thủ, nhưng tầm bắn lại rất ngắn và tốc độ di chuyển chậm.
Khoảng thời gian thất truyền của Corki đã kéo dài khá lâu, kể từ khi Corki được buff nội tại mới. Corki giờ đây được ưu tiên sử dụng ở Đường Giữa hơn là Xạ Thủ.
Với hình ảnh và bộ kỹ năng rất cũ, phải mất một thời gian dài nữa, Riot mới xây dựng lại vị tướng này.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/7VVmvBAj1dA" title="Corki Build" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Corki AD và AP</p></center>

<p></p>

<p></p>

<center><img src="/upload/images/game/corki-build-ad-ap.jpg" width="100%" alt="Corki Build" />

<p></p></center>





<p></p>
',
            'date_post'         => '2023-04-02',
            'thumbnail_post'    => 'best-ADCs-to-play-as-ap-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Thể thức mới của MSI 2023 bất lợi cho Việt Nam?',
            'url_post'        => 'the-thuc-moi-cua-msi-2023-bat-loi-cho-viet-nam',
            'present_vi_post' => 'Thể thức mới không còn đánh B01 nữa.',
            'content_vi_post' => '<p>Ngày 10/1/2023, Riot Games đã có thông báo về địa điểm thi đấu chính thức của MSI 2023 và CKTG 2023, cùng các dự án thể thao điện tử trong năm 2023.
Mid-Season Invitational 2023 sẽ diễn ra ở London.</p>

<p>Nguồn: <a href="https://www.oneesports.vn/lmht/lmht-msi-2023-the-thuc-moi/" rel="nofollow" target="_blank" title="Thể thức mới của MSI 2023">One Esports</a></p>

<p>Nguồn: <a href="https://lolesports.com/article/msi-2023-primer/bltb6358c9e252470e2" rel="nofollow" target="_blank" title="Thể thức mới của MSI 2023">LOL Esports</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/cJT5d5Ue3ao" title="Thể thức mới MSI 2023" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer ra mắt mùa giải 2023</p>

<img src="/upload/images/game/msi-2023-format.jpg" width="100%" alt="Thể thức mới MSI 2023" /></center>

<p>Một điều đặc biệt sẽ được diễn ra trong MSI 2023 và CKTG 2023, đó là thể thức mới. Các đội sẽ không thi đấu theo vòng bảng đấu vòng tròn nữa. Thay vào đó, các trận đấu sẽ là B03 loại trực tiếp.</p>

<center><img src="/upload/images/game/msi-2023-playins.jpg" width="100%" alt="Thể thức mới MSI 2023" />

<p>Vòng Khởi Động</p>

<img src="/upload/images/game/msi-2023-playoffs.jpg" width="100%" alt="Thể thức mới MSI 2023" />

<p>Vòng Play Off</p></center>

<h3>Thể thức MSI 2023 bất lợi cho các đội yếu?</h3>

<p>Nguồn: <a href="https://lolesports.com/article/state-of-the-game-lol-esports-in-2023/blt5d3bca31d1b39e0c" rel="nofollow" target="_blank" title="Thể thức mới của MSI 2023">LOL Esports</a></p>

<p>Mọi năm, thể thức MSI sẽ bao gồm 2 vòng: vòng Wildcard và vòng chung kết. Vòng Wildcard gồm các khu vực yếu như VCS của Việt Nam, CIS của Cộng đồng các quốc gia độc lập (Commonwealth of Independent States) hay LJL của Nhật Bản. Họ sẽ đấu với nhau để chọn ra 1 khu vực duy nhất được tiến vào vòng chung kết.
Tại đây, khu vực mạnh nhất Wildcard sẽ đối đầu 5 khu vực khác là LCK của Hàn Quốc, LPL của Trung Quốc, LCL của Châu Âu, NA của Bắc Mỹ và LMS của Đài Loan.
Tuy nhiên, vì nhiều lý do như LMS của Đài Loan đã sát nhập với LST của Đông Nam Á. Sau đó 2 khu vưc này cũng đã gom lại với các khu vực khác, tạo thành khu vực PCS (Pacific Championship Series), dẫn đến số đội ít đi.
Vì vậy, việc thay đổi thể thức là điều bắt buộc.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/L2DieiPZRr0" title="Thể thức mới MSI 2023" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Vega Squadron vs Phong Vũ Buffalo chung kết vòng Wildcard 2019</p></center>

<p>Xem thêm: <a href="/post/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020" rel="nofollow" target="_blank" title="Thể thức mới MSI 2023">LMS sát nhập với GPL thành giải đấu mới từ năm 2020</a></p>

<p>Với thể thức mới, VCS sẽ đấu với 1 đội trong khu vực mạnh. Nếu thua, họ sẽ phải xuống nhánh thua và gặp đội thua ở trận còn lại. Nghĩa là trường hợp xấu nhất, VCS sẽ chỉ được đấu 2 trận B03 với 2 đội, 1 mạnh 1 yếu, tổng cộng 6 game đấu. Nếu thua hết cả 2 loạt B03 sẽ bị loại.</p>

<p>Trong thể thức cũ, tất cả những đội khu vực Wildcard sẽ đấu với nhau. Đội mạnh nhất Wildcard sẽ gặp các đội mạnh.
Ở thế thức mới, đội Wildcard phải gặp đội hạt giống số 2 của các khu vực LPL - LEC - LCS. Khả năng chiến thắng trong loạt trận B03 rất khó với các đội Wildcard.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/CwyjyxfwLoM" title="Thể thức mới MSI 2023" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/Ro5A1v3YIDg" title="Thể thức mới MSI 2023" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>BLV Hoàng Luân phân tích thể thức mới của MSI 2023</p></center>

<p>Thêm một vấn đề nữa dành cho các đội yếu, cụ thể là GAM. Đó là họ sẽ khó có thể thắng dựa vào bài dị. VCS từ khi ra thế giới đến nay, họ chưa bao giờ thắng các khu vực lớn trong loạt trận B03 và B05. Trận BO5 cảm xúc nhất là trận Gigabyte Marine với Team Solomid năm 2017.
Sau 2 ván thắng, GAM tràn trề hy vọng được vào thẳng vòng chung kết. Nhưng TSM đã lật lại bằng 3 ván thắng, kết thúc loạt BO5 với tỷ số 3-2.</p>

<p>Hay như trận B05 giữa Damwon Gaming vs Lowkey. LK dù cố gắng có được 1 trận thắng trước đại diện Hàn Quốc, vẫn bị loại với tỷ số 3-1.</p>

<p>Vì vậy, việc bắt các đội yếu đánh B03 với các đội mạnh, gần như không có khả năng thắng dành cho các đội yếu.</p>

<h3>VCS vẫn có 2 đội tham gia CKTG 2023</h3>

<p>Dù kết quả MSI 2023 có như thế nào, VCS và PCS vẫn sẽ có 2 đại diện tham gia CKTG 2023 diễn ra vào cuối năm. Vì vậy, GAM hoàn toàn thoải mái khi thi đấu tại MSI 2023 mà không sợ ảnh hưởng đến kết quả CKTG 2023.
Kết quả CKTG 2023 sẽ quyết định số đội của VCS tham dự năm sau.</p>

<p>Tuy nhiên, CKTG 2023 VCS sẽ bắt đầu từ vòng Khởi Động. Nghĩa là VCS sẽ phải quay lại thi đấu với các đội Wildcard. Điều này vừa là bất lợi, vừa có lợi cho VCS. VCS sẽ phải thi đấu nhiều hơn, các tuyển thủ được rèn luyện nhiều hơn nhưng chiến thuật cũng bị lộ nhiều hơn.</p>
',
            'date_post'         => '2023-04-10',
            'thumbnail_post'    => 'the-thuc-moi-cua-msi-2023-bat-loi-cho-viet-nam-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'LMHT Việt Nam sắp giống như Đài Loan?',
            'url_post'        => 'lmht-viet-nam-sap-giong-nhu-dai-loan',
            'present_vi_post' => 'GAM Esports đang đi theo vết xe đổ của Flash Wolves',
            'content_vi_post' => '<p>MSI 2023 được khởi tranh từ ngày 2/5/2023. Theo thể thức thi đấu mới, các đội sẽ được chia thành nhánh thắng và nhánh thua.</p>

<p>Đại diện của Việt Nam, GAM Esports sau khi thua đại diện của LCS Golden Guardians vào ngày 3/5 với tỉ số 2-0 đã phải xuống nhánh thua.
Tối ngày 5/5, GAM gặp đại diện của Mỹ Latin LLA, Movistar R7. Đội thắng sẽ gặp Golden Guardians vào ngày 6/5 do Golden Guardians đã thua đại diện của Trung Quốc LPL là Bilibili Gaming.</p>

<p>Xem lịch thi đấu tại: <a href="https://thethao247.vn/400-lich-thi-dau-msi-2023-lmht-moi-nhat-d254970.html" rel="nofollow" target="_blank" title="GAM Esports VCS and LMS">Thể Thao 24/7</a></p>

<center><img src="/upload/images/game/msi-2023-gam-vs-gg-1.jpg" width="100%" alt="GAM Esports VCS and LMS" /><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/iFOZyot7Jf8" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>GAM vs GG</p>

<img src="/upload/images/game/msi-2023-gam-vs-r7-1.jpg" width="100%" alt="GAM Esports VCS and LMS" /><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/0IBsjBW45Ao" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>GAM vs R7</p></center>

<p>Kết quả: GAM Esports đã thua Movistar R7 với tỉ số 1-2. Đáng nói hơn, 2 trận thua thật sự rất chóng vánh và khó hiểu. Như vậy, GAM Esports chính thức bị loại khỏi MSI 2023 với 4 trận thua và 1 trận thắng, thành tích tệ nhất của VCS trong những năm gần đây.
Thành tích này có thể sánh ngang với chuỗi thua 0-8 của Saigon Joker năm 2016 khiến đội này phải giải tán.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/5JBV1l_E928" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Tổng hợp 3 trận đấu GAM Esports vs Movistar R7</p>

<img src="/upload/images/game/khan-gia-khong-dong-gop-gi-cho-cac-tuyen-thu-nen-khong-duoc-phe-binh-nham-to-IWCQ.jpg" width="100%" alt="GAM Esports VCS and LMS" />

<p>Năm 2016, giải đấu IWCQ là giải đấu tệ hại nhất của LMHT Việt Nam<br>
với kết quả 0-8 của Saigon Joker</p></center>

<h3>VCS sắp giống như Đài Loan</h3>

<p>Khu vực Đài Loan LMS đã chính thức hợp nhất với khu vực Đông Nam Á GPL vào năm 2020 vì 2 khu vực này quá ít khán giả. Ở LMS, đội vô địch trong nhiều mùa giải liên tiếp luôn là Flash Wolves.
Ở Thái Lan, Bangkok Titans với đầu tàu là G4 luôn đứng đầu. Tại VCS, trong những mùa giải gần đây, GAM Esports trở thành độc cô cầu bại.
Và khi ra các giải đấu lớn như MSI hay World Championship, các đội VCS và LMS thường xuyên trở thành đội lót đường và gạt giò các đội lớn khác.
Trong Chung Kết Thế Giới 2022, GAM Esports đã có một trận thắng duy nhất, cũng là trận gạt giò Top Esports khiến đại diện Trung Quốc bất ngờ bị loại khỏi vòng bảng, dù trước đó họ được đánh giá là ứng cử viên vô địch.
Đây cũng là lần đầu tiên VCS thắng LPL.</p>

<p>Xem thêm: <a href="/post/lms-sat-nhap-voi-gpl-thanh-giai-dau-moi-tu-nam-2020" rel="nofollow" target="_blank" title="GAM Esports VCS and LMS">LMS sát nhập với GPL thành giải đấu mới từ năm 2020</a></p>

<p><b>Cả VCS đang đi xuống</b></p>

<p>Theo Tinikun, người Việt Nam rất dễ thỏa mãn. Các đội tuyển, tuyển thủ VCS lười hơn so với trước. GAM 2017 rất chăm chỉ, train liên tục đến sáng, train với Nhật, tìm team để đánh. Kiaya hiện tại đang là top laner tốt nhất VCS. Tinikun nói rằng ở VCS không tìm ra ai chăm chỉ bằng 1/3 Kiaya.</p>

<p>Theo Sena, "mặt bằng của VCS hiện tại yếu, chứ không phải GAM yếu".</p>

<p><b>Kinh tế của các đội đang rất yếu</b></p>

<p>Theo BLV Hoàng Luân, có rất nhiều đội đang vận hành thiếu kinh phí, "cố gắng những tháng cuối cùng vì đang hết tiền". Mặt tích cực của việc này "là reset lại", tức là quay trở lại thời chơi ở phòng net, không có gaming house. VCS vẫn tiếp tục, các tuyển thủ vẫn chơi game, chỉ đơn giản là các đội tuyển sẽ quay lại thời khó khăn như cách đây 5 năm.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/wsub6J05WPc" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/EALVF10pLRU" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/QQ5aYsKhiNI" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/1xfPcrWPU8I" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Tổng hợp các vấn đề của VCS</p></center>

<p><b>Lứa già đang đi xuống, giới trẻ thiếu môi trường, các đội thiếu sự cọ xát</b></p>

<p>Các tuyển thủ lớn tuổi cũng đang có biểu hiện đi xuống. Trong 5 trận đấu của GAM tại MSI 2023, người ổn định nhất là người đi Đường Rrên Kiaya. Hỗ Trợ Zin chơi tròn vai. 2 vị trí Sty1e và Kati mắc quá nhiều lỗi.
Và người đáng thất vọng nhất lại là đội trưởng, niềm hy vọng của đội, Levi. Thống kê số rồng, Baron mà Levi có được trong 5 trận đấu chứng tỏ anh đang chơi dưới kỳ vọng hoàn toàn.
Liệu có phải nguyên nhân do tuổi tác của anh.</p>

<center><img src="/upload/images/game/levi-msi-2023-analytics.jpg" width="100%" alt="GAM Esports VCS and LMS Levi" />

<p>Thống kê số rồng, Baron và lượng tướng của Levi trong 5 trận.</p></center>

<p>Ngày trước, các lứa trẻ có rất nhiều giải đấu như giải đấu phòng net, giải đấu Teemo Cup... Những giải đấu đó là nguồn động lực để các đội luyện tập với nhau hằng ngày. Giờ đây, với số lượng người chơi giảm, các giải phòng net cũng ít dần, một phần do đại dịch COVID-19, những lứa trẻ ít có cơ hội tham gia cọ xát.</p>

<p>Chưa kể, khi VCS tách ra thành một khu vực riêng, các tuyển thủ càng ít có cơ hội cọ xát ở cấp độ quốc tế. Ngày trước, VCS phải cạnh tranh với các đội Đông Nam Á GPL, hay tập luyện với Đài Loan LMS. Giờ đây, họ lại phải tự tập trong đánh xếp hạng.
Nhưng kể cả trong xếp hạng, Riot Hàn Quốc đã lấy lại tài khoản của các tuyển thủ VCS, khiến các tuyển thủ VCS không tham gia rank Hàn được. Vì vậy, đang có vấn đề rất lớn về việc cọ xát giữa các đội và các khu vực.</p>

<p>VCS vẫn còn 2 suất dự CKTG 2023 và Riot đã xác định cho VCS đánh với Wild Card lại như trước. Tuy nhiên, với những gì mà GAM Esports thể hiện thì khán giả khó có thể hy vọng được gì.
Theo BLV Hoàng Luân, cả team GAM sai lầm mọi mặt, từ cấm chọn tướng, đi đường cho đến giao tranh, tính toán. Tinikun, BLV Hoàng Luân và cả HLV Ren đều phải kêu gọi VCS có thành tích tốt hơn. Nếu không, các nhà tài trợ và khán giả sẽ rời bỏ giải đấu.</p>
',
            'date_post'         => '2023-05-06',
            'thumbnail_post'    => 'lmht-viet-nam-sap-giong-nhu-dai-loan-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Số phận hẩm hiu của các Xạ Thủ Tay Ngắn trong Liên Minh Huyền Thoại',
            'url_post'        => 'unlucky-fate-of-melee-marksman-in-lol',
            'present_vi_post' => 'Thể thức mới không còn đánh B01 nữa.',
            'content_vi_post' => '<p>Riot luôn muốn đưa ra những ý tưởng sáng tạo và mới lạ. Một trong số những ý tưởng được Riot đưa ra từ những ngày đầu của game đó là Xạ Thủ Tay Ngắn (Melee marksman).</p>

<h3>Urgot cũ</h3>

<p>Urgot lúc đầu được xây dựng là một xạ thủ tanker ở đường dưới. Bộ đôi Urgot ADC và Taric cực kỳ bá đạo mùa 3 với khả năng bắt đối thủ phải cận chiến.
Nhưng sau những đợt nerf của Riot, Urgot đã trải qua 3 năm không có ai chơi, dù chỉ là đánh thường. Dù Riot có buff nhẹ cho Urgot nhưng chẳng cải thiện nhiều.
Người chơi cảm thấy chiêu cuối dịch chuyển vị trí với đối thủ là một chiêu cuối rất khó sử dụng.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/1nNYcujNV00" title="melee marksman lol" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Urgot cũ</p></center>

<p>Đến năm 2017, Riot quyết định lột xác Urgot trở thành pháo đài di động ở đường trên như hiện nay. Với chiêu cuối kết liễu đối thủ thấp máu, Urgot chiếm trọn vị trí đường trên cùng với Aatrox được làm lại. Cặp đối đầu giữa Urgot và Aatrox xuất hiện suốt năm 2019.</p>

<h3>Mordekaiser cũ</h3>

<p>Cũng là vị tướng đã quá cũ. Mordekaiser ban đầu là một đấu sĩ pháp sư ở đường trên với chiêu cuối độc đáo: bắt hồn một đối thủ đã chết.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/9eFkZgpnWlY" title="melee marksman lol" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>H2K VS BKT Chung Kết Thế Giới 2015</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/qbpbOT6ADco" title="melee marksman lol" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Bắt rồng làm thú cưng (Dragon Pet)</p></center>

<p>Sau này, Mordekaiser được đưa xuống đường dưới với vị trí xạ thủ tay ngắn, có khả năng buff lá chắn cho đồng đội và một chiêu cuối khác cũng độc đáo không kém: bắt hồn rồng.</p>

<p>Tuy nhiên, những chỉnh sửa đó là chưa đủ để đưa Mordekaiser quay trở lại. Hình ảnh xấu, tốc độ di chuyển chậm chạp và chiêu bắt hồn không có quá nhiều ý nghĩa trong giao tranh. Chỉ cần Mordekaiser chết, linh hồn cũng biến mất. Vì vậy, Mordekaiser được làm lại toàn diện vào năm 2019 và mạnh mẽ như bây giờ.</p>

<h3>Nilah</h3>

<p>Không bỏ cuộc với ý tưởng Xạ Thủ Tay Ngắn, Riot quyết tâm tạo thêm một vị tướng Xạ Thủ mới mang tên Nilah. Ra mắt vào năm 2022, Nilah là một vị tướng có thiên hướng giống Mordekaiser cũ và Yasuo, cộng thêm sự thành công của Samira.</p>

<ul>
<li>Nội tại Niềm Vui Bất Tận: tăng kinh nghiệm cho bản thân và đồng minh khi kết liễu lính. (giống Mordekaiser cũ)
<li>Q Thủy Kiếm Vô Dạng: quất roi xuống đất, tăng xuyên giáp, tầm đánh (giống Mordekaiser Q đập chùy)
<li>W Thủy Giáp Bảo Hộ: tăng tốc độ di chuyển và tránh né đòn đánh thường và giảm kháng phép
<li>E Lướt trên Mặt Nước: lướt 2 lần vào đối thủ hoặc đồng minh (giống Yasuo)
<li>R Vũ Điệu Hân Hoan: xoay chiếc roi gây sát thương xung quanh và kéo đối thủ lại về phía mình. (giống Oriana)
</ul>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/tzXst1y5RR8" title="melee marksman lol" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p></p></center>

<p>Từ khi ra mắt video Tiêu Điểm Tướng vào ngày 13/7/2022, đã gần tròn 1 năm, Nilah có tỷ lệ pick cực thấp, chỉ 1.7% (theo op.gg và mobalytics). Lý do cho điều này có lẽ là vì Nilah chưa hợp meta. Nilah ở vị trí xạ thủ cần hỗ trợ có khả năng hồi máu mạnh như Lulu, Soraka. Các vị tướng này lại trở nên thất thế so với những vị tướng hỗ trợ tank.</p>

<p>Nguồn: <a href="https://www.op.gg/champions/nilah/adc/build?hl=en_US" rel="nofollow" target="_blank" title="melee marksman lol">op.gg</a></p>

<h3>Nilah sẽ là hot pick hậu MSI 2023?</h3>

<p>Cơ hội của Nilah được chú ý hơn đang tới. Sau MSI 2023, Dao Điện Statikk mới và các trang bị hỗ trợ hồi máu chính là tin tốt dành cho Nilah.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/NjplpavRcv8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Sơ Lược Bản Cập Nhật 13.10 | Điểm Tin Liên Minh</p></center>

<p>Cụ thể, Dao Điện Statikk là trang bị bắt buộc, cung cấp mọi thứ Nilah cần: chí mạng, tốc độ đánh và sát thương diện rộng. 3 trang bị còn lại đều là trang bị dành cho hỗ trợ buff.
Bản thân Nilah cũng không chỉ đi đường dưới. Cô ta có thể đi đường trên với khả năng trụ đường tốt, thậm chí có thể lên đồ nửa tank nửa dam giống như các đấu sĩ khác.</p>

<center><img src="/upload/images/game/nilah-build-2023.jpg" width="100%" alt="Nilah build guide" /><br><br>

<p>Cách lên đồ Nilah xạ thủ và đấu sĩ.</p></center>

<ul>
<li>Core: Giày Cuồng Nộ, Nỏ Tử Thủ và Statikk.
<li>Hút Máu: Rìu Mãng Xã và Huyết Kiếm
<li>Chí Mạng: Vô Cực, Huyết Kiếm, Vũ Điệu Tử Thần
<li>Chống chịu: Giáp Thiên Thần và Chùy Gai
</ul>

<p>Hy vọng Nilah sẽ xuất hiện nhiều hơn sau MSI 2023. Nếu không, có lẽ Riot sẽ lại tiếp tục cho ra đời một Xạ Thủ Tay Ngắn khác.</p>
',
            'date_post'         => '2023-05-19',
            'thumbnail_post'    => 'unlucky-fate-of-melee-marksman-in-lol-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Granblue Fantasy: Relink giới thiệu nhân vật, ra mắt vào mùa Đông 2023',
            'url_post'         => 'granblue-fantasy-relink-game-trailer-reveals-more-characters-winter-2023-launch',
            'present_vi_post'  => 'Game dành cho PlayStation 5, PlayStation 4 và PC.',
            'content_vi_post'  => '<p>Cygames đã phát trực tuyến trailer game Granblue Fantasy: Relink trong sự kiện PlayStation Showcase 2023 được phát trực tiếp vào ngày 24/5/2023.
Đoạn trailer tiết lộ ngày phát hành vào mùa Đông năm 2023, cũng như các nhân vật mới là Zeta và Vaseraga. Trailer có cả tiếng Anh và tiếng Nhật.</p>

<p>Trang chủ: <a href="https://relink.granbluefantasy.jp/en/" rel="nofollow" target="_blank" title="Granblue Fantasy Relink">Granblue Fantasy Relink</a></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/CSLN1rqXs1k" title="Granblue Fantasy Relink" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/XzlwPtoW9Ys" title="Granblue Fantasy Relink" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer tiếng Anh và tiếng Nhật</p></center>

<p>Game sẽ ra mắt trên Steam, dành cho hệ máy PlayStation 5, PlayStation 4 và PC. Game được lên kế hoạch sẽ bản địa hóa tiếng Anh, Pháp, Ý, Đức và Tây Ban Nha.</p>

<p>Game đã trải qua một số lần bị trì hoãn, với lần trì hoãn gần đây nhất là vào tháng 6/2022 và thông báo phát hành vào năm 2023. Lý do cho đợt trì hoãn là vì COVID-19.
Cygames đã thông báo vào tháng 2/2019 rằng họ sẽ tiếp quản việc phát triển trò chơi từ Platinum Games.</p>

<center><img src="/upload/images/game/granblue-fantasy-relink-bg.png" width="100%" alt="Granblue Fantasy Relink" />

<p>Background trang chủ</p></center>

<p>Cygames đã ra mắt Granblue Fantasy trên nền tảng smartphone vào năm 2014.</p>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-05-25/granblue-fantasy-relink-game-trailer-reveals-more-characters-winter-2023-launch/.198415" rel="nofollow" target="_blank" title="Granblue Fantasy Relink">Anime News Network</a></p>
',
            'date_post'         => '2023-05-25',
            'thumbnail_post'    => 'granblue-fantasy-relink-game-trailer-reveals-more-characters-winter-2023-launch-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Silent Hill: Ascension ra mắt trailer',
            'url_post'         => 'silent-hill-ascension-release-trailer',
            'present_vi_post'  => 'Game sẽ được ra mắt trong năm nay',
            'content_vi_post'  => '<p>Genvid Entertainment đã giới thiệu trailer Silent Hill: Ascension vào ngày 30/5/2023. Trailer giới thiệu hình ảnh của dự án mới.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/TP6R0bC4LYI" title="Silent Hill Ascension" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer Silent Hill: Ascension</p></center>

<p>Jacob Navok, Giám đốc điều hành của Genvid Entertainment, mô tả trò chơi tập trung vào chấn thương giữa các thế hệ của các nhân vật từ khắp nơi trên thế giới.
Khán giả có thể dẫn dắt câu chuyện bằng cách hoàn thành các nhiệm vụ và câu đố ảnh hưởng đến trạng thái tinh thần của nhân vật.</p>

<p>Silent Hill là tựa game thương hiệu của Konami, được ra mắt vào năm 1999.
Konami cũng đã thông báo vào tháng 10/2022 họ sẽ phát hành phiên bản làm lại của trò chơi Silent Hill 2,
cũng như các game mới Silent Hill: Townfall và Silent Hill f. Konami cũng đang sản xuất bộ phim live-action Return to Silent Hill mới.
Dự án sẽ ra mắt trong năm nay.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/5D1wFxMr6Sk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer Silent Hill f</p></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-05-31/silent-hill-ascension-streaming-experience-previewed-in-trailer/.198632" target="_blank" title="Silent Hill: Ascension">Anime News Network</a></p>
',
            'date_post'         => '2023-05-31',
            'thumbnail_post'    => 'silent-hill-ascension-release-trailer-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Drama VCS và LCS, khủng hoảng lứa trẻ kế thừa',
            'url_post'         => 'drama-vcs-lcs-there-is-no-young-players',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<center>

<p></p></center>

<h3>Drama VCS SE</h3>

<p>Sau khi MSI 2023 kết thúc, một drama bom tấn đã nổ ra với đội tuyển SE.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/37lpSoR3AKQ" title="VCS LCS drama" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Tóm tắt drama SE chấn động VCS</p></center>

<p></p>

<p></p>

<p></p>

<center><img src="/upload/images/game/granblue-fantasy-relink-bg.png" width="100%" alt="VCS LCS drama" />

<p></p></center>

<p></p>

<p>Về mặt tiêu cực, đội tuyển SE có thể sẽ khó lọt vào top 4. Nhưng mặt tích cực thì đây là dịp để các game thủ trẻ có cơ hội tỏa sáng.
Không còn Xạ Thủ Slayder nổi tiếng gồng gánh, họ sẽ làm thế nào để lọt vào top 4? Hãy cùng xem các tuyển thủ trẻ thể hiện.</p>

<p>Nguồn: <a href="" rel="nofollow" target="_blank" title="VCS LCS drama"></a></p>

<p></p>

<p></p>



<h3>Drama LCS đình công</h3>

<p>Drama LCS có thể coi như một quả bong bóng vỡ từ các nhà đầu tư về việc chi tiền quá mạnh tay.</p>

<p>Khoảng 5 năm trước, Riot Games yêu cầu mỗi đội phải thành lập đội hạng nhì. Mục đích là để đào tạo tài năng trẻ và là để marketing cho tựa game, bán skin.
Tuy nhiên, các nhà đầu tư lại cảm thấy chi phí vận hành các đội hạng nhì quá tốn kém. Các đội muốn bỏ đội hạng nhì, tập trung vào đội hạng nhất. Riot Games đồng ý.
Và một cuộc thanh lý hợp đồng quy mô lớn diễn ra: <b>7 trên 10 đội tuyển thanh lý tất cả hợp đồng của đội hạng nhì (ngoại trừ EG, FLY và TL), khiến hàng chục game thủ, huấn luyện viên mất việc.</b></p>

<p>Điều này khiến các game thủ, huấn luyện viên bất bình. Các game thủ giải hạng nhất và giải hạng nhì quyết định tổ chức đình công, không tham gia LCS sắp khai mạc.
Riot Games cũng không nhượng bộ. Họ quyết định giảm bậc hạng tối thiểu để được làm tuyển thủ chuyên nghiệp, từ Kim Cương I xuống các mức rank Bạch Kim, thậm chí rank Vàng cũng được tham gia giải đấu hạng nhất và hạng nhì LCS.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/NeLCjXJT1us" title="VCS LCS drama" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/Onu0w85acK8" title="VCS LCS drama" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/kGMlP8IcYEo" title="VCS LCS drama" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Drama RIOT GAMES & LCS</p>

<blockquote class="twitter-tweet"><p lang="zxx" dir="ltr"><a href="https://t.co/dr4aHrpv8T">pic.twitter.com/dr4aHrpv8T</a></p>&mdash; LCS Players Association (@NALCSPA) <a href="https://twitter.com/NALCSPA/status/1663276405063286784?ref_src=twsrc%5Etfw">May 29, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Trước đó, Riot và các đội tuyển đã có các thỏa thuận với nhau. Các đội tuyển có thể mua slot tham dự giải hạng nhất. Họ sẽ đánh mà không sợ bị xuống hạng.
Riot yêu cầu các đội phải có đội hạng nhì, mục đích vừa để marketing cho game, bán skin, vừa để đào tạo lứa trẻ. Riot sẽ cung cấp cho mỗi đội một số tiền để họ chăm sóc cho đội hạng nhì.
Nhưng các đội tuyển, hay nói chính xác là các nhà đầu tư sử dụng tiền vào 2 mục đích:</p>

<ul>
<li>Sử dụng tiền để đào tạo đội hạng nhì.
<li>Sử dụng tiền để thuê các tuyển thủ Hàn, bao gồm các tuyển thủ kém chất lượng lẫn các tuyển thủ hết thời.
</ul>

<p>Điều này khiến Riot cảm thấy số tiền họ cung cấp không được sử dụng đúng mục đích. Họ quyết định cắt giảm tiền. Đồng nghĩa với việc các đội không thể duy trì đội hạng nhì được nữa. Đó là nguyên nhân sâu xa dẫn đến drama đình công này.</p>

<center><img src="/upload/images/game/drama-lcs-pa-1.jpg" width="100%" alt="VCS LCS drama" />

<img src="/upload/images/game/drama-lcs-pa-2.jpg" width="100%" alt="VCS LCS drama" />

<img src="/upload/images/game/drama-lcs-pa-3.jpg" width="100%" alt="VCS LCS drama" />

<p>Yêu cầu của LCS PA</p></center>
<p>Hiệp hội tuyển thủ LCS (LCSPA) ngay lập tức phản đổi. Họ kêu gọi mọi người không tham gia giải đấu để yêu cầu Riot nhượng bộ. LCS phải chấp nhận bộ bằng cách lùi thời gian tổ chức giải đấu 2 tuần với mục đích tìm ra giải pháp.</p>

<p>Một số nguồn tin khác:</p>

<p>Nguồn: <a href="https://www.gosugamers.net/lol/news/68255-all-you-need-to-know-about-the-drama-between-the-lcspa-and-riot-games" rel="nofollow" target="_blank" title="VCS LCS drama">Gosu Gamers</a></p>

<p>Nguồn: <a href="https://earlygame.com/lol/lol-riot-is-trying-to-force-the-lcs-summer-split" rel="nofollow" target="_blank" title="VCS LCS drama">Early Game</a></p>

<p>Nguồn: <a href="https://earlygame.com/lol/worlds-2023-without-lcs-teams-is-a-possibility" rel="nofollow" target="_blank" title="VCS LCS drama">Early Game</a></p>

<p>Mô hình vận hành của LCS Bắc Mỹ không khác gì bóng rổ nhà nghề NBA. Các đội đá với nhau mà không sợ bị xuống hạng. Mục đích không phải vì yếu tố thể thao hay cạnh tranh, mà là vì yếu tố marketing.
Mô hình này gọi là mô hình franchise. Trong bóng đá, thế giới cũng từng xôn xao về giải đấu European Super League của ông chủ Real Madrid, Florentino Pérez.
Ông Pérez muốn tổ chức một giải đấu không có tính cạnh tranh, các đội mạnh luôn được đối đầu với các đội mạnh. Điều đó đã vấp phải làn sóng chỉ trích đến từ khắp thế giới.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Wv5tMTgMtQ8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/c7VtHDUz5HY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Giải đấu European Super League và đô vật WWE</p></center>

<h3>Khủng hoảng lứa trẻ kế thừa</h3>

<p>Hiện tại, cách vận hành của giải đấu LCS Bắc Mỹ không khác gì sân sau của LCK Hàn Quốc.</p>

<ul>
<li>Giải hạng nhất: các đội tuyển các game thủ Hàn không cạnh tranh được ở LCK.
<li>Giải hạng nhì: là nơi các tuyển thủ LCS không cạnh tranh được ở giải hạng nhất.
<li>Giải hạng ba: là nơi các tuyển thủ trẻ tranh tài.
</ul>

<p>Một số ví dụ về các đội LCS có nhiều người Hàn:</p>

<p><a href="https://lol.fandom.com/wiki/Golden_Guardians" rel="nofollow" target="_blank" title="VCS LCS drama">đội tuyển Golden Guardians</a>vừa đánh bại GAM tại MSI 2023 vừa rồi.
Trong đội hình có 3 game thủ Hàn Quốc là: River Đi Rừng, Gori Đường Giữa và huhi Hỗ Trợ.</p>

<p><a href="https://lol.fandom.com/wiki/Cloud9" rel="nofollow" target="_blank" title="VCS LCS drama">đội tuyển Cloud 9</a> gồng gánh LCS
có 2 game thủ Hàn Quốc là: EMENES Đường Giữa và Berserker Xạ Thủ.</p>

<p><a href="https://lol.fandom.com/wiki/Team_Liquid" rel="nofollow" target="_blank" title="VCS LCS drama">đội tuyển Team Liquid</a>
có 2 game thủ Hàn Quốc là: Summit Đường Trên, Pyosik Đi Rừng và CoreJJ Hỗ Trợ.</p>

<p><a href="https://lol.fandom.com/wiki/Team_Liquid" rel="nofollow" target="_blank" title="VCS LCS drama">đội tuyển FlyQuest</a>
có đến 4 game thủ Hàn Quốc là: Impact Đường Trên, VicLa Đường Giữa, Prince Xạ Thủ và Winsome Hỗ Trợ. Mặc dù Winsome quốc tịch Mỹ nhưng anh có gốc Hàn Quốc.</p>

<p>Chỉ có một số ít đội không có người Hàn như Immortals, Evil Geniuses. Điều này hoàn toàn không có lợi cho sự phát triển của lứa trẻ kế cận.</p>

<p>Với VCS, mặc dù 100% đều là tuyển thủ Việt. Nhưng trong buổi talkshow, cả Optimus và thầy giáo Ba cũng đang nói lên một vấn đề: VCS đang ít sân chơi cho các lứa trẻ, cũng như ít cơ hội cọ xát với các đối thủ ngoài VCS.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/wsub6J05WPc" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/EALVF10pLRU" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/QQ5aYsKhiNI" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/1xfPcrWPU8I" title="GAM Esports VCS and LMS" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Tổng hợp các vấn đề của VCS</p></center>

<p>BLV Hoàng Luân cũng nói về khoản tiền đầu tư của VCS. Sau đại dịch COVID-19, có lẽ các nhà đầu tư kinh doanh thất bại. Họ không thể cố gắng được nữa nên có khả năng, sẽ có một số đội phải thay đổi nhân sự lớn. Giờ chúng ta đã thấy, SE của VCS hay LCS là kết quả của vấn đề kinh phí.</p>

<h3>Mặt tích cực của drama</h3>

<p>Vì vậy, mặt tích cực của drama VCS SE là cơ hội để các game thủ trẻ có tỏa sáng.
Không thể trông chờ Xạ Thủ Slayder nổi tiếng gồng gánh, họ sẽ làm thế nào để lọt vào top 4? Hãy cùng xem các tuyển thủ trẻ thể hiện.</p>

<p>Và mặt tích cực của drama LCS đình công là việc các khu vực khác sẽ có thêm slot tham dự CKTG. Cộng đồng bàn tán với nhau liệu khu vực nào sẽ được thêm slot. Có 2 giả thuyết được đưa ra:</p>

<p><b>Các khu vực lớn như LCK, LPL, EU sẽ có thêm slot.</b></p>

<p>Khả năng này, về thành tích đối đầu thì có vẻ đúng. Nhưng mục đích của Riot Games hiện tại là muốn marketing game nhiều hơn nữa. Riot Games không thể để giải đấu chỉ toàn người Hàn và người Trung Quốc được.
Họ cần giúp các khu vực khác được thi đấu nhiều hơn, có nhiều thay đổi bất ngờ hơn. Thậm chí là các trận thắng kịch tính như GAM thắng TES tại CKTG 2022 vừa rồi.
Vì vậy, giả thuyết này không tốt về mặt marketing.</p>

<p><b>Các khu vực nhỏ hơn VCS, PCS sẽ có thêm slot.</b></p>

<p></p>
',
            'date_post'         => '2023-06-01',
            'thumbnail_post'    => 'drama-vcs-lcs-there-is-no-young-players-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Cách vận hành của các đội tuyển eSport',
            'url_post'         => 'how-esports-teams-work-and-make-money',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<p>Nguồn: <a href="https://www.esports.net/news/how-do-esports-teams-make-money/" target="_blank" title="how esports teams work and make money">eSport.net</a></p>

<h3>eSport team là một hình thức đầu cơ</h3>

<p>Có lẽ các bạn đã từng nghe qua đầu cơ bất động sản (BĐS) tại Việt Nam. Một mảnh đất được người này mua, sau đó bán cho người khác với giá cao hơn.
Người mua sau lại tiếp tục bán cho người khác. Cứ như vậy cho đến khi không còn ai có thể mua được mức giá quá cao nữa thì thị trường BĐS sẽ phát nổ.
Những người mua sau không còn tiền trả nợ ngân hàng sẽ rơi vào tình trạng vỡ nợ.</p>

<p>eSport hiện tại cũng như vậy. Một đội tuyển eSport được lập ra là vì 2 mục tiêu chính: marketing cho trò chơi và marketing cho chủ đầu tư.</p>

<p></p>

<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Onu0w85acK8" title="how esports teams work and make money" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/7CA3Ksp6oHU" title="how esports teams work and make money" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/wcTZJTe9Lk4" title="how esports teams work and make money" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Tinikun nói về cách vận hành của các đội tuyển eSport.</p></center>

<p><b></b></p>

<p></p>




<h3>Những cách duy trì eSport trên thế giới</h3>

<p><b>LCS Bắc Mỹ: mô hình không xuống hạng</b></p>

<p>Nguồn: <a href="https://www.esportsguide.com/news/understanding-the-industry-what-is-esports-franchising" target="_blank" title="how esports teams work and make money">eSports Guide</a></p>
<p>Nguồn: <a href="https://webthethao.vn/lien-minh-huyen-thoai/nhuong-quyen-thuong-hieu-da-lam-thay-doi-nen-esports-nhu-the-nao-clUbALRVR.htm" target="_blank" title="how esports teams work and make money">Webthethao</a></p>


https://www.franchisewire.com/6-things-to-know-about-esports-franchsies/

<p>Nhượng quyền thương hiệu trong eSport là một mô hình giúp duy trì việc vận hành của các đội, đảm bảo nhà phát hành game luôn được marketing game của mình và các đội vẫn tiếp tục được vận hành tốt.</p>

<p>Riot Games đã đề xuất một mô hình xóa bỏ vòng thăng hạng và xuống hạng. Việc thay đổi thứ hạng sẽ ảnh hưởng nhiều đến việc đầu tư và quản lý của tổ chức.
Nhà đầu tư đã dồn hàng tỷ VND, thậm chí là hàng tỷ USD cho một đội tuyển eSport. Nếu chẳng may đội bị xuống hạng, nhà đầu tư xem như mất trắng.</p>

<p></p>

<p></p>

<p></p>

<p></p>

<p><b>LPL và LCK: idol game thủ</b></p>

<p>Faker chính là trường hợp tiêu biểu nhất của idol game thủ. Ở Trung Quốc và Hàn Quốc, các khán giả nữ xem giải đấu rất đông. Họ không chỉ tìm hiểu về game mà còn muốn thấy các nam thần, idol game thủ của mình.
Phong cách idol game thủ khác với phong cách idol trên sân khấu. Các cô gái sẽ không thấy những chàng trai cao ráo, sáu múi. Thay vào đó là những nam thần phong cách thư sinh, cận thị.</p>

<p></p>

<h3>Những cách duy trì tựa game luôn hấp dẫn</h3>

<p><b>MC và bình luận viên</b></p>

<p>Nhắc đến bình luận viên, chúng ta không thể không kể đến BLV Hoàng Luân, thánh dự đoán Pelu của VCS Việt Nam. Nổi tiếng với khả năng đoán đâu sai đó, pháp sư Pelu luôn khiến cho fan hâm mộ lẫn tuyển thủ trong nước và thế giới thất điên bát đảo.</p>

<p></p>

<p></p>

<p></p>

<p></p>




',
            'date_post'         => '2023-06-03',
            'thumbnail_post'    => 'how-esports-teams-work-and-make-money-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Resident Evil Death Island ra mắt trailer',
            'url_post'         => 'resident-evil-death-island-cg-animated-film-trailer',
            'present_vi_post'  => 'Phìm sẽ được công chiếu tại Nhật Bản ngày 7/7',
            'content_vi_post'  => '<p>Sony Pictures Entertainment giới thiệu trailer tiếng Anh Resident Evil Death Island. Tên tiếng Nhật là Biohazard: Death Island.
Đây là phim hoạt hình CG mới trong loạt phim Resident Evil của CAPCOM. Đồng thời tiết lộ bộ phim sẽ ra mắt trên Đĩa Blu-ray, 4K Các nền tảng UHD, DVD và kỹ thuật số vào ngày 25/7/2023.</p>

<p>Phim sẽ được công chiếu tại Nhật Bản ngày 7/7/2023</p>

<p>Đây là trailer thứ 3 của Resident Evil Death Island được tung ra. Trailer đầu tiên xuất hiện vào tháng 8/2/2023.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/nseKndVKkkU" title="Resident Evil Death Island" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/L-vkuA8oqMY" title="Resident Evil Death Island" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/1RYaBQERMBE" title="Resident Evil Death Island" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>RESIDENT EVIL: DEATH ISLAND | OFFICIAL TRAILER</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/TrjF6qYM1A8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Trailer không phụ đề và ngôn từ mạnh.</p></center>

<p>Cốt truyện của phim kể về đặc vụ Leon thực hiện nhiệm vụ giải cứu tiến sĩ Antonio Taylor khỏi những kẻ bắt cóc. Đột nhiên một người phụ nữ bí ẩn ngăn cản anh ta.
Trong khi đó, đặc vụ Chris Redfield đang điều tra một đợt bùng phát thây ma ở San Francisco. Điểm chung của các nạn nhân là họ đã từng đến đảo Alcatraz.
Lần theo manh mối đó, Chris và nhóm của anh tiến đến hòn đảo, nơi một nỗi kinh hoàng mới đang chờ đợi họ.</p>

<center><img src="/upload/images/game/resident-evil-death-island-jill-valentine-1.jpg" width="100%" alt="Resident Evil Death Island" /><br><br>

<img src="/upload/images/game/resident-evil-death-island-1.jpg" width="100%" alt="Resident Evil Death Island" /><br><br></center>

<p>Trong trailer, khán giả có thể thấy các quái vật quen thuộc như các zombie, Licker, cùng với cá voi zombie có lẽ là trùm cuối. Cá voi zombie trong game là Brzak, xuất hiện trong Resident Evil 6.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/QTqxQdjMXOY" title="Resident Evil Death Island" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Brzak trong Resident Evil 6</p></center>

<p>Loạt phim hoạt hình CG Resident Evil: Infinite Darkness riêng của Netflix đã ra mắt độc quyền trên Netflix vào tháng 7/2021 với 4 tập.</p>

<p>Sau khi trailer đầu tiên được tung ra, rất nhiều fanart xuất hiện trên các nền tảng, thể hiện sự quan tâm của khán giả là rất lớn. Họ thích thú với rất nhiều cảnh trong trailer,
đặc biệt nhất là cảnh Jill Valentine trong phòng tập bẳn và cảnh 5 nhân vật nổi tiếng nhất Resident Evil tránh né chiếc vây cá voi khổng lồ.
Khán giả sẽ được chứng kiến 5 nhân vật xuyên suốt series Resident Evil xuất hiện trong phim: Jill Valentine, Leon Kennedy, Chris Redfield, Claire Redfield và Rebecca Chambers.</p>

<ul>
<li>Nicole Tompkins trong vai Jill Valentine
<li>Kevin Dorman trong vai Chris Redfield
<li>Stephanie Panisello trong vai Claire Redfield
<li>Matthew Mercer trong vai Leon S. Kennedy
<li>Erin Cahill trong vai Rebecca Chambers
</ul>

<center><img src="/upload/images/game/resident-evil-death-island-jill-valentine-rule34-1.jpg" width="100%" alt="Resident Evil Death Island" /><br><br>

<p>Hình Rule34</p></center>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-06-05/resident-evil-death-island-cg-animated-film-trailer-reveals-july-25-physical-digital-release/.198837" target="_blank" title="Resident Evil Death Island">Anime News Network</a></p>
',
            'date_post'         => '2023-06-05',
            'thumbnail_post'    => 'resident-evil-death-island-cg-animated-film-trailer-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'    => 'Ngành công nghiệp game lớn hơn cả Hollywood',
            'url_post'        => 'video-games-industry-bigger-than-hollywood',
            'present_vi_post' => 'Trong khi Hollywood tập trung vào vấn đề sắc tộc, ngành game tập trung phát triển chất lượng.',
            'content_vi_post' => '<p></p>

<p></p>

<p></p>

<h3>Doanh thu từ game, phim và âm nhạc</h3>

<p>Nguồn: <a href="https://gamerhub.co.uk/gaming-industry-dominates-as-the-highest-grossing-entertainment-industry/#:~:text=To%20put%20that%20in%20perspective,much%20as%20the%20movie%20industry." target="_blank" title="Resident Evil Death Island">Gamerhub</a></p>






<p>Dự đoán doanh thu của ngành công nghiệp game sẽ đạt 300 tỉ đô vào 2026, năm 2022 đã đạt 230 tỉ đô rồi.

Trong khi công nghiệp điện ảnh chỉ thu về 120 tỉ đô vào năm 2022.

Doanh thu từ game bằng cả âm nhạc và điện ảnh cộng lại.

Và với tình trạng các rạp phim đóng cửa hàng loạt như hiện nay doanh thu của điện ảnh còn chững lại nữa

Video game chưa được coi là 1 art form như cinema vì thế hệ boomers còn bảo thủ, chưa chấp nhận thay đổi. Cũng như những năm 20s 30s của thế kỉ trước, nghệ sĩ sân khấu khinh thường dv, biên kịch phim vậy, coi sân khấu là nghệ thuậtbl đích thực vậy còn điện ảnh là cho trẻ con, dân trí thấp đó</p>

<center><img src="/upload/images/game/gaming-pandemic-lockdowns-pwc-growth-joker.jpg" width="100%" alt="Joker MORTAL KOMBAT 11" />

<p></p></center>

<p></p>

<p></p>

<p></p>


Không chỉ phim Mỹ mà điện ảnh nói chung bắt đầu xuống dốc từ khi video game đầu tiên ra đời vào thời 70s, nhát búa đầu tiên vào sự thống trị của điện ảnh với các loại hình nghệ thuật khác.
Vì bản chất video game ưu việt hơn điện ảnh. Điện ảnh, kịch, hội họa, văn học... đều là nghệ thuật thụ động, dù hay tới đâu thì đều là câu chuyện của tác giả, nhân vật đều là của người khác, người xem người đọc không thể hoàn toàn chìm vào bối cảnh, hòa làm một với nhân vật. Chứ video game ( nhất là game nhập vai) thì tiềm năng bất tận.

Tk21 này tôi dự đoán 100% điện ảnh đi xuống, còn video game sẽ vươn lên thành loại hình nghệ thuật độc tôn, điện ảnh sẽ như sân khấu hội họa bây giờ, vẫn có chỗ đứng nhưng sẽ sống lay lắt.
Nhìn mấy tựa game bom tấn là hiểu. Từ 2020 đến nay toàn thấy game tỏi đô, chục tỏi đô doanh thu như Genshin, LoL, CS GO, Elder Scrolls, Elden Ring là hiểu.



<p>Nguồn: <a href="https://www.weforum.org/agenda/2022/07/gaming-pandemic-lockdowns-pwc-growth/" target="_blank" title="Resident Evil Death Island">World Economic Forum</a></p>

<h3>Game có thể lách các yêu cầu về màu da, giới tính.</h3>

<p>Một số game cho phép người chơi thay đổi màu da, giới tính, chủng tộc.</p>

<p></p>



',
            'date_post'         => '2023-06-20',
            'thumbnail_post'    => 'video-games-industry-bigger-than-hollywood-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]); // https://voz.vn/t/oscar-gay-soc.794378/page-5

        posts::create([
            'name_vi_post'    => 'Roblox cho phép nội dung người lớn',
            'url_post'        => 'roblox-is-going-to-have-adult-content',
            'present_vi_post' => 'Game trên Roblox có độ tuổi từ 17 tuổi trở lên.',
            'content_vi_post' => '<p>Roblox, nền tảng cho phép người dùng tự xây dựng trò chơi rất phổ biến đối với trẻ em. Trên nền tảng này, người dùng có thể tạo ra trò chơi của riêng mình như đua xe, kinh dị...
Roblox đang nỗ lực phát triển khách hàng của mình vượt ra khỏi giới hạn độ tuổi. Vào ngày 20/6/2023, công ty sẽ cho phép nội dung dành cho người từ 17 tuổi trở lên.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/CgV3BSyz2vk" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Game Doors được tạo ra trên nền tảng Roblox.</p></center>

<p>Nội dung được đăng trên <a href="https://en.help.roblox.com/hc/en-us/articles/15869919570708-Roblox-17-Policy-Standards" target="_blank" title="Roblox adult">trang chủ Roblox</a></p>

<blockquote><p>Our vision is that Roblox is a platform for all ages with safety and civility at its foundation. Building on that vision, we are expanding our Experience Guidelines to allow creators who are the age of 17 and up to create content exclusively for older audiences on Roblox. Both creators that develop this content and people who engage with it will have to be 17 or older and ID-verified to access this new category. Such content will remain inaccessible to those who are under 17 or not ID-verified.</p>

<p>Tầm nhìn của chúng tôi là Roblox là một nơi dành cho mọi lứa tuổi, với nền tảng là sự an toàn và lịch sự.
Dựa trên tầm nhìn đó, chúng tôi đang mở rộng Nguyên tắc trải nghiệm của mình để cho phép những người sáng tạo từ 17 tuổi trở lên tạo nội dung dành riêng cho khán giả lớn tuổi hơn trên Roblox.
Cả người sáng tạo, phát triển nội dung và những người tương tác với nội dung đó đều phải từ 17 tuổi trở lên và được xác minh ID để truy cập danh mục mới này.
Nội dung như vậy sẽ không thể truy cập đối với những người dưới 17 tuổi hoặc chưa được xác minh ID.</p>
</blockquote>

<p>Cụ thể, Roblox sẽ cho phép 3 loại nội dung:</p>

<ul>
<li>Bạo lực và máu me
<li>Lãng mạn và tình dục
<li>Đồ uống có cồn
</ul>

<p>Tuy nhiên, nội dung khiêu dâm, ảnh khỏa thân, đề cập đến ma túy bất hợp pháp và hình ảnh bạo lực vẫn bị cấm. Vì vậy, những người đang hy vọng có nhiều nội dung khiêu dâm trên Roblox đừng nên hy vọng.</p>

<p>Nguồn: <a href="https://gadgetadvisor.com/gaming/roblox-is-going-to-have-adult-content-but-nothing-explicit/" target="_blank" title="Roblox adult">Gadget Advisor</a></p>

<p>Trước đây, Roblox chỉ hỗ trợ cho người dùng từ 9 tuổi trở lên và những người từ 13 tuổi trở lên. Tuy nhiên, ngay cả khi nội dung người lớn bị cấm hoàn toàn,
nền tảng vẫn phải rất khó khăn để kiểm soát nội dung. Có hơn 50 triệu trò chơi nhiều người chơi (multi-player) trên nền tảng này.</p>

<p>Đã có ít nhất một trường hợp đáng chú ý về tấn công tình dục trong trò chơi trên Roblox, ảnh hưởng đến một đứa trẻ 7 tuổi.
Vào năm 2022, nền tảng này đã bị kiện vì cáo buộc cho phép khai thác hình ảnh một bé gái 10 tuổi. Kim kardashian cũng dọa sẽ kiện nền tảng này
khi con trai cô nhìn thấy một quảng cáo không phù hợp về tình dục khi chơi game.</p>

<p>Ngoài các vấn đề về nội dung, Roblox cũng đối mặt với hệ thống giao dịch, lấy tiền từ người dùng nhỏ tuổi. Một Robux tương đương 0.01 USD, nhưng các khoản tiền sử dụng để mua quần áo, các vật phẩm trong game dần tăng lên.</p>

<p>Nguồn: <a href="https://gizmodo.com/roblox-to-officially-allow-adult-content-1850557152" target="_blank" title="Roblox adult">Gizmodo</a></p>
',
            'date_post'         => '2023-06-21',
            'thumbnail_post'    => 'roblox-is-going-to-have-adult-content-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Tại sao thể thao Mỹ không đạt thành tích cao?',
            'url_post'         => 'why-american-sports-dont-have-high-achievement',
            'present_vi_post'  => 'Đối với người Mỹ, tiền quan trọng hơn thành tích.',
            'content_vi_post'  => '<p></p>

<h3>Văn hóa "thích vươn cao" và "độc nhất"</h3>

<p>Trong văn hóa người Mỹ, có một điều dễ nhận thấy là: người Mỹ luôn muốn mình là độc nhất, thích vươn cao trên mọi thứ. Trong từng câu nói của người Mỹ luôn thể hiện sự độc nhất đó:</p>

<ul>
<li>"I&apos;ve never seen anything like it before"
<li>"This is the best moment of my life"
</ul>

<p>Vì vậy, người Mỹ và người Trung Quốc có đặc điểm rất giống nhau là luôn muốn bá chủ, đứng đầu thiên hạ. Họ đều có sở thích môn bóng rổ vì đó là môn thể thao vươn cao, điểm số cao. Trong khi bóng đá lại là môn có số bàn thắng thấp, chiều cao quan trọng nhưng không phải tất cả.</p>

<p>Hơn nữa, văn hóa Mỹ còn đề cao sự "độc nhất", "đặc biệt". Có thể bạn không phải người giỏi nhất, nhưng bạn có thể trở thành sự "độc nhất".
Trong những bộ truyện tranh comic, Superman và Supergirl là 2 cá thể cuối cùng còn sót lại của chủng tộc Krypton. Martian Manhunter, kẻ thù Ma&apos;alefa&apos;ak và một số nhân vật khác cũng là những người còn sót lại của người sao Hỏa đã bị diệt chủng.
Peter Quill là đứa con duy nhất của Ego, sau khi những đứa con khác của Ego không mạnh như ông mong muốn và đã chết.</p>

<h3>Thể thao là gameshow thực tế phải có lợi nhuận</h3>

<p>Một văn hóa khác của người Mỹ là sự thực dụng. Nước Mỹ, hay cụ thể hơn là các nhà tài phiệt Mỹ, luôn đặt tiền lên trên hết. Họ muốn có những gameshow truyền hình thực tế để khán giả luôn bỏ tiền ra xem. Và thể thao là một trong số đó.</p>

<p>Từ bóng rổ, bóng đá đến eSport, nước Mỹ đều có giải đấu riêng với các tuyển thủ rất giỏi, sức khỏe phát triển không thua kém các nước khác. Tuy nhiên, họ lại rất ít khi có được thành tích, thứ hạng cao trong các giải đấu. Vì thứ họ cần là tiền, rất nhiều tiền từ các hợp đồng quảng cáo, bán áo, thương mại...</p>

<p>Vì vậy, cho dù người Mỹ đã nắm trong tay rất nhiều các đội bóng lớn như Manchester United, Chelsea, mời được cả David Beckham và Lionel Messi, nhưng giải đấu của họ vẫn không có sức hấp dẫn bằng các giải Ngoại Hạng Anh, Pháp hay Tây Ban Nha.
Việc đội bóng xuống hạng có thể khiến các nhà đầu tư cảm thấy số tiền bỏ ra cho đội không sinh lãi. Vậy nên họ hủy việc xuống hạng.</p>

<p>Ngay cả eSport, cụ thể là game Liên Minh Huyền Thoại, dù là khu vực khai sinh ra tựa game nhưng Bắc Mỹ LCS lại có số thành tích thua xa Hàn, Trung và Châu Âu.
Thậm chí gần đây, drama LCS hủy giải đấu sau khi kết thúc MSI 2023 càng khiến khu vực này đi xuống.
eSport hoàn toàn không cần thể chất vượt trội hay số điểm hạ gục lên đến 50 mạng/trận. Nhưng eSport lại mang về nhiều hợp đồng quảng cáo, tạo nhiều lợi nhuận hơn.</p>

<p>Xem thêm: <a href="/post/drama-vcs-lcs-there-is-no-young-players" target="_blank" title="american sports thể thao mỹ">Drama VCS và LCS, khủng hoảng lứa trẻ kế thừa</a></p>

<center><img src="/upload/images/game/american-sports.jpg" width="100%" alt="american sports thể thao mỹ" /><br><br></center>

<h3>Phong cách "ăn xổi" và giải đấu không xuống hạng của thể thao Mỹ</h3>

<p>Nhìn vào thể thao Mỹ, chúng ta có thể thấy cách làm thể thao của người Mỹ gói gọn trong 2 từ: "ăn xổi" và giải đấu không xuống hạng.</p>

<p>Trong eSport môn Liên Minh Huyền Thoại, rất nhiều tuyển thủ đến từ Hàn Quốc, đất nước có thành tích tốt nhất thế giới.
<a href="https://lol.fandom.com/wiki/Team_Liquid" rel="nofollow" target="_blank" title="VCS LCS drama">đội tuyển FlyQuest</a> có đến 4 game thủ Hàn Quốc.
Chỉ có một số ít đội không có người Hàn như Immortals, Evil Geniuses. Điều này hoàn toàn không có lợi cho sự phát triển của lứa trẻ kế cận.</p>

<p>Ông chủ Chelsea người Mỹ hiện tại là Todd Boehly. Ông đã tiếp quản đội bóng Chelsea sau khi ông chủ người Nga Roman Abramovich bị ép phải cho không đội bóng.
Thành tích của Chelsea hiện tại đi xuống thấy rõ. Mọi người đang chỉ trích cách dùng người của ông chủ mới sau khi sa thải HLV cũ đầy thành tích Graham Potter.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/y0odYZDWLeU" title="american sports thể thao mỹ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>600 triệu Bảng mua đội hình để trụ hạng.</p></center>

<p>Nhưng sự kiện chấn động nhất giới bóng đá là giải đấu Super League của chủ tịch Real Madrid, Florentino Perez. Ông muốn tổ chức một giải đấu của các đội mạnh nhất, nổi tiếng nhất. Các đội sẽ đá với nhau mà không sợ bị xuống hạng.
Khán giả sẽ thường xuyên được theo dõi các trận đấu giữa các ngôi sao với nhau.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/p4iFpO7GeJw" title="american sports thể thao mỹ" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/_NqF_c1aaR8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/vi9wY_n9M2g" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/c7VtHDUz5HY" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Những video tranh cãi về giải đấu Super League</p></center>

<p>Tuy nhiên, giải đấu không xuống hạng không phải là không có thành công. Tiêu biểu là MLB (Giải vô địch bóng chày quốc gia Mỹ) và NFL (Giải vô địch bóng bầu dục quốc gia Mỹ).
Một phần vì đây là các môn thể thao được người Mỹ yêu thích hơn bóng đá. Phần khác vì các môn thể thao này chỉ phổ biến ở một số ít các quốc gia như Mỹ, Nhật... Trong khi bóng đá, Liên Minh Huyền Thoại lại có mặt tại rất nhiều nơi trên thế giới.
Mỗi nước lại có những nền văn hóa riêng. Và họ thích các giải đấu có sự lên hạng, xuống hạng.</p>

<p>Tóm lại, <b>các giải đấu trên thế giới luôn có sự lên xuống hạng và các trận play-off kịch tính. Trong khi thể thao của Mỹ lại bỏ qua phần lên xuống hạng, chỉ tập trung vào play-off.</b> Các vận động viên sẽ giảm bớt áp lực hơn.
Các ông chủ sẽ có nhiều tiền hơn mà không sợ đội của mình xuống hạng, ảnh hưởng đến các khoản đầu tư của họ. Chẳng ai muốn đầu tư vào những đội vô danh tiểu tốt có thành tích kém cỏi cả.</p>

<p>Việc tổ chức giải đấu không xuống hạng là chuyện rất bình thường của Mỹ. Vì đối với họ, thể thao giống như một gameshow không bao giờ cũ. Giải đấu Liên Minh Huyền Thoại LCS, bóng đá MLS, bóng rổ MBA đều là những giải đấu không xuống hạng.
Người Mỹ còn có môn vật biểu diễn WWE. Những cảnh trên sàn đấu đều là diễn. Và việc tổ chức các gameshow này sẽ kéo theo rất nhiều lợi ích kinh tế khác như cá cược, drama, thậm chí là các scandal tình ái, hình ảnh khỏa thân của các vận động viên nữ...</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/hyOilOUl9Wc" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/9Gp_0AnRzVo" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Một số cảnh diễn trên sàn WWE.</p></center>

<p>Những giải đấu không có đội xuống hạng khiến các cầu thủ, vận động viên không có động lực tham dự hay cố gắng. Họ chỉ cần ở đó, tập luyện và lãnh lương. Và khi các nhà đầu tư hết tiền, họ bị đuổi đi không thương tiếc.
Drama LCS đã xảy ra khi các nhà đầu tư không còn tiền lo cho đội tuyển hạng 2. Các tuyển thủ đột nhiên bị sa thải hàng loạt.</p>

<h3>Không thích "tỷ số hòa" và "va chạm mạnh"</h3>

<p>Những bộ môn mà người Mỹ yêu thích là những môn không có tỷ số hòa. Trong bóng rổ,
nếu sau thời gian thi đấu chính thức (4 hiệp), 2 đội vẫn hòa nhau thì trận đấu sẽ bước vào hiệp phụ hay gọi là hiệp thứ 5. Có thể chơi nhiều hiệp phụ.
eSport cũng là những môn không có tỷ số hòa. Liên Minh Huyền Thoại, Valorant, CSGO... tất cả đều phải chơi đến khi phân định thắng thua.</p>

<p>Người Mỹ có sở thích cạnh tranh rất cao. Họ muốn trải nghiệm cảm giác mạnh, chiến đấu và chiến thắng như các bộ phim hành động. Những bất ngồ lớn, những khoảnh khắc tỏa sáng điên rổ phải thường xuyên xuất hiện.
Bóng rổ, bóng bầu dục, eSport, WWE là những môn đáp ứng cho họ những trải nghiệm như vậy. Các cầu thủ va chạm với nhau trên sân rất mạnh.</p>

<p>Không thích "tỷ số hòa" và "va chạm mạnh" là những yếu tố cần thiết cho việc phát triển thể thao. Tuy nhiên, những điều này lại chưa chuyển hóa thành các thành tích lớn vì chúng chỉ dừng ở mức "trải nghiệm".
Giống như việc bạn xem đội bóng đá Việt Nam chơi đôi công với đối thủ vậy. Trông đã mắt, tạo cảm xúc mạnh, nhưng hiệu quả lại không chắc chắn bằng việc đá phòng ngự phản công.
Mourinho "người đặc biệt" nổi tiếng với triết lý thực dụng nhất có thể. Ông sẵn sàng phòng ngự tiêu cực để giành chiến thắng. Triết lý này bị rất nhiều người chỉ trích là giết chết bóng đá, chẳng có gì hấp dẫn. Nhưng hấp dẫn lại chưa chắc mang lại thành tích.</p>
',
            'date_post'         => '2023-07-01',
            'thumbnail_post'    => 'why-american-sports-dont-have-high-achievement-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Hàn Quốc: chính trị gia mất ghế vì gắn mác Blue Archive thành game 18+',
            'url_post'         => 'blue-archive',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>








https://www.youtube.com/watch?v=bE1LaL4aPEE
',
            'date_post'         => '2023-07-09',
            'thumbnail_post'    => 'blue-archive-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'T1 sắp đi theo con đường của Barca',
            'url_post'         => 't1-sap-di-theo-con-duong-cua-barca',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<h3>Barca sau khi Messi rời đi</h3>

<p>Kể từ khi Messi ra đi vào tháng 8/2021, khi mọi người chứng kiến cầu thủ người Argentina khóc trong phòng họp báo, không ít người đã nghĩ đến nhiều viễn cảnh khác nhau khi Barca thiếu Messi.</p>

<p>Messi gánh vác khối lượng công việc khổng lồ trên hàng công.
Anh kéo bóng, rê dắt, kiến tạo, lùi về giữa sân kết nối lối chơi. Khi đồng đội bỏ lỡ cơ hội, Messi trực tiếp ghi bàn.</p>

<p></p>

<p></p>

<h3>T1 thiếu Faker</h3>

<p>Sau chuỗi trận thắng liên tục, vào ngày .... , T1 thông báo Faker phải nghỉ thi đấu vì chấn thương. Vị trí Đường Giữa phải nhanh chóng đưa Poby sinh năm ..., đang ở giải Academy lên thay thế huyền thoại của Liên Minh Huyền Thoại.</p>

<p>Bên cạnh đó, Bengi cũng tuyên bố từ chức.</p>

<p>Những tưởng T1 vẫn có thể chiến thắng với 4 thành viên còn lại, nhưng khi Faker đi, mọi điểm yếu của T1 lộ rõ như Barca thiếu Messi. Họ thua từ các đội đứng đầu đến các đội đứng dưới đáy bảng xếp hạng.</p>

<p></p>

<p></p>

<center>

<p>T1 thua BRO</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/bN4pQ3MmKp8" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>T1 thua DRX, đội đứng dưới đáy bảng xếp hạng LCK</p></center>

<p></p>

<p></p>

<p></p>
',
            'date_post'         => '2023-07-09',
            'thumbnail_post'    => 't1-sap-di-theo-con-duong-cua-barca-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => '20 game thủ nữ chuyên nghiệp có thu nhập cao nhất',
            'url_post'         => 'the-20-highest-earning-pro-female-gamers',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<h3>Alyona "Ailey" Bordukova</h3>

<ul>
<li>Tên trong game: Ailey
<li>Tên thật: Alyona Bordukova
<li>Ngày sinh: N/A
<li>Quốc tịch: Russia
<li>Thu nhập: 22.580 USD
</ul>

<center><img src="/upload/images/game/alyona-ailey-bordukova.jpg" width="100%" alt="Alyona Ailey Bordukova" /><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/lEm8AKGaS0E" title="Alyona Ailey Bordukova" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe></center>

<p>Ailey là một game thủ Counter-Strike: Global Offensive nổi tiếng đến từ Nga. Xếp hạng 3172 trên toàn cầu và hạng 121 tại quốc gia của mình,
Ailey là một thế lực đáng gờm khi thi đấu 5 giải đấu trong CS:GO, giành vị trí thứ nhất chung cuộc trong cuộc thi CS:GO nữ 2018.</p>

<h3>Anastasiya "Nast1a" Evdokina</h3>

<ul>
<li>Tên trong game: Nast1a
<li>Tên thật: Anastasiya Evdokina
<li>Ngày sinh: N/A
<li>Quốc tịch: Russia
<li>Thu nhập: 23.515 USD
</ul>

<p></p>

<p></p>

<h3>Stephanie "FemSteph"</h3>

<ul>
<li>Tên trong game: FemSteph
<li>Tên thật: Stephanie
<li>Ngày sinh: July 24, 1988
<li>Quốc tịch: United States
<li>Thu nhập: 23.875 USD
</ul>

<p>Một game thủ chuyên nghiệp khác đến từ Nga, Nast1a cũng với tựa game Counter Strike: Global Offensive.
Nast1a hiện đang xếp hạng 3086 trên thế giới và thứ 117 ở quốc gia của mình. Nast1a và Ailey rất thân nhau và sự cạnh tranh giữa các nữ game thủ này cũng rất khốc liệt.</p>

<p></p>

<p></p>

<h3>Deb "Annialis"</h3>

<p></p>

<p></p>

<p></p>

<h3>Alyona "Candy" Kuvaeva</h3>

<p></p>

<p></p>

<p></p>

<h3>Janet "xchocobars" Rose</h3>

<p></p>

<p></p>

<p></p>

<h3>Stephanie "missharvey" Harvey</h3>

<p></p>

<p></p>

<p></p>

<h3>Chen "GLHuiHui" YuYan</h3>

<p></p>

<p></p>

<p></p>

<h3>Christine "potter" Chi</h3>

<p></p>

<p></p>

<p></p>

<h3>Wang "BaiZe" Xinyu</h3>

<p></p>

<p></p>

<p></p>

<h3>Zainab "zAAz" Turkie</h3>

<p></p>

<p></p>

<p></p>

<h3>Anna "Ant1ka" Ananikova</h3>

<p></p>

<p></p>

<p></p>

<h3>Kristen "KittyPlays"</h3>

<p></p>

<p></p>

<p></p>

<h3>Ksenia "vilga" Klyuenkova</h3>

<p></p>

<p></p>

<p></p>

<h3>Sarah "Sarah Lou" Harrison</h3>

<p></p>

<p></p>

<p></p>

<h3>Marjorie "Kasumi Chan" Bartell</h3>

<p></p>

<p></p>

<p></p>

<h3>Ricki Sophie Ortiz</h3>

<p></p>

<p></p>

<p></p>

<h3>Sasha "Scarlett" Hostyn</h3>

<ul>
<li>Tên trong game: Scarlett
<li>Tên thật: Sasha Hostyn
<li>Ngày sinh: 14/12/1993
<li>Quốc tịch: Canada
<li>Thu nhập: 23.875 USD
</ul>

<p>Nữ game thủ người Canada, Scarlett chính thức là nữ game thủ chuyên nghiệp được trả lương cao nhất thế giới. Không giống như những người tiền nhiệm trong danh sách, Scarlett chơi Starcraft II, chủ yếu chọn tộc Zerg.</p>

<p>Như các game thủ đã biết, StraCraft là một trò chơi có tính cạnh tranh cao và Scarlett luôn chiếm ưu thế bất cứ khi nào cô ấy thi đấu.
Việc cô giành chiến thắng ở Hàn Quốc có lẽ là thành tích ấn tượng nhất không chỉ của một nữ game thủ chuyên nghiệp mà của bất kỳ game thủ nào.</p>

<p>Nguồn: <a href="https://www.gamedesigning.org/gaming/female-gamers/" target="_blank" title="highest earning pro female gamers">Game Designing</a></p>
',
            'date_post'         => '2023-07-29',
            'thumbnail_post'    => 'the-20-highest-earning-pro-female-gamers-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => ENABLE,
        ]);

        posts::create([
            'name_vi_post'     => 'Nữ game thủ chuyên nghiệp nên chơi game nào?',
            'url_post'         => 'what-games-pro-female-gamers-should-play',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<p>Xem thêm: <a href="/post/the-20-highest-earning-pro-female-gamers" target="_blank" title="pro female gamers">20 game thủ nữ chuyên nghiệp có thu nhập cao nhất</a></p>

<h3>Hearthstone</h3>

<p>Tựa game đầu tiên dành cho phái nữ, không gì khác ngoài Hearthstone. Nữ game thủ Trung Quốc VKLiooon vô địch giải Hearthstone Grandmaster 2019 chính là một hiện tượng lớn của làng game thế giới.</p>

<p>Xem thêm: <a href="/post/vkliooon-becomes-first-female-hearthstone-global-champion">Nữ game thủ Trung Quốc VKLiooon vô địch giải Hearthstone Grandmaster 2019</a></p>

<p>Ngoài ra, có rất nhiều game thủ nữ chơi tựa game này, từ chuyên nghiệp đến không chuyên như GLHuiHui, BaiZe của Trung Quốc.
Eva Elfie, nữ diễn viên phim người lớn cũng đã đạt rank Legend trong Hearthstone.</p>

<p>Lý do để tựa game này thu hút các game thủ nữ và khiến họ thành công vì đây là game không cần phản xạ nhanh hay phối hợp đồng đội.
Chỉ cần có tư duy chiến thuật và đặc biệt là may mắn, game thủ nữ hoàn toàn có thể thắng áp đảo các game thủ nam như cách VKLiooon thắng 3-0 và giành chức vô địch.</p>

<h3>Counter-Strike: Global Offensive</h3>

<p></p>

<p></p>

<p></p>

<h3>Starcraft II</h3>

<p></p>

<p></p>

<p></p>

',
            'date_post'         => '2023-08-01',
            'thumbnail_post'    => 'what-games-pro-female-gamers-should-play-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => ENABLE,
        ]);
        
        posts::create([
            'name_vi_post'     => 'Lara Croft của Tomb Raider tham gia chiến trường của Call of Duty',
            'url_post'         => 'tomb-raiders-lara-croft-joins-call-of-dutys-war-effort',
            'present_vi_post'  => 'Khách mời có cả Nicki Minaj, Snoop Dogg và nhiều nghệ sĩ khác.',
            'content_vi_post'  => '<p>Thương hiệu Call of Duty tiếp tục quá trình "Fortnite hóa" bằng cách công bố nhân vật mới nhất: Lara Croft của tựa game Tomb Raider.
Nữ khảo cổ trẻ đẹp sẽ xuất hiện trong Call of Duty: Warzone và Modern Warfare II, tham gia cùng các nhân vật có thể chơi được ngoài đời thực như Nicki Minaj, Snoop Dogg, Kevin Durant và nhiều nhân vật khác
từ chương trình Prime Video The Boys</p>

<p>Publisher Activision hasn’t announced details as to how you get Lara Croft on your side, though it’s likely you’ll have to purchase some sort of bundle to access the renowned ruins ruiner.
For instance, Minaj was available as part of the $10 season 5 battle pack.
There will also likely be Croft-related items, skins and weapons for sale, though her signature dual-wielded pistols should be part of the initial buy-in.</p>

<p>Additionally, the publisher hasn’t announced when Croft would officially debut as a battle-tested combatant. There’s a mid-season update coming for season 5, which would be as good a place as any to introduce the treasure hunter. Engadget reached out to Activision for clarification regarding pricing and availability.
</p>

<p></p>

<p></p>

<p>Nhà phát hành vẫn chưa công bố khi nào Lara Croft sẽ chính thức ra mắt.
Một bản cập nhật giữa mùa cho phần 5. Đây sẽ là nơi tốt nhất để giới thiệu về thợ săn kho báu. Engadget đã liên hệ với Activision để làm rõ về giá cả.</p>

<p>Trong các tin tức liên quan khác, Call of Duty: Modern Warfare III đang tới gần. Game sẽ ra mắt trên hệ máy console vào tháng 11.
Trong khi Tomb Raider bản cuối cùng là Shadow of the Tomb Raider, đã được ra mắt vào năm 2018.
Nhà phát triển Crystal Dynamics, cùng với Amazon, đã thông báo vào tháng 12 về một trò chơi mới sắp ra mắt. Đây sẽ là một "cuộc phiêu lưu theo lối kể chuyện, một người chơi"
được xây dựng bằng Unreal Engine 5. Amazon cũng đang sản xuất Tomb Raider TV nhưng chưa cho biết khi nào sẽ ra mắt.</p>

<p>Nguồn: <a href="https://www.engadget.com/tomb-raiders-lara-croft-joins-call-of-dutys-war-effort-184948028.html" target="_blank" title="Tomb Raider Call of Duty Modern Warfare">Engadget</a></p>
',
            'date_post'         => '2023-08-24',
            'thumbnail_post'    => 'tomb-raiders-lara-croft-joins-call-of-dutys-war-effort-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => ENABLE,
        ]);

        posts::create([
            'name_vi_post'     => 'Boxing Hatsune Miku sẽ phát hành vào mùa xuân 2024',
            'url_post'         => 'fitness-boxing-feat-hatsune-miku-switch-game-announced-for-spring-2024-release',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p>Imagineer đã công bố vào ngay2 31/8/2023 về một trò chơi mới trong series Fitness Boxing (Fit Boxing) với thần tượng Vocaloid Hatsune Miku
có tên là Fitness Boxing feat. Hatsune Miku: Miku to Issho ni Lesson (Tập thể dục cùng Miku) dành cho hệ máy Nintendo Switch tại Nhật Bản. 
Game là sự hợp tác giữa Imagineer và Crypton Future Media, sẽ ra mắt vào mùa xuân năm 2024.</p>

<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/-R2qf6iotdU?si=JDJ3qxjUD6DDXEdu" title="Boxing Hatsune Miku" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<img src="/upload/images/game/a-returner-magic-should-be-special-bg-1.jpg" width="100%" alt="Boxing Hatsune Miku">

<p></p></center>

<p></p>

<p>Trò chơi tập thể dục Fitness Boxing yêu cầu người chơi sử dụng bộ điều khiển Joy-Con của Switch để đấm và né theo phong cách giống như một trò chơi nhảy múa.
Imagineer đã xuất bản trò chơi gốc dưới dạng trò chơi tập thể dục đầu tiên của Switch tại Nhật Bản vào tháng 12/2018. Phần mới nhất trong loạt phim, Fitness Boxing 2: Rhythm and Fitness, đã ra mắt vào tháng 12/2020, bán được 500.000 bản trên toàn thế giới trong 1 tháng.</p>

Imagineer released the Fitness Boxing Fist of the North Star game, a crossover with the Fist of the North Star series, for Switch in Japan last December and in the West on March 2.

<p>Các trò chơi Fitness Boxing dành cho Switch đã truyền cảm hứng cho loạt phim anime truyền hình Kimi to Fit Boxing (You and Fitness Boxing) vào tháng 10/2021.</p>

<p>Crypton Future Media đã phát triển Hatsune Miku từ công nghệ Vocaloid. Vocaloid là ngân hàng phần mềm giọng nói và biểu tượng hình ảnh, được quảng bá như một thần tượng ảo.</p>

<p>Nguồn: <a href="https://www.animenewsnetwork.com/news/2023-09-01/fitness-boxing-feat-hatsune-miku-switch-game-announced-for-spring-2024-release/.201889" target="_blank" title="Boxing Hatsune Miku">Anime News Network</a></p>
',
            'date_post'         => '2023-09-04',
            'thumbnail_post'    => 'fitness-boxing-feat-hatsune-miku-switch-game-announced-for-spring-2024-release-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Kinh nghiệm TFT dành cho người mới (áp dụng mọi mùa)',
            'url_post'         => 'tft-experience-for-newbie',
            'present_vi_post'  => '',
            'content_vi_post'  => '



<h3>Xác định chuỗi thắng hoặc thua trong 3 vòng giao chiến đầu tiên</h3>

<p>Sau khi vào game, các bạn sẽ có 3 vòng farm lính để lấy tiền và kinh nghiệm. Lúc này sẽ có 2 trường hợp:</p>

<ul>
<li>Nếu có nhiều quân tốt: trong 3 vòng giao chiến đầu tiên, khả năng có chuỗi thắng tương đối cao.
<li>Nếu có nhiều quân xấu: trong 3 vòng giao chiến đầu tiên, khả năng có chuỗi thua tương đối cao.
</ul>

<p>Mục tiêu trong 3 vòng giao chiến đầu tiên là <b>phải có chuỗi thắng hoặc thua.</b> Kịch bản xấu nhất là bạn có trận thắng thua xen kẽ. Khi đó, lượng tiền kiếm được từ chuỗi thắng/thua sẽ không có.</p>

<p>Kịch bản đẹp nhất là 2 trận thắng, 1 trận thua.</p>


<h3>Biết quy tắc tăng level</h3>

<p>Level giúp bạn đảm bảo quân số để không bị thua về số lượng. Sau đây là một số nguyên tắc cơ bản:</p>

<p><b>Biết thời điểm tăng level</b></p>

<ul>
<li>Level 4: tăng sớm nếu đã có đủ quân hoặc muốn có chuỗi thắng.
<li>Level 5: phải đạt sau vòng đi chợ thứ 2
<li>Level 6: sau vòng 3.2 (sau khi đánh Người Đá Krug)
<li>Level 7: khoảng từ vòng 3.5 đến 4.2
<li>Level 8: khoảng từ vòng 4.5 đến 5.1
</ul>





<h3>Chọn quân dễ build đồ</h3>

<p>Có những quân dễ build đồ như các quân chống chịu. Chỉ cần ném hết đồ trâu bò nhất cho quân đó là được. Nhưng lại có những quân carry yêu cầu phải đúng item, khiến việc sử dụng gặp nhiều khó khăn.</p>

<p>Thường thấy nhất qua các mùa là các quân cần tốc độ đánh. Có quân tốc độ đánh nhưng cần sát thương phép. Có quân lại cần tốc độ đánh và sát thương vật lý.</p>

<p>Các quân sử dụng phép thuật thì ngược lại. Chúng chỉ cần đảm bảo 2 thứ: sức mạnh phép thuật và mana.</p>




<h3>Chọn đội hình rẻ, dễ triển khai</h3>

<p>Mỗi đội hình sẽ có quân chủ lực. Bạn sẽ sử dụng đội hình với quân chủ lực giá 3 vàng hay 4 vàng?</p>

<h3>Chọn đội hình nhiều khống chế</h3>

<p>Nếu bạn gặp phải đối thủ quá mạnh, hãy sử dụng đội hình nhiều khống chế. Cho dù đối thủ có mạnh, quân cờ đẹp thì cũng vô dụng nếu chúng đã bị bất động, hất tung... Việc khống chế đối thủ giúp tạo khoảng thời gian để các sát thương chủ lực tích năng lượng, sử dụng kỹ năng.</p>

<p>Khi nhắc đến khống chế, không thể không nhắc đến item Phong Kiếm.</p>

<h3>Chọn những quân có năng lượng thấp, tốc độ đánh cao.</h3>

<p>Có 3 điểm cần lưu ý khi chọn quân:</p>

Năng lượng
Tốc độ đánh
Tốc độ triển khai kỹ năng

<p>Mục đích là để đảm bảo quân cờ đó sẽ sử dụng kỹ năng nhiều nhất có thể. Ví dụ như mùa 9, Cassiopeia là quân 1 vàng được ưa thích nhất. Lý do vì Cassiopeia có 3 hệ và năng lượng thấp. Chỉ cần đánh 3 đòn, Xà Nữ sẽ phóng độc vào 1 mục tiêu.</p>

<p>Ngược lại, Jhin mùa 9 là quân không nên sử dụng. Năng lượng nhiều hơn, tốc độ đánh ít hơn Cassiopeia. Đặc biệt, tốc độ triển khai kỹ năng cũng chậm hơn. Hiệu ứng hình ảnh của Xà Nữ khi ra chiêu rất nhanh. Trong khi Nghệ Sĩ Tử Thần phải đưa súng lên ngắm bắn một cách nghệ thuật, trông rất chậm chạp.</p>

<h3>Sử dụng chiến thuật 2 quân giống nhau</h3>

<p>Đôi lúc, bạn có thể sử dụng chiến thuật dị 2 quân giống nhau. Mục đích là để sử dụng kỹ năng của quân đó nhiều lần.</p>

<p>Katarina là ví dụ. Mùa 1 Katarina sử dụng chiêu cuối Bông Sen Tử Thần. Mùa 9 nữ sát thủ Noxus sử dụng chiêu ... Vì vậy, chiến thuật 2 Katarina được sinh ra để quét sạch tuyến sau của đối thủ.</p>

<p>Lissandra mùa 9 cũng có thể dùng 2 quân. Hãy nghĩ đến cảnh đối thủ có 2 Lissandra, mỗi quân có 1 item tăng mana. Đội hình của bạn sẽ liên tục bị đóng băng để tuyến sau xả đạn. Nếu có thêm vài cây Phong Kiếm, trong 5 giây đầu tiên, đội hình của bạn từ 8 quân sẽ bị giảm xuống còn 4 quân.</p>

<p>Miss Fortune mùa 8, nếu được đặt 2 quân ở 2 góc, bạn sẽ được chứng kiến cảnh 2 chiêu cuối Bão Đạn xả toàn bản đồ trông rất đã mắt. Ngoài ra còn có 2 Gnar, 2 Annie thả gấu...</p>

<p>Nguồn: <a href="" target="_blank" title="tft experience for newbie">Anime News Network</a></p>
',
            'date_post'         => '2023-09-11',
            'thumbnail_post'    => 'tft-experience-for-newbie-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Unity thu phí mỗi lần game của họ được cài đặt',
            'url_post'         => 'unity-will-start-charging-developers-each-time-their-game-is-installed',
            'present_vi_post'  => 'Một quyết định gây bức xúc trong cộng đồng làm game.',
            'content_vi_post'  => '<p></p>

<h3></h3>

<p>Unity announced a new fee structure today, and developers are none too happy. “We are introducing a Unity Runtime Fee that is based upon each time a qualifying game is downloaded by an end user,” the company wrote in a blog post announcing the change. “We chose this because each time a game is downloaded, the Unity Runtime is also installed.” The new per-install fees are set to kick in on January 1, 2024.</p>

<p>The company says developers will be charged for installations after passing both a minimum revenue threshold from the last 12 months and a minimum lifetime install count. The exact fees will vary depending on which plan they use. Unity Personal and Unity Plus subscribers will pay $0.20 per install after reaching $200,000 in revenue from the past 12 months and 200,000 lifetime installs. Meanwhile, after hitting $1 million in revenue in the last 12 months and one million lifetime installs, Unity Pro members’ fees start at $0.15 per install, while Unity Enterprise fees start at $0.125 per install.</p>

<p>Members using Unity Pro and Enterprise plans have a tiered fee structure that decreases their rates after reaching thresholds of 100,000, 500,000 and one million installs. The company claims making developers hit both marks before requiring them to pay the fee will ensure that only those who reach “significant success” will be charged.</p>

<p>Các thành viên sử dụng gói Unity Pro và Enterprise có gói phí theo cấp độ giảm dần sau khi đạt đến ngưỡng 100.000, 500.000 và một triệu lượt cài đặt.
Công ty tuyên bố việc yêu cầu các nhà phát triển đạt được cả hai yếu tố trên trước khi yêu cầu họ trả phí sẽ đảm bảo chỉ những người đạt được “thành công đáng kể” mới bị tính phí.</p>

<p>The gaming developer community reacted to the announcement about as positively as you’d expect. “If you buy our Unity game, please don’t install it,” Newfangled Games designer Henry Hoffman quipped on X (formerly Twitter). “This is such an abysmally catastrophic decision that it really will either (likely) be u-turned, or the engine is completely done for on all scales of the indie industry,” posted gaming industry worker Ryan T. Brown on X.</p>

<p>Cộng đồng dev game đã phản ứng tiêu cực với quyết định của Unity. Designer Henry Hoffman của game Newfangled đã tweet: "Nếu bạn mua trò chơi Unity của chúng tôi, vui lòng không cài đặt nó".</p>

<center><img src="/upload/images/game/ceo-john-riccitiello.jpg" width="100%" alt="CEO John Riccitiello">

<p>Giám đốc điều hành John Riccitiello</p></center>

<p>Axios gaming reporter Stephen Totilo wrote on X that Unity clarified several points that, if anything, make the change sound like even more of a hassle for developers. He wrote that if a player deletes and reinstalls a game, that counts for two installs and two charges. Ditto for players installing a single game on two devices. However, charity games and bundles are supposedly exempt.</p>

<p>Việc phát triển game dựa trên Unity sẽ là một rủi ro tài chính đối với:</p>
<ul>
<li>Dịch vụ thuê bao.
<li>Gói từ thiện.
<li>Vi phạm bản quyền.
<li>Trở thành game free to play.
<li>Cài đặt độc hại.
<li>Quà tặng give away
</ul>

<p></p>

<p></p>

<p>Nguồn: <a href="https://esports.gg/news/gaming/unity-pay-per-install-fees/" target="_blank" title="Unity game install">Esports.gg</a></p>

<p></p>

<p></p>

<p>Nguồn: <a href="https://www.engadget.com/unity-will-start-charging-developers-each-time-their-game-is-installed-214851801.html?_fsig=FmQ5tOZnezhKFNUkfgyR5w--%7EA" target="_blank" title="Unity game install">Engadget</a></p>
',
            'date_post'         => '2023-09-13',
            'thumbnail_post'    => 'unity-will-start-charging-developers-each-time-their-game-is-installed-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Hàn Quốc đang ưu ái Việt Nam như thế nào?',
            'url_post'         => 'han-quoc-dang-uu-ai-viet-nam-nhu-the-nao',
            'present_vi_post'  => 'Hãy cùng nhìn lại những sự ưu ái của Hàn Quốc trong năm 2023.',
            'content_vi_post'  => '<p>Hàn Quốc và Việt Nam là 2 quốc gia có khoảng cách rất lớn về mọi mặt. Từ kinh tế, giải trí đến thể thao. Tuy vậy, Hàn và Việt lại có những nét văn hóa giống nhau.
Và riêng năm 2023, Hàn Quốc đã có nhiều sự ưu ái đặc biệt dành cho Việt Nam. Hãy cùng nhìn lại những sự kiện vừa qua để tìm hiểu xe,: Hàn Quốc đang ưu ái Việt Nam như thế nào?</p>

<h3>Các Chaebol sang Việt Nam</h3>

<p>Ngày 23/6/2023, lãnh đạo của các tập đoàn hàng đầu Hàn Quốc xuất hiện tại một sự kiện ở Việt Nam.
205 doanh nghiệp Hàn Quốc, trong đó có các doanh nghiệp hàng đầu thế giới, đã cùng Tổng thống Yoon Suk Yeol đến Việt Nam.
Những chủ tịch của các doanh nghiệp quen thuộc với Việt Nam như Lotte, Samsung, Hyundai, LG... cùng đến Việt Nam, cùng chụp chung một tấm hình là một sự kiện đặc biệt hiếm có.</p>

<center><img src="/upload/images/game/thu-tuong-pham-minh-chinh-chaebol-han-quoc.jpg" width="100%" alt="Thủ tướng Phạm Minh Chính Chaebol Việt Nam">

<p>Thủ tướng Phạm Minh Chính chụp hình cùng các Chaebol lớn nhất Hàn Quốc</p></center>

<p>Hàn Quốc là một trong những đối tác quan trọng hàng đầu của Việt Nam, đứng thứ nhất về đầu tư trực tiếp nước ngoài (FDI) với hơn 9.500 dự án, tổng vốn đầu tư đăng ký gần 82 tỉ USD.</p>

<p>Sự kiện này đánh dấu bước tiến mới trong quan hệ Việt-Hàn, giúp Hàn Quốc thuận lợi hơn trong việc đầu tư phát triển, hợp tác kinh tế với Việt Nam.</p>

<h3>Blackpink lưu diễn ở Việt Nam</h3>

<p>Concert Blackpink ở Việt Nam được thông báo ngay sau sự kiện các Chaebol qua Việt Nam. Ngay khi Blackpink thông báo tổ chức show ở Việt Nam vào cuối tháng 6/2023, thông tin lập tức gây bão.
Thậm chí nhiều nguồn tin cho biết, concert Blackpink không có trong dự kiến của nhóm. Vì vậy, đã có nhiều giả thuyết cho rằng đây là món quà của các Chaebol dành tặng Việt Nam.</p>

<center><img src="/upload/images/game/concert-blackpink-1.jpg" width="100%" alt="Concert Blackpink Việt Nam">

<iframe width="100%" height="350" src="https://www.youtube.com/embed/kvC-L6fkYW0?si=PwPLeZKrnmQiqhQE" title="Concert Blackpink Việt Nam" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p></p></center>

<p>Nhờ có tour lưu diễn, cả Hàn Quốc và Việt Nam đều đạt được rất nhiều lợi ích. Hàn Quốc quảng bá văn hóa, có tiền bán vé, quảng cáo...
Việt Nam phát triển du lịch từ khán giả khắp nơi đổ về Hà Nội, đặc biệt là khán giả Trung Quốc vì nước này không nằm trong lịch trình của nhóm.</p>

<h3>Morgan làm đại sứ du lịch</h3>

<p>Morgan là người chơi Đường Trên Morgan của đội tuyển Liên Minh Huyền Thoại khu vực Hàn Quốc BRION, viết tắt là BRO.</p>

<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/H8fz9TTfLPo?si=JaMfsPA9MCYCNafY" title="Morgan Việt Nam" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br><br>

<p>Lời chào của Morgan</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/RfoTXUS7IhY?si=4So53LvA2fuGYsBv" title="Morgan Việt Nam" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br><br>

<p>BLV Hoàng Luân tại sự kiện Morgan sang Việt Nam</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/MgCbYQWJkHU?si=pk5UkiMIoXP8CMt3" title="Morgan Việt Nam" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe><br><br>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/X5n7z98MMlg?si=8jUqMtxCh2BbF2ZI" title="Morgan Việt Nam" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Vlog Morgan đến Việt Nam trên kênh YouTube đội tuyển BRION</p></center>

<p></p>

<p></p>

<h3>Đội tuyển ASIAD Hàn Quốc mời Việt Nam đấu giao hữu</h3>

<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Y5gaT97uaYo?si=qC7vjoTfS1cqbcOk" title="ASIAD Hàn Quốc Việt Nam 2023" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p><</p></center>

<p></p>

<p></p>

<h3></h3>

<p></p>

<p></p>

<p></p>

<p></p>

<h3></h3>

<p></p>

<p></p>

<p></p>

<p></p>

<p>Nguồn: <a href="" target="_blank" title="tft experience for newbie">Anime News Network</a></p>
',
            'date_post'         => '2023-09-14',
            'thumbnail_post'    => 'han-quoc-dang-uu-ai-viet-nam-nhu-the-nao-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Megan Fox là diễn viên lồng tiếng tệ nhất trong game Mortal Kombat 1',
            'url_post'         => 'megan-fox-is-the-worst-voice-acting-in-mortal-kombat-1',
            'present_vi_post'  => 'Nhân vật của cô là ma cà rồng Nitara',
            'content_vi_post'  => '<p></p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/bkXlFp8pubw?si=Pe6aSlkOUZlUxt6P" title="Megan Fox Nitara Mortal Kombat" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Mortal Kombat 1 | Official Megan Fox Becomes Nitara Trailer</p></center>

<h3></h3>

<p></p>

<p></p>

<p></p>

<p></p>

<h3>Không được như kỳ vọng</h3>

<p>Nguồn: <a href="https://www.gamespot.com/articles/megan-foxs-mortal-kombat-1-performance-isnt-going-over-well/1100-6517807/" target="_blank" title="Megan Fox Nitara Mortal Kombat">Gamespot</a></p>

<p>Việc đưa Megan Fox vào vai Nitara với hy vọng cô có thể hóa thân thành ma cà rồng gợi cảm, cũng như đưa tên tuổi của series game Mortal Kombat càng thêm nổi tiếng. Tuy nhiên, mọi việc có lẽ không như kỳ vọng của đội ngũ sản xuất.</p>

<p>Những người hâm mộ series đã nhanh chóng chỉ ra, diễn xuất của Fox có vẻ mờ nhạt so với các diễn viên còn lại. Trên Twitter, nếu tìm kiếm "Megan Fox Mortal Kombat" sẽ thấy rất nhiều tweet bày tỏ ý kiến về màn trình diễn của Megan Fox.</p>

<center><blockquote class="twitter-tweet"><p lang="en" dir="ltr">nitara is a character in mortal kombat 1. her voice actress, megan fox, did a terrible job delivering lines. they&#39;re all monotonous and have a complete lack of emotion <a href="https://t.co/iqgaTLDMZP">pic.twitter.com/iqgaTLDMZP</a></p>&mdash; rodenr (@rodentgame) <a href="https://twitter.com/rodentgame/status/1704363423671189840?ref_src=twsrc%5Etfw">September 20, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>

<blockquote class="twitter-tweet"><p lang="en" dir="ltr">I just have to say that <a href="https://twitter.com/hashtag/QuanChi?src=hash&amp;ref_src=twsrc%5Etfw">#QuanChi</a> looks sick in this game. Just totally amazing. Literally a younger version from the one a I remember. Great work on detail. They nailed it. Megan Fox looks legit too! <a href="https://twitter.com/hashtag/MK1?src=hash&amp;ref_src=twsrc%5Etfw">#MK1</a> <a href="https://twitter.com/hashtag/MortalKombat1?src=hash&amp;ref_src=twsrc%5Etfw">#MortalKombat1</a> <a href="https://twitter.com/hashtag/MortalKombat?src=hash&amp;ref_src=twsrc%5Etfw">#MortalKombat</a> <a href="https://twitter.com/hashtag/PCShare?src=hash&amp;ref_src=twsrc%5Etfw">#PCShare</a> <a href="https://twitter.com/hashtag/Nitara?src=hash&amp;ref_src=twsrc%5Etfw">#Nitara</a> <a href="https://t.co/25NiYQoLlY">pic.twitter.com/25NiYQoLlY</a></p>&mdash; Paulie 🎮 (@x_xpauliexx_) <a href="https://twitter.com/x_xpauliexx_/status/1703601859456360781?ref_src=twsrc%5Etfw">September 18, 2023</a></blockquote> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script></center>

<p>Những bình luận đánh giá lời thoại của Megan Fox không thể hiện cảm xúc. Dù nhân vật Nitara đang nói chuyện hay đang chiến đấu, giọng của Megan Fox vẫn không thay đổi. Cô giống như học sinh trả bài cho giáo viên vậy.</p>

<p>Vấn đề về diễn xuất của Megan Fox đã tồn tại từ lâu. Sau khi cô thành công với 2 phần phim Transformers, cô đã tham gia nhiều phim khác,
bao gồm cả phim kinh dị như Jennifer&apos;s Body (2009), Till Death (2021). Trong phim Night Teeth (2021), cô cũng đã vào vai ma cà rồng Grace.
Cô cũng đã từng hợp tác với game Diablo IV. Vì vậy, lẽ ra cô phải thể hiện tốt hơn khi vào vai Nitara, cũng là một nữ ma cà rồng gợi cảm.</p>

<center><iframe width="560" height="315" src="https://www.youtube.com/embed/j0bzbmPqvWE?si=MFKQrJS5s8QhM2Yh" title="Megan Fox Diablo IV" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
    
<p>Megan Fox trong game Diablo IV.</p></center>

<p>Đây là một tin xấu khác trong năm 2023 của Megan Fox. Thời điểm trailer ra mắt, bộ phim Expendables 4 đang được công chiếu tại các rạp. Những lời bình luận thất vọng về bộ phim nói chung, về Megan Fox nói riêng xuất hiện ngày càng nhiều.
Khán giả thất vọng về cách Fox diễn xuất khi cô chỉ thể hiện tốt ở những cảnh gợi cảm. Cùng với đoạn cuối tại quán bar, cô không mặc đồ lót. Còn về cách chiến đấu hay cách lãnh đạo nhóm, cô không thể hiện được nhiều.</p>

<p>Dù rất cố gắng, nhưng có lẽ Megan Fox chỉ xuất hiện trong phim như một bóng hồng gợi cảm. Cô được tạo rất nhiều cơ hội, nhưng tất cả đều trôi qua mà không đọng lại gì. Thời huy hoàng của cô có lẽ đã nằm lại ở 2 phần phim Transformers.</p>
',
            'date_post'         => '2023-09-15',
            'thumbnail_post'    => 'megan-fox-is-the-worst-voice-acting-in-mortal-kombat-1-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Koei Tecmo đánh bản quyền họa sĩ vẽ game Dead or Alive',
            'url_post'         => 'koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist',
            'present_vi_post'  => 'Họa sĩ này chuyên vẽ hình rule34',
            'content_vi_post'  => '<p>Studio game Koei Tecmo đã gửi lên DMCA về việc đánh bản quyền một tài khoản mạng xã hội X có tên là lewdgazer. Họa sĩ này đã tạo ra nhiều video 3D có nội dung 18+, dựa trên các nhân vật trong game Dead or Alive.</p>

<p>DMCA, viết tắt của "Digital Millennium Copyright Act", luật bảo vệ bản quyền tác giả. Luật này do tổng thống Mỹ Bill Clinton thông qua và ban hành chính thức từ ngày 28/11/1998. Mục tiêu là nhằm bảo vệ bản quyền của tất cả các sản phẩm công nghệ tránh khỏi việc bị ăn cắp, sao chép, bẻ khóa (crack), kinh doanh sản phẩm công nghệ trái phép...</p>

<p>Twitter: <a href="https://twitter.com/lewdgazer" rel="nofollow" target="_blank" title="Koei Tecmo DMCA Dead or Alive">lewdgazer</a></p>

<p>Tài khoản X và tài khoản Pixiv của lewdgazer đã bị xóa tất cả video, hình ảnh liên quan đến game Dead or Alive.</p>

<center><img src="/upload/images/game/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist-lewdgazer.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br>

<img src="/upload/images/game/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist-lewdgazer-1.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br>

<p>Tweet của họa sĩ lewdgazer đã bị xóa hình</p></center>

<p>Việc công ty game gửi yêu cầu gỡ bỏ theo DMCA không phải là chuyện hiếm. Blizzard đã từng làm điều này vào năm 2021. Mặc dù vậy, việc này xảy ra do sự nhiệt tình quá mức của fan hâm mộ.</p>

<p>Xem thêm: <a href="/post/activision-blizzard-to-dmca-takedown-all-overwatch-porn-in-wake-of-harassment-lawsuit" rel="nofollow" target="_blank" title="Koei Tecmo DMCA Dead or Alive">Activision Blizzard yêu cầu DMCA hủy bỏ tất cả phim khiêu dâm Overwatch trong vụ kiện quấy rối tình dục</a></p>

<p></p>

<p></p>

<center><img src="/upload/images/game/dead-or-alive-helena-douglas-1.jpg" width="100%" alt="Koei Tecmo DMCA Dead or Alive"><br><br></center>

<p></p>

<p></p>

<p>Nguồn: <a href="https://nichegamer.com/koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist/" target="_blank" title="Koei Tecmo DMCA Dead or Alive">Niche Gamer</a></p>
',
            'date_post'         => '2023-10-06',
            'thumbnail_post'    => 'koei-tecmo-allegedly-sends-dmca-takedown-on-dead-or-alive-fan-artist-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);
        
        posts::create([
            'name_vi_post'     => 'Đội tuyển nữ Noot Noot hack trong giải Valorant',
            'url_post'         => 'valorant-game-changers-noot-noot-hack',
            'present_vi_post'  => '',
            'content_vi_post'  => '

<h3></h3>

<p></p>

<p></p>

<p></p>

<p></p>



https://www.oneesports.vn/valorant/valorant-game-changers-hack-giua-giai/
Valorant Game Changers NA Series 3: Hack lộ liễu ngay giữa giải, “nữ pháp sư” và cả đội bị loại ngay lập tức

Lần thứ 2 một đội tuyển nữ thuộc hệ thống Valorant Game Changers bị phát hiện gian lận ngay giữa giải đấu

Mới đây, Noot Noot, một đội nữ đang thi đấu trong hệ thống giải Valorant Game Changers đã bị hủy trận đấu và loại ngay lập tức vì bị phát hiện gian lận.


Thông báo của Riot Games về việc Noot Noot đã gian lận trong giải đấu Valorant Game Changers
Credit: Valorant Esports NA
Cụ thể, trong trận đấu giữa Noot Noot và Complexity GX3 trong khuôn khổ VCT Game Changers Series 3 khu vực NA, một thành viên trong đội hình Noot Noot là Malibu đã có những dấu hiệu vô cùng đáng ngờ khi liên tục có những tình huống xuất thần đến mức khó tin.

https://www.esports.net/news/valorant/valorant-game-changers-noot-noot-disqualified/

<h3>Cáo buộc gian lận gây 2 tiếng trì hoãn</h3>

After a particularly impressive clutch in round 2 that saw Malibu kill 4 members of GX3 in quick succession, the match was paused. What followed was a 2 hour delay. Very little information was given before ultimately, it was announced that Noot Noot was to forfeit the match.

The official decision was announced to fans via Twitter. It confirmed that the team had been found in violation of the Valorant Game Changers Rules and Regulations. This meant that the match was immediately forfeit and the team disqualified.

<p>Những người chơi khác ở Noot Noot đã nhanh chóng khẳng định họ không hề biết bất kỳ hành vi gian lận nào.</p>

Xann even confirmed they only met Malibu 2 weeks before the qualifiers took place and so had no context on the plays Malibu was making.

TEAMS AND PLAYERS REACT – VALORANT GAME CHANGERS CHEATERS
Of course, news of cheating is hardly going to be welcomed by other teams and players in the game. Although the player in question, Malibu, was officially caught by the Riot Anti-Cheat system, the plays were eyebrow raising even to a Valorant novice.

Disguised Toast was among the first to comment after his own Game Changers squad was eliminated at the hands of Noot Noot. No decision has been announced about how this will affect previous games played in the tournament. Although it seems unlikely that any real changes will be made.

<p></p>

<p></p>

',
            'date_post'         => '2023-10-07',
            'thumbnail_post'    => 'valorant-game-changers-noot-noot-hack-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Đài Loan, từ nhà vô địch đến "mất tích" ở Chung Kết Thế Giới 2023',
            'url_post'         => 'taiwan-has-no-teams-in-world-championship-2023',
            'present_vi_post'  => 'Sự kiện chưa từng xảy ra từ năm 2012.',
            'content_vi_post'  => '<p>Liên Minh Huyền Thoại bắt đầu mùa Chung Kết Thế Giới đầu tiên vào năm 2011. Nhà vô địch đầu tiên là Fnatic. Sau đó, năm 2012, Taipei Assassins của Đài Loan vô địch. Từ đó đến nay, Đài Loan luôn có tên trong vòng bảng của CKTG.</p>

<p>Nhưng năm 2023, Riot Games quyết định thể thức thi đấu mới. Với thành tích không có gì thay đổi và số lượng người chơi dần giảm sút, cả 2 đại diện của Đài Loan là PSG Talon và CTBC Flying Oyster đều ở vòng khởi động và phải đấu theo luật nhánh thắng nhánh thua.</p>

<p>Đại diện đầu tiên của Đài Loan bị loại là CFO. Tưởng chừng họ và BDS sẽ là 2 đội góp mặt trong trận chung kết.
Nhưng 2 trận thua bất ngờ của BDS và CFO với Team Whales của VCS đã khiến họ phải gặp nhau sớm. Seed 4 của EU đã đánh bại seed 2 của Đài Loan với tỷ số 2-0.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Zib4wddsnTc?si=iO0JI91hxtsBZvac" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>LLL vs GAM, CFO vs BDS</p></center>

<p>Với quyết tâm phục thù cho đồng hương, PSG Talon đã có trận chung kết vòng khởi động đầy kịch tích với 5 ván đấu. Sau khi dẫn trước 2 trận, BDS đã lội ngược dòng thành công, loại đội tuyển seed 1 Đài Loan khỏi CKTG 2023.</p>

<p>Như vậy, sau 12 năm, CKTG 2023 là giải đấu đầu tiên Đài Loan không có tên trong vòng bảng (nay đổi tên thành vòng Thụy Sĩ). Một kết quả đáng buồn.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/gDj_kOcmT8I?si=_ZCd1AqCwrPoeWQq" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Chung kết vòng khởi động, TW vs GAM, PSG vs BDS</p></center>

<h3>Liệu Đài Loan có bị mất slot?</h3>

<p>Với lượng người chơi dần giảm sút và sự kiện chấn động này, Đài Loan đã phải sát nhập với Đông Nam Á, Hồng Kông và Ma Cao. 4 khu vực này hợp lại thành PCS (Pacific Championship Series)
Kết quả này có thể khiến PCS có nguy cơ bị mất 1 slot. Nhưng câu hỏi đặt ra là: <b>slot đó sẽ được chuyển cho khu vực nào?</b></p>

<p>2 khu vực xứng đáng được nhận slot đó là VCS của Việt Nam và LCS của Bắc Mỹ. Hãy cùng xem xét 2 khu vực này.</p>

<p>Trước khi vòng khởi động diễn ra, Riot đã cho một vòng tên là vòng loại liên khu vực. Tại đây, BDS đã có trận đấu BO5 với Golden Guardians. Đội tuyển đến từ Thụy Sĩ đã chiến thắng áp đảo các Vệ Binh Vàng với tỉ số 3-0. Đường Trên Adam đã tung ra vị tướng Garen và thể hiện rất xuất sắc.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/RCI96pl7qHo?si=SlTmYSh2oyJWisiZ" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>BDS vs GG | CKTG 2023 - VÒNG LOẠI LIÊN KHU VỰC</p></center>

<p>LCS đã nhiều vào vòng tứ kết CKTG nhờ đội tuyển Cloud 9. Thậm chí MSI 2019, Team Liquid đã vào đến trận chung kết với G2 nhưng chỉ giành vị trí á quân.
Nhưng với việc GG bị loại sớm, trong khi VCS có 2 đại diện ở vòng khởi động và 1 đại diện vào vòng Thụy Sĩ, việc tăng slot cho GG chưa chắc là quyết định đúng đắn.</p>

<p>Bản sắc của LCS cũng không có. Trong khi đại kình địch EU có lối chơi độc dị mà hiệu quả, LCK và LPL là bậc thầy kiểm soát trận đấu, hay VCS với lối đánh hổ báo không ngại va chạm, LCS lại sử dụng các ngôi sao hết thời với lối đánh cũ.
Đặc biệt hơn, LCS đã có cuộc đình công vào đầu mùa giải 2023. Nguyên nhân do không chú trọng đào tạo lớp trẻ, chỉ sử dụng ngoại binh Hàn và hình ảnh của các ngôi sao già nua để mang về lợi nhuận.
Chứng tỏ giải đấu này đang có rất nhiều biến động. Việc ưu tiên slot cho LCS là khó có thể xảy ra.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/NeLCjXJT1us?si=rTy4REK_7LLKfkD7" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Drama đình công của LCS</p>

<iframe width="100%" height="350" src="https://www.youtube.com/embed/fUhYK-P5wjQ?si=nubhDqukKfBgD2tV" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>Nguyên nhân sa sút của LCS</p></center>

<p>VCS hiện tại vẫn đảm bảo số lượng người chơi và theo dõi giải đấu. Tuy nhiên, thành tích của họ kể từ năm 2017 đến nay, vẫn chỉ là đứng đầu các đội Wildcard.
Trải qua 5 mùa CKTG, VCS vẫn chỉ dậm chân ở 1 trận thắng tại vòng bảng CKTG. Và với thể thức Thụy Sĩ mới được áp dụng năm 2023, khả năng VCS đánh bại các đội tuyển mạnh trong loạt trận BO3 là rất thấp.</p>

<p>Thậm chí, MSI 2023 vừa qua, VCS đã có thành tích tệ nhất kể từ năm 2017. GAM Esport bất ngờ bị loại chỉ sau 2 trận BO3 với GG và Movistar R7 đến từ Mỹ Latinh. Khán giả tức giận, cho rằng VCS đã quay về với vị trí thấp hơn các đội Wildcard.
Ngay cả trong CKTG 2023, GAM Esport tiếp tục thua LLL, đại diện đến từ Brazil. Những trận thua khó tin trong năm 2023, thành tích không đổi qua 5 năm không thể khiến Riot tăng slot cho VCS.</p>

<p>Vì vậy, khả năng cao nhất mà Riot sẽ áp dụng trong năm sau là: <b>thay đổi đối thủ trong vòng loại liên khu vực.</b> Năm 2023, LCS vs EU. Có thể năm 2024, LCS sẽ đấu với PCS. Đây là cách dễ áp dụng nhất nếu như VCS, PCS hay LCS không cải thiện kết quả trong CKTG 2023 này.</p>
',
            'date_post'         => '2023-10-16',
            'thumbnail_post'    => 'taiwan-has-no-teams-in-world-championship-2023-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'Những đội Wildcard được mệnh danh là "Bố của GAM"',
            'url_post'         => 'wildcard-team-defeat-gam',
            'present_vi_post'  => 'GAM đã gặp "những ông bố" nào trong năm 2023',
            'content_vi_post'  => '

<h3>Movistar Rainbow 7</h3>

<p>Tiền thân là đội Lyon Gaming, sau đó đổi tên thành Rainbow 7 vào năm 2018. Năm 2022, đội đổi tên thành Movistar R7. Người Việt Nam gọi đội tuyển này với tên hài hước hơn là Chị Bảy Cầu Vồng, dựa trên 2 ý nghĩa: R7 gần giống với CR7 - Cristiano Ronaldo và cầu vồng là biểu tượng của phong trào LGBT. Trước đây, đội bao gồm các thành viên đến từ phương Tây như Acce, Josedeodo, Aloned, Leza, Shadow. Sau này, đội tuyển thêm các thành viên Hàn Quốc.</p>

<p>R7 đang là cái tên nổi tiếng nhất trong danh sách "bố của GAM". Chỉ trong năm 2023, GAM đã gặp R7 đến 2 lần, trong 2 trận BO3 quyết định đội bị loại đầu tiên của 2 giải đấu MSI 2023 và CKTG 2023. Và điều bất ngờ đã xảy ra khi R7 chiến thắng GAM với tỷ số 2-1 tại MSI 2023.</p>

<p>Trong đội hình của R7, cái tên nổi tiếng nhất là Đường Giữa Mieru. Xuất thân từ lò đào tạo của T1, Mieru bay nửa vòng Trái Đất đến đất nước Mexico xa xôi, liên tục cùng đội tuyển này vô địch giải quốc nội. Anh cũng được gọi là GAM Mieru vì liên tục có những pha quăng game cực mạnh khi đấu với GAM. Khán giả luôn nhớ pha chết lẻ ở đường trên, để rồi mất luôn cả đường trên trong game 1 MSI 2023. Những vị tướng Mieru mang đến 2 giải đấu là Sylas, Taliyah.</p>

<p>Tuyển thủ Hàn tiếp theo là Đường Trên Bong. Sở trường là những vị tướng chống chịu và đấu sĩ như K’sante, Gragas, Gnar. Tại MSI 2023, vị tướng 200 năm K’sante đã gồng gánh đội R7 lội ngược dòng game 1 trước GAM.</p>

<p>Xạ Thủ CEO đã có màn trình diễn cực kỳ tuyệt vời trước GAM tại MSI 2023. Với vị tướng Xayah, CEO đã có một cú Pentakill tiễn GAM rời giải.</p>

<p></p>

<p></p>

<h3>LOUD</h3>

<p>Khởi đầu là một đội Free Fire, năm 2020, LLL mở rộng sang Fortnite. Đến năm 2021, LLL tham gia CBLOL, giải đấu Liên Minh Huyền Thoại của Brazil. Đội tuyển LLL được người Việt Nam gọi bằng cái tên hài hước là Cù Lao, dựa trên bộ phim Cù Lao Xác Sống.</p>

<p>LLL gặp GAM 2 trận tại CKTG 2023. Trận đấu đầu tiên, LLL bất ngờ thắng GAM 2-0. Màn trình diễn đáng thất vọng của GAM tại MSI 2023 tiếp tục xuất hiện tại CKTG với LLL. Sau đó, LLL thua PSG Talon và phải xuống nhánh thua gặp GAM lần nữa. GAM thắng áp đảo với tỉ số 2-0.</p>

<center><iframe width="100%" height="350" src="https://www.youtube.com/embed/Zib4wddsnTc?si=iO0JI91hxtsBZvac" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

<p>LLL vs GAM, CFO vs BDS</p></center>

<p>Xạ Thủ người Hàn Route là cái tên đầu tiên có được Pentakill tại CKTG 2023. Và trớ trêu thay, đó là trận đấu với GAM. Kai’sa là vị tướng có được Pentakill. Cú Pentakill này tiếp tục xát muối vào nỗi đau cho fan hâm mộ VCS vì trước đó, R7 đã có Pentakill trước GAM ở MSI.</p>

<p>Người Đi Rừng Hàn Quốc Croc</p>

<p>3 vị trí còn lại là người Brazil. Đường Trên Robo là người đã có pha solo với Kiaya của GAM. K’sante đã tận dụng cú Cắt Và Sắt của Renekton để đánh nhau trong trụ và chiến thắng.</p>

<p></p>

<p></p>

<h3>Golden Guardians</h3>

<p>Vệ Binh Vàng, tiền thân là đội bóng rổ nhà nghề Mỹ NBA Golden State Warriors. Tên đội viết tắt là GG, giống từ good game. Nhưng người Việt lại gọi là Google.</p>

<p>Dù GG đến từ khu vực Bắc Mỹ NA, nhưng họ lại là ứng viên yếu nhất của Bắc Mỹ tại MSI 2023 và CKTG 2023. Họ đã đánh bại GAM với tỷ số 2-0. GAM không có được bất kỳ rồng hay Baron nào. Đến CKTG 2023, họ là seed 4 của Bắc Mỹ, phải đánh vòng loại liên khu vực với BDS, seed 4 của khu vực Châu  u EU. Họ đã bị áp đảo với tỷ số 3-0.</p>

<p></p>

<p>Đi Rừng River là tuyển thủ người Hàn. </p>

<p>Tuyển thủ người Hàn thứ 2 là Đường Giữa Gori</p>

<p></p>

<p></p>








<h3></h3>

<p></p>

<p></p>

<p></p>

<p></p>

<p></p>

<p></p>
',
            'date_post'         => '2023-10-18',
            'thumbnail_post'    => 'wildcard-team-defeat-gam-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => ENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => '[Review] Legends of Runeterra - Huyền Thoại Runeterra',
            'url_post'         => 'legends-of-runeterra-huyen-thoai-runeterra',
            'present_vi_post'  => 'Hãy cùng so sánh tựa game thẻ bài của Riot với Hearthstone của Blizzard',
            'content_vi_post'  => '<p></p>

<p></p>

<h3></h3>

<p></p>

<p></p>

<p></p>

<h3>Lượt đi đầu tiên có thể tấn công đối thủ</h3>

<p>Trong các tựa game thẻ bài, lượt đi đầu tiên không được tấn công đối thủ. Tuy nhiên, LoR lại cho phép lượt đi đầu tiên có thể tấn công trực tiếp đối thủ.</p>

<p></p>

<p></p>

<h3></h3>

<p></p>

<p></p>

<p></p>
',
            'date_post'         => '2023-10-31',
            'thumbnail_post'    => 'legends-of-runeterra-huyen-thoai-runeterra-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => UNENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        posts::create([
            'name_vi_post'     => 'NRG hồi sinh LCS hay sự sắp đặt của Riot',
            'url_post'         => 'nrg-hoi-sinh-lcs-hay-su-sap-dat-cua-riot',
            'present_vi_post'  => '',
            'content_vi_post'  => '<p></p>

<p>NRG cũng là đội tuyển hiếm hoi có ít người Hàn. Chỉ có một mình Hỗ Trợ IgNar là người Hàn, các thành viên còn lại là 3 người Mỹ: Đường Trên Dhokla, Đi rừng Contractz, Đường Giữa Palafox.
Xạ Thủ FBI quốc tịch Úc. 2 vị trí dự bị là Damonte và Apollo cũng là người Mỹ. Trong khi đó, Cloud 9 có 3 thành viên Hàn, Team Liquid có 4 thành viên Hàn.</p>

<h3>Drama đình công LCS</h3>

<p></p>

<p></p>

<p></p>

<h3></h3>

<p></p>

<p></p>

<p></p>
',
            'date_post'         => '2023-11-01',
            'thumbnail_post'    => 'nrg-hoi-sinh-lcs-hay-su-sap-dat-cua-riot-thumbnail.jpg',
            'id_cat_post'       => GAME_POST,
            'signature'         => 0,
            'author'            => 'NVHAI',
            'views'             => random_int(50,500),
            'enable'            => UNENABLE,
            'popular'           => 0,
            'update'            => 0,
        ]);

        $eng = new GameEngPosts;
        $eng->index();
    }
}

// https://www.animenewsnetwork.com/news/2023-08-11/corpse-party-horror-game-gets-new-sequel-in-2024/.201200

// https://www.animenewsnetwork.com/news/2023-07-23/anonymous-code-game-streams-system-trailer/.200563

// https://www.animenewsnetwork.com/review/the-devil-is-a-part-timer-season-3/episodes-13-14/.200555

// https://www.animenewsnetwork.com/news/2023-07-23/rune-factory-3-special-remake-game-character-trailer-highlights-bachelorettes/.200561

// https://www.animenewsnetwork.com/news/2023-07-24/the-wrong-way-to-use-healing-magic-anime-reveals-main-cast/.200611

// https://www.animenewsnetwork.com/interest/2023-07-25/voice-actress-singer-minako-kotobuki-announces-marriage/.200610

// https://www.animenewsnetwork.com/news/2023-07-25/horror-manga-creator-junji-ito-receives-comic-con-intl-inkpot-award/.200645

// https://www.animenewsnetwork.com/giveaway/2023-06-18/win-a-trip-to-japan-with-anime-news-network-and-pacset-tours/.198361#winner

// https://www.animenewsnetwork.com/news/2023-07-27/man-arrested-for-allegedly-stalking-22-7-idol-uta-kawase/.200692

// https://www.animenewsnetwork.com/news/2023-07-27/bushiroad-reveals-gift-game-trailers-for-mushoku-tensei-rear-sekai-goblin-slayer-games/.200716

// https://www.animenewsnetwork.com/news/2023-07-27/frontwing-ginka-game-unveils-promo-video-casts-ikumi-hasegawa/.200720

// https://www.animenewsnetwork.com/news/2023-07-26/armored-core-vi-game-unveils-13-minute-gameplay-trailer/.200653

// https://www.animenewsnetwork.com/news/2023-07-26/mari-okada-mappa-maboroshi-anime-film-unveils-miyuki-nakajima-new-song-more-characters-in-trailer/.200687

// https://www.animenewsnetwork.com/news/2023-07-26/armed-girl-machiavellism-creators-launch-new-manga/.200654

// https://www.animenewsnetwork.com/news/2023-07-26/fashion-dreamer-switch-game-trailer-reveals-november-3-release/.200673

// https://www.animenewsnetwork.com/news/2023-06-22/marvelous-unveils-silent-hope-frederica-rpg-for-switch-pc/.199488

// https://techraptor.net/gaming/news/sexy-sci-fi-waifu-sim-subverse-release-date-announced

// https://english.kyodonews.net/news/2022/11/662e85309d21-nintendo-praised-for-new-rules-against-customers-who-harass-staff.html

// https://www.animenewsnetwork.com/news/2023-03-28/yu-gi-oh-cross-duel-smartphone-game-ends-service/.196532
