module.exports = {
    i18n: {
        locales: ['en','vi', 'kr', 'jp'],
        defaultLocale: 'en',
    },
}
