export default {
    home: {
        title: 'SUBSCRIBED YOUTUBE CHANNELS RANKING',
        content: 'Bắt đầu một bài viết nào',
    }
}
