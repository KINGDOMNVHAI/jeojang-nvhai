export default {
    home: {
        title: 'BANG XEP HANG YOUTUBE',
        content: 'Bắt đầu một bài viết nào',
    }
}
