netsh interface ipv4 set dnsservers "Ethernet" static 172.30.9.9 primary
pause