netsh interface ipv4 set dnsservers "Ethernet" static 8.8.8.8 primary
pause